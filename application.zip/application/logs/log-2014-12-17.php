<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-12-17 13:10:06 --> Config Class Initialized
DEBUG - 2014-12-17 13:10:06 --> Hooks Class Initialized
DEBUG - 2014-12-17 13:10:06 --> Utf8 Class Initialized
DEBUG - 2014-12-17 13:10:06 --> UTF-8 Support Enabled
DEBUG - 2014-12-17 13:10:06 --> URI Class Initialized
DEBUG - 2014-12-17 13:10:06 --> Router Class Initialized
DEBUG - 2014-12-17 13:10:06 --> Output Class Initialized
DEBUG - 2014-12-17 13:10:06 --> Security Class Initialized
DEBUG - 2014-12-17 13:10:06 --> Input Class Initialized
DEBUG - 2014-12-17 13:10:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-17 13:10:06 --> Language Class Initialized
DEBUG - 2014-12-17 13:10:06 --> Loader Class Initialized
DEBUG - 2014-12-17 13:10:06 --> Database Driver Class Initialized
ERROR - 2014-12-17 13:10:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-17 13:10:06 --> XML-RPC Class Initialized
DEBUG - 2014-12-17 13:10:06 --> Controller Class Initialized
DEBUG - 2014-12-17 13:10:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-17 13:10:06 --> Helper loaded: inflector_helper
DEBUG - 2014-12-17 13:10:09 --> Model Class Initialized
DEBUG - 2014-12-17 13:10:09 --> Model Class Initialized
DEBUG - 2014-12-17 13:55:34 --> Config Class Initialized
DEBUG - 2014-12-17 13:55:34 --> Hooks Class Initialized
DEBUG - 2014-12-17 13:55:34 --> Utf8 Class Initialized
DEBUG - 2014-12-17 13:55:34 --> UTF-8 Support Enabled
DEBUG - 2014-12-17 13:55:34 --> URI Class Initialized
DEBUG - 2014-12-17 13:55:34 --> Router Class Initialized
DEBUG - 2014-12-17 13:55:34 --> Output Class Initialized
DEBUG - 2014-12-17 13:55:34 --> Security Class Initialized
DEBUG - 2014-12-17 13:55:34 --> Input Class Initialized
DEBUG - 2014-12-17 13:55:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-17 13:55:34 --> Language Class Initialized
DEBUG - 2014-12-17 13:55:34 --> Loader Class Initialized
DEBUG - 2014-12-17 13:55:34 --> Database Driver Class Initialized
ERROR - 2014-12-17 13:55:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-17 13:55:34 --> XML-RPC Class Initialized
DEBUG - 2014-12-17 13:55:34 --> Controller Class Initialized
DEBUG - 2014-12-17 13:55:34 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-17 13:55:34 --> Helper loaded: inflector_helper
DEBUG - 2014-12-17 13:55:35 --> Model Class Initialized
DEBUG - 2014-12-17 13:55:35 --> Model Class Initialized
ERROR - 2014-12-17 13:55:35 --> Severity: Notice  --> Undefined variable: validation /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/controllers/api/users.php 45
ERROR - 2014-12-17 13:55:35 --> Severity: Notice  --> Undefined variable: validation /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/controllers/api/users.php 51
ERROR - 2014-12-17 13:55:35 --> Severity: Notice  --> Undefined variable: validation /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/controllers/api/users.php 56
ERROR - 2014-12-17 13:55:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/libraries/REST_Controller.php 485
ERROR - 2014-12-17 13:55:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Common.php 442
ERROR - 2014-12-17 13:55:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/libraries/REST_Controller.php 503
DEBUG - 2014-12-17 13:56:08 --> Config Class Initialized
DEBUG - 2014-12-17 13:56:08 --> Hooks Class Initialized
DEBUG - 2014-12-17 13:56:08 --> Utf8 Class Initialized
DEBUG - 2014-12-17 13:56:08 --> UTF-8 Support Enabled
DEBUG - 2014-12-17 13:56:08 --> URI Class Initialized
DEBUG - 2014-12-17 13:56:08 --> Router Class Initialized
DEBUG - 2014-12-17 13:56:08 --> Output Class Initialized
DEBUG - 2014-12-17 13:56:08 --> Security Class Initialized
DEBUG - 2014-12-17 13:56:08 --> Input Class Initialized
DEBUG - 2014-12-17 13:56:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-17 13:56:08 --> Language Class Initialized
DEBUG - 2014-12-17 13:56:08 --> Loader Class Initialized
DEBUG - 2014-12-17 13:56:08 --> Database Driver Class Initialized
ERROR - 2014-12-17 13:56:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-17 13:56:08 --> XML-RPC Class Initialized
DEBUG - 2014-12-17 13:56:08 --> Controller Class Initialized
DEBUG - 2014-12-17 13:56:08 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-17 13:56:08 --> Helper loaded: inflector_helper
DEBUG - 2014-12-17 13:56:10 --> Model Class Initialized
DEBUG - 2014-12-17 13:56:10 --> Model Class Initialized
DEBUG - 2014-12-17 13:56:24 --> Config Class Initialized
DEBUG - 2014-12-17 13:56:24 --> Hooks Class Initialized
DEBUG - 2014-12-17 13:56:24 --> Utf8 Class Initialized
DEBUG - 2014-12-17 13:56:24 --> UTF-8 Support Enabled
DEBUG - 2014-12-17 13:56:24 --> URI Class Initialized
DEBUG - 2014-12-17 13:56:24 --> Router Class Initialized
DEBUG - 2014-12-17 13:56:24 --> Output Class Initialized
DEBUG - 2014-12-17 13:56:24 --> Security Class Initialized
DEBUG - 2014-12-17 13:56:24 --> Input Class Initialized
DEBUG - 2014-12-17 13:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-17 13:56:24 --> Language Class Initialized
DEBUG - 2014-12-17 13:56:24 --> Loader Class Initialized
DEBUG - 2014-12-17 13:56:24 --> Database Driver Class Initialized
ERROR - 2014-12-17 13:56:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-17 13:56:24 --> XML-RPC Class Initialized
DEBUG - 2014-12-17 13:56:24 --> Controller Class Initialized
DEBUG - 2014-12-17 13:56:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-17 13:56:24 --> Helper loaded: inflector_helper
DEBUG - 2014-12-17 13:56:26 --> Model Class Initialized
DEBUG - 2014-12-17 13:56:26 --> Model Class Initialized
DEBUG - 2014-12-17 13:57:22 --> Config Class Initialized
DEBUG - 2014-12-17 13:57:22 --> Hooks Class Initialized
DEBUG - 2014-12-17 13:57:22 --> Utf8 Class Initialized
DEBUG - 2014-12-17 13:57:22 --> UTF-8 Support Enabled
DEBUG - 2014-12-17 13:57:22 --> URI Class Initialized
DEBUG - 2014-12-17 13:57:22 --> Router Class Initialized
DEBUG - 2014-12-17 13:57:22 --> Output Class Initialized
DEBUG - 2014-12-17 13:57:22 --> Security Class Initialized
DEBUG - 2014-12-17 13:57:22 --> Input Class Initialized
DEBUG - 2014-12-17 13:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-17 13:57:22 --> Language Class Initialized
DEBUG - 2014-12-17 13:57:22 --> Loader Class Initialized
DEBUG - 2014-12-17 13:57:22 --> Database Driver Class Initialized
ERROR - 2014-12-17 13:57:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-17 13:57:22 --> XML-RPC Class Initialized
DEBUG - 2014-12-17 13:57:22 --> Controller Class Initialized
DEBUG - 2014-12-17 13:57:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-17 13:57:22 --> Helper loaded: inflector_helper
DEBUG - 2014-12-17 13:57:24 --> Model Class Initialized
DEBUG - 2014-12-17 13:57:24 --> Model Class Initialized
DEBUG - 2014-12-17 13:57:24 --> Final output sent to browser
DEBUG - 2014-12-17 13:57:24 --> Total execution time: 2.6943
DEBUG - 2014-12-17 13:59:16 --> Config Class Initialized
DEBUG - 2014-12-17 13:59:16 --> Hooks Class Initialized
DEBUG - 2014-12-17 13:59:16 --> Utf8 Class Initialized
DEBUG - 2014-12-17 13:59:16 --> UTF-8 Support Enabled
DEBUG - 2014-12-17 13:59:16 --> URI Class Initialized
DEBUG - 2014-12-17 13:59:16 --> Router Class Initialized
DEBUG - 2014-12-17 13:59:16 --> Output Class Initialized
DEBUG - 2014-12-17 13:59:16 --> Security Class Initialized
DEBUG - 2014-12-17 13:59:16 --> Input Class Initialized
DEBUG - 2014-12-17 13:59:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-17 13:59:16 --> Language Class Initialized
DEBUG - 2014-12-17 13:59:16 --> Loader Class Initialized
DEBUG - 2014-12-17 13:59:16 --> Database Driver Class Initialized
ERROR - 2014-12-17 13:59:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-17 13:59:16 --> XML-RPC Class Initialized
DEBUG - 2014-12-17 13:59:16 --> Controller Class Initialized
DEBUG - 2014-12-17 13:59:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-17 13:59:16 --> Helper loaded: inflector_helper
DEBUG - 2014-12-17 13:59:18 --> Model Class Initialized
DEBUG - 2014-12-17 13:59:18 --> Model Class Initialized
ERROR - 2014-12-17 13:59:18 --> Severity: Notice  --> Array to string conversion /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/controllers/api/users.php 64
DEBUG - 2014-12-17 13:59:18 --> Final output sent to browser
DEBUG - 2014-12-17 13:59:18 --> Total execution time: 1.5691
DEBUG - 2014-12-17 13:59:31 --> Config Class Initialized
DEBUG - 2014-12-17 13:59:31 --> Hooks Class Initialized
DEBUG - 2014-12-17 13:59:31 --> Utf8 Class Initialized
DEBUG - 2014-12-17 13:59:31 --> UTF-8 Support Enabled
DEBUG - 2014-12-17 13:59:31 --> URI Class Initialized
DEBUG - 2014-12-17 13:59:31 --> Router Class Initialized
DEBUG - 2014-12-17 13:59:31 --> Output Class Initialized
DEBUG - 2014-12-17 13:59:31 --> Security Class Initialized
DEBUG - 2014-12-17 13:59:31 --> Input Class Initialized
DEBUG - 2014-12-17 13:59:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-17 13:59:31 --> Language Class Initialized
DEBUG - 2014-12-17 13:59:31 --> Loader Class Initialized
DEBUG - 2014-12-17 13:59:31 --> Database Driver Class Initialized
ERROR - 2014-12-17 13:59:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-17 13:59:31 --> XML-RPC Class Initialized
DEBUG - 2014-12-17 13:59:31 --> Controller Class Initialized
DEBUG - 2014-12-17 13:59:31 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-17 13:59:31 --> Helper loaded: inflector_helper
DEBUG - 2014-12-17 13:59:33 --> Model Class Initialized
DEBUG - 2014-12-17 13:59:33 --> Model Class Initialized
DEBUG - 2014-12-17 13:59:33 --> Final output sent to browser
DEBUG - 2014-12-17 13:59:33 --> Total execution time: 1.5357
DEBUG - 2014-12-17 13:59:42 --> Config Class Initialized
DEBUG - 2014-12-17 13:59:42 --> Hooks Class Initialized
DEBUG - 2014-12-17 13:59:42 --> Utf8 Class Initialized
DEBUG - 2014-12-17 13:59:42 --> UTF-8 Support Enabled
DEBUG - 2014-12-17 13:59:42 --> URI Class Initialized
DEBUG - 2014-12-17 13:59:42 --> Router Class Initialized
DEBUG - 2014-12-17 13:59:42 --> Output Class Initialized
DEBUG - 2014-12-17 13:59:42 --> Security Class Initialized
DEBUG - 2014-12-17 13:59:42 --> Input Class Initialized
DEBUG - 2014-12-17 13:59:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-17 13:59:42 --> Language Class Initialized
DEBUG - 2014-12-17 13:59:42 --> Loader Class Initialized
DEBUG - 2014-12-17 13:59:42 --> Database Driver Class Initialized
ERROR - 2014-12-17 13:59:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-17 13:59:42 --> XML-RPC Class Initialized
DEBUG - 2014-12-17 13:59:42 --> Controller Class Initialized
DEBUG - 2014-12-17 13:59:42 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-17 13:59:42 --> Helper loaded: inflector_helper
DEBUG - 2014-12-17 13:59:43 --> Model Class Initialized
DEBUG - 2014-12-17 13:59:43 --> Model Class Initialized
DEBUG - 2014-12-17 13:59:43 --> Final output sent to browser
DEBUG - 2014-12-17 13:59:43 --> Total execution time: 1.7233
DEBUG - 2014-12-17 14:00:01 --> Config Class Initialized
DEBUG - 2014-12-17 14:00:01 --> Hooks Class Initialized
DEBUG - 2014-12-17 14:00:01 --> Utf8 Class Initialized
DEBUG - 2014-12-17 14:00:01 --> UTF-8 Support Enabled
DEBUG - 2014-12-17 14:00:01 --> URI Class Initialized
DEBUG - 2014-12-17 14:00:01 --> Router Class Initialized
DEBUG - 2014-12-17 14:00:01 --> Output Class Initialized
DEBUG - 2014-12-17 14:00:01 --> Security Class Initialized
DEBUG - 2014-12-17 14:00:01 --> Input Class Initialized
DEBUG - 2014-12-17 14:00:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-17 14:00:01 --> Language Class Initialized
DEBUG - 2014-12-17 14:00:01 --> Loader Class Initialized
DEBUG - 2014-12-17 14:00:01 --> Database Driver Class Initialized
ERROR - 2014-12-17 14:00:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-17 14:00:01 --> XML-RPC Class Initialized
DEBUG - 2014-12-17 14:00:01 --> Controller Class Initialized
DEBUG - 2014-12-17 14:00:01 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-17 14:00:01 --> Helper loaded: inflector_helper
DEBUG - 2014-12-17 14:00:02 --> Model Class Initialized
DEBUG - 2014-12-17 14:00:02 --> Model Class Initialized
DEBUG - 2014-12-17 14:00:02 --> Final output sent to browser
DEBUG - 2014-12-17 14:00:02 --> Total execution time: 1.5899
DEBUG - 2014-12-17 14:01:07 --> Config Class Initialized
DEBUG - 2014-12-17 14:01:07 --> Hooks Class Initialized
DEBUG - 2014-12-17 14:01:07 --> Utf8 Class Initialized
DEBUG - 2014-12-17 14:01:07 --> UTF-8 Support Enabled
DEBUG - 2014-12-17 14:01:07 --> URI Class Initialized
DEBUG - 2014-12-17 14:01:07 --> Router Class Initialized
DEBUG - 2014-12-17 14:01:07 --> Output Class Initialized
DEBUG - 2014-12-17 14:01:07 --> Security Class Initialized
DEBUG - 2014-12-17 14:01:07 --> Input Class Initialized
DEBUG - 2014-12-17 14:01:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-17 14:01:07 --> Language Class Initialized
DEBUG - 2014-12-17 14:01:07 --> Loader Class Initialized
DEBUG - 2014-12-17 14:01:07 --> Database Driver Class Initialized
ERROR - 2014-12-17 14:01:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-17 14:01:07 --> XML-RPC Class Initialized
DEBUG - 2014-12-17 14:01:07 --> Controller Class Initialized
DEBUG - 2014-12-17 14:01:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-17 14:01:07 --> Helper loaded: inflector_helper
DEBUG - 2014-12-17 14:01:09 --> Model Class Initialized
DEBUG - 2014-12-17 14:01:09 --> Model Class Initialized
DEBUG - 2014-12-17 14:01:09 --> Final output sent to browser
DEBUG - 2014-12-17 14:01:09 --> Total execution time: 1.5959
DEBUG - 2014-12-17 14:01:26 --> Config Class Initialized
DEBUG - 2014-12-17 14:01:26 --> Hooks Class Initialized
DEBUG - 2014-12-17 14:01:26 --> Utf8 Class Initialized
DEBUG - 2014-12-17 14:01:26 --> UTF-8 Support Enabled
DEBUG - 2014-12-17 14:01:26 --> URI Class Initialized
DEBUG - 2014-12-17 14:01:26 --> Router Class Initialized
DEBUG - 2014-12-17 14:01:26 --> Output Class Initialized
DEBUG - 2014-12-17 14:01:26 --> Security Class Initialized
DEBUG - 2014-12-17 14:01:26 --> Input Class Initialized
DEBUG - 2014-12-17 14:01:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-17 14:01:26 --> Language Class Initialized
DEBUG - 2014-12-17 14:01:26 --> Loader Class Initialized
DEBUG - 2014-12-17 14:01:26 --> Database Driver Class Initialized
ERROR - 2014-12-17 14:01:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-17 14:01:26 --> XML-RPC Class Initialized
DEBUG - 2014-12-17 14:01:26 --> Controller Class Initialized
DEBUG - 2014-12-17 14:01:26 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-17 14:01:26 --> Helper loaded: inflector_helper
DEBUG - 2014-12-17 14:01:28 --> Model Class Initialized
DEBUG - 2014-12-17 14:01:28 --> Model Class Initialized
DEBUG - 2014-12-17 14:02:43 --> Config Class Initialized
DEBUG - 2014-12-17 14:02:43 --> Hooks Class Initialized
DEBUG - 2014-12-17 14:02:43 --> Utf8 Class Initialized
DEBUG - 2014-12-17 14:02:43 --> UTF-8 Support Enabled
DEBUG - 2014-12-17 14:02:43 --> URI Class Initialized
DEBUG - 2014-12-17 14:02:43 --> Router Class Initialized
DEBUG - 2014-12-17 14:02:43 --> Output Class Initialized
DEBUG - 2014-12-17 14:02:43 --> Security Class Initialized
DEBUG - 2014-12-17 14:02:43 --> Input Class Initialized
DEBUG - 2014-12-17 14:02:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-17 14:02:43 --> Language Class Initialized
DEBUG - 2014-12-17 14:02:43 --> Loader Class Initialized
DEBUG - 2014-12-17 14:02:43 --> Database Driver Class Initialized
ERROR - 2014-12-17 14:02:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-17 14:02:43 --> XML-RPC Class Initialized
DEBUG - 2014-12-17 14:02:43 --> Controller Class Initialized
DEBUG - 2014-12-17 14:02:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-17 14:02:43 --> Helper loaded: inflector_helper
DEBUG - 2014-12-17 14:02:45 --> Model Class Initialized
DEBUG - 2014-12-17 14:02:45 --> Model Class Initialized
DEBUG - 2014-12-17 14:03:24 --> Config Class Initialized
DEBUG - 2014-12-17 14:03:24 --> Hooks Class Initialized
DEBUG - 2014-12-17 14:03:24 --> Utf8 Class Initialized
DEBUG - 2014-12-17 14:03:24 --> UTF-8 Support Enabled
DEBUG - 2014-12-17 14:03:24 --> URI Class Initialized
DEBUG - 2014-12-17 14:03:24 --> Router Class Initialized
DEBUG - 2014-12-17 14:03:24 --> Output Class Initialized
DEBUG - 2014-12-17 14:03:24 --> Security Class Initialized
DEBUG - 2014-12-17 14:03:24 --> Input Class Initialized
DEBUG - 2014-12-17 14:03:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-17 14:03:24 --> Language Class Initialized
DEBUG - 2014-12-17 14:03:24 --> Loader Class Initialized
DEBUG - 2014-12-17 14:03:24 --> Database Driver Class Initialized
ERROR - 2014-12-17 14:03:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-17 14:03:24 --> XML-RPC Class Initialized
DEBUG - 2014-12-17 14:03:24 --> Controller Class Initialized
DEBUG - 2014-12-17 14:03:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-17 14:03:24 --> Helper loaded: inflector_helper
DEBUG - 2014-12-17 14:03:26 --> Model Class Initialized
DEBUG - 2014-12-17 14:03:26 --> Model Class Initialized
ERROR - 2014-12-17 14:03:26 --> Severity: Notice  --> Undefined variable: sugarcrm_id /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/models/users_model.php 22
DEBUG - 2014-12-17 14:03:26 --> DB Transaction Failure
ERROR - 2014-12-17 14:03:26 --> Query error: Column 'sugarcrm_id' cannot be null
DEBUG - 2014-12-17 14:03:26 --> Language file loaded: language/english/db_lang.php
ERROR - 2014-12-17 14:03:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Common.php 442
DEBUG - 2014-12-17 14:04:38 --> Config Class Initialized
DEBUG - 2014-12-17 14:04:38 --> Hooks Class Initialized
DEBUG - 2014-12-17 14:04:38 --> Utf8 Class Initialized
DEBUG - 2014-12-17 14:04:38 --> UTF-8 Support Enabled
DEBUG - 2014-12-17 14:04:38 --> URI Class Initialized
DEBUG - 2014-12-17 14:04:38 --> Router Class Initialized
DEBUG - 2014-12-17 14:04:38 --> Output Class Initialized
DEBUG - 2014-12-17 14:04:38 --> Security Class Initialized
DEBUG - 2014-12-17 14:04:38 --> Input Class Initialized
DEBUG - 2014-12-17 14:04:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-17 14:04:38 --> Language Class Initialized
DEBUG - 2014-12-17 14:04:38 --> Loader Class Initialized
DEBUG - 2014-12-17 14:04:38 --> Database Driver Class Initialized
ERROR - 2014-12-17 14:04:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-17 14:04:38 --> XML-RPC Class Initialized
DEBUG - 2014-12-17 14:04:38 --> Controller Class Initialized
DEBUG - 2014-12-17 14:04:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-17 14:04:38 --> Helper loaded: inflector_helper
DEBUG - 2014-12-17 14:04:40 --> Model Class Initialized
DEBUG - 2014-12-17 14:04:40 --> Model Class Initialized
DEBUG - 2014-12-17 14:04:40 --> Final output sent to browser
DEBUG - 2014-12-17 14:04:40 --> Total execution time: 2.1188
