<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-12-18 10:08:33 --> Config Class Initialized
DEBUG - 2014-12-18 10:08:33 --> Hooks Class Initialized
DEBUG - 2014-12-18 10:08:33 --> Utf8 Class Initialized
DEBUG - 2014-12-18 10:08:33 --> UTF-8 Support Enabled
DEBUG - 2014-12-18 10:08:33 --> URI Class Initialized
DEBUG - 2014-12-18 10:08:33 --> Router Class Initialized
DEBUG - 2014-12-18 10:08:33 --> Output Class Initialized
DEBUG - 2014-12-18 10:08:33 --> Security Class Initialized
DEBUG - 2014-12-18 10:08:33 --> Input Class Initialized
DEBUG - 2014-12-18 10:08:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-18 10:08:33 --> Language Class Initialized
DEBUG - 2014-12-18 10:08:33 --> Loader Class Initialized
DEBUG - 2014-12-18 10:08:33 --> Database Driver Class Initialized
ERROR - 2014-12-18 10:08:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-18 10:08:33 --> XML-RPC Class Initialized
DEBUG - 2014-12-18 10:08:33 --> Controller Class Initialized
DEBUG - 2014-12-18 10:08:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-18 10:08:33 --> Helper loaded: inflector_helper
DEBUG - 2014-12-18 10:08:35 --> Model Class Initialized
DEBUG - 2014-12-18 10:08:36 --> Model Class Initialized
DEBUG - 2014-12-18 11:38:49 --> Config Class Initialized
DEBUG - 2014-12-18 11:38:49 --> Hooks Class Initialized
DEBUG - 2014-12-18 11:38:49 --> Utf8 Class Initialized
DEBUG - 2014-12-18 11:38:49 --> UTF-8 Support Enabled
DEBUG - 2014-12-18 11:38:49 --> URI Class Initialized
DEBUG - 2014-12-18 11:38:49 --> Router Class Initialized
DEBUG - 2014-12-18 11:38:49 --> Output Class Initialized
DEBUG - 2014-12-18 11:38:49 --> Security Class Initialized
DEBUG - 2014-12-18 11:38:49 --> Input Class Initialized
DEBUG - 2014-12-18 11:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-18 11:38:49 --> Language Class Initialized
DEBUG - 2014-12-18 11:38:49 --> Loader Class Initialized
DEBUG - 2014-12-18 11:38:49 --> Database Driver Class Initialized
ERROR - 2014-12-18 11:38:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-18 11:38:49 --> XML-RPC Class Initialized
DEBUG - 2014-12-18 11:38:49 --> Controller Class Initialized
DEBUG - 2014-12-18 11:38:49 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-18 11:38:49 --> Helper loaded: inflector_helper
DEBUG - 2014-12-18 11:38:51 --> Model Class Initialized
DEBUG - 2014-12-18 11:38:51 --> Model Class Initialized
DEBUG - 2014-12-18 13:15:42 --> Config Class Initialized
DEBUG - 2014-12-18 13:15:42 --> Hooks Class Initialized
DEBUG - 2014-12-18 13:15:42 --> Utf8 Class Initialized
DEBUG - 2014-12-18 13:15:42 --> UTF-8 Support Enabled
DEBUG - 2014-12-18 13:15:42 --> URI Class Initialized
DEBUG - 2014-12-18 13:15:42 --> Router Class Initialized
DEBUG - 2014-12-18 13:15:42 --> Output Class Initialized
DEBUG - 2014-12-18 13:15:42 --> Security Class Initialized
DEBUG - 2014-12-18 13:15:42 --> Input Class Initialized
DEBUG - 2014-12-18 13:15:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-18 13:15:42 --> Language Class Initialized
DEBUG - 2014-12-18 13:15:43 --> Loader Class Initialized
DEBUG - 2014-12-18 13:15:43 --> Database Driver Class Initialized
ERROR - 2014-12-18 13:15:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-18 13:15:43 --> XML-RPC Class Initialized
DEBUG - 2014-12-18 13:15:43 --> Controller Class Initialized
DEBUG - 2014-12-18 13:15:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-18 13:15:43 --> Helper loaded: inflector_helper
DEBUG - 2014-12-18 13:15:45 --> Model Class Initialized
DEBUG - 2014-12-18 13:15:45 --> Model Class Initialized
DEBUG - 2014-12-18 13:15:51 --> Config Class Initialized
DEBUG - 2014-12-18 13:15:51 --> Hooks Class Initialized
DEBUG - 2014-12-18 13:15:51 --> Utf8 Class Initialized
DEBUG - 2014-12-18 13:15:51 --> UTF-8 Support Enabled
DEBUG - 2014-12-18 13:15:51 --> URI Class Initialized
DEBUG - 2014-12-18 13:15:51 --> Router Class Initialized
DEBUG - 2014-12-18 13:15:51 --> Output Class Initialized
DEBUG - 2014-12-18 13:15:51 --> Security Class Initialized
DEBUG - 2014-12-18 13:15:51 --> Input Class Initialized
DEBUG - 2014-12-18 13:15:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-18 13:15:51 --> Language Class Initialized
DEBUG - 2014-12-18 13:15:51 --> Loader Class Initialized
DEBUG - 2014-12-18 13:15:51 --> Database Driver Class Initialized
ERROR - 2014-12-18 13:15:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-18 13:15:51 --> XML-RPC Class Initialized
DEBUG - 2014-12-18 13:15:51 --> Controller Class Initialized
DEBUG - 2014-12-18 13:15:51 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-18 13:15:51 --> Helper loaded: inflector_helper
DEBUG - 2014-12-18 13:15:53 --> Model Class Initialized
DEBUG - 2014-12-18 13:15:53 --> Model Class Initialized
DEBUG - 2014-12-18 13:16:31 --> Config Class Initialized
DEBUG - 2014-12-18 13:16:31 --> Hooks Class Initialized
DEBUG - 2014-12-18 13:16:31 --> Utf8 Class Initialized
DEBUG - 2014-12-18 13:16:31 --> UTF-8 Support Enabled
DEBUG - 2014-12-18 13:16:31 --> URI Class Initialized
DEBUG - 2014-12-18 13:16:31 --> Router Class Initialized
DEBUG - 2014-12-18 13:16:31 --> Output Class Initialized
DEBUG - 2014-12-18 13:16:31 --> Security Class Initialized
DEBUG - 2014-12-18 13:16:31 --> Input Class Initialized
DEBUG - 2014-12-18 13:16:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-18 13:16:31 --> Language Class Initialized
DEBUG - 2014-12-18 13:16:31 --> Loader Class Initialized
DEBUG - 2014-12-18 13:16:31 --> Database Driver Class Initialized
ERROR - 2014-12-18 13:16:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-18 13:16:31 --> XML-RPC Class Initialized
DEBUG - 2014-12-18 13:16:31 --> Controller Class Initialized
DEBUG - 2014-12-18 13:16:31 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-18 13:16:31 --> Helper loaded: inflector_helper
DEBUG - 2014-12-18 13:16:33 --> Model Class Initialized
DEBUG - 2014-12-18 13:16:33 --> Model Class Initialized
ERROR - 2014-12-18 13:16:33 --> Severity: Notice  --> Array to string conversion /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/controllers/api/users.php 181
ERROR - 2014-12-18 13:16:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/libraries/REST_Controller.php 485
ERROR - 2014-12-18 13:16:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Common.php 442
ERROR - 2014-12-18 13:16:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/libraries/REST_Controller.php 503
DEBUG - 2014-12-18 13:17:07 --> Config Class Initialized
DEBUG - 2014-12-18 13:17:07 --> Hooks Class Initialized
DEBUG - 2014-12-18 13:17:07 --> Utf8 Class Initialized
DEBUG - 2014-12-18 13:17:07 --> UTF-8 Support Enabled
DEBUG - 2014-12-18 13:17:07 --> URI Class Initialized
DEBUG - 2014-12-18 13:17:07 --> Router Class Initialized
DEBUG - 2014-12-18 13:17:07 --> Output Class Initialized
DEBUG - 2014-12-18 13:17:07 --> Security Class Initialized
DEBUG - 2014-12-18 13:17:07 --> Input Class Initialized
DEBUG - 2014-12-18 13:17:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-18 13:17:07 --> Language Class Initialized
DEBUG - 2014-12-18 13:17:07 --> Loader Class Initialized
DEBUG - 2014-12-18 13:17:07 --> Database Driver Class Initialized
ERROR - 2014-12-18 13:17:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-18 13:17:07 --> XML-RPC Class Initialized
DEBUG - 2014-12-18 13:17:07 --> Controller Class Initialized
DEBUG - 2014-12-18 13:17:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-18 13:17:07 --> Helper loaded: inflector_helper
DEBUG - 2014-12-18 13:17:08 --> Model Class Initialized
DEBUG - 2014-12-18 13:17:08 --> Model Class Initialized
DEBUG - 2014-12-18 13:22:21 --> Config Class Initialized
DEBUG - 2014-12-18 13:22:21 --> Hooks Class Initialized
DEBUG - 2014-12-18 13:22:21 --> Utf8 Class Initialized
DEBUG - 2014-12-18 13:22:21 --> UTF-8 Support Enabled
DEBUG - 2014-12-18 13:22:21 --> URI Class Initialized
DEBUG - 2014-12-18 13:22:21 --> Router Class Initialized
DEBUG - 2014-12-18 13:22:21 --> Output Class Initialized
DEBUG - 2014-12-18 13:22:21 --> Security Class Initialized
DEBUG - 2014-12-18 13:22:21 --> Input Class Initialized
DEBUG - 2014-12-18 13:22:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-18 13:22:21 --> Language Class Initialized
DEBUG - 2014-12-18 13:22:21 --> Loader Class Initialized
DEBUG - 2014-12-18 13:22:21 --> Database Driver Class Initialized
ERROR - 2014-12-18 13:22:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-18 13:22:21 --> XML-RPC Class Initialized
DEBUG - 2014-12-18 13:22:21 --> Controller Class Initialized
DEBUG - 2014-12-18 13:22:21 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-18 13:22:21 --> Helper loaded: inflector_helper
DEBUG - 2014-12-18 13:22:22 --> Model Class Initialized
DEBUG - 2014-12-18 13:22:22 --> Model Class Initialized
DEBUG - 2014-12-18 13:22:54 --> Config Class Initialized
DEBUG - 2014-12-18 13:22:54 --> Hooks Class Initialized
DEBUG - 2014-12-18 13:22:54 --> Utf8 Class Initialized
DEBUG - 2014-12-18 13:22:54 --> UTF-8 Support Enabled
DEBUG - 2014-12-18 13:22:54 --> URI Class Initialized
DEBUG - 2014-12-18 13:22:54 --> Router Class Initialized
DEBUG - 2014-12-18 13:22:54 --> Output Class Initialized
DEBUG - 2014-12-18 13:22:54 --> Security Class Initialized
DEBUG - 2014-12-18 13:22:54 --> Input Class Initialized
DEBUG - 2014-12-18 13:22:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-18 13:22:54 --> Language Class Initialized
DEBUG - 2014-12-18 13:22:54 --> Loader Class Initialized
DEBUG - 2014-12-18 13:22:54 --> Database Driver Class Initialized
ERROR - 2014-12-18 13:22:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-18 13:22:54 --> XML-RPC Class Initialized
DEBUG - 2014-12-18 13:22:54 --> Controller Class Initialized
DEBUG - 2014-12-18 13:22:54 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-18 13:22:54 --> Helper loaded: inflector_helper
DEBUG - 2014-12-18 13:22:56 --> Model Class Initialized
DEBUG - 2014-12-18 13:22:56 --> Model Class Initialized
DEBUG - 2014-12-18 13:50:37 --> Config Class Initialized
DEBUG - 2014-12-18 13:50:37 --> Hooks Class Initialized
DEBUG - 2014-12-18 13:50:37 --> Utf8 Class Initialized
DEBUG - 2014-12-18 13:50:37 --> UTF-8 Support Enabled
DEBUG - 2014-12-18 13:50:37 --> URI Class Initialized
DEBUG - 2014-12-18 13:50:37 --> Router Class Initialized
DEBUG - 2014-12-18 13:50:38 --> Output Class Initialized
DEBUG - 2014-12-18 13:50:38 --> Security Class Initialized
DEBUG - 2014-12-18 13:50:38 --> Input Class Initialized
DEBUG - 2014-12-18 13:50:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-18 13:50:38 --> Language Class Initialized
DEBUG - 2014-12-18 13:50:38 --> Loader Class Initialized
DEBUG - 2014-12-18 13:50:38 --> Database Driver Class Initialized
ERROR - 2014-12-18 13:50:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-12-18 13:50:38 --> Severity: Warning  --> mysql_pconnect(): Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-12-18 13:50:38 --> Unable to connect to the database
DEBUG - 2014-12-18 13:50:38 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-18 13:50:49 --> Config Class Initialized
DEBUG - 2014-12-18 13:50:49 --> Hooks Class Initialized
DEBUG - 2014-12-18 13:50:49 --> Utf8 Class Initialized
DEBUG - 2014-12-18 13:50:49 --> UTF-8 Support Enabled
DEBUG - 2014-12-18 13:50:49 --> URI Class Initialized
DEBUG - 2014-12-18 13:50:49 --> Router Class Initialized
DEBUG - 2014-12-18 13:50:49 --> Output Class Initialized
DEBUG - 2014-12-18 13:50:49 --> Security Class Initialized
DEBUG - 2014-12-18 13:50:49 --> Input Class Initialized
DEBUG - 2014-12-18 13:50:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-18 13:50:49 --> Language Class Initialized
DEBUG - 2014-12-18 13:50:49 --> Loader Class Initialized
DEBUG - 2014-12-18 13:50:49 --> Database Driver Class Initialized
ERROR - 2014-12-18 13:50:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-12-18 13:50:49 --> Severity: Warning  --> mysql_pconnect(): Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-12-18 13:50:49 --> Unable to connect to the database
DEBUG - 2014-12-18 13:50:49 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-18 13:50:59 --> Config Class Initialized
DEBUG - 2014-12-18 13:50:59 --> Hooks Class Initialized
DEBUG - 2014-12-18 13:50:59 --> Utf8 Class Initialized
DEBUG - 2014-12-18 13:50:59 --> UTF-8 Support Enabled
DEBUG - 2014-12-18 13:50:59 --> URI Class Initialized
DEBUG - 2014-12-18 13:50:59 --> Router Class Initialized
DEBUG - 2014-12-18 13:50:59 --> Output Class Initialized
DEBUG - 2014-12-18 13:50:59 --> Security Class Initialized
DEBUG - 2014-12-18 13:50:59 --> Input Class Initialized
DEBUG - 2014-12-18 13:50:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-18 13:50:59 --> Language Class Initialized
DEBUG - 2014-12-18 13:50:59 --> Loader Class Initialized
DEBUG - 2014-12-18 13:50:59 --> Database Driver Class Initialized
ERROR - 2014-12-18 13:50:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-12-18 13:50:59 --> Severity: Warning  --> mysql_pconnect(): Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-12-18 13:50:59 --> Unable to connect to the database
DEBUG - 2014-12-18 13:50:59 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-18 13:51:14 --> Config Class Initialized
DEBUG - 2014-12-18 13:51:14 --> Hooks Class Initialized
DEBUG - 2014-12-18 13:51:14 --> Utf8 Class Initialized
DEBUG - 2014-12-18 13:51:14 --> UTF-8 Support Enabled
DEBUG - 2014-12-18 13:51:14 --> URI Class Initialized
DEBUG - 2014-12-18 13:51:14 --> Router Class Initialized
DEBUG - 2014-12-18 13:51:14 --> Output Class Initialized
DEBUG - 2014-12-18 13:51:14 --> Security Class Initialized
DEBUG - 2014-12-18 13:51:14 --> Input Class Initialized
DEBUG - 2014-12-18 13:51:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-18 13:51:14 --> Language Class Initialized
DEBUG - 2014-12-18 13:51:14 --> Loader Class Initialized
DEBUG - 2014-12-18 13:51:14 --> Database Driver Class Initialized
ERROR - 2014-12-18 13:51:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-12-18 13:51:14 --> Severity: Warning  --> mysql_pconnect(): Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-12-18 13:51:14 --> Unable to connect to the database
DEBUG - 2014-12-18 13:51:14 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-18 13:51:28 --> Config Class Initialized
DEBUG - 2014-12-18 13:51:28 --> Hooks Class Initialized
DEBUG - 2014-12-18 13:51:28 --> Utf8 Class Initialized
DEBUG - 2014-12-18 13:51:28 --> UTF-8 Support Enabled
DEBUG - 2014-12-18 13:51:28 --> URI Class Initialized
DEBUG - 2014-12-18 13:51:28 --> Router Class Initialized
DEBUG - 2014-12-18 13:51:28 --> Output Class Initialized
DEBUG - 2014-12-18 13:51:28 --> Security Class Initialized
DEBUG - 2014-12-18 13:51:28 --> Input Class Initialized
DEBUG - 2014-12-18 13:51:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-18 13:51:28 --> Language Class Initialized
DEBUG - 2014-12-18 13:51:28 --> Loader Class Initialized
DEBUG - 2014-12-18 13:51:28 --> Database Driver Class Initialized
ERROR - 2014-12-18 13:51:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-12-18 13:51:28 --> Severity: Warning  --> mysql_pconnect(): Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-12-18 13:51:28 --> Unable to connect to the database
DEBUG - 2014-12-18 13:51:28 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-18 13:51:33 --> Config Class Initialized
DEBUG - 2014-12-18 13:51:33 --> Hooks Class Initialized
DEBUG - 2014-12-18 13:51:33 --> Utf8 Class Initialized
DEBUG - 2014-12-18 13:51:33 --> UTF-8 Support Enabled
DEBUG - 2014-12-18 13:51:33 --> URI Class Initialized
DEBUG - 2014-12-18 13:51:33 --> Router Class Initialized
DEBUG - 2014-12-18 13:51:33 --> Output Class Initialized
DEBUG - 2014-12-18 13:51:33 --> Security Class Initialized
DEBUG - 2014-12-18 13:51:33 --> Input Class Initialized
DEBUG - 2014-12-18 13:51:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-18 13:51:33 --> Language Class Initialized
DEBUG - 2014-12-18 13:51:33 --> Loader Class Initialized
DEBUG - 2014-12-18 13:51:33 --> Database Driver Class Initialized
ERROR - 2014-12-18 13:51:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-12-18 13:51:33 --> Severity: Warning  --> mysql_pconnect(): Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-12-18 13:51:33 --> Unable to connect to the database
DEBUG - 2014-12-18 13:51:33 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-18 13:51:48 --> Config Class Initialized
DEBUG - 2014-12-18 13:51:48 --> Hooks Class Initialized
DEBUG - 2014-12-18 13:51:48 --> Utf8 Class Initialized
DEBUG - 2014-12-18 13:51:48 --> UTF-8 Support Enabled
DEBUG - 2014-12-18 13:51:48 --> URI Class Initialized
DEBUG - 2014-12-18 13:51:48 --> Router Class Initialized
DEBUG - 2014-12-18 13:51:48 --> Output Class Initialized
DEBUG - 2014-12-18 13:51:48 --> Security Class Initialized
DEBUG - 2014-12-18 13:51:48 --> Input Class Initialized
DEBUG - 2014-12-18 13:51:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-18 13:51:48 --> Language Class Initialized
DEBUG - 2014-12-18 13:51:48 --> Loader Class Initialized
DEBUG - 2014-12-18 13:51:48 --> Database Driver Class Initialized
ERROR - 2014-12-18 13:51:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-12-18 13:51:48 --> Severity: Warning  --> mysql_pconnect(): Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-12-18 13:51:48 --> Unable to connect to the database
DEBUG - 2014-12-18 13:51:48 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-18 13:53:31 --> Config Class Initialized
DEBUG - 2014-12-18 13:53:31 --> Hooks Class Initialized
DEBUG - 2014-12-18 13:53:31 --> Utf8 Class Initialized
DEBUG - 2014-12-18 13:53:31 --> UTF-8 Support Enabled
DEBUG - 2014-12-18 13:53:31 --> URI Class Initialized
DEBUG - 2014-12-18 13:53:31 --> Router Class Initialized
DEBUG - 2014-12-18 13:53:32 --> Output Class Initialized
DEBUG - 2014-12-18 13:53:32 --> Security Class Initialized
DEBUG - 2014-12-18 13:53:32 --> Input Class Initialized
DEBUG - 2014-12-18 13:53:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-18 13:53:32 --> Language Class Initialized
DEBUG - 2014-12-18 13:53:32 --> Loader Class Initialized
DEBUG - 2014-12-18 13:53:32 --> Database Driver Class Initialized
ERROR - 2014-12-18 13:53:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-12-18 13:53:32 --> Severity: Warning  --> mysql_pconnect(): Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-12-18 13:53:32 --> Unable to connect to the database
DEBUG - 2014-12-18 13:53:32 --> Language file loaded: language/english/db_lang.php
