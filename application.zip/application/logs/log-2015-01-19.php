<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-01-19 13:26:47 --> Config Class Initialized
DEBUG - 2015-01-19 13:26:47 --> Hooks Class Initialized
DEBUG - 2015-01-19 13:26:47 --> Utf8 Class Initialized
DEBUG - 2015-01-19 13:26:47 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 13:26:47 --> URI Class Initialized
DEBUG - 2015-01-19 13:26:47 --> Router Class Initialized
DEBUG - 2015-01-19 13:26:47 --> Output Class Initialized
DEBUG - 2015-01-19 13:26:47 --> Security Class Initialized
DEBUG - 2015-01-19 13:26:47 --> Input Class Initialized
DEBUG - 2015-01-19 13:26:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-01-19 13:26:47 --> Language Class Initialized
DEBUG - 2015-01-19 13:26:47 --> Loader Class Initialized
DEBUG - 2015-01-19 13:26:48 --> Database Driver Class Initialized
ERROR - 2015-01-19 13:26:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-01-19 13:26:48 --> XML-RPC Class Initialized
DEBUG - 2015-01-19 13:26:48 --> Controller Class Initialized
DEBUG - 2015-01-19 13:26:48 --> Config file loaded: application/config/rest.php
DEBUG - 2015-01-19 13:26:48 --> Helper loaded: inflector_helper
DEBUG - 2015-01-19 13:26:50 --> Model Class Initialized
DEBUG - 2015-01-19 13:26:50 --> Model Class Initialized
DEBUG - 2015-01-19 14:45:00 --> Config Class Initialized
DEBUG - 2015-01-19 14:45:00 --> Hooks Class Initialized
DEBUG - 2015-01-19 14:45:00 --> Utf8 Class Initialized
DEBUG - 2015-01-19 14:45:00 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 14:45:00 --> URI Class Initialized
DEBUG - 2015-01-19 14:45:00 --> Router Class Initialized
DEBUG - 2015-01-19 14:45:00 --> Output Class Initialized
DEBUG - 2015-01-19 14:45:00 --> Security Class Initialized
DEBUG - 2015-01-19 14:45:00 --> Input Class Initialized
DEBUG - 2015-01-19 14:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-01-19 14:45:00 --> Language Class Initialized
DEBUG - 2015-01-19 14:45:00 --> Loader Class Initialized
DEBUG - 2015-01-19 14:45:00 --> Database Driver Class Initialized
ERROR - 2015-01-19 14:45:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-01-19 14:45:00 --> XML-RPC Class Initialized
DEBUG - 2015-01-19 14:45:00 --> Controller Class Initialized
DEBUG - 2015-01-19 14:45:00 --> Config file loaded: application/config/rest.php
DEBUG - 2015-01-19 14:45:00 --> Helper loaded: inflector_helper
DEBUG - 2015-01-19 14:45:02 --> Model Class Initialized
DEBUG - 2015-01-19 14:45:02 --> Model Class Initialized
DEBUG - 2015-01-19 14:45:02 --> File loaded: application/views/email/registration.php
DEBUG - 2015-01-19 14:45:02 --> Email Class Initialized
DEBUG - 2015-01-19 14:45:06 --> Language file loaded: language/english/email_lang.php
