<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-03-07 12:40:02 --> Config Class Initialized
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-03-07 12:40:02 --> Config Class Initialized
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-03-07 12:40:02 --> Config Class Initialized
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-03-07 12:40:02 --> Config Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Hooks Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Hooks Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Hooks Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Hooks Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Utf8 Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Utf8 Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Utf8 Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Utf8 Class Initialized
DEBUG - 2015-03-07 12:40:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-07 12:40:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-07 12:40:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-07 12:40:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-07 12:40:02 --> URI Class Initialized
DEBUG - 2015-03-07 12:40:02 --> URI Class Initialized
DEBUG - 2015-03-07 12:40:02 --> URI Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Router Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Router Class Initialized
DEBUG - 2015-03-07 12:40:02 --> URI Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Router Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Router Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Output Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Output Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Output Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Output Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Security Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Security Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Security Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Security Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Input Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-07 12:40:02 --> Input Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Language Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-07 12:40:02 --> Language Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Input Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Input Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-07 12:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-07 12:40:02 --> Language Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Language Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Loader Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Loader Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Loader Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Loader Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Database Driver Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Database Driver Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Database Driver Class Initialized
DEBUG - 2015-03-07 12:40:02 --> Database Driver Class Initialized
DEBUG - 2015-03-07 12:40:04 --> XML-RPC Class Initialized
DEBUG - 2015-03-07 12:40:04 --> XML-RPC Class Initialized
DEBUG - 2015-03-07 12:40:04 --> XML-RPC Class Initialized
DEBUG - 2015-03-07 12:40:04 --> XML-RPC Class Initialized
DEBUG - 2015-03-07 12:40:04 --> Controller Class Initialized
DEBUG - 2015-03-07 12:40:04 --> Controller Class Initialized
DEBUG - 2015-03-07 12:40:04 --> Controller Class Initialized
DEBUG - 2015-03-07 12:40:04 --> Controller Class Initialized
DEBUG - 2015-03-07 12:40:04 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-07 12:40:04 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-07 12:40:04 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-07 12:40:04 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-07 12:40:04 --> Helper loaded: inflector_helper
DEBUG - 2015-03-07 12:40:04 --> Helper loaded: inflector_helper
DEBUG - 2015-03-07 12:40:04 --> Helper loaded: inflector_helper
DEBUG - 2015-03-07 12:40:04 --> Helper loaded: inflector_helper
DEBUG - 2015-03-07 12:40:04 --> Model Class Initialized
DEBUG - 2015-03-07 12:40:04 --> Model Class Initialized
DEBUG - 2015-03-07 12:40:04 --> Model Class Initialized
DEBUG - 2015-03-07 12:40:04 --> Model Class Initialized
DEBUG - 2015-03-07 12:40:04 --> Model Class Initialized
DEBUG - 2015-03-07 12:40:04 --> Model Class Initialized
DEBUG - 2015-03-07 12:40:04 --> Model Class Initialized
DEBUG - 2015-03-07 12:40:04 --> Model Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Config Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Hooks Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Utf8 Class Initialized
DEBUG - 2015-03-07 12:40:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-07 12:40:15 --> URI Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Config Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Hooks Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Utf8 Class Initialized
DEBUG - 2015-03-07 12:40:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-07 12:40:15 --> Config Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Hooks Class Initialized
DEBUG - 2015-03-07 12:40:15 --> URI Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Utf8 Class Initialized
DEBUG - 2015-03-07 12:40:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-07 12:40:15 --> URI Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Router Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Output Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Security Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Input Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-07 12:40:15 --> Language Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Loader Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Router Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Output Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Security Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Input Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-07 12:40:15 --> Language Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Loader Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Router Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Output Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Security Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Input Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-07 12:40:15 --> Language Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Loader Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Database Driver Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Database Driver Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Database Driver Class Initialized
DEBUG - 2015-03-07 12:40:15 --> XML-RPC Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Controller Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-07 12:40:15 --> XML-RPC Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Controller Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-07 12:40:15 --> Helper loaded: inflector_helper
DEBUG - 2015-03-07 12:40:15 --> Model Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Model Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Helper loaded: inflector_helper
DEBUG - 2015-03-07 12:40:15 --> Model Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Model Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Config Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Hooks Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Utf8 Class Initialized
DEBUG - 2015-03-07 12:40:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-07 12:40:15 --> URI Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Router Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Output Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Security Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Input Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-07 12:40:15 --> Language Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Loader Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Database Driver Class Initialized
DEBUG - 2015-03-07 12:40:15 --> XML-RPC Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Controller Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-07 12:40:15 --> Helper loaded: inflector_helper
DEBUG - 2015-03-07 12:40:15 --> Model Class Initialized
DEBUG - 2015-03-07 12:40:15 --> Model Class Initialized
DEBUG - 2015-03-07 12:40:17 --> XML-RPC Class Initialized
DEBUG - 2015-03-07 12:40:17 --> Controller Class Initialized
DEBUG - 2015-03-07 12:40:17 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-07 12:40:17 --> Helper loaded: inflector_helper
DEBUG - 2015-03-07 12:40:17 --> Model Class Initialized
DEBUG - 2015-03-07 12:40:17 --> Model Class Initialized
