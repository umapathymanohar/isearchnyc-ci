<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-12-22 13:09:10 --> Config Class Initialized
DEBUG - 2014-12-22 13:09:10 --> Hooks Class Initialized
DEBUG - 2014-12-22 13:09:10 --> Utf8 Class Initialized
DEBUG - 2014-12-22 13:09:10 --> UTF-8 Support Enabled
DEBUG - 2014-12-22 13:09:10 --> URI Class Initialized
DEBUG - 2014-12-22 13:09:10 --> Router Class Initialized
DEBUG - 2014-12-22 13:09:10 --> Output Class Initialized
DEBUG - 2014-12-22 13:09:10 --> Security Class Initialized
DEBUG - 2014-12-22 13:09:10 --> Input Class Initialized
DEBUG - 2014-12-22 13:09:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-22 13:09:10 --> Language Class Initialized
DEBUG - 2014-12-22 13:09:11 --> Loader Class Initialized
DEBUG - 2014-12-22 13:09:11 --> Database Driver Class Initialized
ERROR - 2014-12-22 13:09:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-22 13:09:11 --> XML-RPC Class Initialized
DEBUG - 2014-12-22 13:09:11 --> Controller Class Initialized
DEBUG - 2014-12-22 13:09:11 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-22 13:09:11 --> Helper loaded: inflector_helper
DEBUG - 2014-12-22 13:09:13 --> Model Class Initialized
DEBUG - 2014-12-22 13:09:13 --> Model Class Initialized
DEBUG - 2014-12-22 13:12:00 --> Config Class Initialized
DEBUG - 2014-12-22 13:12:00 --> Hooks Class Initialized
DEBUG - 2014-12-22 13:12:00 --> Utf8 Class Initialized
DEBUG - 2014-12-22 13:12:00 --> UTF-8 Support Enabled
DEBUG - 2014-12-22 13:12:00 --> URI Class Initialized
DEBUG - 2014-12-22 13:12:00 --> Router Class Initialized
DEBUG - 2014-12-22 13:12:00 --> Output Class Initialized
DEBUG - 2014-12-22 13:12:00 --> Security Class Initialized
DEBUG - 2014-12-22 13:12:00 --> Input Class Initialized
DEBUG - 2014-12-22 13:12:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-22 13:12:00 --> Language Class Initialized
DEBUG - 2014-12-22 13:12:00 --> Loader Class Initialized
DEBUG - 2014-12-22 13:12:00 --> Database Driver Class Initialized
ERROR - 2014-12-22 13:12:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-22 13:12:00 --> XML-RPC Class Initialized
DEBUG - 2014-12-22 13:12:00 --> Controller Class Initialized
DEBUG - 2014-12-22 13:12:00 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-22 13:12:00 --> Helper loaded: inflector_helper
DEBUG - 2014-12-22 13:12:02 --> Model Class Initialized
DEBUG - 2014-12-22 13:12:02 --> Model Class Initialized
DEBUG - 2014-12-22 13:20:43 --> Config Class Initialized
DEBUG - 2014-12-22 13:20:43 --> Hooks Class Initialized
DEBUG - 2014-12-22 13:20:43 --> Utf8 Class Initialized
DEBUG - 2014-12-22 13:20:43 --> UTF-8 Support Enabled
DEBUG - 2014-12-22 13:20:43 --> URI Class Initialized
DEBUG - 2014-12-22 13:20:43 --> Router Class Initialized
DEBUG - 2014-12-22 13:20:43 --> Output Class Initialized
DEBUG - 2014-12-22 13:20:43 --> Security Class Initialized
DEBUG - 2014-12-22 13:20:43 --> Input Class Initialized
DEBUG - 2014-12-22 13:20:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-22 13:20:43 --> Language Class Initialized
DEBUG - 2014-12-22 13:20:43 --> Loader Class Initialized
DEBUG - 2014-12-22 13:20:43 --> Database Driver Class Initialized
ERROR - 2014-12-22 13:20:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-22 13:20:43 --> XML-RPC Class Initialized
DEBUG - 2014-12-22 13:20:43 --> Controller Class Initialized
DEBUG - 2014-12-22 13:20:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-22 13:20:43 --> Helper loaded: inflector_helper
DEBUG - 2014-12-22 13:20:45 --> Model Class Initialized
DEBUG - 2014-12-22 13:20:45 --> Model Class Initialized
DEBUG - 2014-12-22 13:20:45 --> File loaded: application/views/email/registration.php
DEBUG - 2014-12-22 13:21:43 --> Config Class Initialized
DEBUG - 2014-12-22 13:21:43 --> Hooks Class Initialized
DEBUG - 2014-12-22 13:21:43 --> Utf8 Class Initialized
DEBUG - 2014-12-22 13:21:43 --> UTF-8 Support Enabled
DEBUG - 2014-12-22 13:21:43 --> URI Class Initialized
DEBUG - 2014-12-22 13:21:43 --> Router Class Initialized
DEBUG - 2014-12-22 13:21:43 --> Output Class Initialized
DEBUG - 2014-12-22 13:21:43 --> Security Class Initialized
DEBUG - 2014-12-22 13:21:43 --> Input Class Initialized
DEBUG - 2014-12-22 13:21:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-22 13:21:43 --> Language Class Initialized
DEBUG - 2014-12-22 13:21:43 --> Loader Class Initialized
DEBUG - 2014-12-22 13:21:43 --> Database Driver Class Initialized
ERROR - 2014-12-22 13:21:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-22 13:21:43 --> XML-RPC Class Initialized
DEBUG - 2014-12-22 13:21:43 --> Controller Class Initialized
DEBUG - 2014-12-22 13:21:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-22 13:21:43 --> Helper loaded: inflector_helper
DEBUG - 2014-12-22 13:21:44 --> Model Class Initialized
DEBUG - 2014-12-22 13:21:44 --> Model Class Initialized
DEBUG - 2014-12-22 13:21:47 --> File loaded: application/views/email/registration.php
DEBUG - 2014-12-22 13:22:43 --> Config Class Initialized
DEBUG - 2014-12-22 13:22:43 --> Hooks Class Initialized
DEBUG - 2014-12-22 13:22:43 --> Utf8 Class Initialized
DEBUG - 2014-12-22 13:22:43 --> UTF-8 Support Enabled
DEBUG - 2014-12-22 13:22:43 --> URI Class Initialized
DEBUG - 2014-12-22 13:22:43 --> Router Class Initialized
DEBUG - 2014-12-22 13:22:43 --> Output Class Initialized
DEBUG - 2014-12-22 13:22:43 --> Security Class Initialized
DEBUG - 2014-12-22 13:22:43 --> Input Class Initialized
DEBUG - 2014-12-22 13:22:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-22 13:22:43 --> Language Class Initialized
DEBUG - 2014-12-22 13:22:43 --> Loader Class Initialized
DEBUG - 2014-12-22 13:22:43 --> Database Driver Class Initialized
ERROR - 2014-12-22 13:22:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-22 13:22:43 --> XML-RPC Class Initialized
DEBUG - 2014-12-22 13:22:43 --> Controller Class Initialized
DEBUG - 2014-12-22 13:22:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-22 13:22:43 --> Helper loaded: inflector_helper
DEBUG - 2014-12-22 13:22:45 --> Model Class Initialized
DEBUG - 2014-12-22 13:22:45 --> Model Class Initialized
DEBUG - 2014-12-22 13:22:45 --> File loaded: application/views/email/registration.php
DEBUG - 2014-12-22 13:24:02 --> Config Class Initialized
DEBUG - 2014-12-22 13:24:02 --> Hooks Class Initialized
DEBUG - 2014-12-22 13:24:02 --> Utf8 Class Initialized
DEBUG - 2014-12-22 13:24:02 --> UTF-8 Support Enabled
DEBUG - 2014-12-22 13:24:02 --> URI Class Initialized
DEBUG - 2014-12-22 13:24:02 --> Router Class Initialized
DEBUG - 2014-12-22 13:24:02 --> Output Class Initialized
DEBUG - 2014-12-22 13:24:02 --> Security Class Initialized
DEBUG - 2014-12-22 13:24:02 --> Input Class Initialized
DEBUG - 2014-12-22 13:24:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-22 13:24:02 --> Language Class Initialized
DEBUG - 2014-12-22 13:24:02 --> Loader Class Initialized
DEBUG - 2014-12-22 13:24:02 --> Database Driver Class Initialized
ERROR - 2014-12-22 13:24:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-22 13:24:02 --> XML-RPC Class Initialized
DEBUG - 2014-12-22 13:24:02 --> Controller Class Initialized
DEBUG - 2014-12-22 13:24:02 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-22 13:24:02 --> Helper loaded: inflector_helper
DEBUG - 2014-12-22 13:24:03 --> Model Class Initialized
DEBUG - 2014-12-22 13:24:03 --> Model Class Initialized
DEBUG - 2014-12-22 13:24:03 --> File loaded: application/views/email/registration.php
DEBUG - 2014-12-22 13:24:03 --> Email Class Initialized
DEBUG - 2014-12-22 13:24:07 --> Language file loaded: language/english/email_lang.php
DEBUG - 2014-12-22 13:24:10 --> Final output sent to browser
DEBUG - 2014-12-22 13:24:10 --> Total execution time: 8.6068
DEBUG - 2014-12-22 13:25:32 --> Config Class Initialized
DEBUG - 2014-12-22 13:25:32 --> Hooks Class Initialized
DEBUG - 2014-12-22 13:25:32 --> Utf8 Class Initialized
DEBUG - 2014-12-22 13:25:32 --> UTF-8 Support Enabled
DEBUG - 2014-12-22 13:25:32 --> URI Class Initialized
DEBUG - 2014-12-22 13:25:32 --> Router Class Initialized
DEBUG - 2014-12-22 13:25:32 --> Output Class Initialized
DEBUG - 2014-12-22 13:25:32 --> Security Class Initialized
DEBUG - 2014-12-22 13:25:32 --> Input Class Initialized
DEBUG - 2014-12-22 13:25:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-22 13:25:32 --> Language Class Initialized
DEBUG - 2014-12-22 13:25:32 --> Loader Class Initialized
DEBUG - 2014-12-22 13:25:32 --> Database Driver Class Initialized
ERROR - 2014-12-22 13:25:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-22 13:25:32 --> XML-RPC Class Initialized
DEBUG - 2014-12-22 13:25:32 --> Controller Class Initialized
DEBUG - 2014-12-22 13:25:32 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-22 13:25:32 --> Helper loaded: inflector_helper
DEBUG - 2014-12-22 13:25:34 --> Model Class Initialized
DEBUG - 2014-12-22 13:25:34 --> Model Class Initialized
DEBUG - 2014-12-22 13:25:34 --> File loaded: application/views/email/registration.php
DEBUG - 2014-12-22 13:25:34 --> Final output sent to browser
DEBUG - 2014-12-22 13:25:34 --> Total execution time: 1.7390
DEBUG - 2014-12-22 13:25:57 --> Config Class Initialized
DEBUG - 2014-12-22 13:25:57 --> Hooks Class Initialized
DEBUG - 2014-12-22 13:25:57 --> Utf8 Class Initialized
DEBUG - 2014-12-22 13:25:57 --> UTF-8 Support Enabled
DEBUG - 2014-12-22 13:25:57 --> URI Class Initialized
DEBUG - 2014-12-22 13:25:57 --> Router Class Initialized
DEBUG - 2014-12-22 13:25:57 --> Output Class Initialized
DEBUG - 2014-12-22 13:25:57 --> Security Class Initialized
DEBUG - 2014-12-22 13:25:57 --> Input Class Initialized
DEBUG - 2014-12-22 13:25:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-22 13:25:57 --> Language Class Initialized
DEBUG - 2014-12-22 13:25:57 --> Loader Class Initialized
DEBUG - 2014-12-22 13:25:57 --> Database Driver Class Initialized
ERROR - 2014-12-22 13:25:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-22 13:25:57 --> XML-RPC Class Initialized
DEBUG - 2014-12-22 13:25:57 --> Controller Class Initialized
DEBUG - 2014-12-22 13:25:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-22 13:25:57 --> Helper loaded: inflector_helper
DEBUG - 2014-12-22 13:25:59 --> Model Class Initialized
DEBUG - 2014-12-22 13:25:59 --> Model Class Initialized
DEBUG - 2014-12-22 13:25:59 --> File loaded: application/views/email/registration.php
DEBUG - 2014-12-22 13:25:59 --> Final output sent to browser
DEBUG - 2014-12-22 13:25:59 --> Total execution time: 1.9797
DEBUG - 2014-12-22 13:29:00 --> Config Class Initialized
DEBUG - 2014-12-22 13:29:00 --> Hooks Class Initialized
DEBUG - 2014-12-22 13:29:00 --> Utf8 Class Initialized
DEBUG - 2014-12-22 13:29:00 --> UTF-8 Support Enabled
DEBUG - 2014-12-22 13:29:00 --> URI Class Initialized
DEBUG - 2014-12-22 13:29:00 --> Router Class Initialized
DEBUG - 2014-12-22 13:29:00 --> Output Class Initialized
DEBUG - 2014-12-22 13:29:00 --> Security Class Initialized
DEBUG - 2014-12-22 13:29:00 --> Input Class Initialized
DEBUG - 2014-12-22 13:29:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-22 13:29:00 --> Language Class Initialized
DEBUG - 2014-12-22 13:29:00 --> Loader Class Initialized
DEBUG - 2014-12-22 13:29:00 --> Database Driver Class Initialized
ERROR - 2014-12-22 13:29:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-22 13:29:00 --> XML-RPC Class Initialized
DEBUG - 2014-12-22 13:29:00 --> Controller Class Initialized
DEBUG - 2014-12-22 13:29:00 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-22 13:29:00 --> Helper loaded: inflector_helper
DEBUG - 2014-12-22 13:29:01 --> Model Class Initialized
DEBUG - 2014-12-22 13:29:01 --> Model Class Initialized
DEBUG - 2014-12-22 13:29:01 --> File loaded: application/views/email/registration.php
DEBUG - 2014-12-22 13:29:01 --> Final output sent to browser
DEBUG - 2014-12-22 13:29:01 --> Total execution time: 1.6208
DEBUG - 2014-12-22 13:29:43 --> Config Class Initialized
DEBUG - 2014-12-22 13:29:43 --> Hooks Class Initialized
DEBUG - 2014-12-22 13:29:43 --> Utf8 Class Initialized
DEBUG - 2014-12-22 13:29:43 --> UTF-8 Support Enabled
DEBUG - 2014-12-22 13:29:43 --> URI Class Initialized
DEBUG - 2014-12-22 13:29:43 --> Router Class Initialized
DEBUG - 2014-12-22 13:29:43 --> Output Class Initialized
DEBUG - 2014-12-22 13:29:43 --> Security Class Initialized
DEBUG - 2014-12-22 13:29:43 --> Input Class Initialized
DEBUG - 2014-12-22 13:29:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-22 13:29:43 --> Language Class Initialized
DEBUG - 2014-12-22 13:29:43 --> Loader Class Initialized
DEBUG - 2014-12-22 13:29:43 --> Database Driver Class Initialized
ERROR - 2014-12-22 13:29:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-22 13:29:43 --> XML-RPC Class Initialized
DEBUG - 2014-12-22 13:29:43 --> Controller Class Initialized
DEBUG - 2014-12-22 13:29:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-22 13:29:43 --> Helper loaded: inflector_helper
DEBUG - 2014-12-22 13:29:45 --> Model Class Initialized
DEBUG - 2014-12-22 13:29:45 --> Model Class Initialized
DEBUG - 2014-12-22 13:29:45 --> File loaded: application/views/email/registration.php
DEBUG - 2014-12-22 13:29:45 --> Email Class Initialized
DEBUG - 2014-12-22 13:29:46 --> Language file loaded: language/english/email_lang.php
DEBUG - 2014-12-22 13:29:49 --> Final output sent to browser
DEBUG - 2014-12-22 13:29:49 --> Total execution time: 6.2451
DEBUG - 2014-12-22 13:34:27 --> Config Class Initialized
DEBUG - 2014-12-22 13:34:27 --> Hooks Class Initialized
DEBUG - 2014-12-22 13:34:27 --> Utf8 Class Initialized
DEBUG - 2014-12-22 13:34:27 --> UTF-8 Support Enabled
DEBUG - 2014-12-22 13:34:27 --> URI Class Initialized
DEBUG - 2014-12-22 13:34:27 --> Router Class Initialized
DEBUG - 2014-12-22 13:34:27 --> Output Class Initialized
DEBUG - 2014-12-22 13:34:27 --> Security Class Initialized
DEBUG - 2014-12-22 13:34:27 --> Input Class Initialized
DEBUG - 2014-12-22 13:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-22 13:34:27 --> Language Class Initialized
DEBUG - 2014-12-22 13:34:27 --> Loader Class Initialized
DEBUG - 2014-12-22 13:34:27 --> Database Driver Class Initialized
ERROR - 2014-12-22 13:34:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-22 13:34:27 --> XML-RPC Class Initialized
DEBUG - 2014-12-22 13:34:27 --> Controller Class Initialized
DEBUG - 2014-12-22 13:34:27 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-22 13:34:27 --> Helper loaded: inflector_helper
DEBUG - 2014-12-22 13:34:29 --> Model Class Initialized
DEBUG - 2014-12-22 13:34:29 --> Model Class Initialized
DEBUG - 2014-12-22 13:34:29 --> File loaded: application/views/email/registration.php
DEBUG - 2014-12-22 13:34:29 --> Email Class Initialized
DEBUG - 2014-12-22 13:34:30 --> Language file loaded: language/english/email_lang.php
DEBUG - 2014-12-22 13:34:34 --> Final output sent to browser
DEBUG - 2014-12-22 13:34:34 --> Total execution time: 6.5670
DEBUG - 2014-12-22 13:34:37 --> Config Class Initialized
DEBUG - 2014-12-22 13:34:37 --> Hooks Class Initialized
DEBUG - 2014-12-22 13:34:37 --> Utf8 Class Initialized
DEBUG - 2014-12-22 13:34:37 --> UTF-8 Support Enabled
DEBUG - 2014-12-22 13:34:37 --> URI Class Initialized
DEBUG - 2014-12-22 13:34:37 --> Router Class Initialized
DEBUG - 2014-12-22 13:34:37 --> Output Class Initialized
DEBUG - 2014-12-22 13:34:37 --> Security Class Initialized
DEBUG - 2014-12-22 13:34:37 --> Input Class Initialized
DEBUG - 2014-12-22 13:34:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-22 13:34:37 --> Language Class Initialized
DEBUG - 2014-12-22 13:34:37 --> Loader Class Initialized
DEBUG - 2014-12-22 13:34:37 --> Database Driver Class Initialized
ERROR - 2014-12-22 13:34:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-22 13:34:37 --> XML-RPC Class Initialized
DEBUG - 2014-12-22 13:34:37 --> Controller Class Initialized
DEBUG - 2014-12-22 13:34:37 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-22 13:34:37 --> Helper loaded: inflector_helper
DEBUG - 2014-12-22 13:34:39 --> Model Class Initialized
DEBUG - 2014-12-22 13:34:39 --> Model Class Initialized
DEBUG - 2014-12-22 13:34:39 --> File loaded: application/views/email/registration.php
DEBUG - 2014-12-22 13:34:39 --> Email Class Initialized
DEBUG - 2014-12-22 13:34:40 --> Language file loaded: language/english/email_lang.php
DEBUG - 2014-12-22 13:34:43 --> Final output sent to browser
DEBUG - 2014-12-22 13:34:43 --> Total execution time: 5.4983
DEBUG - 2014-12-22 14:27:57 --> Config Class Initialized
DEBUG - 2014-12-22 14:27:57 --> Hooks Class Initialized
DEBUG - 2014-12-22 14:27:57 --> Utf8 Class Initialized
DEBUG - 2014-12-22 14:27:57 --> UTF-8 Support Enabled
DEBUG - 2014-12-22 14:27:57 --> URI Class Initialized
DEBUG - 2014-12-22 14:27:57 --> Router Class Initialized
DEBUG - 2014-12-22 14:27:57 --> Output Class Initialized
DEBUG - 2014-12-22 14:27:57 --> Security Class Initialized
DEBUG - 2014-12-22 14:27:57 --> Input Class Initialized
DEBUG - 2014-12-22 14:27:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-22 14:27:57 --> Language Class Initialized
DEBUG - 2014-12-22 14:27:57 --> Loader Class Initialized
DEBUG - 2014-12-22 14:27:57 --> Database Driver Class Initialized
ERROR - 2014-12-22 14:27:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-22 14:27:57 --> XML-RPC Class Initialized
DEBUG - 2014-12-22 14:27:57 --> Controller Class Initialized
DEBUG - 2014-12-22 14:27:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-22 14:27:57 --> Helper loaded: inflector_helper
DEBUG - 2014-12-22 14:27:59 --> Model Class Initialized
DEBUG - 2014-12-22 14:28:22 --> Config Class Initialized
DEBUG - 2014-12-22 14:28:22 --> Hooks Class Initialized
DEBUG - 2014-12-22 14:28:22 --> Utf8 Class Initialized
DEBUG - 2014-12-22 14:28:22 --> UTF-8 Support Enabled
DEBUG - 2014-12-22 14:28:22 --> URI Class Initialized
DEBUG - 2014-12-22 14:28:22 --> Router Class Initialized
DEBUG - 2014-12-22 14:28:22 --> Output Class Initialized
DEBUG - 2014-12-22 14:28:22 --> Security Class Initialized
DEBUG - 2014-12-22 14:28:22 --> Input Class Initialized
DEBUG - 2014-12-22 14:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-22 14:28:22 --> Language Class Initialized
DEBUG - 2014-12-22 14:28:22 --> Loader Class Initialized
DEBUG - 2014-12-22 14:28:22 --> Database Driver Class Initialized
ERROR - 2014-12-22 14:28:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-22 14:28:23 --> XML-RPC Class Initialized
DEBUG - 2014-12-22 14:28:23 --> Controller Class Initialized
DEBUG - 2014-12-22 14:28:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-22 14:28:23 --> Helper loaded: inflector_helper
DEBUG - 2014-12-22 14:28:24 --> Model Class Initialized
DEBUG - 2014-12-22 14:28:30 --> Config Class Initialized
DEBUG - 2014-12-22 14:28:30 --> Hooks Class Initialized
DEBUG - 2014-12-22 14:28:30 --> Utf8 Class Initialized
DEBUG - 2014-12-22 14:28:30 --> UTF-8 Support Enabled
DEBUG - 2014-12-22 14:28:30 --> URI Class Initialized
DEBUG - 2014-12-22 14:28:30 --> Router Class Initialized
DEBUG - 2014-12-22 14:28:30 --> Output Class Initialized
DEBUG - 2014-12-22 14:28:30 --> Security Class Initialized
DEBUG - 2014-12-22 14:28:30 --> Input Class Initialized
DEBUG - 2014-12-22 14:28:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-22 14:28:30 --> Language Class Initialized
DEBUG - 2014-12-22 14:28:30 --> Loader Class Initialized
DEBUG - 2014-12-22 14:28:30 --> Database Driver Class Initialized
ERROR - 2014-12-22 14:28:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-22 14:28:30 --> XML-RPC Class Initialized
DEBUG - 2014-12-22 14:28:30 --> Controller Class Initialized
DEBUG - 2014-12-22 14:28:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-22 14:28:30 --> Helper loaded: inflector_helper
DEBUG - 2014-12-22 14:28:31 --> Model Class Initialized
DEBUG - 2014-12-22 14:30:43 --> Config Class Initialized
DEBUG - 2014-12-22 14:30:43 --> Hooks Class Initialized
DEBUG - 2014-12-22 14:30:43 --> Utf8 Class Initialized
DEBUG - 2014-12-22 14:30:43 --> UTF-8 Support Enabled
DEBUG - 2014-12-22 14:30:43 --> URI Class Initialized
DEBUG - 2014-12-22 14:30:43 --> Router Class Initialized
DEBUG - 2014-12-22 14:30:43 --> Output Class Initialized
DEBUG - 2014-12-22 14:30:43 --> Security Class Initialized
DEBUG - 2014-12-22 14:30:43 --> Input Class Initialized
DEBUG - 2014-12-22 14:30:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-22 14:30:43 --> Language Class Initialized
DEBUG - 2014-12-22 14:30:43 --> Loader Class Initialized
DEBUG - 2014-12-22 14:30:43 --> Database Driver Class Initialized
ERROR - 2014-12-22 14:30:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-22 14:30:43 --> XML-RPC Class Initialized
DEBUG - 2014-12-22 14:30:43 --> Controller Class Initialized
DEBUG - 2014-12-22 14:30:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-22 14:30:43 --> Helper loaded: inflector_helper
DEBUG - 2014-12-22 14:30:45 --> Model Class Initialized
DEBUG - 2014-12-22 14:32:26 --> Config Class Initialized
DEBUG - 2014-12-22 14:32:26 --> Hooks Class Initialized
DEBUG - 2014-12-22 14:32:26 --> Utf8 Class Initialized
DEBUG - 2014-12-22 14:32:26 --> UTF-8 Support Enabled
DEBUG - 2014-12-22 14:32:26 --> URI Class Initialized
DEBUG - 2014-12-22 14:32:26 --> Router Class Initialized
DEBUG - 2014-12-22 14:32:26 --> Output Class Initialized
DEBUG - 2014-12-22 14:32:26 --> Security Class Initialized
DEBUG - 2014-12-22 14:32:26 --> Input Class Initialized
DEBUG - 2014-12-22 14:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-22 14:32:26 --> Language Class Initialized
DEBUG - 2014-12-22 14:32:26 --> Loader Class Initialized
DEBUG - 2014-12-22 14:32:26 --> Database Driver Class Initialized
ERROR - 2014-12-22 14:32:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-22 14:32:26 --> XML-RPC Class Initialized
DEBUG - 2014-12-22 14:32:26 --> Controller Class Initialized
DEBUG - 2014-12-22 14:32:27 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-22 14:32:27 --> Helper loaded: inflector_helper
DEBUG - 2014-12-22 14:32:28 --> Model Class Initialized
DEBUG - 2014-12-22 14:35:17 --> Config Class Initialized
DEBUG - 2014-12-22 14:35:17 --> Hooks Class Initialized
DEBUG - 2014-12-22 14:35:17 --> Utf8 Class Initialized
DEBUG - 2014-12-22 14:35:17 --> UTF-8 Support Enabled
DEBUG - 2014-12-22 14:35:17 --> URI Class Initialized
DEBUG - 2014-12-22 14:35:17 --> Router Class Initialized
DEBUG - 2014-12-22 14:35:17 --> Output Class Initialized
DEBUG - 2014-12-22 14:35:17 --> Security Class Initialized
DEBUG - 2014-12-22 14:35:17 --> Input Class Initialized
DEBUG - 2014-12-22 14:35:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-22 14:35:17 --> Language Class Initialized
DEBUG - 2014-12-22 14:35:17 --> Loader Class Initialized
DEBUG - 2014-12-22 14:35:18 --> Database Driver Class Initialized
ERROR - 2014-12-22 14:35:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-22 14:35:18 --> XML-RPC Class Initialized
DEBUG - 2014-12-22 14:35:18 --> Controller Class Initialized
DEBUG - 2014-12-22 14:35:18 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-22 14:35:18 --> Helper loaded: inflector_helper
DEBUG - 2014-12-22 14:35:20 --> Model Class Initialized
DEBUG - 2014-12-22 14:36:29 --> Config Class Initialized
DEBUG - 2014-12-22 14:36:29 --> Hooks Class Initialized
DEBUG - 2014-12-22 14:36:29 --> Utf8 Class Initialized
DEBUG - 2014-12-22 14:36:29 --> UTF-8 Support Enabled
DEBUG - 2014-12-22 14:36:29 --> URI Class Initialized
DEBUG - 2014-12-22 14:36:29 --> Router Class Initialized
DEBUG - 2014-12-22 14:36:29 --> Output Class Initialized
DEBUG - 2014-12-22 14:36:29 --> Security Class Initialized
DEBUG - 2014-12-22 14:36:29 --> Input Class Initialized
DEBUG - 2014-12-22 14:36:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-22 14:36:29 --> Language Class Initialized
DEBUG - 2014-12-22 14:36:29 --> Loader Class Initialized
DEBUG - 2014-12-22 14:36:29 --> Database Driver Class Initialized
ERROR - 2014-12-22 14:36:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-22 14:36:29 --> XML-RPC Class Initialized
DEBUG - 2014-12-22 14:36:29 --> Controller Class Initialized
DEBUG - 2014-12-22 14:36:29 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-22 14:36:29 --> Helper loaded: inflector_helper
DEBUG - 2014-12-22 14:36:31 --> Model Class Initialized
DEBUG - 2014-12-22 14:37:25 --> Config Class Initialized
DEBUG - 2014-12-22 14:37:25 --> Hooks Class Initialized
DEBUG - 2014-12-22 14:37:25 --> Utf8 Class Initialized
DEBUG - 2014-12-22 14:37:25 --> UTF-8 Support Enabled
DEBUG - 2014-12-22 14:37:25 --> URI Class Initialized
DEBUG - 2014-12-22 14:37:25 --> Router Class Initialized
DEBUG - 2014-12-22 14:37:25 --> Output Class Initialized
DEBUG - 2014-12-22 14:37:25 --> Security Class Initialized
DEBUG - 2014-12-22 14:37:25 --> Input Class Initialized
DEBUG - 2014-12-22 14:37:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-22 14:37:25 --> Language Class Initialized
DEBUG - 2014-12-22 14:37:25 --> Loader Class Initialized
DEBUG - 2014-12-22 14:37:25 --> Database Driver Class Initialized
ERROR - 2014-12-22 14:37:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-22 14:37:25 --> XML-RPC Class Initialized
DEBUG - 2014-12-22 14:37:25 --> Controller Class Initialized
DEBUG - 2014-12-22 14:37:25 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-22 14:37:25 --> Helper loaded: inflector_helper
DEBUG - 2014-12-22 14:37:27 --> Model Class Initialized
DEBUG - 2014-12-22 14:37:52 --> Config Class Initialized
DEBUG - 2014-12-22 14:37:52 --> Hooks Class Initialized
DEBUG - 2014-12-22 14:37:52 --> Utf8 Class Initialized
DEBUG - 2014-12-22 14:37:52 --> UTF-8 Support Enabled
DEBUG - 2014-12-22 14:37:52 --> URI Class Initialized
DEBUG - 2014-12-22 14:37:52 --> Router Class Initialized
DEBUG - 2014-12-22 14:37:52 --> Output Class Initialized
DEBUG - 2014-12-22 14:37:52 --> Security Class Initialized
DEBUG - 2014-12-22 14:37:52 --> Input Class Initialized
DEBUG - 2014-12-22 14:37:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-22 14:37:52 --> Language Class Initialized
DEBUG - 2014-12-22 14:37:52 --> Loader Class Initialized
DEBUG - 2014-12-22 14:37:52 --> Database Driver Class Initialized
ERROR - 2014-12-22 14:37:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-22 14:37:52 --> XML-RPC Class Initialized
DEBUG - 2014-12-22 14:37:52 --> Controller Class Initialized
DEBUG - 2014-12-22 14:37:52 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-22 14:37:52 --> Helper loaded: inflector_helper
DEBUG - 2014-12-22 14:37:53 --> Model Class Initialized
DEBUG - 2014-12-22 14:37:53 --> Model Class Initialized
DEBUG - 2014-12-22 14:37:53 --> File loaded: application/views/email/registration.php
DEBUG - 2014-12-22 14:37:53 --> Email Class Initialized
DEBUG - 2014-12-22 14:37:55 --> Language file loaded: language/english/email_lang.php
DEBUG - 2014-12-22 14:37:58 --> Final output sent to browser
DEBUG - 2014-12-22 14:37:58 --> Total execution time: 6.8395
DEBUG - 2014-12-22 14:38:36 --> Config Class Initialized
DEBUG - 2014-12-22 14:38:36 --> Hooks Class Initialized
DEBUG - 2014-12-22 14:38:36 --> Utf8 Class Initialized
DEBUG - 2014-12-22 14:38:36 --> UTF-8 Support Enabled
DEBUG - 2014-12-22 14:38:36 --> URI Class Initialized
DEBUG - 2014-12-22 14:38:36 --> Router Class Initialized
DEBUG - 2014-12-22 14:38:36 --> Output Class Initialized
DEBUG - 2014-12-22 14:38:36 --> Security Class Initialized
DEBUG - 2014-12-22 14:38:36 --> Input Class Initialized
DEBUG - 2014-12-22 14:38:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-22 14:38:36 --> Language Class Initialized
DEBUG - 2014-12-22 14:38:36 --> Loader Class Initialized
DEBUG - 2014-12-22 14:38:36 --> Database Driver Class Initialized
ERROR - 2014-12-22 14:38:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-22 14:38:36 --> XML-RPC Class Initialized
DEBUG - 2014-12-22 14:38:36 --> Controller Class Initialized
DEBUG - 2014-12-22 14:38:36 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-22 14:38:36 --> Helper loaded: inflector_helper
DEBUG - 2014-12-22 14:38:38 --> Model Class Initialized
DEBUG - 2014-12-22 14:38:38 --> Model Class Initialized
DEBUG - 2014-12-22 14:38:38 --> File loaded: application/views/email/registration.php
DEBUG - 2014-12-22 14:38:38 --> Email Class Initialized
DEBUG - 2014-12-22 14:38:38 --> Language file loaded: language/english/email_lang.php
DEBUG - 2014-12-22 14:56:17 --> Config Class Initialized
DEBUG - 2014-12-22 14:56:17 --> Hooks Class Initialized
DEBUG - 2014-12-22 14:56:17 --> Utf8 Class Initialized
DEBUG - 2014-12-22 14:56:17 --> UTF-8 Support Enabled
DEBUG - 2014-12-22 14:56:17 --> URI Class Initialized
DEBUG - 2014-12-22 14:56:17 --> Router Class Initialized
DEBUG - 2014-12-22 14:56:17 --> Output Class Initialized
DEBUG - 2014-12-22 14:56:17 --> Security Class Initialized
DEBUG - 2014-12-22 14:56:17 --> Input Class Initialized
DEBUG - 2014-12-22 14:56:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-22 14:56:17 --> Language Class Initialized
DEBUG - 2014-12-22 14:56:17 --> Loader Class Initialized
DEBUG - 2014-12-22 14:56:17 --> Database Driver Class Initialized
ERROR - 2014-12-22 14:56:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-22 14:56:17 --> XML-RPC Class Initialized
DEBUG - 2014-12-22 14:56:17 --> Controller Class Initialized
DEBUG - 2014-12-22 14:56:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-22 14:56:17 --> Helper loaded: inflector_helper
DEBUG - 2014-12-22 14:56:19 --> Model Class Initialized
DEBUG - 2014-12-22 14:56:19 --> Model Class Initialized
DEBUG - 2014-12-22 14:56:19 --> File loaded: application/views/email/registration.php
DEBUG - 2014-12-22 14:56:19 --> Email Class Initialized
DEBUG - 2014-12-22 14:56:21 --> Language file loaded: language/english/email_lang.php
ERROR - 2014-12-22 14:56:33 --> Severity: Warning  --> Missing argument 1 for Users_model::updateSugarCRM(), called in /Volumes/Data/www/thunderbirds/server/application/controllers/api/users.php on line 62 and defined /Volumes/Data/www/thunderbirds/server/application/models/users_model.php 75
ERROR - 2014-12-22 14:56:33 --> Severity: Notice  --> Undefined variable: sugarcrm_id /Volumes/Data/www/thunderbirds/server/application/models/users_model.php 80
ERROR - 2014-12-22 14:56:33 --> Severity: Notice  --> Undefined variable: callname /Volumes/Data/www/thunderbirds/server/application/models/users_model.php 87
ERROR - 2014-12-22 14:56:33 --> Severity: Notice  --> Undefined variable: firstname /Volumes/Data/www/thunderbirds/server/application/models/users_model.php 87
ERROR - 2014-12-22 14:56:33 --> Severity: Notice  --> Undefined variable: lastname /Volumes/Data/www/thunderbirds/server/application/models/users_model.php 87
ERROR - 2014-12-22 14:56:33 --> Severity: Notice  --> Undefined variable: gender /Volumes/Data/www/thunderbirds/server/application/models/users_model.php 87
ERROR - 2014-12-22 14:56:33 --> Severity: Notice  --> Undefined variable: dob /Volumes/Data/www/thunderbirds/server/application/models/users_model.php 87
ERROR - 2014-12-22 14:56:33 --> Severity: Notice  --> Undefined variable: password /Volumes/Data/www/thunderbirds/server/application/models/users_model.php 87
ERROR - 2014-12-22 14:56:33 --> Severity: Notice  --> Undefined variable: type /Volumes/Data/www/thunderbirds/server/application/models/users_model.php 87
ERROR - 2014-12-22 14:56:33 --> Severity: Notice  --> Undefined variable: status /Volumes/Data/www/thunderbirds/server/application/models/users_model.php 87
ERROR - 2014-12-22 14:56:33 --> Severity: Notice  --> Undefined variable: newsletter /Volumes/Data/www/thunderbirds/server/application/models/users_model.php 87
ERROR - 2014-12-22 14:56:33 --> Severity: Notice  --> Undefined variable: email /Volumes/Data/www/thunderbirds/server/application/models/users_model.php 87
ERROR - 2014-12-22 14:56:33 --> Severity: Notice  --> Undefined variable: parent_callname /Volumes/Data/www/thunderbirds/server/application/models/users_model.php 87
ERROR - 2014-12-22 14:56:36 --> Severity: Notice  --> Undefined variable: email /Volumes/Data/www/thunderbirds/server/application/models/users_model.php 92
ERROR - 2014-12-22 14:56:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/server/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/server/application/libraries/REST_Controller.php 485
ERROR - 2014-12-22 14:56:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/server/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/server/system/core/Common.php 442
ERROR - 2014-12-22 14:56:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/server/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/server/application/libraries/REST_Controller.php 503
DEBUG - 2014-12-22 14:59:41 --> Config Class Initialized
DEBUG - 2014-12-22 14:59:41 --> Hooks Class Initialized
DEBUG - 2014-12-22 14:59:41 --> Utf8 Class Initialized
DEBUG - 2014-12-22 14:59:41 --> UTF-8 Support Enabled
DEBUG - 2014-12-22 14:59:41 --> URI Class Initialized
DEBUG - 2014-12-22 14:59:41 --> Router Class Initialized
DEBUG - 2014-12-22 14:59:41 --> Output Class Initialized
DEBUG - 2014-12-22 14:59:41 --> Security Class Initialized
DEBUG - 2014-12-22 14:59:41 --> Input Class Initialized
DEBUG - 2014-12-22 14:59:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-22 14:59:41 --> Language Class Initialized
DEBUG - 2014-12-22 14:59:41 --> Loader Class Initialized
DEBUG - 2014-12-22 14:59:41 --> Database Driver Class Initialized
ERROR - 2014-12-22 14:59:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-22 14:59:41 --> XML-RPC Class Initialized
DEBUG - 2014-12-22 14:59:41 --> Controller Class Initialized
DEBUG - 2014-12-22 14:59:41 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-22 14:59:41 --> Helper loaded: inflector_helper
DEBUG - 2014-12-22 14:59:43 --> Model Class Initialized
DEBUG - 2014-12-22 14:59:43 --> Model Class Initialized
DEBUG - 2014-12-22 14:59:43 --> File loaded: application/views/email/registration.php
DEBUG - 2014-12-22 14:59:43 --> Email Class Initialized
DEBUG - 2014-12-22 14:59:44 --> Language file loaded: language/english/email_lang.php
ERROR - 2014-12-22 14:59:55 --> Severity: Notice  --> Undefined variable: email /Volumes/Data/www/thunderbirds/server/application/models/users_model.php 90
ERROR - 2014-12-22 14:59:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/server/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/server/application/libraries/REST_Controller.php 485
ERROR - 2014-12-22 14:59:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/server/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/server/system/core/Common.php 442
ERROR - 2014-12-22 14:59:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/server/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/server/application/libraries/REST_Controller.php 503
DEBUG - 2014-12-22 15:00:50 --> Config Class Initialized
DEBUG - 2014-12-22 15:00:50 --> Hooks Class Initialized
DEBUG - 2014-12-22 15:00:50 --> Utf8 Class Initialized
DEBUG - 2014-12-22 15:00:50 --> UTF-8 Support Enabled
DEBUG - 2014-12-22 15:00:50 --> URI Class Initialized
DEBUG - 2014-12-22 15:00:50 --> Router Class Initialized
DEBUG - 2014-12-22 15:00:50 --> Output Class Initialized
DEBUG - 2014-12-22 15:00:50 --> Security Class Initialized
DEBUG - 2014-12-22 15:00:50 --> Input Class Initialized
DEBUG - 2014-12-22 15:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-22 15:00:50 --> Language Class Initialized
DEBUG - 2014-12-22 15:00:50 --> Loader Class Initialized
DEBUG - 2014-12-22 15:00:50 --> Database Driver Class Initialized
ERROR - 2014-12-22 15:00:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-22 15:00:50 --> XML-RPC Class Initialized
DEBUG - 2014-12-22 15:00:50 --> Controller Class Initialized
DEBUG - 2014-12-22 15:00:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-22 15:00:50 --> Helper loaded: inflector_helper
DEBUG - 2014-12-22 15:00:52 --> Model Class Initialized
DEBUG - 2014-12-22 15:00:52 --> Model Class Initialized
DEBUG - 2014-12-22 15:00:52 --> File loaded: application/views/email/registration.php
DEBUG - 2014-12-22 15:00:52 --> Email Class Initialized
DEBUG - 2014-12-22 15:00:53 --> Language file loaded: language/english/email_lang.php
DEBUG - 2014-12-22 15:21:56 --> Config Class Initialized
DEBUG - 2014-12-22 15:21:56 --> Hooks Class Initialized
DEBUG - 2014-12-22 15:21:56 --> Utf8 Class Initialized
DEBUG - 2014-12-22 15:21:56 --> UTF-8 Support Enabled
DEBUG - 2014-12-22 15:21:56 --> URI Class Initialized
DEBUG - 2014-12-22 15:21:56 --> Router Class Initialized
DEBUG - 2014-12-22 15:21:56 --> Output Class Initialized
DEBUG - 2014-12-22 15:21:56 --> Security Class Initialized
DEBUG - 2014-12-22 15:21:56 --> Input Class Initialized
DEBUG - 2014-12-22 15:21:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-22 15:21:56 --> Language Class Initialized
DEBUG - 2014-12-22 15:21:56 --> Loader Class Initialized
DEBUG - 2014-12-22 15:21:56 --> Database Driver Class Initialized
ERROR - 2014-12-22 15:21:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-22 15:21:56 --> XML-RPC Class Initialized
DEBUG - 2014-12-22 15:21:56 --> Controller Class Initialized
DEBUG - 2014-12-22 15:21:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-22 15:21:56 --> Helper loaded: inflector_helper
DEBUG - 2014-12-22 15:21:58 --> Model Class Initialized
DEBUG - 2014-12-22 15:21:58 --> Model Class Initialized
DEBUG - 2014-12-22 15:21:58 --> File loaded: application/views/email/registration.php
DEBUG - 2014-12-22 15:21:58 --> Email Class Initialized
DEBUG - 2014-12-22 15:21:59 --> Language file loaded: language/english/email_lang.php
