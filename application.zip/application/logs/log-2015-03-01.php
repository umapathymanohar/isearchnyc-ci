<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-03-01 01:33:10 --> Config Class Initialized
DEBUG - 2015-03-01 01:33:10 --> Hooks Class Initialized
DEBUG - 2015-03-01 01:33:10 --> Utf8 Class Initialized
DEBUG - 2015-03-01 01:33:10 --> UTF-8 Support Enabled
DEBUG - 2015-03-01 01:33:10 --> URI Class Initialized
DEBUG - 2015-03-01 01:33:10 --> Router Class Initialized
DEBUG - 2015-03-01 01:33:10 --> Output Class Initialized
DEBUG - 2015-03-01 01:33:10 --> Security Class Initialized
DEBUG - 2015-03-01 01:33:10 --> Input Class Initialized
DEBUG - 2015-03-01 01:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-01 01:33:10 --> Language Class Initialized
DEBUG - 2015-03-01 01:33:10 --> Loader Class Initialized
DEBUG - 2015-03-01 01:33:10 --> Database Driver Class Initialized
DEBUG - 2015-03-01 01:33:11 --> XML-RPC Class Initialized
DEBUG - 2015-03-01 01:33:11 --> Controller Class Initialized
DEBUG - 2015-03-01 01:33:11 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-01 01:33:11 --> Helper loaded: inflector_helper
DEBUG - 2015-03-01 01:33:11 --> Model Class Initialized
DEBUG - 2015-03-01 01:33:11 --> Model Class Initialized
DEBUG - 2015-03-01 01:33:11 --> DB Transaction Failure
ERROR - 2015-03-01 01:33:11 --> Query error: Unknown column 'username' in 'where clause'
DEBUG - 2015-03-01 01:33:11 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-01 01:36:16 --> Config Class Initialized
DEBUG - 2015-03-01 01:36:16 --> Hooks Class Initialized
DEBUG - 2015-03-01 01:36:16 --> Utf8 Class Initialized
DEBUG - 2015-03-01 01:36:16 --> UTF-8 Support Enabled
DEBUG - 2015-03-01 01:36:16 --> URI Class Initialized
DEBUG - 2015-03-01 01:36:16 --> Router Class Initialized
DEBUG - 2015-03-01 01:36:16 --> Output Class Initialized
DEBUG - 2015-03-01 01:36:16 --> Security Class Initialized
DEBUG - 2015-03-01 01:36:16 --> Input Class Initialized
DEBUG - 2015-03-01 01:36:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-01 01:36:16 --> Language Class Initialized
DEBUG - 2015-03-01 01:36:16 --> Loader Class Initialized
DEBUG - 2015-03-01 01:36:16 --> Database Driver Class Initialized
DEBUG - 2015-03-01 01:36:17 --> XML-RPC Class Initialized
DEBUG - 2015-03-01 01:36:17 --> Controller Class Initialized
DEBUG - 2015-03-01 01:36:17 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-01 01:36:17 --> Helper loaded: inflector_helper
DEBUG - 2015-03-01 01:36:17 --> Model Class Initialized
DEBUG - 2015-03-01 01:36:17 --> Model Class Initialized
DEBUG - 2015-03-01 01:38:02 --> Config Class Initialized
DEBUG - 2015-03-01 01:38:02 --> Hooks Class Initialized
DEBUG - 2015-03-01 01:38:02 --> Utf8 Class Initialized
DEBUG - 2015-03-01 01:38:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-01 01:38:02 --> URI Class Initialized
DEBUG - 2015-03-01 01:38:02 --> Router Class Initialized
DEBUG - 2015-03-01 01:38:02 --> Output Class Initialized
DEBUG - 2015-03-01 01:38:02 --> Security Class Initialized
DEBUG - 2015-03-01 01:38:02 --> Input Class Initialized
DEBUG - 2015-03-01 01:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-01 01:38:02 --> Language Class Initialized
DEBUG - 2015-03-01 01:38:02 --> Loader Class Initialized
DEBUG - 2015-03-01 01:38:02 --> Database Driver Class Initialized
DEBUG - 2015-03-01 01:38:03 --> XML-RPC Class Initialized
DEBUG - 2015-03-01 01:38:03 --> Controller Class Initialized
DEBUG - 2015-03-01 01:38:03 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-01 01:38:03 --> Helper loaded: inflector_helper
DEBUG - 2015-03-01 01:38:03 --> Model Class Initialized
DEBUG - 2015-03-01 01:38:03 --> Model Class Initialized
DEBUG - 2015-03-01 01:43:05 --> Config Class Initialized
DEBUG - 2015-03-01 01:43:05 --> Hooks Class Initialized
DEBUG - 2015-03-01 01:43:05 --> Utf8 Class Initialized
DEBUG - 2015-03-01 01:43:05 --> UTF-8 Support Enabled
DEBUG - 2015-03-01 01:43:05 --> URI Class Initialized
DEBUG - 2015-03-01 01:43:05 --> Router Class Initialized
DEBUG - 2015-03-01 01:43:05 --> Output Class Initialized
DEBUG - 2015-03-01 01:43:05 --> Security Class Initialized
DEBUG - 2015-03-01 01:43:05 --> Input Class Initialized
DEBUG - 2015-03-01 01:43:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-01 01:43:05 --> Language Class Initialized
DEBUG - 2015-03-01 01:43:05 --> Loader Class Initialized
DEBUG - 2015-03-01 01:43:05 --> Database Driver Class Initialized
DEBUG - 2015-03-01 01:43:06 --> XML-RPC Class Initialized
DEBUG - 2015-03-01 01:43:06 --> Controller Class Initialized
DEBUG - 2015-03-01 01:43:06 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-01 01:43:06 --> Helper loaded: inflector_helper
DEBUG - 2015-03-01 01:43:06 --> Model Class Initialized
DEBUG - 2015-03-01 01:43:06 --> Model Class Initialized
DEBUG - 2015-03-01 01:43:45 --> Config Class Initialized
DEBUG - 2015-03-01 01:43:45 --> Hooks Class Initialized
DEBUG - 2015-03-01 01:43:45 --> Utf8 Class Initialized
DEBUG - 2015-03-01 01:43:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-01 01:43:45 --> URI Class Initialized
DEBUG - 2015-03-01 01:43:45 --> Router Class Initialized
DEBUG - 2015-03-01 01:43:45 --> Output Class Initialized
DEBUG - 2015-03-01 01:43:45 --> Security Class Initialized
DEBUG - 2015-03-01 01:43:45 --> Input Class Initialized
DEBUG - 2015-03-01 01:43:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-01 01:43:45 --> Language Class Initialized
DEBUG - 2015-03-01 01:43:45 --> Loader Class Initialized
DEBUG - 2015-03-01 01:43:45 --> Database Driver Class Initialized
DEBUG - 2015-03-01 01:43:45 --> XML-RPC Class Initialized
DEBUG - 2015-03-01 01:43:45 --> Controller Class Initialized
DEBUG - 2015-03-01 01:43:45 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-01 01:43:45 --> Helper loaded: inflector_helper
DEBUG - 2015-03-01 01:43:45 --> Model Class Initialized
DEBUG - 2015-03-01 01:43:45 --> Model Class Initialized
DEBUG - 2015-03-01 01:43:45 --> Final output sent to browser
DEBUG - 2015-03-01 01:43:45 --> Total execution time: 0.0756
DEBUG - 2015-03-01 01:43:56 --> Config Class Initialized
DEBUG - 2015-03-01 01:43:56 --> Hooks Class Initialized
DEBUG - 2015-03-01 01:43:56 --> Utf8 Class Initialized
DEBUG - 2015-03-01 01:43:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-01 01:43:56 --> URI Class Initialized
DEBUG - 2015-03-01 01:43:56 --> Router Class Initialized
DEBUG - 2015-03-01 01:43:56 --> Output Class Initialized
DEBUG - 2015-03-01 01:43:56 --> Security Class Initialized
DEBUG - 2015-03-01 01:43:56 --> Input Class Initialized
DEBUG - 2015-03-01 01:43:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-01 01:43:56 --> Language Class Initialized
DEBUG - 2015-03-01 01:43:56 --> Loader Class Initialized
DEBUG - 2015-03-01 01:43:56 --> Database Driver Class Initialized
DEBUG - 2015-03-01 01:43:56 --> XML-RPC Class Initialized
DEBUG - 2015-03-01 01:43:56 --> Controller Class Initialized
DEBUG - 2015-03-01 01:43:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-01 01:43:56 --> Helper loaded: inflector_helper
DEBUG - 2015-03-01 01:43:56 --> Model Class Initialized
DEBUG - 2015-03-01 01:43:56 --> Model Class Initialized
ERROR - 2015-03-01 01:43:56 --> Severity: Notice  --> Undefined variable: obj D:\www\nyc\server\application\controllers\api\users.php 118
DEBUG - 2015-03-01 01:43:56 --> Final output sent to browser
DEBUG - 2015-03-01 01:43:56 --> Total execution time: 0.0596
DEBUG - 2015-03-01 01:43:57 --> Config Class Initialized
DEBUG - 2015-03-01 01:43:57 --> Hooks Class Initialized
DEBUG - 2015-03-01 01:43:57 --> Utf8 Class Initialized
DEBUG - 2015-03-01 01:43:57 --> UTF-8 Support Enabled
DEBUG - 2015-03-01 01:43:57 --> URI Class Initialized
DEBUG - 2015-03-01 01:43:57 --> Router Class Initialized
DEBUG - 2015-03-01 01:43:57 --> Output Class Initialized
DEBUG - 2015-03-01 01:43:57 --> Security Class Initialized
DEBUG - 2015-03-01 01:43:57 --> Input Class Initialized
DEBUG - 2015-03-01 01:43:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-01 01:43:57 --> Language Class Initialized
DEBUG - 2015-03-01 01:43:57 --> Loader Class Initialized
DEBUG - 2015-03-01 01:43:57 --> Database Driver Class Initialized
DEBUG - 2015-03-01 01:43:57 --> XML-RPC Class Initialized
DEBUG - 2015-03-01 01:43:57 --> Controller Class Initialized
DEBUG - 2015-03-01 01:43:57 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-01 01:43:57 --> Helper loaded: inflector_helper
DEBUG - 2015-03-01 01:43:57 --> Model Class Initialized
DEBUG - 2015-03-01 01:43:57 --> Model Class Initialized
ERROR - 2015-03-01 01:43:57 --> Severity: Notice  --> Undefined variable: obj D:\www\nyc\server\application\controllers\api\users.php 118
DEBUG - 2015-03-01 01:43:57 --> Final output sent to browser
DEBUG - 2015-03-01 01:43:57 --> Total execution time: 0.0629
DEBUG - 2015-03-01 01:44:10 --> Config Class Initialized
DEBUG - 2015-03-01 01:44:10 --> Hooks Class Initialized
DEBUG - 2015-03-01 01:44:10 --> Utf8 Class Initialized
DEBUG - 2015-03-01 01:44:10 --> UTF-8 Support Enabled
DEBUG - 2015-03-01 01:44:10 --> URI Class Initialized
DEBUG - 2015-03-01 01:44:10 --> Router Class Initialized
DEBUG - 2015-03-01 01:44:10 --> Output Class Initialized
DEBUG - 2015-03-01 01:44:10 --> Security Class Initialized
DEBUG - 2015-03-01 01:44:10 --> Input Class Initialized
DEBUG - 2015-03-01 01:44:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-01 01:44:10 --> Language Class Initialized
DEBUG - 2015-03-01 01:44:10 --> Loader Class Initialized
DEBUG - 2015-03-01 01:44:10 --> Database Driver Class Initialized
DEBUG - 2015-03-01 01:44:10 --> XML-RPC Class Initialized
DEBUG - 2015-03-01 01:44:10 --> Controller Class Initialized
DEBUG - 2015-03-01 01:44:10 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-01 01:44:10 --> Helper loaded: inflector_helper
DEBUG - 2015-03-01 01:44:10 --> Model Class Initialized
DEBUG - 2015-03-01 01:44:10 --> Model Class Initialized
DEBUG - 2015-03-01 01:44:28 --> Config Class Initialized
DEBUG - 2015-03-01 01:44:28 --> Hooks Class Initialized
DEBUG - 2015-03-01 01:44:28 --> Utf8 Class Initialized
DEBUG - 2015-03-01 01:44:28 --> UTF-8 Support Enabled
DEBUG - 2015-03-01 01:44:28 --> URI Class Initialized
DEBUG - 2015-03-01 01:44:28 --> Router Class Initialized
DEBUG - 2015-03-01 01:44:28 --> Output Class Initialized
DEBUG - 2015-03-01 01:44:28 --> Security Class Initialized
DEBUG - 2015-03-01 01:44:28 --> Input Class Initialized
DEBUG - 2015-03-01 01:44:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-01 01:44:28 --> Language Class Initialized
DEBUG - 2015-03-01 01:44:28 --> Loader Class Initialized
DEBUG - 2015-03-01 01:44:28 --> Database Driver Class Initialized
DEBUG - 2015-03-01 01:44:28 --> XML-RPC Class Initialized
DEBUG - 2015-03-01 01:44:28 --> Controller Class Initialized
DEBUG - 2015-03-01 01:44:28 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-01 01:44:28 --> Helper loaded: inflector_helper
DEBUG - 2015-03-01 01:44:28 --> Model Class Initialized
DEBUG - 2015-03-01 01:44:28 --> Model Class Initialized
DEBUG - 2015-03-01 01:44:29 --> Config Class Initialized
DEBUG - 2015-03-01 01:44:29 --> Hooks Class Initialized
DEBUG - 2015-03-01 01:44:29 --> Utf8 Class Initialized
DEBUG - 2015-03-01 01:44:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-01 01:44:29 --> URI Class Initialized
DEBUG - 2015-03-01 01:44:29 --> Router Class Initialized
DEBUG - 2015-03-01 01:44:29 --> Output Class Initialized
DEBUG - 2015-03-01 01:44:29 --> Security Class Initialized
DEBUG - 2015-03-01 01:44:29 --> Input Class Initialized
DEBUG - 2015-03-01 01:44:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-01 01:44:29 --> Language Class Initialized
DEBUG - 2015-03-01 01:44:29 --> Loader Class Initialized
DEBUG - 2015-03-01 01:44:29 --> Database Driver Class Initialized
DEBUG - 2015-03-01 01:44:29 --> XML-RPC Class Initialized
DEBUG - 2015-03-01 01:44:29 --> Controller Class Initialized
DEBUG - 2015-03-01 01:44:29 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-01 01:44:29 --> Helper loaded: inflector_helper
DEBUG - 2015-03-01 01:44:29 --> Model Class Initialized
DEBUG - 2015-03-01 01:44:29 --> Model Class Initialized
DEBUG - 2015-03-01 01:45:13 --> Config Class Initialized
DEBUG - 2015-03-01 01:45:13 --> Hooks Class Initialized
DEBUG - 2015-03-01 01:45:13 --> Utf8 Class Initialized
DEBUG - 2015-03-01 01:45:13 --> UTF-8 Support Enabled
DEBUG - 2015-03-01 01:45:13 --> URI Class Initialized
DEBUG - 2015-03-01 01:45:13 --> Router Class Initialized
DEBUG - 2015-03-01 01:45:13 --> Output Class Initialized
DEBUG - 2015-03-01 01:45:13 --> Security Class Initialized
DEBUG - 2015-03-01 01:45:13 --> Input Class Initialized
DEBUG - 2015-03-01 01:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-01 01:45:13 --> Language Class Initialized
DEBUG - 2015-03-01 01:45:13 --> Loader Class Initialized
DEBUG - 2015-03-01 01:45:13 --> Database Driver Class Initialized
DEBUG - 2015-03-01 01:45:13 --> XML-RPC Class Initialized
DEBUG - 2015-03-01 01:45:13 --> Controller Class Initialized
DEBUG - 2015-03-01 01:45:13 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-01 01:45:13 --> Helper loaded: inflector_helper
DEBUG - 2015-03-01 01:45:13 --> Model Class Initialized
DEBUG - 2015-03-01 01:45:13 --> Model Class Initialized
DEBUG - 2015-03-01 01:48:36 --> Config Class Initialized
DEBUG - 2015-03-01 01:48:36 --> Hooks Class Initialized
DEBUG - 2015-03-01 01:48:36 --> Utf8 Class Initialized
DEBUG - 2015-03-01 01:48:36 --> UTF-8 Support Enabled
DEBUG - 2015-03-01 01:48:36 --> URI Class Initialized
DEBUG - 2015-03-01 01:48:36 --> Router Class Initialized
DEBUG - 2015-03-01 01:48:36 --> Output Class Initialized
DEBUG - 2015-03-01 01:48:36 --> Security Class Initialized
DEBUG - 2015-03-01 01:48:36 --> Input Class Initialized
DEBUG - 2015-03-01 01:48:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-01 01:48:36 --> Language Class Initialized
DEBUG - 2015-03-01 01:48:36 --> Loader Class Initialized
DEBUG - 2015-03-01 01:48:36 --> Database Driver Class Initialized
DEBUG - 2015-03-01 01:48:37 --> XML-RPC Class Initialized
DEBUG - 2015-03-01 01:48:37 --> Controller Class Initialized
DEBUG - 2015-03-01 01:48:37 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-01 01:48:37 --> Helper loaded: inflector_helper
DEBUG - 2015-03-01 01:48:37 --> Model Class Initialized
DEBUG - 2015-03-01 01:48:37 --> Model Class Initialized
DEBUG - 2015-03-01 01:50:44 --> Config Class Initialized
DEBUG - 2015-03-01 01:50:44 --> Hooks Class Initialized
DEBUG - 2015-03-01 01:50:44 --> Utf8 Class Initialized
DEBUG - 2015-03-01 01:50:44 --> UTF-8 Support Enabled
DEBUG - 2015-03-01 01:50:44 --> URI Class Initialized
DEBUG - 2015-03-01 01:50:44 --> Router Class Initialized
DEBUG - 2015-03-01 01:50:44 --> Output Class Initialized
DEBUG - 2015-03-01 01:50:44 --> Security Class Initialized
DEBUG - 2015-03-01 01:50:44 --> Input Class Initialized
DEBUG - 2015-03-01 01:50:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-01 01:50:44 --> Language Class Initialized
DEBUG - 2015-03-01 01:50:44 --> Loader Class Initialized
DEBUG - 2015-03-01 01:50:44 --> Database Driver Class Initialized
DEBUG - 2015-03-01 01:50:44 --> XML-RPC Class Initialized
DEBUG - 2015-03-01 01:50:44 --> Controller Class Initialized
DEBUG - 2015-03-01 01:50:44 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-01 01:50:44 --> Helper loaded: inflector_helper
DEBUG - 2015-03-01 01:50:44 --> Model Class Initialized
DEBUG - 2015-03-01 01:50:44 --> Model Class Initialized
DEBUG - 2015-03-01 01:50:44 --> Final output sent to browser
DEBUG - 2015-03-01 01:50:44 --> Total execution time: 0.0668
DEBUG - 2015-03-01 01:51:16 --> Config Class Initialized
DEBUG - 2015-03-01 01:51:16 --> Hooks Class Initialized
DEBUG - 2015-03-01 01:51:16 --> Utf8 Class Initialized
DEBUG - 2015-03-01 01:51:16 --> UTF-8 Support Enabled
DEBUG - 2015-03-01 01:51:16 --> URI Class Initialized
DEBUG - 2015-03-01 01:51:16 --> Router Class Initialized
DEBUG - 2015-03-01 01:51:16 --> Output Class Initialized
DEBUG - 2015-03-01 01:51:16 --> Security Class Initialized
DEBUG - 2015-03-01 01:51:16 --> Input Class Initialized
DEBUG - 2015-03-01 01:51:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-01 01:51:16 --> Language Class Initialized
DEBUG - 2015-03-01 01:51:16 --> Loader Class Initialized
DEBUG - 2015-03-01 01:51:16 --> Database Driver Class Initialized
DEBUG - 2015-03-01 01:51:16 --> XML-RPC Class Initialized
DEBUG - 2015-03-01 01:51:16 --> Controller Class Initialized
DEBUG - 2015-03-01 01:51:16 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-01 01:51:16 --> Helper loaded: inflector_helper
DEBUG - 2015-03-01 01:51:16 --> Model Class Initialized
DEBUG - 2015-03-01 01:51:16 --> Model Class Initialized
DEBUG - 2015-03-01 01:51:16 --> Final output sent to browser
DEBUG - 2015-03-01 01:51:16 --> Total execution time: 0.0676
DEBUG - 2015-03-01 01:52:55 --> Config Class Initialized
DEBUG - 2015-03-01 01:52:55 --> Hooks Class Initialized
DEBUG - 2015-03-01 01:52:55 --> Utf8 Class Initialized
DEBUG - 2015-03-01 01:52:55 --> UTF-8 Support Enabled
DEBUG - 2015-03-01 01:52:55 --> URI Class Initialized
DEBUG - 2015-03-01 01:52:55 --> Router Class Initialized
DEBUG - 2015-03-01 01:52:55 --> Output Class Initialized
DEBUG - 2015-03-01 01:52:55 --> Security Class Initialized
DEBUG - 2015-03-01 01:52:55 --> Input Class Initialized
DEBUG - 2015-03-01 01:52:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-01 01:52:55 --> Language Class Initialized
DEBUG - 2015-03-01 01:52:55 --> Loader Class Initialized
DEBUG - 2015-03-01 01:52:55 --> Database Driver Class Initialized
DEBUG - 2015-03-01 01:52:55 --> XML-RPC Class Initialized
DEBUG - 2015-03-01 01:52:55 --> Controller Class Initialized
DEBUG - 2015-03-01 01:52:55 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-01 01:52:55 --> Helper loaded: inflector_helper
DEBUG - 2015-03-01 01:52:55 --> Model Class Initialized
DEBUG - 2015-03-01 01:52:55 --> Model Class Initialized
DEBUG - 2015-03-01 01:52:55 --> Final output sent to browser
DEBUG - 2015-03-01 01:52:55 --> Total execution time: 0.0815
DEBUG - 2015-03-01 01:53:11 --> Config Class Initialized
DEBUG - 2015-03-01 01:53:11 --> Hooks Class Initialized
DEBUG - 2015-03-01 01:53:11 --> Utf8 Class Initialized
DEBUG - 2015-03-01 01:53:11 --> UTF-8 Support Enabled
DEBUG - 2015-03-01 01:53:11 --> URI Class Initialized
DEBUG - 2015-03-01 01:53:11 --> Router Class Initialized
DEBUG - 2015-03-01 01:53:11 --> Output Class Initialized
DEBUG - 2015-03-01 01:53:11 --> Security Class Initialized
DEBUG - 2015-03-01 01:53:11 --> Input Class Initialized
DEBUG - 2015-03-01 01:53:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-01 01:53:11 --> Language Class Initialized
DEBUG - 2015-03-01 01:53:11 --> Loader Class Initialized
DEBUG - 2015-03-01 01:53:11 --> Database Driver Class Initialized
DEBUG - 2015-03-01 01:53:11 --> XML-RPC Class Initialized
DEBUG - 2015-03-01 01:53:11 --> Controller Class Initialized
DEBUG - 2015-03-01 01:53:11 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-01 01:53:11 --> Helper loaded: inflector_helper
DEBUG - 2015-03-01 01:53:11 --> Model Class Initialized
DEBUG - 2015-03-01 01:53:11 --> Model Class Initialized
DEBUG - 2015-03-01 01:53:11 --> Final output sent to browser
DEBUG - 2015-03-01 01:53:11 --> Total execution time: 0.0696
DEBUG - 2015-03-01 01:53:17 --> Config Class Initialized
DEBUG - 2015-03-01 01:53:17 --> Hooks Class Initialized
DEBUG - 2015-03-01 01:53:17 --> Utf8 Class Initialized
DEBUG - 2015-03-01 01:53:17 --> UTF-8 Support Enabled
DEBUG - 2015-03-01 01:53:17 --> URI Class Initialized
DEBUG - 2015-03-01 01:53:17 --> Router Class Initialized
DEBUG - 2015-03-01 01:53:17 --> Output Class Initialized
DEBUG - 2015-03-01 01:53:17 --> Security Class Initialized
DEBUG - 2015-03-01 01:53:17 --> Input Class Initialized
DEBUG - 2015-03-01 01:53:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-01 01:53:17 --> Language Class Initialized
DEBUG - 2015-03-01 01:53:17 --> Loader Class Initialized
DEBUG - 2015-03-01 01:53:18 --> Database Driver Class Initialized
DEBUG - 2015-03-01 01:53:18 --> XML-RPC Class Initialized
DEBUG - 2015-03-01 01:53:18 --> Controller Class Initialized
DEBUG - 2015-03-01 01:53:18 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-01 01:53:18 --> Helper loaded: inflector_helper
DEBUG - 2015-03-01 01:53:18 --> Model Class Initialized
DEBUG - 2015-03-01 01:53:18 --> Model Class Initialized
DEBUG - 2015-03-01 01:53:18 --> Final output sent to browser
DEBUG - 2015-03-01 01:53:18 --> Total execution time: 0.0666
DEBUG - 2015-03-01 01:54:13 --> Config Class Initialized
DEBUG - 2015-03-01 01:54:13 --> Hooks Class Initialized
DEBUG - 2015-03-01 01:54:13 --> Utf8 Class Initialized
DEBUG - 2015-03-01 01:54:13 --> UTF-8 Support Enabled
DEBUG - 2015-03-01 01:54:13 --> URI Class Initialized
DEBUG - 2015-03-01 01:54:13 --> Router Class Initialized
DEBUG - 2015-03-01 01:54:13 --> Output Class Initialized
DEBUG - 2015-03-01 01:54:13 --> Security Class Initialized
DEBUG - 2015-03-01 01:54:13 --> Input Class Initialized
DEBUG - 2015-03-01 01:54:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-01 01:54:13 --> Language Class Initialized
DEBUG - 2015-03-01 01:54:13 --> Loader Class Initialized
DEBUG - 2015-03-01 01:54:13 --> Database Driver Class Initialized
DEBUG - 2015-03-01 01:54:13 --> XML-RPC Class Initialized
DEBUG - 2015-03-01 01:54:13 --> Controller Class Initialized
DEBUG - 2015-03-01 01:54:13 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-01 01:54:13 --> Helper loaded: inflector_helper
DEBUG - 2015-03-01 01:54:13 --> Model Class Initialized
DEBUG - 2015-03-01 01:54:13 --> Model Class Initialized
DEBUG - 2015-03-01 01:54:22 --> Config Class Initialized
DEBUG - 2015-03-01 01:54:22 --> Hooks Class Initialized
DEBUG - 2015-03-01 01:54:22 --> Utf8 Class Initialized
DEBUG - 2015-03-01 01:54:22 --> UTF-8 Support Enabled
DEBUG - 2015-03-01 01:54:22 --> URI Class Initialized
DEBUG - 2015-03-01 01:54:22 --> Router Class Initialized
DEBUG - 2015-03-01 01:54:22 --> Output Class Initialized
DEBUG - 2015-03-01 01:54:22 --> Security Class Initialized
DEBUG - 2015-03-01 01:54:22 --> Input Class Initialized
DEBUG - 2015-03-01 01:54:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-01 01:54:22 --> Language Class Initialized
DEBUG - 2015-03-01 01:54:22 --> Loader Class Initialized
DEBUG - 2015-03-01 01:54:22 --> Database Driver Class Initialized
DEBUG - 2015-03-01 01:54:22 --> XML-RPC Class Initialized
DEBUG - 2015-03-01 01:54:22 --> Controller Class Initialized
DEBUG - 2015-03-01 01:54:22 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-01 01:54:22 --> Helper loaded: inflector_helper
DEBUG - 2015-03-01 01:54:22 --> Model Class Initialized
DEBUG - 2015-03-01 01:54:22 --> Model Class Initialized
DEBUG - 2015-03-01 01:59:38 --> Config Class Initialized
DEBUG - 2015-03-01 01:59:38 --> Hooks Class Initialized
DEBUG - 2015-03-01 01:59:38 --> Utf8 Class Initialized
DEBUG - 2015-03-01 01:59:38 --> UTF-8 Support Enabled
DEBUG - 2015-03-01 01:59:38 --> URI Class Initialized
DEBUG - 2015-03-01 01:59:38 --> Router Class Initialized
DEBUG - 2015-03-01 01:59:38 --> Output Class Initialized
DEBUG - 2015-03-01 01:59:38 --> Security Class Initialized
DEBUG - 2015-03-01 01:59:38 --> Input Class Initialized
DEBUG - 2015-03-01 01:59:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-01 01:59:38 --> Language Class Initialized
DEBUG - 2015-03-01 01:59:38 --> Loader Class Initialized
DEBUG - 2015-03-01 01:59:38 --> Database Driver Class Initialized
DEBUG - 2015-03-01 01:59:38 --> XML-RPC Class Initialized
DEBUG - 2015-03-01 01:59:38 --> Controller Class Initialized
DEBUG - 2015-03-01 01:59:38 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-01 01:59:38 --> Helper loaded: inflector_helper
DEBUG - 2015-03-01 01:59:38 --> Model Class Initialized
DEBUG - 2015-03-01 01:59:38 --> Model Class Initialized
