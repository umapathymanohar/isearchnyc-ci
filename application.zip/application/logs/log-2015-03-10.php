<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-03-10 02:16:53 --> Config Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Config Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:16:53 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:16:53 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:16:53 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:16:53 --> URI Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Router Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Output Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Security Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Input Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:16:53 --> Language Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Loader Class Initialized
DEBUG - 2015-03-10 02:16:53 --> URI Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Router Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Output Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Security Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Input Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:16:53 --> Language Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Loader Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Config Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:16:53 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:16:53 --> URI Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Router Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Output Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Security Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Input Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:16:53 --> Language Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Loader Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Config Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:16:53 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:16:53 --> URI Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Router Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Output Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Security Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Input Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:16:53 --> Language Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Loader Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:16:53 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:16:54 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:16:54 --> Controller Class Initialized
DEBUG - 2015-03-10 02:16:54 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:16:54 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:16:54 --> Model Class Initialized
DEBUG - 2015-03-10 02:16:54 --> Model Class Initialized
DEBUG - 2015-03-10 02:16:54 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:16:54 --> Controller Class Initialized
DEBUG - 2015-03-10 02:16:54 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:16:54 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:16:54 --> Model Class Initialized
DEBUG - 2015-03-10 02:16:54 --> Model Class Initialized
DEBUG - 2015-03-10 02:16:55 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:16:55 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:16:55 --> Controller Class Initialized
DEBUG - 2015-03-10 02:16:55 --> Controller Class Initialized
DEBUG - 2015-03-10 02:16:55 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:16:55 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:16:55 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:16:55 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:16:55 --> Model Class Initialized
DEBUG - 2015-03-10 02:16:55 --> Model Class Initialized
DEBUG - 2015-03-10 02:16:55 --> Model Class Initialized
DEBUG - 2015-03-10 02:16:55 --> Model Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Config Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:25:52 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:25:52 --> URI Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Router Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Output Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Security Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Config Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:25:52 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:25:52 --> URI Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Router Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Output Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Security Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Input Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:25:52 --> Input Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:25:52 --> Language Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Config Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:25:52 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:25:52 --> URI Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Router Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Output Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Config Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Security Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Language Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Input Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Loader Class Initialized
DEBUG - 2015-03-10 02:25:52 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:25:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:25:52 --> Loader Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Language Class Initialized
DEBUG - 2015-03-10 02:25:52 --> URI Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Router Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Loader Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:25:52 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:25:53 --> Output Class Initialized
DEBUG - 2015-03-10 02:25:53 --> Security Class Initialized
DEBUG - 2015-03-10 02:25:53 --> Input Class Initialized
DEBUG - 2015-03-10 02:25:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:25:53 --> Language Class Initialized
DEBUG - 2015-03-10 02:25:53 --> Loader Class Initialized
DEBUG - 2015-03-10 02:25:53 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:25:53 --> Controller Class Initialized
DEBUG - 2015-03-10 02:25:53 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:25:53 --> Controller Class Initialized
DEBUG - 2015-03-10 02:25:53 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:25:53 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:25:53 --> Model Class Initialized
DEBUG - 2015-03-10 02:25:53 --> Model Class Initialized
DEBUG - 2015-03-10 02:25:53 --> DB Transaction Failure
ERROR - 2015-03-10 02:25:53 --> Query error: Table 'nyc.sales' doesn't exist
DEBUG - 2015-03-10 02:25:53 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-10 02:25:53 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:25:53 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:25:53 --> Controller Class Initialized
DEBUG - 2015-03-10 02:25:53 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:25:53 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:25:53 --> Model Class Initialized
DEBUG - 2015-03-10 02:25:53 --> Model Class Initialized
DEBUG - 2015-03-10 02:25:53 --> DB Transaction Failure
ERROR - 2015-03-10 02:25:53 --> Query error: Table 'nyc.agents' doesn't exist
DEBUG - 2015-03-10 02:25:53 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-10 02:25:53 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:25:53 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:25:53 --> Model Class Initialized
DEBUG - 2015-03-10 02:25:53 --> Model Class Initialized
DEBUG - 2015-03-10 02:25:53 --> DB Transaction Failure
ERROR - 2015-03-10 02:25:53 --> Query error: Table 'nyc.rentals' doesn't exist
DEBUG - 2015-03-10 02:25:53 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-10 02:25:54 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:25:54 --> Controller Class Initialized
DEBUG - 2015-03-10 02:25:54 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:25:54 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:25:54 --> Model Class Initialized
DEBUG - 2015-03-10 02:25:54 --> Model Class Initialized
DEBUG - 2015-03-10 02:25:54 --> DB Transaction Failure
ERROR - 2015-03-10 02:25:54 --> Query error: Table 'nyc.listings' doesn't exist
DEBUG - 2015-03-10 02:25:54 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-10 02:26:05 --> Config Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:26:05 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:26:05 --> URI Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Router Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Output Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Security Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Input Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:26:05 --> Language Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Loader Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Config Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:26:05 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:26:05 --> URI Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Router Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Output Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Security Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Input Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:26:05 --> Language Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Loader Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Config Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:26:05 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:26:05 --> URI Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Router Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Output Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Security Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Input Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:26:05 --> Language Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Loader Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Config Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:26:05 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:26:05 --> URI Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Router Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Output Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Security Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Input Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:26:05 --> Language Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Loader Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:26:05 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Controller Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:26:05 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:26:05 --> Model Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Model Class Initialized
DEBUG - 2015-03-10 02:26:05 --> DB Transaction Failure
ERROR - 2015-03-10 02:26:05 --> Query error: Table 'nyc.sales' doesn't exist
DEBUG - 2015-03-10 02:26:05 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-10 02:26:05 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Controller Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:26:05 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:26:05 --> Model Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Model Class Initialized
DEBUG - 2015-03-10 02:26:05 --> DB Transaction Failure
ERROR - 2015-03-10 02:26:05 --> Query error: Table 'nyc.rentals' doesn't exist
DEBUG - 2015-03-10 02:26:05 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-10 02:26:05 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:26:05 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Controller Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:26:05 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:26:05 --> Model Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Model Class Initialized
DEBUG - 2015-03-10 02:26:05 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Controller Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:26:05 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:26:05 --> Model Class Initialized
DEBUG - 2015-03-10 02:26:05 --> Model Class Initialized
DEBUG - 2015-03-10 02:26:05 --> DB Transaction Failure
ERROR - 2015-03-10 02:26:05 --> Query error: Table 'nyc.listings' doesn't exist
DEBUG - 2015-03-10 02:26:05 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-10 02:26:05 --> DB Transaction Failure
ERROR - 2015-03-10 02:26:05 --> Query error: Table 'nyc.agents' doesn't exist
DEBUG - 2015-03-10 02:26:05 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-10 02:26:09 --> Config Class Initialized
DEBUG - 2015-03-10 02:26:09 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:26:09 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:26:09 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:26:09 --> URI Class Initialized
DEBUG - 2015-03-10 02:26:09 --> Router Class Initialized
DEBUG - 2015-03-10 02:26:09 --> Output Class Initialized
DEBUG - 2015-03-10 02:26:09 --> Security Class Initialized
DEBUG - 2015-03-10 02:26:09 --> Input Class Initialized
DEBUG - 2015-03-10 02:26:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:26:09 --> Language Class Initialized
DEBUG - 2015-03-10 02:26:09 --> Loader Class Initialized
DEBUG - 2015-03-10 02:26:09 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:26:10 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:26:10 --> Controller Class Initialized
DEBUG - 2015-03-10 02:26:10 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:26:10 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:26:10 --> Model Class Initialized
DEBUG - 2015-03-10 02:26:10 --> Model Class Initialized
DEBUG - 2015-03-10 02:26:10 --> DB Transaction Failure
ERROR - 2015-03-10 02:26:10 --> Query error: Table 'nyc.users' doesn't exist
DEBUG - 2015-03-10 02:26:10 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-10 02:27:02 --> Config Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:27:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:27:02 --> URI Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Router Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Output Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Security Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Input Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:27:02 --> Language Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Loader Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Config Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:27:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:27:02 --> URI Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Router Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Output Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Security Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Input Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:27:02 --> Language Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Loader Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Config Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:27:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:27:02 --> URI Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Router Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Config Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:27:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:27:02 --> URI Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Output Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Router Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Security Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Input Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Output Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Security Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Input Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:27:02 --> Language Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Loader Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:27:02 --> Language Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Loader Class Initialized
DEBUG - 2015-03-10 02:27:02 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Controller Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:27:02 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:27:02 --> Model Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Model Class Initialized
DEBUG - 2015-03-10 02:27:02 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Controller Class Initialized
DEBUG - 2015-03-10 02:27:02 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:27:02 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:27:02 --> Controller Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Controller Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:27:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:27:02 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:27:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:27:02 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:27:02 --> Model Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Model Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Model Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Model Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Model Class Initialized
DEBUG - 2015-03-10 02:27:02 --> Model Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Config Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:27:18 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:27:18 --> URI Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Router Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Output Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Security Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Config Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:27:18 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:27:18 --> URI Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Router Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Output Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Security Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Input Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:27:18 --> Language Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Loader Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Config Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:27:18 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:27:18 --> URI Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Router Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Output Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Security Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Input Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:27:18 --> Language Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Loader Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:27:18 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Controller Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:27:18 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:27:18 --> Model Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Model Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:27:18 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Controller Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:27:18 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:27:18 --> Model Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Model Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Input Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:27:18 --> Language Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Loader Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:27:18 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Controller Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:27:18 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:27:18 --> Model Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Model Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Config Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:27:18 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:27:18 --> URI Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Router Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Output Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Security Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Input Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:27:18 --> Language Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Loader Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:27:18 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Controller Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:27:18 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:27:18 --> Model Class Initialized
DEBUG - 2015-03-10 02:27:18 --> Model Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Config Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:28:25 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:28:25 --> URI Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Router Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Output Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Security Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Input Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:28:25 --> Language Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Loader Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Config Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:28:25 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:28:25 --> URI Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Router Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Output Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Security Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Input Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:28:25 --> Language Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Loader Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:28:25 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Controller Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:28:25 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:28:25 --> Model Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Model Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:28:25 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Controller Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:28:25 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:28:25 --> Model Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Model Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Config Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:28:25 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:28:25 --> URI Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Router Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Output Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Security Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Input Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:28:25 --> Language Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Loader Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:28:25 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Config Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:28:25 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:28:25 --> URI Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Router Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Output Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Controller Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:28:25 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:28:25 --> Model Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Model Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Security Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Input Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:28:25 --> Language Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Loader Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:28:25 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Controller Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:28:25 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:28:25 --> Model Class Initialized
DEBUG - 2015-03-10 02:28:25 --> Model Class Initialized
DEBUG - 2015-03-10 02:28:55 --> Config Class Initialized
DEBUG - 2015-03-10 02:28:55 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:28:55 --> Config Class Initialized
DEBUG - 2015-03-10 02:28:55 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:28:55 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:28:55 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:28:55 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:28:55 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:28:55 --> URI Class Initialized
DEBUG - 2015-03-10 02:28:55 --> Router Class Initialized
DEBUG - 2015-03-10 02:28:55 --> Output Class Initialized
DEBUG - 2015-03-10 02:28:55 --> Security Class Initialized
DEBUG - 2015-03-10 02:28:55 --> Input Class Initialized
DEBUG - 2015-03-10 02:28:55 --> Config Class Initialized
DEBUG - 2015-03-10 02:28:55 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:28:55 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:28:55 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:28:55 --> URI Class Initialized
DEBUG - 2015-03-10 02:28:55 --> Router Class Initialized
DEBUG - 2015-03-10 02:28:55 --> Output Class Initialized
DEBUG - 2015-03-10 02:28:55 --> Security Class Initialized
DEBUG - 2015-03-10 02:28:55 --> Input Class Initialized
DEBUG - 2015-03-10 02:28:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:28:55 --> Language Class Initialized
DEBUG - 2015-03-10 02:28:55 --> Loader Class Initialized
DEBUG - 2015-03-10 02:28:55 --> URI Class Initialized
DEBUG - 2015-03-10 02:28:55 --> Router Class Initialized
DEBUG - 2015-03-10 02:28:55 --> Output Class Initialized
DEBUG - 2015-03-10 02:28:55 --> Security Class Initialized
DEBUG - 2015-03-10 02:28:55 --> Input Class Initialized
DEBUG - 2015-03-10 02:28:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:28:55 --> Language Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Loader Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:28:56 --> Language Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Loader Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:28:56 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Controller Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:28:56 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:28:56 --> Model Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Model Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:28:56 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Controller Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:28:56 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:28:56 --> Model Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Model Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:28:56 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Controller Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:28:56 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:28:56 --> Model Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Model Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Config Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:28:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:28:56 --> URI Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Router Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Output Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Security Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Input Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:28:56 --> Language Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Loader Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:28:56 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Controller Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:28:56 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:28:56 --> Model Class Initialized
DEBUG - 2015-03-10 02:28:56 --> Model Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Config Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:38:14 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:38:14 --> Config Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:38:14 --> URI Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:38:14 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:38:14 --> Router Class Initialized
DEBUG - 2015-03-10 02:38:14 --> URI Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Router Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Output Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Security Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Output Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Input Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:38:14 --> Security Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Language Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Input Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:38:14 --> Language Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Loader Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Loader Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:38:14 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Controller Class Initialized
DEBUG - 2015-03-10 02:38:14 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Controller Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:38:14 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:38:14 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:38:14 --> Model Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Model Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Config Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:38:14 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:38:14 --> URI Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Router Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Output Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:38:14 --> Model Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Model Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Config Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:38:14 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:38:14 --> URI Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Router Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Output Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Security Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Input Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:38:14 --> Language Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Loader Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:38:14 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Controller Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:38:14 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:38:14 --> Model Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Model Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Security Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Input Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:38:14 --> Language Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Loader Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:38:14 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Controller Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:38:14 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:38:14 --> Model Class Initialized
DEBUG - 2015-03-10 02:38:14 --> Model Class Initialized
DEBUG - 2015-03-10 02:42:22 --> Config Class Initialized
DEBUG - 2015-03-10 02:42:22 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:42:22 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:42:22 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:42:22 --> Config Class Initialized
DEBUG - 2015-03-10 02:42:22 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:42:22 --> URI Class Initialized
DEBUG - 2015-03-10 02:42:22 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:42:22 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:42:22 --> Router Class Initialized
DEBUG - 2015-03-10 02:42:22 --> URI Class Initialized
DEBUG - 2015-03-10 02:42:22 --> Router Class Initialized
DEBUG - 2015-03-10 02:42:22 --> Output Class Initialized
DEBUG - 2015-03-10 02:42:22 --> Output Class Initialized
DEBUG - 2015-03-10 02:42:22 --> Security Class Initialized
DEBUG - 2015-03-10 02:42:22 --> Input Class Initialized
DEBUG - 2015-03-10 02:42:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:42:22 --> Language Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Loader Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Security Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Input Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:42:23 --> Language Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Loader Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:42:23 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Controller Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Config Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:42:23 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:42:23 --> URI Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Router Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Config Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:42:23 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:42:23 --> URI Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Router Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Output Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Security Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:42:23 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:42:23 --> Model Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Model Class Initialized
DEBUG - 2015-03-10 02:42:23 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Controller Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:42:23 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:42:23 --> Model Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Model Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Output Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Security Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Input Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Input Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:42:23 --> Language Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Loader Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:42:23 --> Language Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Loader Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:42:23 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Controller Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:42:23 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:42:23 --> Model Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Model Class Initialized
DEBUG - 2015-03-10 02:42:23 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Controller Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:42:23 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:42:23 --> Model Class Initialized
DEBUG - 2015-03-10 02:42:23 --> Model Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Config Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:42:36 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:42:36 --> URI Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Router Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Output Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Security Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Input Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:42:36 --> Language Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Loader Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Config Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:42:36 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:42:36 --> URI Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Router Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Output Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Config Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Config Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Security Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Input Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:42:36 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:42:36 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:42:36 --> Language Class Initialized
DEBUG - 2015-03-10 02:42:36 --> URI Class Initialized
DEBUG - 2015-03-10 02:42:36 --> URI Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Loader Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Router Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Output Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Security Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Input Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:42:36 --> Language Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Router Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Output Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Security Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Input Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:42:36 --> Language Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Loader Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Loader Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:42:36 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Controller Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:42:36 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:42:36 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Controller Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:42:36 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:42:36 --> Model Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Model Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:42:36 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Controller Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:42:36 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:42:36 --> Model Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Model Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:42:36 --> Model Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Model Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:42:36 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Controller Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:42:36 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:42:36 --> Model Class Initialized
DEBUG - 2015-03-10 02:42:36 --> Model Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Config Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:44:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:44:02 --> URI Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Router Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Output Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Security Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Input Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:44:02 --> Language Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Loader Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Config Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:44:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:44:02 --> URI Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Router Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Output Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Security Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Input Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:44:02 --> Language Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Loader Class Initialized
DEBUG - 2015-03-10 02:44:02 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Config Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:44:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:44:02 --> URI Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Router Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Output Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Security Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Input Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:44:02 --> Language Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Config Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:44:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:44:02 --> URI Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Router Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Loader Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Output Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Security Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Input Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:44:02 --> Language Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Loader Class Initialized
DEBUG - 2015-03-10 02:44:02 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Controller Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:44:02 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:44:02 --> Model Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Model Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:44:02 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Controller Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:44:02 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:44:02 --> Model Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Model Class Initialized
DEBUG - 2015-03-10 02:44:02 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Controller Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:44:02 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:44:02 --> Model Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Controller Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:44:02 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:44:02 --> Model Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Model Class Initialized
DEBUG - 2015-03-10 02:44:02 --> Model Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Config Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Config Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:47:06 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:47:06 --> URI Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Router Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Output Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Security Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Input Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:47:06 --> Language Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Loader Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Config Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:47:06 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:47:06 --> URI Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Router Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Output Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Security Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Input Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:47:06 --> Language Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Loader Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:47:06 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Controller Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:47:06 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:47:06 --> Model Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Model Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Config Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:47:06 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:47:06 --> URI Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Router Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Output Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Security Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Input Class Initialized
DEBUG - 2015-03-10 02:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:47:06 --> Language Class Initialized
DEBUG - 2015-03-10 02:47:07 --> Loader Class Initialized
DEBUG - 2015-03-10 02:47:07 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:47:07 --> Controller Class Initialized
DEBUG - 2015-03-10 02:47:07 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:47:07 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:47:07 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:47:07 --> Model Class Initialized
DEBUG - 2015-03-10 02:47:07 --> Model Class Initialized
DEBUG - 2015-03-10 02:47:07 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:47:07 --> Controller Class Initialized
DEBUG - 2015-03-10 02:47:07 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:47:07 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:47:07 --> Model Class Initialized
DEBUG - 2015-03-10 02:47:07 --> Model Class Initialized
DEBUG - 2015-03-10 02:47:07 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:47:07 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:47:07 --> URI Class Initialized
DEBUG - 2015-03-10 02:47:07 --> Router Class Initialized
DEBUG - 2015-03-10 02:47:07 --> Output Class Initialized
DEBUG - 2015-03-10 02:47:07 --> Security Class Initialized
DEBUG - 2015-03-10 02:47:07 --> Input Class Initialized
DEBUG - 2015-03-10 02:47:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:47:07 --> Language Class Initialized
DEBUG - 2015-03-10 02:47:07 --> Loader Class Initialized
DEBUG - 2015-03-10 02:47:07 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:47:07 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:47:07 --> Controller Class Initialized
DEBUG - 2015-03-10 02:47:07 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:47:07 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:47:07 --> Model Class Initialized
DEBUG - 2015-03-10 02:47:07 --> Model Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Config Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Config Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:48:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:48:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:48:47 --> URI Class Initialized
DEBUG - 2015-03-10 02:48:47 --> URI Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Router Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Router Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Output Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Output Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Security Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Security Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Input Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:48:47 --> Language Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Input Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:48:47 --> Language Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Loader Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Loader Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:48:47 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Controller Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:48:47 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Controller Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:48:47 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:48:47 --> Model Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Model Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:48:47 --> Model Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Model Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Config Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:48:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:48:47 --> URI Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Router Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Output Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Security Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Input Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:48:47 --> Language Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Loader Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Config Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:48:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:48:47 --> URI Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Router Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Output Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Security Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Input Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:48:47 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:48:47 --> Language Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Loader Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:48:47 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Controller Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:48:47 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:48:47 --> Model Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Model Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Controller Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:48:47 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:48:47 --> Model Class Initialized
DEBUG - 2015-03-10 02:48:47 --> Model Class Initialized
DEBUG - 2015-03-10 02:48:50 --> Config Class Initialized
DEBUG - 2015-03-10 02:48:50 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:48:50 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:48:50 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:48:50 --> URI Class Initialized
DEBUG - 2015-03-10 02:48:50 --> Router Class Initialized
DEBUG - 2015-03-10 02:48:50 --> Output Class Initialized
DEBUG - 2015-03-10 02:48:50 --> Security Class Initialized
DEBUG - 2015-03-10 02:48:50 --> Input Class Initialized
DEBUG - 2015-03-10 02:48:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:48:50 --> Language Class Initialized
DEBUG - 2015-03-10 02:48:50 --> Loader Class Initialized
DEBUG - 2015-03-10 02:48:50 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:48:50 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:48:50 --> Controller Class Initialized
DEBUG - 2015-03-10 02:48:50 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:48:50 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:48:50 --> Model Class Initialized
DEBUG - 2015-03-10 02:48:50 --> Model Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Config Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:55:48 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:55:48 --> URI Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Router Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Output Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Security Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Input Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:55:48 --> Language Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Loader Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Config Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:55:48 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:55:48 --> URI Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Router Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Output Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Security Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Input Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:55:48 --> Language Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Loader Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Config Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:55:48 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:55:48 --> URI Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Router Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Output Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Security Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Input Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:55:48 --> Language Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:55:48 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Controller Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:55:48 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:55:48 --> Model Class Initialized
DEBUG - 2015-03-10 02:55:48 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Controller Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:55:48 --> Loader Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:55:48 --> Model Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Model Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Config Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Model Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:55:48 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Controller Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:55:48 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:55:48 --> Model Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Model Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:55:48 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:55:48 --> URI Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Router Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Output Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Security Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Input Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:55:48 --> Language Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Loader Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:55:48 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Controller Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:55:48 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:55:48 --> Model Class Initialized
DEBUG - 2015-03-10 02:55:48 --> Model Class Initialized
DEBUG - 2015-03-10 02:56:01 --> Config Class Initialized
DEBUG - 2015-03-10 02:56:01 --> Hooks Class Initialized
DEBUG - 2015-03-10 02:56:01 --> Utf8 Class Initialized
DEBUG - 2015-03-10 02:56:01 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 02:56:01 --> URI Class Initialized
DEBUG - 2015-03-10 02:56:01 --> Router Class Initialized
DEBUG - 2015-03-10 02:56:01 --> Output Class Initialized
DEBUG - 2015-03-10 02:56:01 --> Security Class Initialized
DEBUG - 2015-03-10 02:56:01 --> Input Class Initialized
DEBUG - 2015-03-10 02:56:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 02:56:01 --> Language Class Initialized
DEBUG - 2015-03-10 02:56:01 --> Loader Class Initialized
DEBUG - 2015-03-10 02:56:01 --> Database Driver Class Initialized
DEBUG - 2015-03-10 02:56:01 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 02:56:01 --> Controller Class Initialized
DEBUG - 2015-03-10 02:56:01 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 02:56:01 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 02:56:01 --> Model Class Initialized
DEBUG - 2015-03-10 02:56:01 --> Model Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Config Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Config Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Config Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Config Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Hooks Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Hooks Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Hooks Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Hooks Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Utf8 Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Utf8 Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Utf8 Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Utf8 Class Initialized
DEBUG - 2015-03-10 10:45:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 10:45:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 10:45:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 10:45:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 10:45:15 --> URI Class Initialized
DEBUG - 2015-03-10 10:45:15 --> URI Class Initialized
DEBUG - 2015-03-10 10:45:15 --> URI Class Initialized
DEBUG - 2015-03-10 10:45:15 --> URI Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Router Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Router Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Router Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Router Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Output Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Output Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Output Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Output Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Security Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Security Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Security Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Security Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Input Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Input Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 10:45:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 10:45:15 --> Language Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Input Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Language Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 10:45:15 --> Language Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Input Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 10:45:15 --> Language Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Loader Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Loader Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Loader Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Loader Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Database Driver Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Database Driver Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Database Driver Class Initialized
DEBUG - 2015-03-10 10:45:15 --> Database Driver Class Initialized
ERROR - 2015-03-10 10:45:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-10 10:45:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-10 10:45:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-10 10:45:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-10 10:45:15 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'root'@'localhost' (using password: NO) /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-10 10:45:15 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'root'@'localhost' (using password: NO) /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-10 10:45:15 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'root'@'localhost' (using password: NO) /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-10 10:45:15 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'root'@'localhost' (using password: NO) /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-10 10:45:15 --> Unable to connect to the database
ERROR - 2015-03-10 10:45:15 --> Unable to connect to the database
ERROR - 2015-03-10 10:45:15 --> Unable to connect to the database
ERROR - 2015-03-10 10:45:15 --> Unable to connect to the database
DEBUG - 2015-03-10 10:45:15 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-10 10:45:15 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-10 10:45:15 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-10 10:45:15 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-10 10:59:53 --> Config Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Config Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Config Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Hooks Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Hooks Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Hooks Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Config Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Hooks Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Utf8 Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Utf8 Class Initialized
DEBUG - 2015-03-10 10:59:53 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 10:59:53 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 10:59:53 --> Utf8 Class Initialized
DEBUG - 2015-03-10 10:59:53 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 10:59:53 --> Utf8 Class Initialized
DEBUG - 2015-03-10 10:59:53 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 10:59:53 --> URI Class Initialized
DEBUG - 2015-03-10 10:59:53 --> URI Class Initialized
DEBUG - 2015-03-10 10:59:53 --> URI Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Router Class Initialized
DEBUG - 2015-03-10 10:59:53 --> URI Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Router Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Router Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Router Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Output Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Output Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Output Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Output Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Security Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Security Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Security Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Security Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Input Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Input Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 10:59:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 10:59:53 --> Language Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Input Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 10:59:53 --> Language Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Language Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Input Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 10:59:53 --> Language Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Loader Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Loader Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Loader Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Loader Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Database Driver Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Database Driver Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Database Driver Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Database Driver Class Initialized
ERROR - 2015-03-10 10:59:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-10 10:59:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-10 10:59:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-10 10:59:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 10:59:53 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 10:59:53 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 10:59:53 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Controller Class Initialized
DEBUG - 2015-03-10 10:59:53 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Controller Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Controller Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Controller Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 10:59:53 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 10:59:53 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 10:59:53 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 10:59:53 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 10:59:53 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 10:59:53 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 10:59:53 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 10:59:53 --> Model Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Model Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Model Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Model Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Model Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Model Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Model Class Initialized
DEBUG - 2015-03-10 10:59:53 --> Model Class Initialized
DEBUG - 2015-03-10 10:59:53 --> DB Transaction Failure
ERROR - 2015-03-10 10:59:53 --> Query error: Table 'nyc.agents' doesn't exist
DEBUG - 2015-03-10 10:59:53 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-10 11:00:00 --> Config Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Config Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Config Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:00:00 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:00:00 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:00:00 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:00:00 --> Config Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:00:00 --> URI Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:00:00 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:00:00 --> URI Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Router Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:00:00 --> URI Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Router Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:00:00 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:00:00 --> Router Class Initialized
DEBUG - 2015-03-10 11:00:00 --> URI Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Output Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Output Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Router Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Security Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Output Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Security Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Output Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Security Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Input Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:00:00 --> Language Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Input Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Security Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Input Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:00:00 --> Language Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:00:00 --> Input Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:00:00 --> Language Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Language Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Loader Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Loader Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Loader Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Loader Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:00:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:00:00 --> Database Driver Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Database Driver Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:00:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-10 11:00:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-10 11:00:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:00:00 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Controller Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:00:00 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:00:00 --> Model Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Model Class Initialized
DEBUG - 2015-03-10 11:00:00 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:00:00 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Controller Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Controller Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:00:00 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:00:00 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Controller Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:00:00 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:00:00 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:00:00 --> Model Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Model Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Model Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:00:00 --> Model Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Model Class Initialized
DEBUG - 2015-03-10 11:00:00 --> Model Class Initialized
DEBUG - 2015-03-10 11:00:00 --> DB Transaction Failure
ERROR - 2015-03-10 11:00:00 --> Query error: Table 'nyc.agents' doesn't exist
DEBUG - 2015-03-10 11:00:00 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-10 11:38:00 --> Config Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Config Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Config Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Config Class Initialized
DEBUG - 2015-03-10 11:38:00 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:38:00 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:38:00 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:38:00 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:38:00 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:38:00 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:38:00 --> URI Class Initialized
DEBUG - 2015-03-10 11:38:00 --> URI Class Initialized
DEBUG - 2015-03-10 11:38:00 --> URI Class Initialized
DEBUG - 2015-03-10 11:38:00 --> URI Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Router Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Router Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Router Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Router Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Output Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Output Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Output Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Output Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Security Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Security Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Security Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Security Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Input Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:38:00 --> Input Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:38:00 --> Input Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:38:00 --> Input Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:38:00 --> Language Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Language Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Language Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Language Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Loader Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Loader Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Loader Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Loader Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Database Driver Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Database Driver Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Database Driver Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:38:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-10 11:38:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-10 11:38:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-10 11:38:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:38:00 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:38:00 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:38:00 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Controller Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Controller Class Initialized
DEBUG - 2015-03-10 11:38:00 --> Controller Class Initialized
DEBUG - 2015-03-10 11:38:01 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:38:01 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:38:01 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:38:01 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:38:01 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:38:01 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:38:01 --> Controller Class Initialized
DEBUG - 2015-03-10 11:38:01 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:38:01 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:38:01 --> Model Class Initialized
DEBUG - 2015-03-10 11:38:01 --> Model Class Initialized
DEBUG - 2015-03-10 11:38:01 --> Model Class Initialized
DEBUG - 2015-03-10 11:38:01 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:38:01 --> Model Class Initialized
DEBUG - 2015-03-10 11:38:01 --> Model Class Initialized
DEBUG - 2015-03-10 11:38:01 --> Model Class Initialized
DEBUG - 2015-03-10 11:38:01 --> Model Class Initialized
DEBUG - 2015-03-10 11:38:01 --> Model Class Initialized
DEBUG - 2015-03-10 11:38:01 --> DB Transaction Failure
ERROR - 2015-03-10 11:38:01 --> Query error: Table 'nyc.agents' doesn't exist
DEBUG - 2015-03-10 11:38:01 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-10 11:45:42 --> Config Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Config Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:45:42 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:45:42 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:45:42 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:45:42 --> Config Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:45:42 --> URI Class Initialized
DEBUG - 2015-03-10 11:45:42 --> URI Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:45:42 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:45:42 --> Router Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Router Class Initialized
DEBUG - 2015-03-10 11:45:42 --> URI Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Config Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Output Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Output Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Router Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:45:42 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:45:42 --> Security Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Security Class Initialized
DEBUG - 2015-03-10 11:45:42 --> URI Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Input Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Output Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:45:42 --> Language Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Input Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:45:42 --> Router Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Language Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Security Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Input Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Output Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:45:42 --> Language Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Security Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Loader Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Input Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:45:42 --> Language Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Loader Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Loader Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:45:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:45:42 --> Loader Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:45:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:45:42 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:45:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:45:42 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Controller Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:45:42 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Controller Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:45:42 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:45:42 --> Model Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:45:42 --> Model Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Model Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Model Class Initialized
DEBUG - 2015-03-10 11:45:42 --> DB Transaction Failure
ERROR - 2015-03-10 11:45:42 --> Query error: Table 'nyc.agents' doesn't exist
DEBUG - 2015-03-10 11:45:42 --> Database Driver Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Language file loaded: language/english/db_lang.php
ERROR - 2015-03-10 11:45:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:45:42 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Controller Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:45:42 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:45:42 --> Model Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Model Class Initialized
DEBUG - 2015-03-10 11:45:42 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Controller Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:45:42 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:45:42 --> Model Class Initialized
DEBUG - 2015-03-10 11:45:42 --> Model Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Config Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:46:01 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:46:01 --> Config Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:46:01 --> URI Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:46:01 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:46:01 --> Router Class Initialized
DEBUG - 2015-03-10 11:46:01 --> URI Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Config Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Output Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:46:01 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:46:01 --> URI Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Security Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Router Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Output Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Router Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Config Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Security Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:46:01 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:46:01 --> Output Class Initialized
DEBUG - 2015-03-10 11:46:01 --> URI Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Security Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Input Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Input Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:46:01 --> Input Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Language Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:46:01 --> Language Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Language Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Router Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Loader Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Loader Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Loader Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Output Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Security Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Input Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:46:01 --> Language Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:46:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:46:01 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:46:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:46:01 --> Loader Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:46:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:46:01 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Controller Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:46:01 --> Database Driver Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Helper loaded: inflector_helper
ERROR - 2015-03-10 11:46:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:46:01 --> Model Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Model Class Initialized
DEBUG - 2015-03-10 11:46:01 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Controller Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:46:01 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:46:01 --> Model Class Initialized
DEBUG - 2015-03-10 11:46:01 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Controller Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:46:01 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:46:01 --> Model Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Model Class Initialized
DEBUG - 2015-03-10 11:46:01 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Controller Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:46:01 --> Model Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:46:01 --> Model Class Initialized
DEBUG - 2015-03-10 11:46:01 --> Model Class Initialized
DEBUG - 2015-03-10 11:46:01 --> DB Transaction Failure
ERROR - 2015-03-10 11:46:01 --> Query error: Table 'nyc.agents' doesn't exist
DEBUG - 2015-03-10 11:46:01 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-10 11:47:12 --> Config Class Initialized
DEBUG - 2015-03-10 11:47:12 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:47:12 --> Config Class Initialized
DEBUG - 2015-03-10 11:47:12 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:47:12 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:47:12 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:47:12 --> Config Class Initialized
DEBUG - 2015-03-10 11:47:12 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:47:12 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:47:12 --> Config Class Initialized
DEBUG - 2015-03-10 11:47:12 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:47:12 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:47:12 --> URI Class Initialized
DEBUG - 2015-03-10 11:47:12 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:47:12 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:47:12 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:47:12 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:47:12 --> URI Class Initialized
DEBUG - 2015-03-10 11:47:12 --> URI Class Initialized
DEBUG - 2015-03-10 11:47:12 --> Router Class Initialized
DEBUG - 2015-03-10 11:47:12 --> URI Class Initialized
DEBUG - 2015-03-10 11:47:12 --> Output Class Initialized
DEBUG - 2015-03-10 11:47:12 --> Router Class Initialized
DEBUG - 2015-03-10 11:47:12 --> Security Class Initialized
DEBUG - 2015-03-10 11:47:12 --> Output Class Initialized
DEBUG - 2015-03-10 11:47:12 --> Security Class Initialized
DEBUG - 2015-03-10 11:47:12 --> Router Class Initialized
DEBUG - 2015-03-10 11:47:12 --> Router Class Initialized
DEBUG - 2015-03-10 11:47:12 --> Input Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:47:13 --> Language Class Initialized
DEBUG - 2015-03-10 11:47:12 --> Output Class Initialized
DEBUG - 2015-03-10 11:47:12 --> Output Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Security Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Security Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Input Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:47:13 --> Language Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Input Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:47:13 --> Language Class Initialized
DEBUG - 2015-03-10 11:47:12 --> Input Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Loader Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:47:13 --> Loader Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Language Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Loader Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Loader Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Database Driver Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Database Driver Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:47:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-10 11:47:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-10 11:47:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:47:13 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:47:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:47:13 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Controller Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:47:13 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Controller Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:47:13 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:47:13 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:47:13 --> Model Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Model Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Model Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Model Class Initialized
DEBUG - 2015-03-10 11:47:13 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Controller Class Initialized
DEBUG - 2015-03-10 11:47:13 --> DB Transaction Failure
ERROR - 2015-03-10 11:47:13 --> Query error: Table 'nyc.agents' doesn't exist
DEBUG - 2015-03-10 11:47:13 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Controller Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-10 11:47:13 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:47:13 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:47:13 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:47:13 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:47:13 --> Model Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Model Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Model Class Initialized
DEBUG - 2015-03-10 11:47:13 --> Model Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Config Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:49:12 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:49:12 --> Config Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Config Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:49:12 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:49:12 --> URI Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Config Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:49:12 --> URI Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Router Class Initialized
DEBUG - 2015-03-10 11:49:12 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:49:12 --> Router Class Initialized
DEBUG - 2015-03-10 11:49:12 --> URI Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:49:12 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:49:12 --> Output Class Initialized
DEBUG - 2015-03-10 11:49:12 --> URI Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Security Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Router Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Input Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:49:12 --> Language Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Output Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Output Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Router Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Security Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Security Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Output Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Input Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:49:12 --> Language Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Security Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Input Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:49:12 --> Language Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Loader Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Input Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:49:12 --> Language Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Loader Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Loader Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Loader Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:49:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:49:12 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:49:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:49:12 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:49:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:49:12 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:49:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:49:12 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:49:12 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Controller Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Controller Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:49:12 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:49:12 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:49:12 --> Model Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Model Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Controller Class Initialized
DEBUG - 2015-03-10 11:49:12 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Controller Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:49:12 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:49:12 --> Model Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Model Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:49:12 --> Model Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Model Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:49:12 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:49:12 --> Model Class Initialized
DEBUG - 2015-03-10 11:49:12 --> Model Class Initialized
DEBUG - 2015-03-10 11:49:12 --> DB Transaction Failure
ERROR - 2015-03-10 11:49:12 --> Query error: Table 'nyc.agents' doesn't exist
DEBUG - 2015-03-10 11:49:12 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-10 11:49:49 --> Config Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:49:49 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:49:49 --> Config Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:49:49 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:49:49 --> URI Class Initialized
DEBUG - 2015-03-10 11:49:49 --> URI Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Router Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Output Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Config Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Router Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Security Class Initialized
DEBUG - 2015-03-10 11:49:49 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:49:49 --> URI Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Output Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Input Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:49:49 --> Language Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Router Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Security Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Input Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:49:49 --> Output Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Language Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Security Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Config Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:49:49 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:49:49 --> URI Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Input Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:49:49 --> Language Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Loader Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Router Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Output Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Loader Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Security Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Input Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:49:49 --> Language Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Loader Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:49:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:49:49 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:49:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:49:49 --> Loader Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:49:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:49:49 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Controller Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:49:49 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:49:49 --> Model Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Model Class Initialized
DEBUG - 2015-03-10 11:49:49 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Controller Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:49:49 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:49:49 --> Model Class Initialized
DEBUG - 2015-03-10 11:49:49 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Controller Class Initialized
DEBUG - 2015-03-10 11:49:49 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:49:49 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:49:49 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:49:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:49:49 --> Model Class Initialized
DEBUG - 2015-03-10 11:49:50 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:49:50 --> Model Class Initialized
DEBUG - 2015-03-10 11:49:50 --> Controller Class Initialized
DEBUG - 2015-03-10 11:49:50 --> Model Class Initialized
DEBUG - 2015-03-10 11:49:50 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:49:50 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:49:50 --> Model Class Initialized
DEBUG - 2015-03-10 11:49:50 --> Model Class Initialized
DEBUG - 2015-03-10 11:49:50 --> DB Transaction Failure
ERROR - 2015-03-10 11:49:50 --> Query error: Table 'nyc.agents' doesn't exist
DEBUG - 2015-03-10 11:49:50 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-10 11:50:32 --> Config Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:50:32 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:50:32 --> URI Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Config Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:50:32 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:50:32 --> Config Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Config Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Router Class Initialized
DEBUG - 2015-03-10 11:50:32 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:50:32 --> URI Class Initialized
DEBUG - 2015-03-10 11:50:32 --> URI Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Output Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Router Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:50:32 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:50:32 --> Security Class Initialized
DEBUG - 2015-03-10 11:50:32 --> URI Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Router Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Output Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Router Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Input Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:50:32 --> Language Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Output Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Security Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Output Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Security Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Input Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:50:32 --> Language Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Security Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Input Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:50:32 --> Language Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Loader Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Input Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:50:32 --> Language Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Loader Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Loader Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Database Driver Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Loader Class Initialized
ERROR - 2015-03-10 11:50:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:50:32 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:50:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:50:32 --> Database Driver Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:50:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-10 11:50:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:50:32 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Controller Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:50:32 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:50:32 --> Model Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Model Class Initialized
DEBUG - 2015-03-10 11:50:32 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Controller Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:50:32 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Controller Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:50:32 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:50:32 --> Model Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:50:32 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Controller Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Model Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Model Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:50:32 --> Model Class Initialized
DEBUG - 2015-03-10 11:50:32 --> DB Transaction Failure
ERROR - 2015-03-10 11:50:32 --> Query error: Table 'nyc.agents' doesn't exist
DEBUG - 2015-03-10 11:50:32 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-10 11:50:32 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:50:32 --> Model Class Initialized
DEBUG - 2015-03-10 11:50:32 --> Model Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Config Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Config Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:51:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:51:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:51:46 --> Config Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:51:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:51:46 --> URI Class Initialized
DEBUG - 2015-03-10 11:51:46 --> URI Class Initialized
DEBUG - 2015-03-10 11:51:46 --> URI Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Router Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Config Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Router Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:51:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:51:46 --> Output Class Initialized
DEBUG - 2015-03-10 11:51:46 --> URI Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Output Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Router Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Security Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Security Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Output Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Input Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Input Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:51:46 --> Language Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Security Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Router Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Output Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Input Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:51:46 --> Security Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Language Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Input Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:51:46 --> Language Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:51:46 --> Language Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Loader Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Loader Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Loader Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Loader Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:51:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:51:46 --> Database Driver Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:51:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:51:46 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:51:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-10 11:51:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:51:46 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Controller Class Initialized
DEBUG - 2015-03-10 11:51:46 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:51:46 --> Controller Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:51:46 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:51:46 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Controller Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Model Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:51:46 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:51:46 --> Model Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Model Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Model Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:51:46 --> Model Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Model Class Initialized
DEBUG - 2015-03-10 11:51:46 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Controller Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:51:46 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:51:46 --> Model Class Initialized
DEBUG - 2015-03-10 11:51:46 --> Model Class Initialized
DEBUG - 2015-03-10 11:51:46 --> DB Transaction Failure
ERROR - 2015-03-10 11:51:46 --> Query error: Table 'nyc.agents' doesn't exist
DEBUG - 2015-03-10 11:51:46 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-10 11:51:47 --> Config Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:51:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:51:47 --> Config Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:51:47 --> URI Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Config Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:51:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:51:47 --> Router Class Initialized
DEBUG - 2015-03-10 11:51:47 --> URI Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Config Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:51:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:51:47 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:51:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:51:47 --> Output Class Initialized
DEBUG - 2015-03-10 11:51:47 --> URI Class Initialized
DEBUG - 2015-03-10 11:51:47 --> URI Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Security Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Router Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Router Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Input Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:51:47 --> Language Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Output Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Output Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Security Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Security Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Input Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Router Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:51:47 --> Language Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Output Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Input Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:51:47 --> Language Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Security Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Input Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:51:47 --> Language Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Loader Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Loader Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Loader Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Loader Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:51:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:51:47 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:51:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:51:47 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:51:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:51:47 --> Database Driver Class Initialized
DEBUG - 2015-03-10 11:51:47 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Controller Class Initialized
ERROR - 2015-03-10 11:51:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:51:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:51:47 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Controller Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:51:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:51:47 --> Model Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Model Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:51:47 --> Model Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Model Class Initialized
DEBUG - 2015-03-10 11:51:47 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Controller Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:51:47 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:51:47 --> Model Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Model Class Initialized
DEBUG - 2015-03-10 11:51:47 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Controller Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:51:47 --> DB Transaction Failure
ERROR - 2015-03-10 11:51:47 --> Query error: Table 'nyc.agents' doesn't exist
DEBUG - 2015-03-10 11:51:47 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-10 11:51:47 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:51:47 --> Model Class Initialized
DEBUG - 2015-03-10 11:51:47 --> Model Class Initialized
DEBUG - 2015-03-10 11:54:15 --> Config Class Initialized
DEBUG - 2015-03-10 11:54:15 --> Hooks Class Initialized
DEBUG - 2015-03-10 11:54:15 --> Utf8 Class Initialized
DEBUG - 2015-03-10 11:54:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 11:54:15 --> URI Class Initialized
DEBUG - 2015-03-10 11:54:15 --> Router Class Initialized
DEBUG - 2015-03-10 11:54:15 --> Output Class Initialized
DEBUG - 2015-03-10 11:54:15 --> Security Class Initialized
DEBUG - 2015-03-10 11:54:15 --> Input Class Initialized
DEBUG - 2015-03-10 11:54:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 11:54:15 --> Language Class Initialized
DEBUG - 2015-03-10 11:54:15 --> Loader Class Initialized
DEBUG - 2015-03-10 11:54:15 --> Database Driver Class Initialized
ERROR - 2015-03-10 11:54:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 11:54:15 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 11:54:15 --> Controller Class Initialized
DEBUG - 2015-03-10 11:54:15 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 11:54:15 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 11:54:15 --> Model Class Initialized
DEBUG - 2015-03-10 11:54:15 --> Model Class Initialized
ERROR - 2015-03-10 11:54:15 --> Severity: Notice  --> Undefined index: email /Volumes/Data/www/nyc/server/application/models/users_model.php 10
DEBUG - 2015-03-10 12:03:38 --> Config Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Hooks Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Utf8 Class Initialized
DEBUG - 2015-03-10 12:03:38 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 12:03:38 --> Config Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Hooks Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Utf8 Class Initialized
DEBUG - 2015-03-10 12:03:38 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 12:03:38 --> URI Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Config Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Hooks Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Utf8 Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Router Class Initialized
DEBUG - 2015-03-10 12:03:38 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 12:03:38 --> URI Class Initialized
DEBUG - 2015-03-10 12:03:38 --> URI Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Output Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Config Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Security Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Router Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Output Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Hooks Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Router Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Utf8 Class Initialized
DEBUG - 2015-03-10 12:03:38 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 12:03:38 --> Input Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 12:03:38 --> Language Class Initialized
DEBUG - 2015-03-10 12:03:38 --> URI Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Output Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Router Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Security Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Input Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Output Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 12:03:38 --> Language Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Security Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Security Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Input Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Input Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 12:03:38 --> Loader Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Language Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Loader Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Loader Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Database Driver Class Initialized
ERROR - 2015-03-10 12:03:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 12:03:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 12:03:38 --> Language Class Initialized
DEBUG - 2015-03-10 12:03:38 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Controller Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 12:03:38 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 12:03:38 --> Model Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Model Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Database Driver Class Initialized
ERROR - 2015-03-10 12:03:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 12:03:38 --> Database Driver Class Initialized
ERROR - 2015-03-10 12:03:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 12:03:38 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Controller Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 12:03:38 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Controller Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 12:03:38 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 12:03:38 --> Model Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Loader Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Model Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 12:03:38 --> Model Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Model Class Initialized
DEBUG - 2015-03-10 12:03:38 --> DB Transaction Failure
ERROR - 2015-03-10 12:03:38 --> Query error: Table 'nyc.agents' doesn't exist
DEBUG - 2015-03-10 12:03:38 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-10 12:03:38 --> Database Driver Class Initialized
ERROR - 2015-03-10 12:03:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 12:03:38 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Controller Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 12:03:38 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 12:03:38 --> Model Class Initialized
DEBUG - 2015-03-10 12:03:38 --> Model Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Config Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Config Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Hooks Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Hooks Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Utf8 Class Initialized
DEBUG - 2015-03-10 12:04:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 12:04:15 --> Utf8 Class Initialized
DEBUG - 2015-03-10 12:04:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 12:04:15 --> URI Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Config Class Initialized
DEBUG - 2015-03-10 12:04:15 --> URI Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Hooks Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Utf8 Class Initialized
DEBUG - 2015-03-10 12:04:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 12:04:15 --> Router Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Router Class Initialized
DEBUG - 2015-03-10 12:04:15 --> URI Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Output Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Config Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Output Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Hooks Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Security Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Security Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Utf8 Class Initialized
DEBUG - 2015-03-10 12:04:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 12:04:15 --> URI Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Input Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 12:04:15 --> Language Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Router Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Router Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Output Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Input Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 12:04:15 --> Language Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Security Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Input Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 12:04:15 --> Language Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Output Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Loader Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Security Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Loader Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Input Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 12:04:15 --> Language Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Loader Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Loader Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Database Driver Class Initialized
ERROR - 2015-03-10 12:04:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 12:04:15 --> Database Driver Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Database Driver Class Initialized
ERROR - 2015-03-10 12:04:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-10 12:04:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 12:04:15 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 12:04:15 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Controller Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Controller Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 12:04:15 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 12:04:15 --> Controller Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 12:04:15 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 12:04:15 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 12:04:15 --> Database Driver Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Model Class Initialized
ERROR - 2015-03-10 12:04:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 12:04:15 --> Model Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 12:04:15 --> Model Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Model Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Model Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Model Class Initialized
DEBUG - 2015-03-10 12:04:15 --> DB Transaction Failure
ERROR - 2015-03-10 12:04:15 --> Query error: Table 'nyc.agents' doesn't exist
DEBUG - 2015-03-10 12:04:15 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-10 12:04:15 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Controller Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 12:04:15 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 12:04:15 --> Model Class Initialized
DEBUG - 2015-03-10 12:04:15 --> Model Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Config Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Hooks Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Utf8 Class Initialized
DEBUG - 2015-03-10 12:04:38 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 12:04:38 --> Config Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Hooks Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Utf8 Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Config Class Initialized
DEBUG - 2015-03-10 12:04:38 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 12:04:38 --> Hooks Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Utf8 Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Config Class Initialized
DEBUG - 2015-03-10 12:04:38 --> URI Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Hooks Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Utf8 Class Initialized
DEBUG - 2015-03-10 12:04:38 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 12:04:38 --> URI Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Router Class Initialized
DEBUG - 2015-03-10 12:04:38 --> URI Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Router Class Initialized
DEBUG - 2015-03-10 12:04:38 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 12:04:38 --> Output Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Router Class Initialized
DEBUG - 2015-03-10 12:04:38 --> URI Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Security Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Output Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Output Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Input Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 12:04:38 --> Security Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Language Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Security Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Router Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Input Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 12:04:38 --> Language Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Output Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Security Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Input Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 12:04:38 --> Language Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Loader Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Input Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 12:04:38 --> Language Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Loader Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Loader Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Database Driver Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Loader Class Initialized
ERROR - 2015-03-10 12:04:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 12:04:38 --> Database Driver Class Initialized
ERROR - 2015-03-10 12:04:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 12:04:38 --> Database Driver Class Initialized
ERROR - 2015-03-10 12:04:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 12:04:38 --> Database Driver Class Initialized
ERROR - 2015-03-10 12:04:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 12:04:38 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Controller Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 12:04:38 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Controller Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 12:04:38 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 12:04:38 --> Model Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Model Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 12:04:38 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Controller Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Model Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Model Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 12:04:38 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 12:04:38 --> Model Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Model Class Initialized
DEBUG - 2015-03-10 12:04:38 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Controller Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 12:04:38 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 12:04:38 --> Model Class Initialized
DEBUG - 2015-03-10 12:04:38 --> Model Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Config Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Hooks Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Utf8 Class Initialized
DEBUG - 2015-03-10 12:04:55 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 12:04:55 --> URI Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Config Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Hooks Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Utf8 Class Initialized
DEBUG - 2015-03-10 12:04:55 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 12:04:55 --> Router Class Initialized
DEBUG - 2015-03-10 12:04:55 --> URI Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Output Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Router Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Security Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Output Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Config Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Hooks Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Utf8 Class Initialized
DEBUG - 2015-03-10 12:04:55 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 12:04:55 --> Security Class Initialized
DEBUG - 2015-03-10 12:04:55 --> URI Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Config Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Input Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 12:04:55 --> Router Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Language Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Output Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Security Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Hooks Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Input Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 12:04:55 --> Utf8 Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Language Class Initialized
DEBUG - 2015-03-10 12:04:55 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 12:04:55 --> URI Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Router Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Input Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Output Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 12:04:55 --> Language Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Loader Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Security Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Input Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-10 12:04:55 --> Language Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Loader Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Loader Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Loader Class Initialized
DEBUG - 2015-03-10 12:04:55 --> Database Driver Class Initialized
ERROR - 2015-03-10 12:04:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 12:04:55 --> Database Driver Class Initialized
ERROR - 2015-03-10 12:04:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 12:04:56 --> Database Driver Class Initialized
ERROR - 2015-03-10 12:04:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 12:04:56 --> Database Driver Class Initialized
DEBUG - 2015-03-10 12:04:56 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 12:04:56 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 12:04:56 --> Controller Class Initialized
DEBUG - 2015-03-10 12:04:56 --> Controller Class Initialized
ERROR - 2015-03-10 12:04:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-10 12:04:56 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 12:04:56 --> Controller Class Initialized
DEBUG - 2015-03-10 12:04:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 12:04:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 12:04:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 12:04:56 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 12:04:56 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 12:04:56 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 12:04:56 --> Model Class Initialized
DEBUG - 2015-03-10 12:04:56 --> Model Class Initialized
DEBUG - 2015-03-10 12:04:56 --> Model Class Initialized
DEBUG - 2015-03-10 12:04:56 --> Model Class Initialized
DEBUG - 2015-03-10 12:04:56 --> Model Class Initialized
DEBUG - 2015-03-10 12:04:56 --> Model Class Initialized
DEBUG - 2015-03-10 12:04:56 --> XML-RPC Class Initialized
DEBUG - 2015-03-10 12:04:56 --> Controller Class Initialized
DEBUG - 2015-03-10 12:04:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-10 12:04:56 --> Helper loaded: inflector_helper
DEBUG - 2015-03-10 12:04:56 --> Model Class Initialized
DEBUG - 2015-03-10 12:04:56 --> Model Class Initialized
