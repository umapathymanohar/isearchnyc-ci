<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-12-23 10:17:00 --> Config Class Initialized
DEBUG - 2014-12-23 10:17:00 --> Hooks Class Initialized
DEBUG - 2014-12-23 10:17:00 --> Utf8 Class Initialized
DEBUG - 2014-12-23 10:17:00 --> UTF-8 Support Enabled
DEBUG - 2014-12-23 10:17:00 --> URI Class Initialized
DEBUG - 2014-12-23 10:17:00 --> Router Class Initialized
DEBUG - 2014-12-23 10:17:00 --> Output Class Initialized
DEBUG - 2014-12-23 10:17:00 --> Security Class Initialized
DEBUG - 2014-12-23 10:17:00 --> Input Class Initialized
DEBUG - 2014-12-23 10:17:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-23 10:17:00 --> Language Class Initialized
DEBUG - 2014-12-23 10:17:00 --> Loader Class Initialized
DEBUG - 2014-12-23 10:17:00 --> Database Driver Class Initialized
ERROR - 2014-12-23 10:17:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-23 10:17:00 --> XML-RPC Class Initialized
DEBUG - 2014-12-23 10:17:00 --> Controller Class Initialized
DEBUG - 2014-12-23 10:17:00 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-23 10:17:00 --> Helper loaded: inflector_helper
DEBUG - 2014-12-23 10:17:02 --> Model Class Initialized
DEBUG - 2014-12-23 10:17:02 --> Model Class Initialized
DEBUG - 2014-12-23 10:17:02 --> File loaded: application/views/email/registration.php
DEBUG - 2014-12-23 10:17:02 --> Email Class Initialized
DEBUG - 2014-12-23 10:17:05 --> Language file loaded: language/english/email_lang.php
DEBUG - 2014-12-23 10:18:30 --> Config Class Initialized
DEBUG - 2014-12-23 10:18:30 --> Hooks Class Initialized
DEBUG - 2014-12-23 10:18:30 --> Utf8 Class Initialized
DEBUG - 2014-12-23 10:18:30 --> UTF-8 Support Enabled
DEBUG - 2014-12-23 10:18:30 --> URI Class Initialized
DEBUG - 2014-12-23 10:18:30 --> Router Class Initialized
DEBUG - 2014-12-23 10:18:30 --> Output Class Initialized
DEBUG - 2014-12-23 10:18:30 --> Security Class Initialized
DEBUG - 2014-12-23 10:18:30 --> Input Class Initialized
DEBUG - 2014-12-23 10:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-23 10:18:30 --> Language Class Initialized
DEBUG - 2014-12-23 10:18:30 --> Loader Class Initialized
DEBUG - 2014-12-23 10:18:31 --> Database Driver Class Initialized
ERROR - 2014-12-23 10:18:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-23 10:18:31 --> XML-RPC Class Initialized
DEBUG - 2014-12-23 10:18:31 --> Controller Class Initialized
DEBUG - 2014-12-23 10:18:31 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-23 10:18:31 --> Helper loaded: inflector_helper
DEBUG - 2014-12-23 10:18:32 --> Model Class Initialized
DEBUG - 2014-12-23 10:18:32 --> Model Class Initialized
DEBUG - 2014-12-23 10:18:32 --> File loaded: application/views/email/registration.php
DEBUG - 2014-12-23 10:18:32 --> Email Class Initialized
DEBUG - 2014-12-23 10:18:34 --> Language file loaded: language/english/email_lang.php
DEBUG - 2014-12-23 10:22:33 --> Config Class Initialized
DEBUG - 2014-12-23 10:22:33 --> Hooks Class Initialized
DEBUG - 2014-12-23 10:22:33 --> Utf8 Class Initialized
DEBUG - 2014-12-23 10:22:33 --> UTF-8 Support Enabled
DEBUG - 2014-12-23 10:22:33 --> URI Class Initialized
DEBUG - 2014-12-23 10:22:33 --> Router Class Initialized
DEBUG - 2014-12-23 10:22:33 --> Output Class Initialized
DEBUG - 2014-12-23 10:22:33 --> Security Class Initialized
DEBUG - 2014-12-23 10:22:33 --> Input Class Initialized
DEBUG - 2014-12-23 10:22:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-23 10:22:33 --> Language Class Initialized
DEBUG - 2014-12-23 10:22:33 --> Loader Class Initialized
DEBUG - 2014-12-23 10:22:33 --> Database Driver Class Initialized
ERROR - 2014-12-23 10:22:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-23 10:22:33 --> XML-RPC Class Initialized
DEBUG - 2014-12-23 10:22:33 --> Controller Class Initialized
DEBUG - 2014-12-23 10:22:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-23 10:22:33 --> Helper loaded: inflector_helper
DEBUG - 2014-12-23 10:22:35 --> Model Class Initialized
DEBUG - 2014-12-23 10:22:35 --> Model Class Initialized
ERROR - 2014-12-23 10:22:35 --> Severity: Notice  --> Undefined variable: callname /Volumes/Data/www/thunderbirds/server/application/models/users_model.php 19
ERROR - 2014-12-23 10:22:35 --> Severity: Notice  --> Undefined variable: firstname /Volumes/Data/www/thunderbirds/server/application/models/users_model.php 19
ERROR - 2014-12-23 10:22:35 --> Severity: Notice  --> Undefined variable: lastname /Volumes/Data/www/thunderbirds/server/application/models/users_model.php 19
ERROR - 2014-12-23 10:22:35 --> Severity: Notice  --> Undefined variable: gender /Volumes/Data/www/thunderbirds/server/application/models/users_model.php 19
ERROR - 2014-12-23 10:22:35 --> Severity: Notice  --> Undefined variable: dob /Volumes/Data/www/thunderbirds/server/application/models/users_model.php 19
ERROR - 2014-12-23 10:22:35 --> Severity: Notice  --> Undefined variable: password /Volumes/Data/www/thunderbirds/server/application/models/users_model.php 19
ERROR - 2014-12-23 10:22:35 --> Severity: Notice  --> Undefined variable: type /Volumes/Data/www/thunderbirds/server/application/models/users_model.php 19
ERROR - 2014-12-23 10:22:35 --> Severity: Notice  --> Undefined variable: status /Volumes/Data/www/thunderbirds/server/application/models/users_model.php 19
ERROR - 2014-12-23 10:22:35 --> Severity: Notice  --> Undefined variable: newsletter /Volumes/Data/www/thunderbirds/server/application/models/users_model.php 19
ERROR - 2014-12-23 10:22:35 --> Severity: Notice  --> Undefined variable: email /Volumes/Data/www/thunderbirds/server/application/models/users_model.php 19
ERROR - 2014-12-23 10:22:35 --> Severity: Notice  --> Undefined variable: parent_callname /Volumes/Data/www/thunderbirds/server/application/models/users_model.php 19
DEBUG - 2014-12-23 10:22:38 --> DB Transaction Failure
ERROR - 2014-12-23 10:22:38 --> Query error: Column 'sugarcrm_id' cannot be null
DEBUG - 2014-12-23 10:22:38 --> Language file loaded: language/english/db_lang.php
ERROR - 2014-12-23 10:22:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/server/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/server/system/core/Common.php 442
DEBUG - 2014-12-23 10:23:42 --> Config Class Initialized
DEBUG - 2014-12-23 10:23:42 --> Hooks Class Initialized
DEBUG - 2014-12-23 10:23:42 --> Utf8 Class Initialized
DEBUG - 2014-12-23 10:23:42 --> UTF-8 Support Enabled
DEBUG - 2014-12-23 10:23:42 --> URI Class Initialized
DEBUG - 2014-12-23 10:23:42 --> Router Class Initialized
DEBUG - 2014-12-23 10:23:42 --> Output Class Initialized
DEBUG - 2014-12-23 10:23:42 --> Security Class Initialized
DEBUG - 2014-12-23 10:23:42 --> Input Class Initialized
DEBUG - 2014-12-23 10:23:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-23 10:23:42 --> Language Class Initialized
DEBUG - 2014-12-23 10:23:42 --> Loader Class Initialized
DEBUG - 2014-12-23 10:23:42 --> Database Driver Class Initialized
ERROR - 2014-12-23 10:23:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-23 10:23:42 --> XML-RPC Class Initialized
DEBUG - 2014-12-23 10:23:42 --> Controller Class Initialized
DEBUG - 2014-12-23 10:23:42 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-23 10:23:42 --> Helper loaded: inflector_helper
DEBUG - 2014-12-23 10:23:44 --> Model Class Initialized
DEBUG - 2014-12-23 10:23:44 --> Model Class Initialized
DEBUG - 2014-12-23 10:23:46 --> DB Transaction Failure
ERROR - 2014-12-23 10:23:46 --> Query error: Column 'sugarcrm_id' cannot be null
DEBUG - 2014-12-23 10:23:46 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-23 10:25:41 --> Config Class Initialized
DEBUG - 2014-12-23 10:25:41 --> Hooks Class Initialized
DEBUG - 2014-12-23 10:25:41 --> Utf8 Class Initialized
DEBUG - 2014-12-23 10:25:41 --> UTF-8 Support Enabled
DEBUG - 2014-12-23 10:25:41 --> URI Class Initialized
DEBUG - 2014-12-23 10:25:41 --> Router Class Initialized
DEBUG - 2014-12-23 10:25:41 --> Output Class Initialized
DEBUG - 2014-12-23 10:25:41 --> Security Class Initialized
DEBUG - 2014-12-23 10:25:41 --> Input Class Initialized
DEBUG - 2014-12-23 10:25:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-23 10:25:41 --> Language Class Initialized
DEBUG - 2014-12-23 10:25:53 --> Config Class Initialized
DEBUG - 2014-12-23 10:25:53 --> Hooks Class Initialized
DEBUG - 2014-12-23 10:25:53 --> Utf8 Class Initialized
DEBUG - 2014-12-23 10:25:53 --> UTF-8 Support Enabled
DEBUG - 2014-12-23 10:25:53 --> URI Class Initialized
DEBUG - 2014-12-23 10:25:53 --> Router Class Initialized
DEBUG - 2014-12-23 10:25:53 --> Output Class Initialized
DEBUG - 2014-12-23 10:25:53 --> Security Class Initialized
DEBUG - 2014-12-23 10:25:53 --> Input Class Initialized
DEBUG - 2014-12-23 10:25:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-23 10:25:53 --> Language Class Initialized
DEBUG - 2014-12-23 10:25:58 --> Config Class Initialized
DEBUG - 2014-12-23 10:25:58 --> Hooks Class Initialized
DEBUG - 2014-12-23 10:25:58 --> Utf8 Class Initialized
DEBUG - 2014-12-23 10:25:58 --> UTF-8 Support Enabled
DEBUG - 2014-12-23 10:25:58 --> URI Class Initialized
DEBUG - 2014-12-23 10:25:58 --> Router Class Initialized
DEBUG - 2014-12-23 10:25:58 --> Output Class Initialized
DEBUG - 2014-12-23 10:25:58 --> Security Class Initialized
DEBUG - 2014-12-23 10:25:58 --> Input Class Initialized
DEBUG - 2014-12-23 10:25:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-23 10:25:58 --> Language Class Initialized
DEBUG - 2014-12-23 10:26:31 --> Config Class Initialized
DEBUG - 2014-12-23 10:26:31 --> Hooks Class Initialized
DEBUG - 2014-12-23 10:26:31 --> Utf8 Class Initialized
DEBUG - 2014-12-23 10:26:31 --> UTF-8 Support Enabled
DEBUG - 2014-12-23 10:26:31 --> URI Class Initialized
DEBUG - 2014-12-23 10:26:31 --> Router Class Initialized
DEBUG - 2014-12-23 10:26:31 --> Output Class Initialized
DEBUG - 2014-12-23 10:26:31 --> Security Class Initialized
DEBUG - 2014-12-23 10:26:31 --> Input Class Initialized
DEBUG - 2014-12-23 10:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-23 10:26:31 --> Language Class Initialized
DEBUG - 2014-12-23 10:26:50 --> Config Class Initialized
DEBUG - 2014-12-23 10:26:50 --> Hooks Class Initialized
DEBUG - 2014-12-23 10:26:50 --> Utf8 Class Initialized
DEBUG - 2014-12-23 10:26:50 --> UTF-8 Support Enabled
DEBUG - 2014-12-23 10:26:50 --> URI Class Initialized
DEBUG - 2014-12-23 10:26:50 --> Router Class Initialized
DEBUG - 2014-12-23 10:26:50 --> Output Class Initialized
DEBUG - 2014-12-23 10:26:50 --> Security Class Initialized
DEBUG - 2014-12-23 10:26:50 --> Input Class Initialized
DEBUG - 2014-12-23 10:26:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-23 10:26:50 --> Language Class Initialized
DEBUG - 2014-12-23 10:26:52 --> Config Class Initialized
DEBUG - 2014-12-23 10:26:52 --> Hooks Class Initialized
DEBUG - 2014-12-23 10:26:52 --> Utf8 Class Initialized
DEBUG - 2014-12-23 10:26:52 --> UTF-8 Support Enabled
DEBUG - 2014-12-23 10:26:52 --> URI Class Initialized
DEBUG - 2014-12-23 10:26:52 --> Router Class Initialized
DEBUG - 2014-12-23 10:26:52 --> Output Class Initialized
DEBUG - 2014-12-23 10:26:52 --> Security Class Initialized
DEBUG - 2014-12-23 10:26:52 --> Input Class Initialized
DEBUG - 2014-12-23 10:26:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-23 10:26:52 --> Language Class Initialized
DEBUG - 2014-12-23 10:27:24 --> Config Class Initialized
DEBUG - 2014-12-23 10:27:24 --> Hooks Class Initialized
DEBUG - 2014-12-23 10:27:24 --> Utf8 Class Initialized
DEBUG - 2014-12-23 10:27:24 --> UTF-8 Support Enabled
DEBUG - 2014-12-23 10:27:24 --> URI Class Initialized
DEBUG - 2014-12-23 10:27:24 --> Router Class Initialized
DEBUG - 2014-12-23 10:27:24 --> Output Class Initialized
DEBUG - 2014-12-23 10:27:24 --> Security Class Initialized
DEBUG - 2014-12-23 10:27:24 --> Input Class Initialized
DEBUG - 2014-12-23 10:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-23 10:27:24 --> Language Class Initialized
DEBUG - 2014-12-23 10:27:24 --> Loader Class Initialized
DEBUG - 2014-12-23 10:27:24 --> Database Driver Class Initialized
ERROR - 2014-12-23 10:27:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-23 10:27:25 --> XML-RPC Class Initialized
DEBUG - 2014-12-23 10:27:25 --> Controller Class Initialized
DEBUG - 2014-12-23 10:27:25 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-23 10:27:25 --> Helper loaded: inflector_helper
DEBUG - 2014-12-23 10:27:26 --> Model Class Initialized
DEBUG - 2014-12-23 10:27:26 --> Model Class Initialized
DEBUG - 2014-12-23 10:27:31 --> Config Class Initialized
DEBUG - 2014-12-23 10:27:31 --> Hooks Class Initialized
DEBUG - 2014-12-23 10:27:31 --> Utf8 Class Initialized
DEBUG - 2014-12-23 10:27:31 --> UTF-8 Support Enabled
DEBUG - 2014-12-23 10:27:31 --> URI Class Initialized
DEBUG - 2014-12-23 10:27:31 --> Router Class Initialized
DEBUG - 2014-12-23 10:27:31 --> Output Class Initialized
DEBUG - 2014-12-23 10:27:31 --> Security Class Initialized
DEBUG - 2014-12-23 10:27:31 --> Input Class Initialized
DEBUG - 2014-12-23 10:27:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-23 10:27:31 --> Language Class Initialized
DEBUG - 2014-12-23 10:27:31 --> Loader Class Initialized
DEBUG - 2014-12-23 10:27:31 --> Database Driver Class Initialized
ERROR - 2014-12-23 10:27:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-23 10:27:31 --> XML-RPC Class Initialized
DEBUG - 2014-12-23 10:27:31 --> Controller Class Initialized
DEBUG - 2014-12-23 10:27:31 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-23 10:27:31 --> Helper loaded: inflector_helper
DEBUG - 2014-12-23 10:27:33 --> Model Class Initialized
DEBUG - 2014-12-23 10:27:33 --> Model Class Initialized
DEBUG - 2014-12-23 10:27:33 --> File loaded: application/views/email/registration.php
DEBUG - 2014-12-23 10:27:33 --> Email Class Initialized
DEBUG - 2014-12-23 10:27:35 --> Language file loaded: language/english/email_lang.php
DEBUG - 2014-12-23 10:29:09 --> Config Class Initialized
DEBUG - 2014-12-23 10:29:09 --> Hooks Class Initialized
DEBUG - 2014-12-23 10:29:09 --> Utf8 Class Initialized
DEBUG - 2014-12-23 10:29:09 --> UTF-8 Support Enabled
DEBUG - 2014-12-23 10:29:09 --> URI Class Initialized
DEBUG - 2014-12-23 10:29:09 --> Router Class Initialized
DEBUG - 2014-12-23 10:29:09 --> Output Class Initialized
DEBUG - 2014-12-23 10:29:09 --> Security Class Initialized
DEBUG - 2014-12-23 10:29:09 --> Input Class Initialized
DEBUG - 2014-12-23 10:29:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-23 10:29:09 --> Language Class Initialized
DEBUG - 2014-12-23 10:29:09 --> Loader Class Initialized
DEBUG - 2014-12-23 10:29:09 --> Database Driver Class Initialized
ERROR - 2014-12-23 10:29:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-23 10:29:09 --> XML-RPC Class Initialized
DEBUG - 2014-12-23 10:29:09 --> Controller Class Initialized
DEBUG - 2014-12-23 10:29:09 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-23 10:29:09 --> Helper loaded: inflector_helper
DEBUG - 2014-12-23 10:29:11 --> Model Class Initialized
DEBUG - 2014-12-23 10:29:11 --> Model Class Initialized
DEBUG - 2014-12-23 10:29:11 --> File loaded: application/views/email/registration.php
DEBUG - 2014-12-23 10:29:11 --> Email Class Initialized
DEBUG - 2014-12-23 10:29:12 --> Language file loaded: language/english/email_lang.php
DEBUG - 2014-12-23 10:29:39 --> Config Class Initialized
DEBUG - 2014-12-23 10:29:39 --> Hooks Class Initialized
DEBUG - 2014-12-23 10:29:39 --> Utf8 Class Initialized
DEBUG - 2014-12-23 10:29:39 --> UTF-8 Support Enabled
DEBUG - 2014-12-23 10:29:39 --> URI Class Initialized
DEBUG - 2014-12-23 10:29:39 --> Router Class Initialized
DEBUG - 2014-12-23 10:29:39 --> Output Class Initialized
DEBUG - 2014-12-23 10:29:39 --> Security Class Initialized
DEBUG - 2014-12-23 10:29:39 --> Input Class Initialized
DEBUG - 2014-12-23 10:29:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-23 10:29:39 --> Language Class Initialized
DEBUG - 2014-12-23 10:29:40 --> Loader Class Initialized
DEBUG - 2014-12-23 10:29:40 --> Database Driver Class Initialized
ERROR - 2014-12-23 10:29:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-23 10:29:40 --> XML-RPC Class Initialized
DEBUG - 2014-12-23 10:29:40 --> Controller Class Initialized
DEBUG - 2014-12-23 10:29:40 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-23 10:29:40 --> Helper loaded: inflector_helper
DEBUG - 2014-12-23 10:29:41 --> Model Class Initialized
DEBUG - 2014-12-23 10:29:41 --> Model Class Initialized
DEBUG - 2014-12-23 10:29:41 --> File loaded: application/views/email/registration.php
DEBUG - 2014-12-23 10:29:41 --> Email Class Initialized
DEBUG - 2014-12-23 10:29:42 --> Language file loaded: language/english/email_lang.php
