<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-01-20 06:48:22 --> Config Class Initialized
DEBUG - 2015-01-20 06:48:22 --> Hooks Class Initialized
DEBUG - 2015-01-20 06:48:22 --> Utf8 Class Initialized
DEBUG - 2015-01-20 06:48:22 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 06:48:22 --> URI Class Initialized
DEBUG - 2015-01-20 06:48:22 --> Router Class Initialized
DEBUG - 2015-01-20 06:48:22 --> Output Class Initialized
DEBUG - 2015-01-20 06:48:22 --> Security Class Initialized
DEBUG - 2015-01-20 06:48:22 --> Input Class Initialized
DEBUG - 2015-01-20 06:48:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-01-20 06:48:22 --> Language Class Initialized
DEBUG - 2015-01-20 06:48:22 --> Loader Class Initialized
DEBUG - 2015-01-20 06:48:22 --> Database Driver Class Initialized
ERROR - 2015-01-20 06:48:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-01-20 06:48:22 --> XML-RPC Class Initialized
DEBUG - 2015-01-20 06:48:22 --> Controller Class Initialized
DEBUG - 2015-01-20 06:48:22 --> Config file loaded: application/config/rest.php
DEBUG - 2015-01-20 06:48:22 --> Helper loaded: inflector_helper
DEBUG - 2015-01-20 06:48:45 --> Config Class Initialized
DEBUG - 2015-01-20 06:48:45 --> Hooks Class Initialized
DEBUG - 2015-01-20 06:48:45 --> Utf8 Class Initialized
DEBUG - 2015-01-20 06:48:45 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 06:48:45 --> URI Class Initialized
DEBUG - 2015-01-20 06:48:45 --> Router Class Initialized
DEBUG - 2015-01-20 06:48:45 --> Output Class Initialized
DEBUG - 2015-01-20 06:48:45 --> Security Class Initialized
DEBUG - 2015-01-20 06:48:45 --> Input Class Initialized
DEBUG - 2015-01-20 06:48:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-01-20 06:48:45 --> Language Class Initialized
DEBUG - 2015-01-20 06:48:45 --> Loader Class Initialized
DEBUG - 2015-01-20 06:48:45 --> Database Driver Class Initialized
ERROR - 2015-01-20 06:48:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-01-20 06:48:45 --> XML-RPC Class Initialized
DEBUG - 2015-01-20 06:48:45 --> Controller Class Initialized
DEBUG - 2015-01-20 06:48:45 --> Config file loaded: application/config/rest.php
DEBUG - 2015-01-20 06:48:45 --> Helper loaded: inflector_helper
