<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-12-11 13:08:40 --> Config Class Initialized
DEBUG - 2014-12-11 13:08:40 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:08:40 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:08:40 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:08:40 --> URI Class Initialized
DEBUG - 2014-12-11 13:08:40 --> Router Class Initialized
DEBUG - 2014-12-11 13:08:40 --> Output Class Initialized
DEBUG - 2014-12-11 13:08:40 --> Security Class Initialized
DEBUG - 2014-12-11 13:08:40 --> Input Class Initialized
DEBUG - 2014-12-11 13:08:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:08:40 --> Language Class Initialized
DEBUG - 2014-12-11 13:08:40 --> Loader Class Initialized
DEBUG - 2014-12-11 13:08:40 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:08:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:08:40 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:08:40 --> Controller Class Initialized
DEBUG - 2014-12-11 13:08:40 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:08:40 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:08:40 --> Model Class Initialized
DEBUG - 2014-12-11 13:08:52 --> Config Class Initialized
DEBUG - 2014-12-11 13:08:52 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:08:52 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:08:52 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:08:52 --> URI Class Initialized
DEBUG - 2014-12-11 13:08:52 --> Router Class Initialized
DEBUG - 2014-12-11 13:08:52 --> Output Class Initialized
DEBUG - 2014-12-11 13:08:52 --> Security Class Initialized
DEBUG - 2014-12-11 13:08:52 --> Input Class Initialized
DEBUG - 2014-12-11 13:08:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:08:52 --> Language Class Initialized
DEBUG - 2014-12-11 13:08:52 --> Loader Class Initialized
DEBUG - 2014-12-11 13:08:52 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:08:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:08:52 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:08:52 --> Controller Class Initialized
DEBUG - 2014-12-11 13:08:52 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:08:52 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:08:52 --> Model Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Config Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:08:53 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:08:53 --> URI Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Router Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Output Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Security Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Input Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:08:53 --> Language Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Loader Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:08:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:08:53 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Controller Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:08:53 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:08:53 --> Model Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Config Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:08:53 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:08:53 --> URI Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Router Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Output Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Security Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Input Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:08:53 --> Language Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Loader Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:08:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:08:53 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Controller Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:08:53 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:08:53 --> Model Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Config Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:08:53 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:08:53 --> URI Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Router Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Output Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Security Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Input Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:08:53 --> Language Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Loader Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:08:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:08:53 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Controller Class Initialized
DEBUG - 2014-12-11 13:08:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:08:53 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:08:53 --> Model Class Initialized
DEBUG - 2014-12-11 13:09:19 --> Config Class Initialized
DEBUG - 2014-12-11 13:09:19 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:09:19 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:09:19 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:09:19 --> URI Class Initialized
DEBUG - 2014-12-11 13:09:19 --> Router Class Initialized
DEBUG - 2014-12-11 13:09:19 --> Output Class Initialized
DEBUG - 2014-12-11 13:09:19 --> Security Class Initialized
DEBUG - 2014-12-11 13:09:19 --> Input Class Initialized
DEBUG - 2014-12-11 13:09:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:09:19 --> Language Class Initialized
DEBUG - 2014-12-11 13:09:19 --> Loader Class Initialized
DEBUG - 2014-12-11 13:09:19 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:09:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:09:19 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:09:19 --> Controller Class Initialized
DEBUG - 2014-12-11 13:09:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:09:19 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:09:19 --> Model Class Initialized
DEBUG - 2014-12-11 13:09:20 --> Config Class Initialized
DEBUG - 2014-12-11 13:09:20 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:09:20 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:09:20 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:09:20 --> URI Class Initialized
DEBUG - 2014-12-11 13:09:20 --> Router Class Initialized
DEBUG - 2014-12-11 13:09:20 --> Output Class Initialized
DEBUG - 2014-12-11 13:09:20 --> Security Class Initialized
DEBUG - 2014-12-11 13:09:20 --> Input Class Initialized
DEBUG - 2014-12-11 13:09:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:09:20 --> Language Class Initialized
DEBUG - 2014-12-11 13:09:20 --> Loader Class Initialized
DEBUG - 2014-12-11 13:09:20 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:09:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:09:20 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:09:20 --> Controller Class Initialized
DEBUG - 2014-12-11 13:09:20 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:09:20 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:09:20 --> Model Class Initialized
DEBUG - 2014-12-11 13:09:24 --> Config Class Initialized
DEBUG - 2014-12-11 13:09:24 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:09:24 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:09:24 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:09:24 --> URI Class Initialized
DEBUG - 2014-12-11 13:09:24 --> Router Class Initialized
DEBUG - 2014-12-11 13:09:24 --> Output Class Initialized
DEBUG - 2014-12-11 13:09:24 --> Security Class Initialized
DEBUG - 2014-12-11 13:09:24 --> Input Class Initialized
DEBUG - 2014-12-11 13:09:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:09:24 --> Language Class Initialized
DEBUG - 2014-12-11 13:09:24 --> Loader Class Initialized
DEBUG - 2014-12-11 13:09:24 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:09:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:09:24 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:09:24 --> Controller Class Initialized
DEBUG - 2014-12-11 13:09:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:09:24 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:09:24 --> Model Class Initialized
DEBUG - 2014-12-11 13:09:27 --> Config Class Initialized
DEBUG - 2014-12-11 13:09:27 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:09:27 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:09:27 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:09:27 --> URI Class Initialized
DEBUG - 2014-12-11 13:09:27 --> Router Class Initialized
DEBUG - 2014-12-11 13:09:27 --> Output Class Initialized
DEBUG - 2014-12-11 13:09:27 --> Security Class Initialized
DEBUG - 2014-12-11 13:09:27 --> Input Class Initialized
DEBUG - 2014-12-11 13:09:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:09:27 --> Language Class Initialized
DEBUG - 2014-12-11 13:09:27 --> Loader Class Initialized
DEBUG - 2014-12-11 13:09:27 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:09:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:09:27 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:09:27 --> Controller Class Initialized
DEBUG - 2014-12-11 13:09:27 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:09:27 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:09:27 --> Model Class Initialized
DEBUG - 2014-12-11 13:09:27 --> Model Class Initialized
DEBUG - 2014-12-11 13:09:35 --> Config Class Initialized
DEBUG - 2014-12-11 13:09:35 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:09:35 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:09:35 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:09:35 --> URI Class Initialized
DEBUG - 2014-12-11 13:09:35 --> Router Class Initialized
ERROR - 2014-12-11 13:09:35 --> 404 Page Not Found --> api/nission
DEBUG - 2014-12-11 13:09:39 --> Config Class Initialized
DEBUG - 2014-12-11 13:09:39 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:09:39 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:09:39 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:09:39 --> URI Class Initialized
DEBUG - 2014-12-11 13:09:39 --> Router Class Initialized
DEBUG - 2014-12-11 13:09:39 --> Output Class Initialized
DEBUG - 2014-12-11 13:09:39 --> Security Class Initialized
DEBUG - 2014-12-11 13:09:39 --> Input Class Initialized
DEBUG - 2014-12-11 13:09:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:09:39 --> Language Class Initialized
DEBUG - 2014-12-11 13:09:39 --> Loader Class Initialized
DEBUG - 2014-12-11 13:09:39 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:09:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:09:39 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:09:39 --> Controller Class Initialized
DEBUG - 2014-12-11 13:09:39 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:09:39 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:09:39 --> Model Class Initialized
DEBUG - 2014-12-11 13:10:04 --> Config Class Initialized
DEBUG - 2014-12-11 13:10:04 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:10:04 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:10:04 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:10:04 --> URI Class Initialized
DEBUG - 2014-12-11 13:10:04 --> Router Class Initialized
DEBUG - 2014-12-11 13:10:04 --> Output Class Initialized
DEBUG - 2014-12-11 13:10:04 --> Security Class Initialized
DEBUG - 2014-12-11 13:10:04 --> Input Class Initialized
DEBUG - 2014-12-11 13:10:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:10:04 --> Language Class Initialized
DEBUG - 2014-12-11 13:10:04 --> Loader Class Initialized
DEBUG - 2014-12-11 13:10:04 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:10:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:10:04 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:10:04 --> Controller Class Initialized
DEBUG - 2014-12-11 13:10:04 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:10:04 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:10:04 --> Model Class Initialized
DEBUG - 2014-12-11 13:10:25 --> Config Class Initialized
DEBUG - 2014-12-11 13:10:25 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:10:25 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:10:25 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:10:25 --> URI Class Initialized
DEBUG - 2014-12-11 13:10:25 --> Router Class Initialized
DEBUG - 2014-12-11 13:10:25 --> Output Class Initialized
DEBUG - 2014-12-11 13:10:25 --> Security Class Initialized
DEBUG - 2014-12-11 13:10:25 --> Input Class Initialized
DEBUG - 2014-12-11 13:10:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:10:25 --> Language Class Initialized
DEBUG - 2014-12-11 13:10:25 --> Loader Class Initialized
DEBUG - 2014-12-11 13:10:25 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:10:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:10:25 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:10:25 --> Controller Class Initialized
DEBUG - 2014-12-11 13:10:25 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:10:25 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:10:25 --> Model Class Initialized
DEBUG - 2014-12-11 13:10:33 --> Config Class Initialized
DEBUG - 2014-12-11 13:10:33 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:10:33 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:10:33 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:10:33 --> URI Class Initialized
DEBUG - 2014-12-11 13:10:33 --> Router Class Initialized
DEBUG - 2014-12-11 13:10:33 --> Output Class Initialized
DEBUG - 2014-12-11 13:10:33 --> Security Class Initialized
DEBUG - 2014-12-11 13:10:33 --> Input Class Initialized
DEBUG - 2014-12-11 13:10:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:10:33 --> Language Class Initialized
DEBUG - 2014-12-11 13:10:33 --> Loader Class Initialized
DEBUG - 2014-12-11 13:10:33 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:10:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:10:33 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:10:33 --> Controller Class Initialized
DEBUG - 2014-12-11 13:10:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:10:33 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:10:33 --> Model Class Initialized
DEBUG - 2014-12-11 13:10:38 --> Config Class Initialized
DEBUG - 2014-12-11 13:10:38 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:10:38 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:10:38 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:10:38 --> URI Class Initialized
DEBUG - 2014-12-11 13:10:38 --> Router Class Initialized
DEBUG - 2014-12-11 13:10:38 --> Output Class Initialized
DEBUG - 2014-12-11 13:10:38 --> Security Class Initialized
DEBUG - 2014-12-11 13:10:38 --> Input Class Initialized
DEBUG - 2014-12-11 13:10:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:10:38 --> Language Class Initialized
DEBUG - 2014-12-11 13:10:38 --> Loader Class Initialized
DEBUG - 2014-12-11 13:10:38 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:10:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:10:38 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:10:38 --> Controller Class Initialized
DEBUG - 2014-12-11 13:10:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:10:38 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:10:38 --> Model Class Initialized
DEBUG - 2014-12-11 13:17:23 --> Config Class Initialized
DEBUG - 2014-12-11 13:17:23 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:17:23 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:17:23 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:17:23 --> URI Class Initialized
DEBUG - 2014-12-11 13:17:23 --> Router Class Initialized
DEBUG - 2014-12-11 13:17:23 --> Output Class Initialized
DEBUG - 2014-12-11 13:17:23 --> Security Class Initialized
DEBUG - 2014-12-11 13:17:23 --> Input Class Initialized
DEBUG - 2014-12-11 13:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:17:23 --> Language Class Initialized
DEBUG - 2014-12-11 13:17:23 --> Loader Class Initialized
DEBUG - 2014-12-11 13:17:23 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:17:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:17:23 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:17:23 --> Controller Class Initialized
DEBUG - 2014-12-11 13:17:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:17:23 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:17:40 --> Config Class Initialized
DEBUG - 2014-12-11 13:17:40 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:17:40 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:17:40 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:17:40 --> URI Class Initialized
DEBUG - 2014-12-11 13:17:40 --> Router Class Initialized
DEBUG - 2014-12-11 13:17:40 --> Output Class Initialized
DEBUG - 2014-12-11 13:17:40 --> Security Class Initialized
DEBUG - 2014-12-11 13:17:40 --> Input Class Initialized
DEBUG - 2014-12-11 13:17:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:17:40 --> Language Class Initialized
DEBUG - 2014-12-11 13:17:40 --> Loader Class Initialized
DEBUG - 2014-12-11 13:17:40 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:17:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:17:40 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:17:40 --> Controller Class Initialized
DEBUG - 2014-12-11 13:17:40 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:17:40 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:17:40 --> Model Class Initialized
DEBUG - 2014-12-11 13:17:44 --> Config Class Initialized
DEBUG - 2014-12-11 13:17:44 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:17:44 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:17:44 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:17:44 --> URI Class Initialized
DEBUG - 2014-12-11 13:17:44 --> Router Class Initialized
DEBUG - 2014-12-11 13:17:44 --> Output Class Initialized
DEBUG - 2014-12-11 13:17:44 --> Security Class Initialized
DEBUG - 2014-12-11 13:17:44 --> Input Class Initialized
DEBUG - 2014-12-11 13:17:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:17:44 --> Language Class Initialized
DEBUG - 2014-12-11 13:17:44 --> Loader Class Initialized
DEBUG - 2014-12-11 13:17:44 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:17:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:17:44 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:17:44 --> Controller Class Initialized
DEBUG - 2014-12-11 13:17:44 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:17:44 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:18:08 --> Config Class Initialized
DEBUG - 2014-12-11 13:18:08 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:18:08 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:18:08 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:18:08 --> URI Class Initialized
DEBUG - 2014-12-11 13:18:08 --> Router Class Initialized
DEBUG - 2014-12-11 13:18:08 --> Output Class Initialized
DEBUG - 2014-12-11 13:18:08 --> Security Class Initialized
DEBUG - 2014-12-11 13:18:08 --> Input Class Initialized
DEBUG - 2014-12-11 13:18:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:18:08 --> Language Class Initialized
DEBUG - 2014-12-11 13:18:08 --> Loader Class Initialized
DEBUG - 2014-12-11 13:18:08 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:18:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:18:08 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:18:08 --> Controller Class Initialized
DEBUG - 2014-12-11 13:18:08 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:18:08 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:18:08 --> Model Class Initialized
DEBUG - 2014-12-11 13:18:08 --> Model Class Initialized
DEBUG - 2014-12-11 13:18:12 --> Config Class Initialized
DEBUG - 2014-12-11 13:18:12 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:18:12 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:18:12 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:18:12 --> URI Class Initialized
DEBUG - 2014-12-11 13:18:12 --> Router Class Initialized
DEBUG - 2014-12-11 13:18:12 --> Output Class Initialized
DEBUG - 2014-12-11 13:18:12 --> Security Class Initialized
DEBUG - 2014-12-11 13:18:12 --> Input Class Initialized
DEBUG - 2014-12-11 13:18:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:18:12 --> Language Class Initialized
DEBUG - 2014-12-11 13:18:12 --> Loader Class Initialized
DEBUG - 2014-12-11 13:18:12 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:18:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:18:12 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:18:12 --> Controller Class Initialized
DEBUG - 2014-12-11 13:18:12 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:18:12 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:18:12 --> Model Class Initialized
DEBUG - 2014-12-11 13:18:12 --> Model Class Initialized
DEBUG - 2014-12-11 13:18:24 --> Config Class Initialized
DEBUG - 2014-12-11 13:18:24 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:18:24 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:18:24 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:18:24 --> URI Class Initialized
DEBUG - 2014-12-11 13:18:24 --> Router Class Initialized
DEBUG - 2014-12-11 13:18:24 --> Output Class Initialized
DEBUG - 2014-12-11 13:18:24 --> Security Class Initialized
DEBUG - 2014-12-11 13:18:24 --> Input Class Initialized
DEBUG - 2014-12-11 13:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:18:24 --> Language Class Initialized
DEBUG - 2014-12-11 13:18:24 --> Loader Class Initialized
DEBUG - 2014-12-11 13:18:24 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:18:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:18:24 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:18:24 --> Controller Class Initialized
DEBUG - 2014-12-11 13:18:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:18:24 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:18:24 --> Model Class Initialized
DEBUG - 2014-12-11 13:18:24 --> Model Class Initialized
DEBUG - 2014-12-11 13:18:33 --> Config Class Initialized
DEBUG - 2014-12-11 13:18:33 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:18:33 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:18:33 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:18:33 --> URI Class Initialized
DEBUG - 2014-12-11 13:18:33 --> Router Class Initialized
DEBUG - 2014-12-11 13:18:33 --> Output Class Initialized
DEBUG - 2014-12-11 13:18:33 --> Security Class Initialized
DEBUG - 2014-12-11 13:18:33 --> Input Class Initialized
DEBUG - 2014-12-11 13:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:18:33 --> Language Class Initialized
DEBUG - 2014-12-11 13:18:33 --> Loader Class Initialized
DEBUG - 2014-12-11 13:18:33 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:18:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:18:33 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:18:33 --> Controller Class Initialized
DEBUG - 2014-12-11 13:18:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:18:33 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:18:33 --> Model Class Initialized
DEBUG - 2014-12-11 13:18:33 --> Model Class Initialized
DEBUG - 2014-12-11 13:18:43 --> Config Class Initialized
DEBUG - 2014-12-11 13:18:43 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:18:43 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:18:43 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:18:43 --> URI Class Initialized
DEBUG - 2014-12-11 13:18:43 --> Router Class Initialized
DEBUG - 2014-12-11 13:18:43 --> Output Class Initialized
DEBUG - 2014-12-11 13:18:43 --> Security Class Initialized
DEBUG - 2014-12-11 13:18:43 --> Input Class Initialized
DEBUG - 2014-12-11 13:18:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:18:43 --> Language Class Initialized
DEBUG - 2014-12-11 13:18:43 --> Loader Class Initialized
DEBUG - 2014-12-11 13:18:43 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:18:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:18:43 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:18:43 --> Controller Class Initialized
DEBUG - 2014-12-11 13:18:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:18:43 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:18:43 --> Model Class Initialized
DEBUG - 2014-12-11 13:19:17 --> Config Class Initialized
DEBUG - 2014-12-11 13:19:17 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:19:17 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:19:17 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:19:17 --> URI Class Initialized
DEBUG - 2014-12-11 13:19:17 --> Router Class Initialized
DEBUG - 2014-12-11 13:19:17 --> Output Class Initialized
DEBUG - 2014-12-11 13:19:17 --> Security Class Initialized
DEBUG - 2014-12-11 13:19:17 --> Input Class Initialized
DEBUG - 2014-12-11 13:19:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:19:17 --> Language Class Initialized
DEBUG - 2014-12-11 13:19:17 --> Loader Class Initialized
DEBUG - 2014-12-11 13:19:17 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:19:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:19:17 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:19:17 --> Controller Class Initialized
DEBUG - 2014-12-11 13:19:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:19:17 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:19:17 --> Model Class Initialized
DEBUG - 2014-12-11 13:19:17 --> Model Class Initialized
DEBUG - 2014-12-11 13:19:33 --> Config Class Initialized
DEBUG - 2014-12-11 13:19:33 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:19:33 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:19:33 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:19:33 --> URI Class Initialized
DEBUG - 2014-12-11 13:19:33 --> Router Class Initialized
DEBUG - 2014-12-11 13:19:33 --> Output Class Initialized
DEBUG - 2014-12-11 13:19:33 --> Security Class Initialized
DEBUG - 2014-12-11 13:19:33 --> Input Class Initialized
DEBUG - 2014-12-11 13:19:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:19:33 --> Language Class Initialized
DEBUG - 2014-12-11 13:19:33 --> Loader Class Initialized
DEBUG - 2014-12-11 13:19:33 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:19:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:19:33 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:19:33 --> Controller Class Initialized
DEBUG - 2014-12-11 13:19:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:19:33 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:19:33 --> Model Class Initialized
DEBUG - 2014-12-11 13:19:33 --> Model Class Initialized
DEBUG - 2014-12-11 13:19:38 --> Config Class Initialized
DEBUG - 2014-12-11 13:19:38 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:19:38 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:19:38 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:19:38 --> URI Class Initialized
DEBUG - 2014-12-11 13:19:38 --> Router Class Initialized
DEBUG - 2014-12-11 13:19:38 --> Output Class Initialized
DEBUG - 2014-12-11 13:19:38 --> Security Class Initialized
DEBUG - 2014-12-11 13:19:38 --> Input Class Initialized
DEBUG - 2014-12-11 13:19:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:19:38 --> Language Class Initialized
DEBUG - 2014-12-11 13:19:38 --> Loader Class Initialized
DEBUG - 2014-12-11 13:19:38 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:19:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:19:38 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:19:38 --> Controller Class Initialized
DEBUG - 2014-12-11 13:19:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:19:38 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:19:38 --> Model Class Initialized
DEBUG - 2014-12-11 13:19:38 --> Model Class Initialized
DEBUG - 2014-12-11 13:19:57 --> Config Class Initialized
DEBUG - 2014-12-11 13:19:57 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:19:57 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:19:57 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:19:57 --> URI Class Initialized
DEBUG - 2014-12-11 13:19:57 --> Router Class Initialized
DEBUG - 2014-12-11 13:19:57 --> Output Class Initialized
DEBUG - 2014-12-11 13:19:57 --> Security Class Initialized
DEBUG - 2014-12-11 13:19:57 --> Input Class Initialized
DEBUG - 2014-12-11 13:19:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:19:57 --> Language Class Initialized
DEBUG - 2014-12-11 13:19:57 --> Loader Class Initialized
DEBUG - 2014-12-11 13:19:57 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:19:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:19:57 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:19:57 --> Controller Class Initialized
DEBUG - 2014-12-11 13:19:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:19:57 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:19:57 --> Model Class Initialized
DEBUG - 2014-12-11 13:19:57 --> Model Class Initialized
DEBUG - 2014-12-11 13:20:06 --> Config Class Initialized
DEBUG - 2014-12-11 13:20:06 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:20:06 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:20:06 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:20:06 --> URI Class Initialized
DEBUG - 2014-12-11 13:20:06 --> Router Class Initialized
DEBUG - 2014-12-11 13:20:06 --> Output Class Initialized
DEBUG - 2014-12-11 13:20:06 --> Security Class Initialized
DEBUG - 2014-12-11 13:20:06 --> Input Class Initialized
DEBUG - 2014-12-11 13:20:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:20:06 --> Language Class Initialized
DEBUG - 2014-12-11 13:20:06 --> Loader Class Initialized
DEBUG - 2014-12-11 13:20:06 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:20:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:20:06 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:20:06 --> Controller Class Initialized
DEBUG - 2014-12-11 13:20:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:20:06 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:20:06 --> Model Class Initialized
DEBUG - 2014-12-11 13:20:06 --> Model Class Initialized
DEBUG - 2014-12-11 13:21:34 --> Config Class Initialized
DEBUG - 2014-12-11 13:21:34 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:21:34 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:21:34 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:21:34 --> URI Class Initialized
DEBUG - 2014-12-11 13:21:34 --> Router Class Initialized
DEBUG - 2014-12-11 13:21:34 --> Output Class Initialized
DEBUG - 2014-12-11 13:21:34 --> Security Class Initialized
DEBUG - 2014-12-11 13:21:34 --> Input Class Initialized
DEBUG - 2014-12-11 13:21:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:21:34 --> Language Class Initialized
DEBUG - 2014-12-11 13:21:34 --> Loader Class Initialized
DEBUG - 2014-12-11 13:21:34 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:21:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:21:34 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:21:34 --> Controller Class Initialized
DEBUG - 2014-12-11 13:21:34 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:21:34 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:21:34 --> Model Class Initialized
DEBUG - 2014-12-11 13:21:34 --> Model Class Initialized
DEBUG - 2014-12-11 13:21:56 --> Config Class Initialized
DEBUG - 2014-12-11 13:21:56 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:21:56 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:21:56 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:21:56 --> URI Class Initialized
DEBUG - 2014-12-11 13:21:56 --> Router Class Initialized
DEBUG - 2014-12-11 13:21:56 --> Output Class Initialized
DEBUG - 2014-12-11 13:21:56 --> Security Class Initialized
DEBUG - 2014-12-11 13:21:56 --> Input Class Initialized
DEBUG - 2014-12-11 13:21:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:21:56 --> Language Class Initialized
DEBUG - 2014-12-11 13:21:56 --> Loader Class Initialized
DEBUG - 2014-12-11 13:21:56 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:21:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:21:56 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:21:56 --> Controller Class Initialized
DEBUG - 2014-12-11 13:21:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:21:56 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:21:56 --> Model Class Initialized
DEBUG - 2014-12-11 13:21:56 --> Model Class Initialized
DEBUG - 2014-12-11 13:22:50 --> Config Class Initialized
DEBUG - 2014-12-11 13:22:50 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:22:50 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:22:50 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:22:50 --> URI Class Initialized
DEBUG - 2014-12-11 13:22:50 --> Router Class Initialized
DEBUG - 2014-12-11 13:22:50 --> Output Class Initialized
DEBUG - 2014-12-11 13:22:50 --> Security Class Initialized
DEBUG - 2014-12-11 13:22:50 --> Input Class Initialized
DEBUG - 2014-12-11 13:22:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:22:50 --> Language Class Initialized
DEBUG - 2014-12-11 13:22:50 --> Loader Class Initialized
DEBUG - 2014-12-11 13:22:50 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:22:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:22:50 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:22:50 --> Controller Class Initialized
DEBUG - 2014-12-11 13:22:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:22:50 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:22:50 --> Model Class Initialized
DEBUG - 2014-12-11 13:22:50 --> Model Class Initialized
DEBUG - 2014-12-11 13:23:07 --> Config Class Initialized
DEBUG - 2014-12-11 13:23:07 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:23:07 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:23:07 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:23:07 --> URI Class Initialized
DEBUG - 2014-12-11 13:23:07 --> Router Class Initialized
DEBUG - 2014-12-11 13:23:07 --> Output Class Initialized
DEBUG - 2014-12-11 13:23:07 --> Security Class Initialized
DEBUG - 2014-12-11 13:23:07 --> Input Class Initialized
DEBUG - 2014-12-11 13:23:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:23:07 --> Language Class Initialized
DEBUG - 2014-12-11 13:23:07 --> Loader Class Initialized
DEBUG - 2014-12-11 13:23:07 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:23:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:23:07 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:23:07 --> Controller Class Initialized
DEBUG - 2014-12-11 13:23:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:23:07 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:23:07 --> Model Class Initialized
DEBUG - 2014-12-11 13:23:07 --> Model Class Initialized
ERROR - 2014-12-11 13:23:07 --> Severity: Notice  --> Undefined index: mission_status /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/models/mission_model.php 42
ERROR - 2014-12-11 13:23:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/libraries/REST_Controller.php 485
ERROR - 2014-12-11 13:23:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Common.php 442
ERROR - 2014-12-11 13:23:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/libraries/REST_Controller.php 503
DEBUG - 2014-12-11 13:23:53 --> Config Class Initialized
DEBUG - 2014-12-11 13:23:53 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:23:53 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:23:53 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:23:53 --> URI Class Initialized
DEBUG - 2014-12-11 13:23:53 --> Router Class Initialized
DEBUG - 2014-12-11 13:23:53 --> Output Class Initialized
DEBUG - 2014-12-11 13:23:53 --> Security Class Initialized
DEBUG - 2014-12-11 13:23:53 --> Input Class Initialized
DEBUG - 2014-12-11 13:23:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:23:53 --> Language Class Initialized
DEBUG - 2014-12-11 13:23:53 --> Loader Class Initialized
DEBUG - 2014-12-11 13:23:53 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:23:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:23:53 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:23:53 --> Controller Class Initialized
DEBUG - 2014-12-11 13:23:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:23:53 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:23:53 --> Model Class Initialized
DEBUG - 2014-12-11 13:23:53 --> Model Class Initialized
ERROR - 2014-12-11 13:23:53 --> Severity: Notice  --> Undefined index: mission_status /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/models/mission_model.php 42
ERROR - 2014-12-11 13:23:53 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/libraries/REST_Controller.php 485
ERROR - 2014-12-11 13:23:53 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Common.php 442
ERROR - 2014-12-11 13:23:53 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/libraries/REST_Controller.php 503
DEBUG - 2014-12-11 13:24:28 --> Config Class Initialized
DEBUG - 2014-12-11 13:24:28 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:24:28 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:24:28 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:24:28 --> URI Class Initialized
DEBUG - 2014-12-11 13:24:28 --> Router Class Initialized
DEBUG - 2014-12-11 13:24:28 --> Output Class Initialized
DEBUG - 2014-12-11 13:24:28 --> Security Class Initialized
DEBUG - 2014-12-11 13:24:28 --> Input Class Initialized
DEBUG - 2014-12-11 13:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:24:28 --> Language Class Initialized
DEBUG - 2014-12-11 13:24:28 --> Loader Class Initialized
DEBUG - 2014-12-11 13:24:28 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:24:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:24:28 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:24:28 --> Controller Class Initialized
DEBUG - 2014-12-11 13:24:28 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:24:28 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:24:28 --> Model Class Initialized
DEBUG - 2014-12-11 13:24:28 --> Model Class Initialized
DEBUG - 2014-12-11 13:24:51 --> Config Class Initialized
DEBUG - 2014-12-11 13:24:51 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:24:51 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:24:51 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:24:51 --> URI Class Initialized
DEBUG - 2014-12-11 13:24:51 --> Router Class Initialized
DEBUG - 2014-12-11 13:24:51 --> Output Class Initialized
DEBUG - 2014-12-11 13:24:51 --> Security Class Initialized
DEBUG - 2014-12-11 13:24:51 --> Input Class Initialized
DEBUG - 2014-12-11 13:24:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:24:51 --> Language Class Initialized
DEBUG - 2014-12-11 13:24:51 --> Loader Class Initialized
DEBUG - 2014-12-11 13:24:51 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:24:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:24:51 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:24:51 --> Controller Class Initialized
DEBUG - 2014-12-11 13:24:51 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:24:51 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:24:51 --> Model Class Initialized
DEBUG - 2014-12-11 13:24:51 --> Model Class Initialized
DEBUG - 2014-12-11 13:25:29 --> Config Class Initialized
DEBUG - 2014-12-11 13:25:29 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:25:29 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:25:29 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:25:29 --> URI Class Initialized
DEBUG - 2014-12-11 13:25:29 --> Router Class Initialized
DEBUG - 2014-12-11 13:25:29 --> Output Class Initialized
DEBUG - 2014-12-11 13:25:29 --> Security Class Initialized
DEBUG - 2014-12-11 13:25:29 --> Input Class Initialized
DEBUG - 2014-12-11 13:25:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:25:29 --> Language Class Initialized
DEBUG - 2014-12-11 13:25:29 --> Loader Class Initialized
DEBUG - 2014-12-11 13:25:29 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:25:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:25:29 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:25:29 --> Controller Class Initialized
DEBUG - 2014-12-11 13:25:29 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:25:29 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:25:29 --> Model Class Initialized
DEBUG - 2014-12-11 13:25:29 --> Model Class Initialized
DEBUG - 2014-12-11 13:25:45 --> Config Class Initialized
DEBUG - 2014-12-11 13:25:45 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:25:45 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:25:45 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:25:45 --> URI Class Initialized
DEBUG - 2014-12-11 13:25:45 --> Router Class Initialized
DEBUG - 2014-12-11 13:25:45 --> Output Class Initialized
DEBUG - 2014-12-11 13:25:45 --> Security Class Initialized
DEBUG - 2014-12-11 13:25:45 --> Input Class Initialized
DEBUG - 2014-12-11 13:25:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:25:45 --> Language Class Initialized
DEBUG - 2014-12-11 13:25:45 --> Loader Class Initialized
DEBUG - 2014-12-11 13:25:45 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:25:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:25:45 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:25:45 --> Controller Class Initialized
DEBUG - 2014-12-11 13:25:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:25:45 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:25:45 --> Model Class Initialized
DEBUG - 2014-12-11 13:25:45 --> Model Class Initialized
ERROR - 2014-12-11 13:25:45 --> Severity: Notice  --> Undefined index: mission_meta /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/models/mission_model.php 154
ERROR - 2014-12-11 13:25:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/libraries/REST_Controller.php 485
ERROR - 2014-12-11 13:25:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Common.php 442
ERROR - 2014-12-11 13:25:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/libraries/REST_Controller.php 503
DEBUG - 2014-12-11 13:26:04 --> Config Class Initialized
DEBUG - 2014-12-11 13:26:04 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:26:04 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:26:04 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:26:04 --> URI Class Initialized
DEBUG - 2014-12-11 13:26:04 --> Router Class Initialized
DEBUG - 2014-12-11 13:26:04 --> Output Class Initialized
DEBUG - 2014-12-11 13:26:04 --> Security Class Initialized
DEBUG - 2014-12-11 13:26:04 --> Input Class Initialized
DEBUG - 2014-12-11 13:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:26:04 --> Language Class Initialized
DEBUG - 2014-12-11 13:26:04 --> Loader Class Initialized
DEBUG - 2014-12-11 13:26:04 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:26:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:26:04 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:26:04 --> Controller Class Initialized
DEBUG - 2014-12-11 13:26:04 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:26:04 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:26:04 --> Model Class Initialized
DEBUG - 2014-12-11 13:26:04 --> Model Class Initialized
DEBUG - 2014-12-11 13:47:21 --> Config Class Initialized
DEBUG - 2014-12-11 13:47:21 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:47:21 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:47:21 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:47:21 --> URI Class Initialized
DEBUG - 2014-12-11 13:47:21 --> Router Class Initialized
DEBUG - 2014-12-11 13:47:21 --> Output Class Initialized
DEBUG - 2014-12-11 13:47:21 --> Security Class Initialized
DEBUG - 2014-12-11 13:47:21 --> Input Class Initialized
DEBUG - 2014-12-11 13:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:47:21 --> Language Class Initialized
DEBUG - 2014-12-11 13:47:21 --> Loader Class Initialized
DEBUG - 2014-12-11 13:47:21 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:47:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:47:21 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:47:21 --> Controller Class Initialized
DEBUG - 2014-12-11 13:47:21 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:47:21 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:47:21 --> Model Class Initialized
DEBUG - 2014-12-11 13:47:21 --> Model Class Initialized
DEBUG - 2014-12-11 13:50:50 --> Config Class Initialized
DEBUG - 2014-12-11 13:50:50 --> Hooks Class Initialized
DEBUG - 2014-12-11 13:50:50 --> Utf8 Class Initialized
DEBUG - 2014-12-11 13:50:50 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 13:50:50 --> URI Class Initialized
DEBUG - 2014-12-11 13:50:50 --> Router Class Initialized
DEBUG - 2014-12-11 13:50:50 --> Output Class Initialized
DEBUG - 2014-12-11 13:50:50 --> Security Class Initialized
DEBUG - 2014-12-11 13:50:50 --> Input Class Initialized
DEBUG - 2014-12-11 13:50:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 13:50:50 --> Language Class Initialized
DEBUG - 2014-12-11 13:50:50 --> Loader Class Initialized
DEBUG - 2014-12-11 13:50:50 --> Database Driver Class Initialized
ERROR - 2014-12-11 13:50:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 13:50:50 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 13:50:50 --> Controller Class Initialized
DEBUG - 2014-12-11 13:50:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 13:50:50 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 13:50:50 --> Model Class Initialized
DEBUG - 2014-12-11 13:50:50 --> Model Class Initialized
DEBUG - 2014-12-11 14:38:33 --> Config Class Initialized
DEBUG - 2014-12-11 14:38:33 --> Hooks Class Initialized
DEBUG - 2014-12-11 14:38:33 --> Utf8 Class Initialized
DEBUG - 2014-12-11 14:38:33 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 14:38:33 --> URI Class Initialized
DEBUG - 2014-12-11 14:38:33 --> Router Class Initialized
DEBUG - 2014-12-11 14:38:33 --> Output Class Initialized
DEBUG - 2014-12-11 14:38:33 --> Security Class Initialized
DEBUG - 2014-12-11 14:38:33 --> Input Class Initialized
DEBUG - 2014-12-11 14:38:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 14:38:33 --> Language Class Initialized
DEBUG - 2014-12-11 14:38:33 --> Loader Class Initialized
DEBUG - 2014-12-11 14:38:33 --> Database Driver Class Initialized
ERROR - 2014-12-11 14:38:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 14:38:33 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 14:38:33 --> Controller Class Initialized
DEBUG - 2014-12-11 14:38:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 14:38:33 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 14:38:33 --> Model Class Initialized
DEBUG - 2014-12-11 14:38:33 --> Model Class Initialized
DEBUG - 2014-12-11 14:38:38 --> Config Class Initialized
DEBUG - 2014-12-11 14:38:38 --> Hooks Class Initialized
DEBUG - 2014-12-11 14:38:38 --> Utf8 Class Initialized
DEBUG - 2014-12-11 14:38:38 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 14:38:38 --> URI Class Initialized
DEBUG - 2014-12-11 14:38:38 --> Router Class Initialized
DEBUG - 2014-12-11 14:38:38 --> Output Class Initialized
DEBUG - 2014-12-11 14:38:38 --> Security Class Initialized
DEBUG - 2014-12-11 14:38:38 --> Input Class Initialized
DEBUG - 2014-12-11 14:38:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 14:38:38 --> Language Class Initialized
DEBUG - 2014-12-11 14:38:39 --> Loader Class Initialized
DEBUG - 2014-12-11 14:38:39 --> Database Driver Class Initialized
ERROR - 2014-12-11 14:38:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 14:38:39 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 14:38:39 --> Controller Class Initialized
DEBUG - 2014-12-11 14:38:39 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 14:38:39 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 14:38:39 --> Model Class Initialized
DEBUG - 2014-12-11 14:38:39 --> Model Class Initialized
DEBUG - 2014-12-11 14:38:45 --> Config Class Initialized
DEBUG - 2014-12-11 14:38:45 --> Hooks Class Initialized
DEBUG - 2014-12-11 14:38:45 --> Utf8 Class Initialized
DEBUG - 2014-12-11 14:38:45 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 14:38:45 --> URI Class Initialized
DEBUG - 2014-12-11 14:38:45 --> Router Class Initialized
DEBUG - 2014-12-11 14:38:45 --> Output Class Initialized
DEBUG - 2014-12-11 14:38:45 --> Security Class Initialized
DEBUG - 2014-12-11 14:38:45 --> Input Class Initialized
DEBUG - 2014-12-11 14:38:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 14:38:45 --> Language Class Initialized
DEBUG - 2014-12-11 14:38:45 --> Loader Class Initialized
DEBUG - 2014-12-11 14:38:45 --> Database Driver Class Initialized
ERROR - 2014-12-11 14:38:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 14:38:45 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 14:38:45 --> Controller Class Initialized
DEBUG - 2014-12-11 14:38:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 14:38:45 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 14:38:45 --> Model Class Initialized
DEBUG - 2014-12-11 14:38:45 --> Model Class Initialized
DEBUG - 2014-12-11 14:38:48 --> Config Class Initialized
DEBUG - 2014-12-11 14:38:48 --> Hooks Class Initialized
DEBUG - 2014-12-11 14:38:48 --> Utf8 Class Initialized
DEBUG - 2014-12-11 14:38:48 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 14:38:48 --> URI Class Initialized
DEBUG - 2014-12-11 14:38:48 --> Router Class Initialized
DEBUG - 2014-12-11 14:38:48 --> Output Class Initialized
DEBUG - 2014-12-11 14:38:48 --> Security Class Initialized
DEBUG - 2014-12-11 14:38:48 --> Input Class Initialized
DEBUG - 2014-12-11 14:38:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 14:38:48 --> Language Class Initialized
DEBUG - 2014-12-11 14:38:48 --> Loader Class Initialized
DEBUG - 2014-12-11 14:38:48 --> Database Driver Class Initialized
ERROR - 2014-12-11 14:38:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 14:38:48 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 14:38:48 --> Controller Class Initialized
DEBUG - 2014-12-11 14:38:48 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 14:38:48 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 14:38:48 --> Model Class Initialized
DEBUG - 2014-12-11 14:38:48 --> Model Class Initialized
DEBUG - 2014-12-11 14:42:19 --> Config Class Initialized
DEBUG - 2014-12-11 14:42:19 --> Hooks Class Initialized
DEBUG - 2014-12-11 14:42:19 --> Utf8 Class Initialized
DEBUG - 2014-12-11 14:42:19 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 14:42:19 --> URI Class Initialized
DEBUG - 2014-12-11 14:42:19 --> Router Class Initialized
DEBUG - 2014-12-11 14:42:19 --> Output Class Initialized
DEBUG - 2014-12-11 14:42:19 --> Security Class Initialized
DEBUG - 2014-12-11 14:42:19 --> Input Class Initialized
DEBUG - 2014-12-11 14:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 14:42:19 --> Language Class Initialized
DEBUG - 2014-12-11 14:42:19 --> Loader Class Initialized
DEBUG - 2014-12-11 14:42:19 --> Database Driver Class Initialized
ERROR - 2014-12-11 14:42:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 14:42:19 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 14:42:19 --> Controller Class Initialized
DEBUG - 2014-12-11 14:42:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 14:42:19 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 14:42:19 --> Model Class Initialized
DEBUG - 2014-12-11 14:42:19 --> Model Class Initialized
DEBUG - 2014-12-11 14:43:12 --> Config Class Initialized
DEBUG - 2014-12-11 14:43:12 --> Hooks Class Initialized
DEBUG - 2014-12-11 14:43:12 --> Utf8 Class Initialized
DEBUG - 2014-12-11 14:43:12 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 14:43:12 --> URI Class Initialized
DEBUG - 2014-12-11 14:43:12 --> Router Class Initialized
DEBUG - 2014-12-11 14:43:12 --> Output Class Initialized
DEBUG - 2014-12-11 14:43:12 --> Security Class Initialized
DEBUG - 2014-12-11 14:43:12 --> Input Class Initialized
DEBUG - 2014-12-11 14:43:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 14:43:12 --> Language Class Initialized
DEBUG - 2014-12-11 14:43:12 --> Loader Class Initialized
DEBUG - 2014-12-11 14:43:12 --> Database Driver Class Initialized
ERROR - 2014-12-11 14:43:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 14:43:12 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 14:43:12 --> Controller Class Initialized
DEBUG - 2014-12-11 14:43:12 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 14:43:12 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 14:43:12 --> Model Class Initialized
DEBUG - 2014-12-11 14:43:12 --> Model Class Initialized
DEBUG - 2014-12-11 14:43:22 --> Config Class Initialized
DEBUG - 2014-12-11 14:43:22 --> Hooks Class Initialized
DEBUG - 2014-12-11 14:43:22 --> Utf8 Class Initialized
DEBUG - 2014-12-11 14:43:22 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 14:43:22 --> URI Class Initialized
DEBUG - 2014-12-11 14:43:22 --> Router Class Initialized
DEBUG - 2014-12-11 14:43:22 --> Output Class Initialized
DEBUG - 2014-12-11 14:43:22 --> Security Class Initialized
DEBUG - 2014-12-11 14:43:22 --> Input Class Initialized
DEBUG - 2014-12-11 14:43:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 14:43:22 --> Language Class Initialized
DEBUG - 2014-12-11 14:43:22 --> Loader Class Initialized
DEBUG - 2014-12-11 14:43:22 --> Database Driver Class Initialized
ERROR - 2014-12-11 14:43:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 14:43:22 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 14:43:22 --> Controller Class Initialized
DEBUG - 2014-12-11 14:43:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 14:43:22 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 14:43:22 --> Model Class Initialized
DEBUG - 2014-12-11 14:43:22 --> Model Class Initialized
DEBUG - 2014-12-11 14:43:25 --> Config Class Initialized
DEBUG - 2014-12-11 14:43:25 --> Hooks Class Initialized
DEBUG - 2014-12-11 14:43:26 --> Utf8 Class Initialized
DEBUG - 2014-12-11 14:43:26 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 14:43:26 --> URI Class Initialized
DEBUG - 2014-12-11 14:43:26 --> Router Class Initialized
DEBUG - 2014-12-11 14:43:26 --> Output Class Initialized
DEBUG - 2014-12-11 14:43:26 --> Security Class Initialized
DEBUG - 2014-12-11 14:43:26 --> Input Class Initialized
DEBUG - 2014-12-11 14:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 14:43:26 --> Language Class Initialized
DEBUG - 2014-12-11 14:43:26 --> Loader Class Initialized
DEBUG - 2014-12-11 14:43:26 --> Database Driver Class Initialized
ERROR - 2014-12-11 14:43:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 14:43:26 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 14:43:26 --> Controller Class Initialized
DEBUG - 2014-12-11 14:43:26 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 14:43:26 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 14:43:26 --> Model Class Initialized
DEBUG - 2014-12-11 14:43:26 --> Model Class Initialized
DEBUG - 2014-12-11 14:43:42 --> Config Class Initialized
DEBUG - 2014-12-11 14:43:42 --> Hooks Class Initialized
DEBUG - 2014-12-11 14:43:42 --> Utf8 Class Initialized
DEBUG - 2014-12-11 14:43:42 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 14:43:42 --> URI Class Initialized
DEBUG - 2014-12-11 14:43:42 --> Router Class Initialized
DEBUG - 2014-12-11 14:43:42 --> Output Class Initialized
DEBUG - 2014-12-11 14:43:42 --> Security Class Initialized
DEBUG - 2014-12-11 14:43:42 --> Input Class Initialized
DEBUG - 2014-12-11 14:43:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 14:43:42 --> Language Class Initialized
DEBUG - 2014-12-11 14:43:42 --> Loader Class Initialized
DEBUG - 2014-12-11 14:43:42 --> Database Driver Class Initialized
ERROR - 2014-12-11 14:43:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 14:43:42 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 14:43:42 --> Controller Class Initialized
DEBUG - 2014-12-11 14:43:42 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 14:43:42 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 14:43:42 --> Model Class Initialized
DEBUG - 2014-12-11 14:43:42 --> Model Class Initialized
DEBUG - 2014-12-11 14:43:48 --> Config Class Initialized
DEBUG - 2014-12-11 14:43:48 --> Hooks Class Initialized
DEBUG - 2014-12-11 14:43:48 --> Utf8 Class Initialized
DEBUG - 2014-12-11 14:43:48 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 14:43:48 --> URI Class Initialized
DEBUG - 2014-12-11 14:43:48 --> Router Class Initialized
DEBUG - 2014-12-11 14:43:48 --> Output Class Initialized
DEBUG - 2014-12-11 14:43:48 --> Security Class Initialized
DEBUG - 2014-12-11 14:43:48 --> Input Class Initialized
DEBUG - 2014-12-11 14:43:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 14:43:48 --> Language Class Initialized
DEBUG - 2014-12-11 14:43:48 --> Loader Class Initialized
DEBUG - 2014-12-11 14:43:48 --> Database Driver Class Initialized
ERROR - 2014-12-11 14:43:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 14:43:48 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 14:43:48 --> Controller Class Initialized
DEBUG - 2014-12-11 14:43:48 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 14:43:48 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 14:43:48 --> Model Class Initialized
DEBUG - 2014-12-11 14:43:48 --> Model Class Initialized
DEBUG - 2014-12-11 14:43:51 --> Config Class Initialized
DEBUG - 2014-12-11 14:43:51 --> Hooks Class Initialized
DEBUG - 2014-12-11 14:43:51 --> Utf8 Class Initialized
DEBUG - 2014-12-11 14:43:51 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 14:43:51 --> URI Class Initialized
DEBUG - 2014-12-11 14:43:51 --> Router Class Initialized
DEBUG - 2014-12-11 14:43:51 --> Output Class Initialized
DEBUG - 2014-12-11 14:43:51 --> Security Class Initialized
DEBUG - 2014-12-11 14:43:51 --> Input Class Initialized
DEBUG - 2014-12-11 14:43:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 14:43:51 --> Language Class Initialized
DEBUG - 2014-12-11 14:43:51 --> Loader Class Initialized
DEBUG - 2014-12-11 14:43:51 --> Database Driver Class Initialized
ERROR - 2014-12-11 14:43:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 14:43:51 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 14:43:51 --> Controller Class Initialized
DEBUG - 2014-12-11 14:43:51 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 14:43:51 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 14:43:51 --> Model Class Initialized
DEBUG - 2014-12-11 14:43:51 --> Model Class Initialized
DEBUG - 2014-12-11 14:44:01 --> Config Class Initialized
DEBUG - 2014-12-11 14:44:01 --> Hooks Class Initialized
DEBUG - 2014-12-11 14:44:01 --> Utf8 Class Initialized
DEBUG - 2014-12-11 14:44:01 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 14:44:01 --> URI Class Initialized
DEBUG - 2014-12-11 14:44:01 --> Router Class Initialized
DEBUG - 2014-12-11 14:44:01 --> Output Class Initialized
DEBUG - 2014-12-11 14:44:01 --> Security Class Initialized
DEBUG - 2014-12-11 14:44:01 --> Input Class Initialized
DEBUG - 2014-12-11 14:44:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 14:44:01 --> Language Class Initialized
DEBUG - 2014-12-11 14:44:01 --> Loader Class Initialized
DEBUG - 2014-12-11 14:44:01 --> Database Driver Class Initialized
ERROR - 2014-12-11 14:44:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 14:44:01 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 14:44:01 --> Controller Class Initialized
DEBUG - 2014-12-11 14:44:01 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 14:44:01 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 14:44:01 --> Model Class Initialized
DEBUG - 2014-12-11 14:44:01 --> Model Class Initialized
DEBUG - 2014-12-11 14:44:06 --> Config Class Initialized
DEBUG - 2014-12-11 14:44:06 --> Hooks Class Initialized
DEBUG - 2014-12-11 14:44:06 --> Utf8 Class Initialized
DEBUG - 2014-12-11 14:44:06 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 14:44:06 --> URI Class Initialized
DEBUG - 2014-12-11 14:44:06 --> Router Class Initialized
DEBUG - 2014-12-11 14:44:06 --> Output Class Initialized
DEBUG - 2014-12-11 14:44:06 --> Security Class Initialized
DEBUG - 2014-12-11 14:44:06 --> Input Class Initialized
DEBUG - 2014-12-11 14:44:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 14:44:06 --> Language Class Initialized
DEBUG - 2014-12-11 14:44:06 --> Loader Class Initialized
DEBUG - 2014-12-11 14:44:06 --> Database Driver Class Initialized
ERROR - 2014-12-11 14:44:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 14:44:06 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 14:44:06 --> Controller Class Initialized
DEBUG - 2014-12-11 14:44:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 14:44:06 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 14:44:06 --> Model Class Initialized
DEBUG - 2014-12-11 14:44:06 --> Model Class Initialized
DEBUG - 2014-12-11 14:44:11 --> Config Class Initialized
DEBUG - 2014-12-11 14:44:11 --> Hooks Class Initialized
DEBUG - 2014-12-11 14:44:11 --> Utf8 Class Initialized
DEBUG - 2014-12-11 14:44:11 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 14:44:11 --> URI Class Initialized
DEBUG - 2014-12-11 14:44:11 --> Router Class Initialized
DEBUG - 2014-12-11 14:44:11 --> Output Class Initialized
DEBUG - 2014-12-11 14:44:11 --> Security Class Initialized
DEBUG - 2014-12-11 14:44:11 --> Input Class Initialized
DEBUG - 2014-12-11 14:44:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 14:44:11 --> Language Class Initialized
DEBUG - 2014-12-11 14:44:11 --> Loader Class Initialized
DEBUG - 2014-12-11 14:44:11 --> Database Driver Class Initialized
ERROR - 2014-12-11 14:44:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 14:44:11 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 14:44:11 --> Controller Class Initialized
DEBUG - 2014-12-11 14:44:11 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 14:44:11 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 14:44:11 --> Model Class Initialized
DEBUG - 2014-12-11 14:44:11 --> Model Class Initialized
DEBUG - 2014-12-11 14:44:15 --> Config Class Initialized
DEBUG - 2014-12-11 14:44:15 --> Hooks Class Initialized
DEBUG - 2014-12-11 14:44:15 --> Utf8 Class Initialized
DEBUG - 2014-12-11 14:44:15 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 14:44:15 --> URI Class Initialized
DEBUG - 2014-12-11 14:44:15 --> Router Class Initialized
DEBUG - 2014-12-11 14:44:15 --> Output Class Initialized
DEBUG - 2014-12-11 14:44:15 --> Security Class Initialized
DEBUG - 2014-12-11 14:44:15 --> Input Class Initialized
DEBUG - 2014-12-11 14:44:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 14:44:15 --> Language Class Initialized
DEBUG - 2014-12-11 14:44:15 --> Loader Class Initialized
DEBUG - 2014-12-11 14:44:15 --> Database Driver Class Initialized
ERROR - 2014-12-11 14:44:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 14:44:15 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 14:44:15 --> Controller Class Initialized
DEBUG - 2014-12-11 14:44:15 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 14:44:15 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 14:44:15 --> Model Class Initialized
DEBUG - 2014-12-11 14:44:15 --> Model Class Initialized
DEBUG - 2014-12-11 14:44:24 --> Config Class Initialized
DEBUG - 2014-12-11 14:44:24 --> Hooks Class Initialized
DEBUG - 2014-12-11 14:44:24 --> Utf8 Class Initialized
DEBUG - 2014-12-11 14:44:24 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 14:44:24 --> URI Class Initialized
DEBUG - 2014-12-11 14:44:24 --> Router Class Initialized
DEBUG - 2014-12-11 14:44:24 --> Output Class Initialized
DEBUG - 2014-12-11 14:44:24 --> Security Class Initialized
DEBUG - 2014-12-11 14:44:24 --> Input Class Initialized
DEBUG - 2014-12-11 14:44:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 14:44:24 --> Language Class Initialized
DEBUG - 2014-12-11 14:44:24 --> Loader Class Initialized
DEBUG - 2014-12-11 14:44:24 --> Database Driver Class Initialized
ERROR - 2014-12-11 14:44:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 14:44:24 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 14:44:24 --> Controller Class Initialized
DEBUG - 2014-12-11 14:44:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 14:44:24 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 14:44:24 --> Model Class Initialized
DEBUG - 2014-12-11 14:44:24 --> Model Class Initialized
DEBUG - 2014-12-11 14:44:29 --> Config Class Initialized
DEBUG - 2014-12-11 14:44:29 --> Hooks Class Initialized
DEBUG - 2014-12-11 14:44:29 --> Utf8 Class Initialized
DEBUG - 2014-12-11 14:44:29 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 14:44:29 --> URI Class Initialized
DEBUG - 2014-12-11 14:44:29 --> Router Class Initialized
DEBUG - 2014-12-11 14:44:29 --> Output Class Initialized
DEBUG - 2014-12-11 14:44:29 --> Security Class Initialized
DEBUG - 2014-12-11 14:44:29 --> Input Class Initialized
DEBUG - 2014-12-11 14:44:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 14:44:29 --> Language Class Initialized
DEBUG - 2014-12-11 14:44:29 --> Loader Class Initialized
DEBUG - 2014-12-11 14:44:29 --> Database Driver Class Initialized
ERROR - 2014-12-11 14:44:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-11 14:44:29 --> XML-RPC Class Initialized
DEBUG - 2014-12-11 14:44:29 --> Controller Class Initialized
DEBUG - 2014-12-11 14:44:29 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-11 14:44:29 --> Helper loaded: inflector_helper
DEBUG - 2014-12-11 14:44:29 --> Model Class Initialized
DEBUG - 2014-12-11 14:44:29 --> Model Class Initialized
