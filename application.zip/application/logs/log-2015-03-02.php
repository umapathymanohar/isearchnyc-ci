<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-03-02 03:53:08 --> Config Class Initialized
DEBUG - 2015-03-02 03:53:08 --> Hooks Class Initialized
DEBUG - 2015-03-02 03:53:08 --> Utf8 Class Initialized
DEBUG - 2015-03-02 03:53:08 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 03:53:08 --> URI Class Initialized
DEBUG - 2015-03-02 03:53:08 --> Router Class Initialized
ERROR - 2015-03-02 03:53:08 --> 404 Page Not Found --> sales
DEBUG - 2015-03-02 03:58:55 --> Config Class Initialized
DEBUG - 2015-03-02 03:58:55 --> Hooks Class Initialized
DEBUG - 2015-03-02 03:58:55 --> Utf8 Class Initialized
DEBUG - 2015-03-02 03:58:55 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 03:58:55 --> URI Class Initialized
DEBUG - 2015-03-02 03:58:55 --> Router Class Initialized
ERROR - 2015-03-02 03:58:55 --> 404 Page Not Found --> sales
DEBUG - 2015-03-02 03:59:05 --> Config Class Initialized
DEBUG - 2015-03-02 03:59:05 --> Hooks Class Initialized
DEBUG - 2015-03-02 03:59:05 --> Utf8 Class Initialized
DEBUG - 2015-03-02 03:59:05 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 03:59:05 --> URI Class Initialized
DEBUG - 2015-03-02 03:59:05 --> Router Class Initialized
DEBUG - 2015-03-02 03:59:05 --> No URI present. Default controller set.
DEBUG - 2015-03-02 03:59:05 --> Output Class Initialized
DEBUG - 2015-03-02 03:59:05 --> Security Class Initialized
DEBUG - 2015-03-02 03:59:05 --> Input Class Initialized
DEBUG - 2015-03-02 03:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 03:59:05 --> Language Class Initialized
DEBUG - 2015-03-02 03:59:05 --> Loader Class Initialized
DEBUG - 2015-03-02 03:59:05 --> Database Driver Class Initialized
DEBUG - 2015-03-02 03:59:06 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 03:59:06 --> Controller Class Initialized
DEBUG - 2015-03-02 03:59:06 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 03:59:06 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 03:59:06 --> Model Class Initialized
DEBUG - 2015-03-02 03:59:06 --> Model Class Initialized
DEBUG - 2015-03-02 03:59:35 --> Config Class Initialized
DEBUG - 2015-03-02 03:59:35 --> Hooks Class Initialized
DEBUG - 2015-03-02 03:59:35 --> Utf8 Class Initialized
DEBUG - 2015-03-02 03:59:35 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 03:59:35 --> URI Class Initialized
DEBUG - 2015-03-02 03:59:35 --> Router Class Initialized
ERROR - 2015-03-02 03:59:35 --> 404 Page Not Found --> users
DEBUG - 2015-03-02 03:59:42 --> Config Class Initialized
DEBUG - 2015-03-02 03:59:42 --> Hooks Class Initialized
DEBUG - 2015-03-02 03:59:42 --> Utf8 Class Initialized
DEBUG - 2015-03-02 03:59:42 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 03:59:42 --> URI Class Initialized
DEBUG - 2015-03-02 03:59:42 --> Router Class Initialized
ERROR - 2015-03-02 03:59:42 --> 404 Page Not Found --> user
DEBUG - 2015-03-02 04:02:02 --> Config Class Initialized
DEBUG - 2015-03-02 04:02:02 --> Hooks Class Initialized
DEBUG - 2015-03-02 04:02:02 --> Utf8 Class Initialized
DEBUG - 2015-03-02 04:02:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 04:02:02 --> URI Class Initialized
DEBUG - 2015-03-02 04:02:02 --> Router Class Initialized
DEBUG - 2015-03-02 04:02:02 --> Output Class Initialized
DEBUG - 2015-03-02 04:02:02 --> Security Class Initialized
DEBUG - 2015-03-02 04:02:02 --> Input Class Initialized
DEBUG - 2015-03-02 04:02:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 04:02:02 --> Language Class Initialized
DEBUG - 2015-03-02 04:02:02 --> Loader Class Initialized
DEBUG - 2015-03-02 04:02:02 --> Database Driver Class Initialized
DEBUG - 2015-03-02 04:02:03 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 04:02:03 --> Controller Class Initialized
DEBUG - 2015-03-02 04:02:03 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 04:02:03 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 04:02:03 --> Model Class Initialized
DEBUG - 2015-03-02 04:02:03 --> Model Class Initialized
DEBUG - 2015-03-02 04:02:38 --> Config Class Initialized
DEBUG - 2015-03-02 04:02:38 --> Hooks Class Initialized
DEBUG - 2015-03-02 04:02:38 --> Utf8 Class Initialized
DEBUG - 2015-03-02 04:02:38 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 04:02:38 --> URI Class Initialized
DEBUG - 2015-03-02 04:02:38 --> Router Class Initialized
DEBUG - 2015-03-02 04:02:38 --> Output Class Initialized
DEBUG - 2015-03-02 04:02:38 --> Security Class Initialized
DEBUG - 2015-03-02 04:02:38 --> Input Class Initialized
DEBUG - 2015-03-02 04:02:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 04:02:38 --> Language Class Initialized
DEBUG - 2015-03-02 04:02:38 --> Loader Class Initialized
DEBUG - 2015-03-02 04:02:38 --> Database Driver Class Initialized
DEBUG - 2015-03-02 04:02:39 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 04:02:39 --> Controller Class Initialized
DEBUG - 2015-03-02 04:02:39 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 04:02:39 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 04:02:39 --> Model Class Initialized
DEBUG - 2015-03-02 04:02:39 --> Model Class Initialized
ERROR - 2015-03-02 04:02:39 --> Severity: Notice  --> Undefined property: Sales::$users_model D:\www\nyc\server\application\controllers\api\sales.php 40
DEBUG - 2015-03-02 04:03:32 --> Config Class Initialized
DEBUG - 2015-03-02 04:03:32 --> Hooks Class Initialized
DEBUG - 2015-03-02 04:03:32 --> Utf8 Class Initialized
DEBUG - 2015-03-02 04:03:32 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 04:03:32 --> URI Class Initialized
DEBUG - 2015-03-02 04:03:32 --> Router Class Initialized
DEBUG - 2015-03-02 04:03:32 --> Output Class Initialized
DEBUG - 2015-03-02 04:03:32 --> Security Class Initialized
DEBUG - 2015-03-02 04:03:32 --> Input Class Initialized
DEBUG - 2015-03-02 04:03:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 04:03:32 --> Language Class Initialized
DEBUG - 2015-03-02 04:03:32 --> Loader Class Initialized
DEBUG - 2015-03-02 04:03:32 --> Database Driver Class Initialized
DEBUG - 2015-03-02 04:03:32 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 04:03:32 --> Controller Class Initialized
DEBUG - 2015-03-02 04:03:32 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 04:03:32 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 04:03:32 --> Model Class Initialized
DEBUG - 2015-03-02 04:03:32 --> Model Class Initialized
ERROR - 2015-03-02 04:03:32 --> Severity: Notice  --> Undefined property: Sales::$users_model D:\www\nyc\server\application\controllers\api\sales.php 40
DEBUG - 2015-03-02 04:04:07 --> Config Class Initialized
DEBUG - 2015-03-02 04:04:07 --> Hooks Class Initialized
DEBUG - 2015-03-02 04:04:07 --> Utf8 Class Initialized
DEBUG - 2015-03-02 04:04:07 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 04:04:07 --> URI Class Initialized
DEBUG - 2015-03-02 04:04:07 --> Router Class Initialized
DEBUG - 2015-03-02 04:04:07 --> Output Class Initialized
DEBUG - 2015-03-02 04:04:07 --> Security Class Initialized
DEBUG - 2015-03-02 04:04:07 --> Input Class Initialized
DEBUG - 2015-03-02 04:04:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 04:04:07 --> Language Class Initialized
DEBUG - 2015-03-02 04:04:07 --> Loader Class Initialized
DEBUG - 2015-03-02 04:04:07 --> Database Driver Class Initialized
DEBUG - 2015-03-02 04:04:07 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 04:04:07 --> Controller Class Initialized
DEBUG - 2015-03-02 04:04:07 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 04:04:07 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 04:04:07 --> Model Class Initialized
DEBUG - 2015-03-02 04:04:07 --> Model Class Initialized
DEBUG - 2015-03-02 04:04:33 --> Config Class Initialized
DEBUG - 2015-03-02 04:04:33 --> Hooks Class Initialized
DEBUG - 2015-03-02 04:04:33 --> Utf8 Class Initialized
DEBUG - 2015-03-02 04:04:33 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 04:04:33 --> URI Class Initialized
DEBUG - 2015-03-02 04:04:33 --> Router Class Initialized
DEBUG - 2015-03-02 04:04:33 --> Output Class Initialized
DEBUG - 2015-03-02 04:04:33 --> Security Class Initialized
DEBUG - 2015-03-02 04:04:33 --> Input Class Initialized
DEBUG - 2015-03-02 04:04:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 04:04:33 --> Language Class Initialized
DEBUG - 2015-03-02 04:04:33 --> Loader Class Initialized
DEBUG - 2015-03-02 04:04:33 --> Database Driver Class Initialized
DEBUG - 2015-03-02 04:04:34 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 04:04:34 --> Controller Class Initialized
DEBUG - 2015-03-02 04:04:34 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 04:04:34 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 04:04:34 --> Model Class Initialized
DEBUG - 2015-03-02 04:04:34 --> Model Class Initialized
ERROR - 2015-03-02 04:04:34 --> Severity: Notice  --> Undefined property: Sales::$users_model D:\www\nyc\server\application\controllers\api\sales.php 40
DEBUG - 2015-03-02 04:09:47 --> Config Class Initialized
DEBUG - 2015-03-02 04:09:47 --> Hooks Class Initialized
DEBUG - 2015-03-02 04:09:47 --> Utf8 Class Initialized
DEBUG - 2015-03-02 04:09:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 04:09:47 --> URI Class Initialized
DEBUG - 2015-03-02 04:09:47 --> Router Class Initialized
DEBUG - 2015-03-02 04:09:47 --> Output Class Initialized
DEBUG - 2015-03-02 04:09:48 --> Security Class Initialized
DEBUG - 2015-03-02 04:09:48 --> Input Class Initialized
DEBUG - 2015-03-02 04:09:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 04:09:48 --> Language Class Initialized
DEBUG - 2015-03-02 04:09:48 --> Loader Class Initialized
DEBUG - 2015-03-02 04:09:48 --> Database Driver Class Initialized
DEBUG - 2015-03-02 04:09:48 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 04:09:48 --> Controller Class Initialized
DEBUG - 2015-03-02 04:09:48 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 04:09:48 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 04:09:48 --> Model Class Initialized
DEBUG - 2015-03-02 04:09:48 --> Model Class Initialized
ERROR - 2015-03-02 04:09:48 --> Severity: Notice  --> Undefined property: Sales::$users_model D:\www\nyc\server\application\controllers\api\sales.php 40
DEBUG - 2015-03-02 04:11:12 --> Config Class Initialized
DEBUG - 2015-03-02 04:11:12 --> Hooks Class Initialized
DEBUG - 2015-03-02 04:11:12 --> Utf8 Class Initialized
DEBUG - 2015-03-02 04:11:12 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 04:11:12 --> URI Class Initialized
DEBUG - 2015-03-02 04:11:12 --> Router Class Initialized
DEBUG - 2015-03-02 04:11:12 --> Output Class Initialized
DEBUG - 2015-03-02 04:11:12 --> Security Class Initialized
DEBUG - 2015-03-02 04:11:12 --> Input Class Initialized
DEBUG - 2015-03-02 04:11:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 04:11:12 --> Language Class Initialized
DEBUG - 2015-03-02 04:11:12 --> Loader Class Initialized
DEBUG - 2015-03-02 04:11:12 --> Database Driver Class Initialized
DEBUG - 2015-03-02 04:11:12 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 04:11:12 --> Controller Class Initialized
DEBUG - 2015-03-02 04:11:12 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 04:11:12 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 04:11:12 --> Model Class Initialized
DEBUG - 2015-03-02 04:11:12 --> Model Class Initialized
ERROR - 2015-03-02 04:11:12 --> Severity: Notice  --> Undefined property: Sales::$users_model D:\www\nyc\server\application\controllers\api\sales.php 40
DEBUG - 2015-03-02 04:20:04 --> Config Class Initialized
DEBUG - 2015-03-02 04:20:04 --> Hooks Class Initialized
DEBUG - 2015-03-02 04:20:04 --> Utf8 Class Initialized
DEBUG - 2015-03-02 04:20:04 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 04:20:04 --> URI Class Initialized
DEBUG - 2015-03-02 04:20:04 --> Router Class Initialized
DEBUG - 2015-03-02 04:20:04 --> Output Class Initialized
DEBUG - 2015-03-02 04:20:04 --> Security Class Initialized
DEBUG - 2015-03-02 04:20:04 --> Input Class Initialized
DEBUG - 2015-03-02 04:20:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 04:20:04 --> Language Class Initialized
DEBUG - 2015-03-02 04:20:04 --> Loader Class Initialized
DEBUG - 2015-03-02 04:20:04 --> Database Driver Class Initialized
DEBUG - 2015-03-02 04:20:04 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 04:20:04 --> Controller Class Initialized
DEBUG - 2015-03-02 04:20:04 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 04:20:04 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 04:20:04 --> Model Class Initialized
DEBUG - 2015-03-02 04:20:04 --> Model Class Initialized
ERROR - 2015-03-02 04:20:04 --> Severity: Notice  --> Undefined property: Sales::$users_model D:\www\nyc\server\application\controllers\api\sales.php 40
DEBUG - 2015-03-02 04:21:50 --> Config Class Initialized
DEBUG - 2015-03-02 04:21:50 --> Hooks Class Initialized
DEBUG - 2015-03-02 04:21:50 --> Utf8 Class Initialized
DEBUG - 2015-03-02 04:21:50 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 04:21:50 --> URI Class Initialized
DEBUG - 2015-03-02 04:21:50 --> Router Class Initialized
DEBUG - 2015-03-02 04:21:50 --> Output Class Initialized
DEBUG - 2015-03-02 04:21:50 --> Security Class Initialized
DEBUG - 2015-03-02 04:21:50 --> Input Class Initialized
DEBUG - 2015-03-02 04:21:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 04:21:50 --> Language Class Initialized
DEBUG - 2015-03-02 04:21:50 --> Loader Class Initialized
DEBUG - 2015-03-02 04:21:50 --> Database Driver Class Initialized
DEBUG - 2015-03-02 04:21:50 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 04:21:50 --> Controller Class Initialized
DEBUG - 2015-03-02 04:21:50 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 04:21:50 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 04:21:50 --> Model Class Initialized
DEBUG - 2015-03-02 04:21:50 --> Model Class Initialized
DEBUG - 2015-03-02 04:23:43 --> Config Class Initialized
DEBUG - 2015-03-02 04:23:43 --> Hooks Class Initialized
DEBUG - 2015-03-02 04:23:43 --> Utf8 Class Initialized
DEBUG - 2015-03-02 04:23:43 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 04:23:43 --> URI Class Initialized
DEBUG - 2015-03-02 04:23:43 --> Router Class Initialized
DEBUG - 2015-03-02 04:23:43 --> Output Class Initialized
DEBUG - 2015-03-02 04:23:43 --> Security Class Initialized
DEBUG - 2015-03-02 04:23:43 --> Input Class Initialized
DEBUG - 2015-03-02 04:23:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 04:23:43 --> Language Class Initialized
DEBUG - 2015-03-02 04:23:43 --> Loader Class Initialized
DEBUG - 2015-03-02 04:23:43 --> Database Driver Class Initialized
DEBUG - 2015-03-02 04:23:43 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 04:23:43 --> Controller Class Initialized
DEBUG - 2015-03-02 04:23:43 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 04:23:43 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 04:23:43 --> Model Class Initialized
DEBUG - 2015-03-02 04:23:43 --> Model Class Initialized
DEBUG - 2015-03-02 04:27:54 --> Config Class Initialized
DEBUG - 2015-03-02 04:27:54 --> Hooks Class Initialized
DEBUG - 2015-03-02 04:27:54 --> Utf8 Class Initialized
DEBUG - 2015-03-02 04:27:54 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 04:27:54 --> URI Class Initialized
DEBUG - 2015-03-02 04:27:54 --> Router Class Initialized
DEBUG - 2015-03-02 04:27:54 --> Output Class Initialized
DEBUG - 2015-03-02 04:27:54 --> Security Class Initialized
DEBUG - 2015-03-02 04:27:54 --> Input Class Initialized
DEBUG - 2015-03-02 04:27:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 04:27:54 --> Language Class Initialized
DEBUG - 2015-03-02 04:27:54 --> Loader Class Initialized
DEBUG - 2015-03-02 04:27:54 --> Database Driver Class Initialized
DEBUG - 2015-03-02 04:27:56 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 04:27:56 --> Controller Class Initialized
DEBUG - 2015-03-02 04:27:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 04:27:56 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 04:27:56 --> Model Class Initialized
DEBUG - 2015-03-02 04:27:56 --> Model Class Initialized
ERROR - 2015-03-02 04:27:56 --> Severity: Notice  --> Undefined index: response D:\www\nyc\server\application\controllers\api\sales.php 52
ERROR - 2015-03-02 04:27:56 --> Severity: Notice  --> Undefined index: response D:\www\nyc\server\application\controllers\api\sales.php 56
ERROR - 2015-03-02 04:27:56 --> Severity: Notice  --> Undefined index: response D:\www\nyc\server\application\controllers\api\sales.php 62
ERROR - 2015-03-02 04:27:56 --> Severity: Notice  --> Undefined index: response D:\www\nyc\server\application\controllers\api\sales.php 68
ERROR - 2015-03-02 04:27:56 --> Severity: Notice  --> Undefined index: response D:\www\nyc\server\application\controllers\api\sales.php 75
ERROR - 2015-03-02 04:27:56 --> Severity: Notice  --> Undefined index: response D:\www\nyc\server\application\controllers\api\sales.php 82
DEBUG - 2015-03-02 04:27:56 --> Final output sent to browser
DEBUG - 2015-03-02 04:27:56 --> Total execution time: 1.1073
DEBUG - 2015-03-02 04:28:26 --> Config Class Initialized
DEBUG - 2015-03-02 04:28:26 --> Hooks Class Initialized
DEBUG - 2015-03-02 04:28:26 --> Utf8 Class Initialized
DEBUG - 2015-03-02 04:28:26 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 04:28:26 --> URI Class Initialized
DEBUG - 2015-03-02 04:28:26 --> Router Class Initialized
DEBUG - 2015-03-02 04:28:26 --> Output Class Initialized
DEBUG - 2015-03-02 04:28:26 --> Security Class Initialized
DEBUG - 2015-03-02 04:28:26 --> Input Class Initialized
DEBUG - 2015-03-02 04:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 04:28:26 --> Language Class Initialized
DEBUG - 2015-03-02 04:28:26 --> Loader Class Initialized
DEBUG - 2015-03-02 04:28:26 --> Database Driver Class Initialized
DEBUG - 2015-03-02 04:28:26 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 04:28:26 --> Controller Class Initialized
DEBUG - 2015-03-02 04:28:26 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 04:28:26 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 04:28:26 --> Model Class Initialized
DEBUG - 2015-03-02 04:28:26 --> Model Class Initialized
DEBUG - 2015-03-02 04:30:13 --> Config Class Initialized
DEBUG - 2015-03-02 04:30:13 --> Hooks Class Initialized
DEBUG - 2015-03-02 04:30:13 --> Utf8 Class Initialized
DEBUG - 2015-03-02 04:30:13 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 04:30:13 --> URI Class Initialized
DEBUG - 2015-03-02 04:30:13 --> Router Class Initialized
DEBUG - 2015-03-02 04:30:13 --> Output Class Initialized
DEBUG - 2015-03-02 04:30:13 --> Security Class Initialized
DEBUG - 2015-03-02 04:30:13 --> Input Class Initialized
DEBUG - 2015-03-02 04:30:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 04:30:13 --> Language Class Initialized
DEBUG - 2015-03-02 04:30:13 --> Loader Class Initialized
DEBUG - 2015-03-02 04:30:13 --> Database Driver Class Initialized
DEBUG - 2015-03-02 04:30:13 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 04:30:13 --> Controller Class Initialized
DEBUG - 2015-03-02 04:30:13 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 04:30:13 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 04:30:13 --> Model Class Initialized
DEBUG - 2015-03-02 04:30:13 --> Model Class Initialized
DEBUG - 2015-03-02 04:30:57 --> Config Class Initialized
DEBUG - 2015-03-02 04:30:57 --> Hooks Class Initialized
DEBUG - 2015-03-02 04:30:57 --> Utf8 Class Initialized
DEBUG - 2015-03-02 04:30:57 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 04:30:57 --> URI Class Initialized
DEBUG - 2015-03-02 04:30:57 --> Router Class Initialized
DEBUG - 2015-03-02 04:30:57 --> Output Class Initialized
DEBUG - 2015-03-02 04:30:57 --> Security Class Initialized
DEBUG - 2015-03-02 04:30:57 --> Input Class Initialized
DEBUG - 2015-03-02 04:30:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 04:30:57 --> Language Class Initialized
DEBUG - 2015-03-02 04:30:57 --> Loader Class Initialized
DEBUG - 2015-03-02 04:30:57 --> Database Driver Class Initialized
DEBUG - 2015-03-02 04:30:57 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 04:30:57 --> Controller Class Initialized
DEBUG - 2015-03-02 04:30:57 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 04:30:57 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 04:30:57 --> Model Class Initialized
DEBUG - 2015-03-02 04:30:57 --> Model Class Initialized
DEBUG - 2015-03-02 04:31:18 --> Config Class Initialized
DEBUG - 2015-03-02 04:31:18 --> Hooks Class Initialized
DEBUG - 2015-03-02 04:31:18 --> Utf8 Class Initialized
DEBUG - 2015-03-02 04:31:18 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 04:31:18 --> URI Class Initialized
DEBUG - 2015-03-02 04:31:18 --> Router Class Initialized
DEBUG - 2015-03-02 04:31:18 --> Output Class Initialized
DEBUG - 2015-03-02 04:31:18 --> Security Class Initialized
DEBUG - 2015-03-02 04:31:18 --> Input Class Initialized
DEBUG - 2015-03-02 04:31:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 04:31:18 --> Language Class Initialized
DEBUG - 2015-03-02 04:31:18 --> Loader Class Initialized
DEBUG - 2015-03-02 04:31:18 --> Database Driver Class Initialized
DEBUG - 2015-03-02 04:31:19 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 04:31:19 --> Controller Class Initialized
DEBUG - 2015-03-02 04:31:19 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 04:31:19 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 04:31:19 --> Model Class Initialized
DEBUG - 2015-03-02 04:31:19 --> Model Class Initialized
DEBUG - 2015-03-02 04:32:38 --> Config Class Initialized
DEBUG - 2015-03-02 04:32:38 --> Hooks Class Initialized
DEBUG - 2015-03-02 04:32:38 --> Utf8 Class Initialized
DEBUG - 2015-03-02 04:32:38 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 04:32:38 --> URI Class Initialized
DEBUG - 2015-03-02 04:32:38 --> Router Class Initialized
DEBUG - 2015-03-02 04:32:38 --> Output Class Initialized
DEBUG - 2015-03-02 04:32:38 --> Security Class Initialized
DEBUG - 2015-03-02 04:32:38 --> Input Class Initialized
DEBUG - 2015-03-02 04:32:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 04:32:38 --> Language Class Initialized
DEBUG - 2015-03-02 04:32:38 --> Loader Class Initialized
DEBUG - 2015-03-02 04:32:38 --> Database Driver Class Initialized
DEBUG - 2015-03-02 04:32:38 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 04:32:38 --> Controller Class Initialized
DEBUG - 2015-03-02 04:32:38 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 04:32:38 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 04:32:38 --> Model Class Initialized
DEBUG - 2015-03-02 04:32:38 --> Model Class Initialized
DEBUG - 2015-03-02 04:32:52 --> Config Class Initialized
DEBUG - 2015-03-02 04:32:52 --> Hooks Class Initialized
DEBUG - 2015-03-02 04:32:52 --> Utf8 Class Initialized
DEBUG - 2015-03-02 04:32:52 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 04:32:52 --> URI Class Initialized
DEBUG - 2015-03-02 04:32:52 --> Router Class Initialized
DEBUG - 2015-03-02 04:32:52 --> Output Class Initialized
DEBUG - 2015-03-02 04:32:52 --> Security Class Initialized
DEBUG - 2015-03-02 04:32:52 --> Input Class Initialized
DEBUG - 2015-03-02 04:32:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 04:32:52 --> Language Class Initialized
DEBUG - 2015-03-02 04:32:52 --> Loader Class Initialized
DEBUG - 2015-03-02 04:32:52 --> Database Driver Class Initialized
DEBUG - 2015-03-02 04:32:52 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 04:32:52 --> Controller Class Initialized
DEBUG - 2015-03-02 04:32:52 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 04:32:52 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 04:32:52 --> Model Class Initialized
DEBUG - 2015-03-02 04:32:52 --> Model Class Initialized
DEBUG - 2015-03-02 04:33:33 --> Config Class Initialized
DEBUG - 2015-03-02 04:33:33 --> Hooks Class Initialized
DEBUG - 2015-03-02 04:33:33 --> Utf8 Class Initialized
DEBUG - 2015-03-02 04:33:33 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 04:33:33 --> URI Class Initialized
DEBUG - 2015-03-02 04:33:33 --> Router Class Initialized
DEBUG - 2015-03-02 04:33:33 --> Output Class Initialized
DEBUG - 2015-03-02 04:33:33 --> Security Class Initialized
DEBUG - 2015-03-02 04:33:33 --> Input Class Initialized
DEBUG - 2015-03-02 04:33:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 04:33:33 --> Language Class Initialized
DEBUG - 2015-03-02 04:33:33 --> Loader Class Initialized
DEBUG - 2015-03-02 04:33:33 --> Database Driver Class Initialized
DEBUG - 2015-03-02 04:33:33 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 04:33:33 --> Controller Class Initialized
DEBUG - 2015-03-02 04:33:33 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 04:33:33 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 04:33:33 --> Model Class Initialized
DEBUG - 2015-03-02 04:33:33 --> Model Class Initialized
DEBUG - 2015-03-02 04:33:39 --> Config Class Initialized
DEBUG - 2015-03-02 04:33:39 --> Hooks Class Initialized
DEBUG - 2015-03-02 04:33:39 --> Utf8 Class Initialized
DEBUG - 2015-03-02 04:33:39 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 04:33:39 --> URI Class Initialized
DEBUG - 2015-03-02 04:33:39 --> Router Class Initialized
DEBUG - 2015-03-02 04:33:39 --> Output Class Initialized
DEBUG - 2015-03-02 04:33:39 --> Security Class Initialized
DEBUG - 2015-03-02 04:33:39 --> Input Class Initialized
DEBUG - 2015-03-02 04:33:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 04:33:39 --> Language Class Initialized
DEBUG - 2015-03-02 04:33:39 --> Loader Class Initialized
DEBUG - 2015-03-02 04:33:39 --> Database Driver Class Initialized
DEBUG - 2015-03-02 04:33:39 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 04:33:39 --> Controller Class Initialized
DEBUG - 2015-03-02 04:33:39 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 04:33:39 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 04:33:39 --> Model Class Initialized
DEBUG - 2015-03-02 04:33:39 --> Model Class Initialized
DEBUG - 2015-03-02 04:34:10 --> Config Class Initialized
DEBUG - 2015-03-02 04:34:10 --> Hooks Class Initialized
DEBUG - 2015-03-02 04:34:10 --> Utf8 Class Initialized
DEBUG - 2015-03-02 04:34:10 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 04:34:10 --> URI Class Initialized
DEBUG - 2015-03-02 04:34:10 --> Router Class Initialized
DEBUG - 2015-03-02 04:34:10 --> Output Class Initialized
DEBUG - 2015-03-02 04:34:10 --> Security Class Initialized
DEBUG - 2015-03-02 04:34:10 --> Input Class Initialized
DEBUG - 2015-03-02 04:34:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 04:34:10 --> Language Class Initialized
DEBUG - 2015-03-02 04:34:10 --> Loader Class Initialized
DEBUG - 2015-03-02 04:34:10 --> Database Driver Class Initialized
DEBUG - 2015-03-02 04:34:11 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 04:34:11 --> Controller Class Initialized
DEBUG - 2015-03-02 04:34:11 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 04:34:11 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 04:34:11 --> Model Class Initialized
DEBUG - 2015-03-02 04:34:11 --> Model Class Initialized
DEBUG - 2015-03-02 04:34:59 --> Config Class Initialized
DEBUG - 2015-03-02 04:34:59 --> Hooks Class Initialized
DEBUG - 2015-03-02 04:34:59 --> Utf8 Class Initialized
DEBUG - 2015-03-02 04:34:59 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 04:34:59 --> URI Class Initialized
DEBUG - 2015-03-02 04:34:59 --> Router Class Initialized
DEBUG - 2015-03-02 04:34:59 --> Output Class Initialized
DEBUG - 2015-03-02 04:34:59 --> Security Class Initialized
DEBUG - 2015-03-02 04:34:59 --> Input Class Initialized
DEBUG - 2015-03-02 04:34:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 04:34:59 --> Language Class Initialized
DEBUG - 2015-03-02 04:34:59 --> Loader Class Initialized
DEBUG - 2015-03-02 04:34:59 --> Database Driver Class Initialized
DEBUG - 2015-03-02 04:34:59 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 04:34:59 --> Controller Class Initialized
DEBUG - 2015-03-02 04:34:59 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 04:34:59 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 04:34:59 --> Model Class Initialized
DEBUG - 2015-03-02 04:34:59 --> Model Class Initialized
DEBUG - 2015-03-02 04:35:04 --> Config Class Initialized
DEBUG - 2015-03-02 04:35:04 --> Hooks Class Initialized
DEBUG - 2015-03-02 04:35:04 --> Utf8 Class Initialized
DEBUG - 2015-03-02 04:35:04 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 04:35:04 --> URI Class Initialized
DEBUG - 2015-03-02 04:35:04 --> Router Class Initialized
DEBUG - 2015-03-02 04:35:04 --> Output Class Initialized
DEBUG - 2015-03-02 04:35:04 --> Security Class Initialized
DEBUG - 2015-03-02 04:35:04 --> Input Class Initialized
DEBUG - 2015-03-02 04:35:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 04:35:04 --> Language Class Initialized
DEBUG - 2015-03-02 04:35:04 --> Loader Class Initialized
DEBUG - 2015-03-02 04:35:04 --> Database Driver Class Initialized
DEBUG - 2015-03-02 04:35:04 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 04:35:04 --> Controller Class Initialized
DEBUG - 2015-03-02 04:35:04 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 04:35:04 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 04:35:04 --> Model Class Initialized
DEBUG - 2015-03-02 04:35:04 --> Model Class Initialized
DEBUG - 2015-03-02 04:37:23 --> Config Class Initialized
DEBUG - 2015-03-02 04:37:23 --> Hooks Class Initialized
DEBUG - 2015-03-02 04:37:23 --> Utf8 Class Initialized
DEBUG - 2015-03-02 04:37:23 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 04:37:23 --> URI Class Initialized
DEBUG - 2015-03-02 04:37:23 --> Router Class Initialized
DEBUG - 2015-03-02 04:37:23 --> Output Class Initialized
DEBUG - 2015-03-02 04:37:23 --> Security Class Initialized
DEBUG - 2015-03-02 04:37:23 --> Input Class Initialized
DEBUG - 2015-03-02 04:37:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 04:37:23 --> Language Class Initialized
DEBUG - 2015-03-02 04:37:23 --> Loader Class Initialized
DEBUG - 2015-03-02 04:37:23 --> Database Driver Class Initialized
DEBUG - 2015-03-02 04:37:23 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 04:37:23 --> Controller Class Initialized
DEBUG - 2015-03-02 04:37:23 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 04:37:23 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 04:37:23 --> Model Class Initialized
DEBUG - 2015-03-02 04:37:23 --> Model Class Initialized
DEBUG - 2015-03-02 05:03:30 --> Config Class Initialized
DEBUG - 2015-03-02 05:03:30 --> Hooks Class Initialized
DEBUG - 2015-03-02 05:03:30 --> Utf8 Class Initialized
DEBUG - 2015-03-02 05:03:30 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 05:03:30 --> Config Class Initialized
DEBUG - 2015-03-02 05:03:30 --> Hooks Class Initialized
DEBUG - 2015-03-02 05:03:30 --> URI Class Initialized
DEBUG - 2015-03-02 05:03:30 --> Utf8 Class Initialized
DEBUG - 2015-03-02 05:03:30 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 05:03:30 --> Router Class Initialized
DEBUG - 2015-03-02 05:03:30 --> URI Class Initialized
DEBUG - 2015-03-02 05:03:30 --> Output Class Initialized
DEBUG - 2015-03-02 05:03:30 --> Router Class Initialized
DEBUG - 2015-03-02 05:03:30 --> Security Class Initialized
DEBUG - 2015-03-02 05:03:30 --> Output Class Initialized
DEBUG - 2015-03-02 05:03:30 --> Input Class Initialized
DEBUG - 2015-03-02 05:03:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 05:03:30 --> Language Class Initialized
DEBUG - 2015-03-02 05:03:30 --> Security Class Initialized
DEBUG - 2015-03-02 05:03:30 --> Input Class Initialized
DEBUG - 2015-03-02 05:03:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 05:03:30 --> Language Class Initialized
DEBUG - 2015-03-02 05:03:30 --> Loader Class Initialized
DEBUG - 2015-03-02 05:03:30 --> Loader Class Initialized
DEBUG - 2015-03-02 05:03:30 --> Database Driver Class Initialized
DEBUG - 2015-03-02 05:03:30 --> Database Driver Class Initialized
DEBUG - 2015-03-02 05:03:30 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 05:03:30 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 05:03:30 --> Controller Class Initialized
DEBUG - 2015-03-02 05:03:30 --> Controller Class Initialized
DEBUG - 2015-03-02 05:03:30 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 05:03:30 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 05:03:30 --> Model Class Initialized
DEBUG - 2015-03-02 05:03:30 --> Model Class Initialized
DEBUG - 2015-03-02 05:03:30 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 05:03:30 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 05:03:30 --> Model Class Initialized
DEBUG - 2015-03-02 05:03:30 --> Model Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Config Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Hooks Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Utf8 Class Initialized
DEBUG - 2015-03-02 05:45:09 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 05:45:09 --> URI Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Config Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Hooks Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Utf8 Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Router Class Initialized
DEBUG - 2015-03-02 05:45:09 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 05:45:09 --> URI Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Output Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Router Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Security Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Output Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Input Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 05:45:09 --> Language Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Security Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Input Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 05:45:09 --> Language Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Loader Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Loader Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Database Driver Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Database Driver Class Initialized
DEBUG - 2015-03-02 05:45:09 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Controller Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 05:45:09 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 05:45:09 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Controller Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Model Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 05:45:09 --> Model Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 05:45:09 --> Model Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Model Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Config Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Hooks Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Utf8 Class Initialized
DEBUG - 2015-03-02 05:45:09 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 05:45:09 --> URI Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Router Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Output Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Security Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Input Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 05:45:09 --> Language Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Config Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Hooks Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Utf8 Class Initialized
DEBUG - 2015-03-02 05:45:09 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 05:45:09 --> URI Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Router Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Loader Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Database Driver Class Initialized
DEBUG - 2015-03-02 05:45:09 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Controller Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 05:45:09 --> Output Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Security Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Input Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 05:45:09 --> Language Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Loader Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Database Driver Class Initialized
DEBUG - 2015-03-02 05:45:09 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Controller Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 05:45:09 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 05:45:09 --> Model Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Model Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 05:45:09 --> Model Class Initialized
DEBUG - 2015-03-02 05:45:09 --> Model Class Initialized
DEBUG - 2015-03-02 05:45:09 --> DB Transaction Failure
ERROR - 2015-03-02 05:45:09 --> Query error: Table 'nyc.agents' doesn't exist
DEBUG - 2015-03-02 05:45:09 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-02 05:47:20 --> Config Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Hooks Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Utf8 Class Initialized
DEBUG - 2015-03-02 05:47:20 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 05:47:20 --> URI Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Router Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Output Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Security Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Input Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 05:47:20 --> Language Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Loader Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Config Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Hooks Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Utf8 Class Initialized
DEBUG - 2015-03-02 05:47:20 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 05:47:20 --> URI Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Router Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Config Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Config Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Output Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Hooks Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Hooks Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Utf8 Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Security Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Utf8 Class Initialized
DEBUG - 2015-03-02 05:47:20 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 05:47:20 --> Input Class Initialized
DEBUG - 2015-03-02 05:47:20 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 05:47:20 --> URI Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 05:47:20 --> URI Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Language Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Router Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Router Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Loader Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Output Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Output Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Security Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Security Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Input Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Input Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 05:47:20 --> Language Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Database Driver Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Loader Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Database Driver Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 05:47:20 --> Language Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Database Driver Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Loader Class Initialized
DEBUG - 2015-03-02 05:47:20 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Controller Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 05:47:20 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 05:47:20 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Database Driver Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Model Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Model Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Controller Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 05:47:20 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Controller Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 05:47:20 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 05:47:20 --> Model Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Model Class Initialized
DEBUG - 2015-03-02 05:47:20 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Controller Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 05:47:20 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 05:47:20 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 05:47:20 --> Model Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Model Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Model Class Initialized
DEBUG - 2015-03-02 05:47:20 --> Model Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Config Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Hooks Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Utf8 Class Initialized
DEBUG - 2015-03-02 05:54:34 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 05:54:34 --> URI Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Router Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Output Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Security Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Input Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 05:54:34 --> Language Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Loader Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Database Driver Class Initialized
DEBUG - 2015-03-02 05:54:34 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Controller Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 05:54:34 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 05:54:34 --> Model Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Model Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Config Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Hooks Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Utf8 Class Initialized
DEBUG - 2015-03-02 05:54:34 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 05:54:34 --> URI Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Router Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Output Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Security Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Input Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 05:54:34 --> Language Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Loader Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Config Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Hooks Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Utf8 Class Initialized
DEBUG - 2015-03-02 05:54:34 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 05:54:34 --> URI Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Router Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Output Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Security Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Input Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 05:54:34 --> Language Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Loader Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Database Driver Class Initialized
DEBUG - 2015-03-02 05:54:34 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Controller Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 05:54:34 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 05:54:34 --> Model Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Model Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Config Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Hooks Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Utf8 Class Initialized
DEBUG - 2015-03-02 05:54:34 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 05:54:34 --> URI Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Database Driver Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Router Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Output Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Security Class Initialized
DEBUG - 2015-03-02 05:54:34 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Controller Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Input Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 05:54:34 --> Language Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 05:54:34 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 05:54:34 --> Model Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Model Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Loader Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Database Driver Class Initialized
DEBUG - 2015-03-02 05:54:34 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Controller Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 05:54:34 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 05:54:34 --> Model Class Initialized
DEBUG - 2015-03-02 05:54:34 --> Model Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Config Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:02:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:02:56 --> URI Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Router Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Output Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Config Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Security Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Input Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:02:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:02:56 --> Language Class Initialized
DEBUG - 2015-03-02 06:02:56 --> URI Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Router Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Config Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:02:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:02:56 --> URI Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Router Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Output Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Security Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Input Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:02:56 --> Language Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Loader Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Loader Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:02:56 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Controller Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:02:56 --> Output Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:02:56 --> Security Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Config Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Model Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Input Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Model Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:02:56 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:02:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:02:56 --> URI Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Router Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Output Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Security Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Input Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:02:56 --> Language Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Loader Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Language Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Loader Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:02:56 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Controller Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:02:56 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:02:56 --> Model Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Model Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:02:56 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Controller Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:02:56 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:02:56 --> Model Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Model Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:02:56 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Controller Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:02:56 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:02:56 --> Model Class Initialized
DEBUG - 2015-03-02 06:02:56 --> Model Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Config Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:07:32 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:07:32 --> URI Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Config Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Router Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:07:32 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:07:32 --> URI Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Output Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Router Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Security Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Input Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:07:32 --> Output Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Language Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Security Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Input Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:07:32 --> Language Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Loader Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Loader Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:07:32 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Controller Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:07:32 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Controller Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:07:32 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:07:32 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:07:32 --> Model Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Model Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Model Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Model Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Config Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:07:32 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:07:32 --> URI Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Router Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Output Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Security Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Input Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:07:32 --> Language Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Loader Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Config Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:07:32 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:07:32 --> URI Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Router Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Output Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Security Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Input Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:07:32 --> Language Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Loader Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:07:32 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Controller Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:07:32 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:07:32 --> Model Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Model Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:07:32 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Controller Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:07:32 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:07:32 --> Model Class Initialized
DEBUG - 2015-03-02 06:07:32 --> Model Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Config Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:14:59 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:14:59 --> URI Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Config Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:14:59 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:14:59 --> URI Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Router Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Output Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Security Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Input Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:14:59 --> Language Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Config Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Config Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Loader Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:14:59 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:14:59 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Controller Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:14:59 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:14:59 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:14:59 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:14:59 --> Router Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Model Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Model Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Output Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Security Class Initialized
DEBUG - 2015-03-02 06:14:59 --> URI Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Input Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:14:59 --> Language Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Router Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Output Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Security Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Loader Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Input Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:14:59 --> Language Class Initialized
DEBUG - 2015-03-02 06:14:59 --> URI Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Router Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Output Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Security Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Input Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:14:59 --> Language Class Initialized
DEBUG - 2015-03-02 06:14:59 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Controller Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:14:59 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:14:59 --> Model Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Model Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Loader Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:14:59 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Loader Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:14:59 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Controller Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:14:59 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:14:59 --> Model Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Controller Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:14:59 --> Model Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:14:59 --> Model Class Initialized
DEBUG - 2015-03-02 06:14:59 --> Model Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Config Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Config Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:29:52 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:29:52 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:29:52 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:29:52 --> URI Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Router Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Output Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Security Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Input Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:29:52 --> URI Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Router Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Output Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Config Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:29:52 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:29:52 --> URI Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Router Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Output Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Language Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Loader Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Security Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Input Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:29:52 --> Language Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Loader Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Security Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Config Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Input Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:29:52 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:29:52 --> URI Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Router Class Initialized
DEBUG - 2015-03-02 06:29:52 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Controller Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:29:52 --> Output Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Security Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Input Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:29:52 --> Language Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:29:52 --> Language Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Loader Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Loader Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:29:52 --> Model Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Model Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:29:52 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Controller Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:29:52 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:29:52 --> Model Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Model Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:29:52 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Controller Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:29:52 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:29:52 --> Model Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Model Class Initialized
DEBUG - 2015-03-02 06:29:52 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Controller Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:29:52 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:29:52 --> Model Class Initialized
DEBUG - 2015-03-02 06:29:52 --> Model Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Config Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:33:48 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:33:48 --> URI Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Router Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Output Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Security Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Input Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:33:48 --> Language Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Loader Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Config Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Config Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Config Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:33:48 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Controller Class Initialized
DEBUG - 2015-03-02 06:33:48 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:33:48 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:33:48 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:33:48 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:33:48 --> URI Class Initialized
DEBUG - 2015-03-02 06:33:48 --> URI Class Initialized
DEBUG - 2015-03-02 06:33:48 --> URI Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:33:48 --> Router Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Router Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Router Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Output Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Model Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Output Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Output Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Security Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Model Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Security Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Input Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Security Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:33:48 --> Input Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Language Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Input Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Loader Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:33:48 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:33:48 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Language Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Controller Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Language Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:33:48 --> Loader Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Loader Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:33:48 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:33:48 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:33:49 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:33:49 --> Controller Class Initialized
DEBUG - 2015-03-02 06:33:49 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:33:49 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:33:49 --> Model Class Initialized
DEBUG - 2015-03-02 06:33:49 --> Model Class Initialized
DEBUG - 2015-03-02 06:33:49 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:33:49 --> Model Class Initialized
DEBUG - 2015-03-02 06:33:49 --> Controller Class Initialized
DEBUG - 2015-03-02 06:33:49 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:33:49 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:33:49 --> Model Class Initialized
DEBUG - 2015-03-02 06:33:49 --> Model Class Initialized
DEBUG - 2015-03-02 06:33:49 --> Model Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Config Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:37:13 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:37:13 --> Config Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:37:13 --> URI Class Initialized
DEBUG - 2015-03-02 06:37:13 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:37:13 --> Router Class Initialized
DEBUG - 2015-03-02 06:37:13 --> URI Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Router Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Output Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Security Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Output Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Input Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:37:13 --> Security Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Language Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Input Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:37:13 --> Language Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Loader Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Loader Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:37:13 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Controller Class Initialized
DEBUG - 2015-03-02 06:37:13 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Controller Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:37:13 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:37:13 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:37:13 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:37:13 --> Model Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Model Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Model Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Model Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Config Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:37:13 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:37:13 --> Config Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:37:13 --> URI Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:37:13 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:37:13 --> Router Class Initialized
DEBUG - 2015-03-02 06:37:13 --> URI Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Router Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Output Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Output Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Security Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Security Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Input Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:37:13 --> Language Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Input Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:37:13 --> Language Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Loader Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:37:13 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Controller Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:37:13 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:37:13 --> Model Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Model Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Loader Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:37:13 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Controller Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:37:13 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:37:13 --> Model Class Initialized
DEBUG - 2015-03-02 06:37:13 --> Model Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Config Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:39:16 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:39:16 --> URI Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Router Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Output Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Security Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Input Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:39:16 --> Language Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Loader Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Config Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:39:16 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:39:16 --> URI Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Router Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Output Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Security Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Input Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:39:16 --> Language Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Loader Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Config Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:39:16 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:39:16 --> URI Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Router Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Output Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Security Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Input Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:39:16 --> Language Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Loader Class Initialized
DEBUG - 2015-03-02 06:39:16 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Controller Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:39:16 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:39:16 --> Model Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Model Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:39:16 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Controller Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:39:16 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:39:16 --> Model Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Model Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:39:16 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Controller Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:39:16 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:39:16 --> Model Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Model Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Config Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:39:16 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:39:16 --> URI Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Router Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Output Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Security Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Input Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:39:16 --> Language Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Loader Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:39:16 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Controller Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:39:16 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:39:16 --> Model Class Initialized
DEBUG - 2015-03-02 06:39:16 --> Model Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Config Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:42:33 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:42:33 --> Config Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:42:33 --> URI Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:42:33 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:42:33 --> Router Class Initialized
DEBUG - 2015-03-02 06:42:33 --> URI Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Router Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Output Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Security Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Output Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Input Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:42:33 --> Security Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Language Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Input Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:42:33 --> Language Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Loader Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Loader Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:42:33 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Controller Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:42:33 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Controller Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:42:33 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:42:33 --> Model Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:42:33 --> Model Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Model Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Model Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Config Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Config Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:42:33 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:42:33 --> URI Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:42:33 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:42:33 --> URI Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Router Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Router Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Output Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Security Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Input Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:42:33 --> Language Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Loader Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:42:33 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Controller Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Output Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Security Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Input Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:42:33 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:42:33 --> Model Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Model Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:42:33 --> Language Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Loader Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:42:33 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Controller Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:42:33 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:42:33 --> Model Class Initialized
DEBUG - 2015-03-02 06:42:33 --> Model Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Config Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:42:51 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:42:51 --> URI Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Router Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Output Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Security Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Input Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:42:51 --> Language Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Loader Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:42:51 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Config Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:42:51 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:42:51 --> URI Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Router Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Output Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Security Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Input Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:42:51 --> Language Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Loader Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Config Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:42:51 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:42:51 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:42:51 --> Controller Class Initialized
DEBUG - 2015-03-02 06:42:51 --> URI Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:42:51 --> Controller Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Router Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:42:51 --> Config Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:42:51 --> Model Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Output Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Model Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:42:51 --> Security Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Model Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Input Class Initialized
DEBUG - 2015-03-02 06:42:51 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:42:51 --> Model Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:42:51 --> URI Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Language Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Router Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Loader Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Output Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Security Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Input Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:42:51 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Language Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Controller Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:42:51 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:42:51 --> Model Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Model Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Loader Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:42:51 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Controller Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:42:51 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:42:51 --> Model Class Initialized
DEBUG - 2015-03-02 06:42:51 --> Model Class Initialized
DEBUG - 2015-03-02 06:42:54 --> Config Class Initialized
DEBUG - 2015-03-02 06:42:54 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:42:54 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:42:54 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:42:54 --> URI Class Initialized
DEBUG - 2015-03-02 06:42:54 --> Router Class Initialized
DEBUG - 2015-03-02 06:42:54 --> Output Class Initialized
DEBUG - 2015-03-02 06:42:54 --> Security Class Initialized
DEBUG - 2015-03-02 06:42:54 --> Input Class Initialized
DEBUG - 2015-03-02 06:42:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:42:54 --> Language Class Initialized
DEBUG - 2015-03-02 06:42:54 --> Loader Class Initialized
DEBUG - 2015-03-02 06:42:54 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:42:54 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:42:54 --> Controller Class Initialized
DEBUG - 2015-03-02 06:42:54 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:42:54 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:42:54 --> Model Class Initialized
DEBUG - 2015-03-02 06:42:54 --> Model Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Config Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:49:03 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:49:03 --> URI Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Router Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Output Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Security Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Input Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:49:03 --> Language Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Config Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:49:03 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:49:03 --> URI Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Loader Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Router Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Output Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Security Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Input Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:49:03 --> Language Class Initialized
DEBUG - 2015-03-02 06:49:03 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Controller Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:49:03 --> Loader Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Config Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:49:03 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:49:03 --> URI Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Router Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Output Class Initialized
DEBUG - 2015-03-02 06:49:03 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Controller Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:49:03 --> Security Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Input Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:49:03 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:49:03 --> Language Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Model Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Model Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Loader Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:49:03 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Controller Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:49:03 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:49:03 --> Model Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Model Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:49:03 --> Model Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Model Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Config Class Initialized
DEBUG - 2015-03-02 06:49:03 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:49:04 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:49:04 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:49:04 --> URI Class Initialized
DEBUG - 2015-03-02 06:49:04 --> Router Class Initialized
DEBUG - 2015-03-02 06:49:04 --> Output Class Initialized
DEBUG - 2015-03-02 06:49:04 --> Security Class Initialized
DEBUG - 2015-03-02 06:49:04 --> Input Class Initialized
DEBUG - 2015-03-02 06:49:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:49:04 --> Language Class Initialized
DEBUG - 2015-03-02 06:49:04 --> Loader Class Initialized
DEBUG - 2015-03-02 06:49:04 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:49:04 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:49:04 --> Controller Class Initialized
DEBUG - 2015-03-02 06:49:04 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:49:04 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:49:04 --> Model Class Initialized
DEBUG - 2015-03-02 06:49:04 --> Model Class Initialized
DEBUG - 2015-03-02 06:49:06 --> Config Class Initialized
DEBUG - 2015-03-02 06:49:06 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:49:06 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:49:06 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:49:06 --> URI Class Initialized
DEBUG - 2015-03-02 06:49:06 --> Router Class Initialized
DEBUG - 2015-03-02 06:49:06 --> Output Class Initialized
DEBUG - 2015-03-02 06:49:06 --> Security Class Initialized
DEBUG - 2015-03-02 06:49:06 --> Input Class Initialized
DEBUG - 2015-03-02 06:49:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:49:06 --> Language Class Initialized
DEBUG - 2015-03-02 06:49:06 --> Loader Class Initialized
DEBUG - 2015-03-02 06:49:06 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:49:06 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:49:06 --> Controller Class Initialized
DEBUG - 2015-03-02 06:49:06 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:49:06 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:49:06 --> Model Class Initialized
DEBUG - 2015-03-02 06:49:06 --> Model Class Initialized
DEBUG - 2015-03-02 06:49:06 --> DB Transaction Failure
ERROR - 2015-03-02 06:49:06 --> Query error: Table 'nyc.user' doesn't exist
DEBUG - 2015-03-02 06:49:06 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-02 06:50:58 --> Config Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:50:58 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:50:58 --> URI Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Router Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Output Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Security Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Input Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:50:58 --> Language Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Loader Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Config Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Config Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:50:58 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:50:58 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:50:58 --> Controller Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:50:58 --> URI Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:50:58 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:50:58 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:50:58 --> Model Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Router Class Initialized
DEBUG - 2015-03-02 06:50:58 --> URI Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Output Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Router Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Security Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Input Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:50:58 --> Output Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Model Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Language Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Security Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Input Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:50:58 --> Language Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Loader Class Initialized
DEBUG - 2015-03-02 06:50:58 --> Loader Class Initialized
DEBUG - 2015-03-02 06:50:59 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:50:59 --> Config Class Initialized
DEBUG - 2015-03-02 06:50:59 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:50:59 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:50:59 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:50:59 --> URI Class Initialized
DEBUG - 2015-03-02 06:50:59 --> Router Class Initialized
DEBUG - 2015-03-02 06:50:59 --> Output Class Initialized
DEBUG - 2015-03-02 06:50:59 --> Security Class Initialized
DEBUG - 2015-03-02 06:50:59 --> Input Class Initialized
DEBUG - 2015-03-02 06:50:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:50:59 --> Language Class Initialized
DEBUG - 2015-03-02 06:50:59 --> Loader Class Initialized
DEBUG - 2015-03-02 06:50:59 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:50:59 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:50:59 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:50:59 --> Controller Class Initialized
DEBUG - 2015-03-02 06:50:59 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:50:59 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:50:59 --> Model Class Initialized
DEBUG - 2015-03-02 06:50:59 --> Model Class Initialized
DEBUG - 2015-03-02 06:50:59 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:50:59 --> Controller Class Initialized
DEBUG - 2015-03-02 06:50:59 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:50:59 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:50:59 --> Model Class Initialized
DEBUG - 2015-03-02 06:50:59 --> Model Class Initialized
DEBUG - 2015-03-02 06:50:59 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:50:59 --> Controller Class Initialized
DEBUG - 2015-03-02 06:50:59 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:50:59 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:50:59 --> Model Class Initialized
DEBUG - 2015-03-02 06:50:59 --> Model Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Config Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:51:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:51:45 --> Config Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:51:45 --> URI Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:51:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:51:45 --> Router Class Initialized
DEBUG - 2015-03-02 06:51:45 --> URI Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Output Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Router Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Output Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Security Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Security Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Input Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:51:45 --> Input Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Language Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:51:45 --> Language Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Loader Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Loader Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:51:45 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Controller Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:51:45 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:51:45 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Controller Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:51:45 --> Model Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Model Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:51:45 --> Model Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Model Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Config Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Config Class Initialized
DEBUG - 2015-03-02 06:51:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:51:45 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:51:45 --> URI Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:51:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:51:45 --> Router Class Initialized
DEBUG - 2015-03-02 06:51:45 --> URI Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Output Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Router Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Security Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Input Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Output Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:51:45 --> Security Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Language Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Input Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:51:45 --> Language Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Loader Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Loader Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:51:45 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Controller Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:51:45 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:51:45 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Model Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Controller Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Model Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:51:45 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:51:45 --> Model Class Initialized
DEBUG - 2015-03-02 06:51:45 --> Model Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Config Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Config Class Initialized
DEBUG - 2015-03-02 06:52:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:52:47 --> URI Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Router Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Output Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Security Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Input Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:52:47 --> Language Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Loader Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Config Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Config Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:52:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:52:47 --> URI Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Router Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Output Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Security Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Input Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:52:47 --> Language Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Loader Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:52:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:52:47 --> URI Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Router Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Output Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Security Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Input Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:52:47 --> Language Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Loader Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:52:47 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Controller Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:52:47 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:52:47 --> Model Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Model Class Initialized
DEBUG - 2015-03-02 06:52:47 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Controller Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:52:47 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:52:47 --> Model Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Model Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:52:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:52:47 --> URI Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Router Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Output Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Security Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Input Class Initialized
DEBUG - 2015-03-02 06:52:47 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Controller Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:52:47 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:52:47 --> Model Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Model Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:52:47 --> Language Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Loader Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:52:47 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Controller Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:52:47 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:52:47 --> Model Class Initialized
DEBUG - 2015-03-02 06:52:47 --> Model Class Initialized
DEBUG - 2015-03-02 06:52:51 --> Config Class Initialized
DEBUG - 2015-03-02 06:52:51 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:52:51 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:52:51 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:52:51 --> URI Class Initialized
DEBUG - 2015-03-02 06:52:51 --> Router Class Initialized
DEBUG - 2015-03-02 06:52:51 --> Output Class Initialized
DEBUG - 2015-03-02 06:52:51 --> Security Class Initialized
DEBUG - 2015-03-02 06:52:51 --> Input Class Initialized
DEBUG - 2015-03-02 06:52:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:52:51 --> Language Class Initialized
DEBUG - 2015-03-02 06:52:51 --> Loader Class Initialized
DEBUG - 2015-03-02 06:52:51 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:52:51 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:52:51 --> Controller Class Initialized
DEBUG - 2015-03-02 06:52:51 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:52:51 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:52:51 --> Model Class Initialized
DEBUG - 2015-03-02 06:52:51 --> Model Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Config Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Config Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:54:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:54:56 --> URI Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Router Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:54:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:54:56 --> URI Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Router Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Output Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Security Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Input Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:54:56 --> Output Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Language Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Security Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Input Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:54:56 --> Language Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Loader Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Loader Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Config Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:54:56 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Controller Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Config Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:54:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:54:56 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:54:56 --> URI Class Initialized
DEBUG - 2015-03-02 06:54:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:54:56 --> URI Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Router Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Router Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Output Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Output Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Security Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Security Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Input Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:54:56 --> Input Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Language Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:54:56 --> Language Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Loader Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Loader Class Initialized
DEBUG - 2015-03-02 06:54:56 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Controller Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:54:56 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Controller Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:54:56 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:54:56 --> Model Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:54:56 --> Model Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Model Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Model Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:54:56 --> Model Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Model Class Initialized
DEBUG - 2015-03-02 06:54:56 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Controller Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:54:56 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:54:56 --> Model Class Initialized
DEBUG - 2015-03-02 06:54:56 --> Model Class Initialized
DEBUG - 2015-03-02 06:59:46 --> Config Class Initialized
DEBUG - 2015-03-02 06:59:46 --> Hooks Class Initialized
DEBUG - 2015-03-02 06:59:46 --> Utf8 Class Initialized
DEBUG - 2015-03-02 06:59:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 06:59:46 --> URI Class Initialized
DEBUG - 2015-03-02 06:59:46 --> Router Class Initialized
DEBUG - 2015-03-02 06:59:46 --> Output Class Initialized
DEBUG - 2015-03-02 06:59:46 --> Security Class Initialized
DEBUG - 2015-03-02 06:59:46 --> Input Class Initialized
DEBUG - 2015-03-02 06:59:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 06:59:46 --> Language Class Initialized
DEBUG - 2015-03-02 06:59:46 --> Loader Class Initialized
DEBUG - 2015-03-02 06:59:46 --> Database Driver Class Initialized
DEBUG - 2015-03-02 06:59:46 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 06:59:46 --> Controller Class Initialized
DEBUG - 2015-03-02 06:59:46 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 06:59:46 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 06:59:46 --> Model Class Initialized
DEBUG - 2015-03-02 06:59:46 --> Model Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Config Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:01:54 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:01:54 --> URI Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Router Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Output Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Security Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Input Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:01:54 --> Language Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Config Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:01:54 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:01:54 --> Loader Class Initialized
DEBUG - 2015-03-02 07:01:54 --> URI Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Config Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Config Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Router Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Output Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Security Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Input Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:01:54 --> Language Class Initialized
DEBUG - 2015-03-02 07:01:54 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:01:54 --> URI Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Loader Class Initialized
DEBUG - 2015-03-02 07:01:54 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:01:54 --> Router Class Initialized
DEBUG - 2015-03-02 07:01:54 --> URI Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Output Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Security Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Input Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:01:54 --> Language Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:01:54 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Controller Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Loader Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Router Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Output Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Security Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Input Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:01:54 --> Language Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Loader Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:01:54 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Controller Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:01:54 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:01:54 --> Model Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Model Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:01:54 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Controller Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:01:54 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Controller Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:01:54 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:01:54 --> Model Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Model Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:01:54 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:01:54 --> Model Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Model Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:01:54 --> Model Class Initialized
DEBUG - 2015-03-02 07:01:54 --> Model Class Initialized
DEBUG - 2015-03-02 07:01:57 --> Config Class Initialized
DEBUG - 2015-03-02 07:01:57 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:01:57 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:01:57 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:01:57 --> URI Class Initialized
DEBUG - 2015-03-02 07:01:57 --> Router Class Initialized
DEBUG - 2015-03-02 07:01:57 --> Output Class Initialized
DEBUG - 2015-03-02 07:01:57 --> Security Class Initialized
DEBUG - 2015-03-02 07:01:57 --> Input Class Initialized
DEBUG - 2015-03-02 07:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:01:57 --> Language Class Initialized
DEBUG - 2015-03-02 07:01:57 --> Loader Class Initialized
DEBUG - 2015-03-02 07:01:57 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:01:57 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:01:57 --> Controller Class Initialized
DEBUG - 2015-03-02 07:01:57 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:01:57 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:01:57 --> Model Class Initialized
DEBUG - 2015-03-02 07:01:57 --> Model Class Initialized
DEBUG - 2015-03-02 07:02:23 --> Config Class Initialized
DEBUG - 2015-03-02 07:02:23 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:02:23 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:02:23 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:02:23 --> URI Class Initialized
DEBUG - 2015-03-02 07:02:23 --> Router Class Initialized
DEBUG - 2015-03-02 07:02:23 --> Output Class Initialized
DEBUG - 2015-03-02 07:02:23 --> Security Class Initialized
DEBUG - 2015-03-02 07:02:23 --> Input Class Initialized
DEBUG - 2015-03-02 07:02:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:02:23 --> Language Class Initialized
DEBUG - 2015-03-02 07:02:23 --> Config Class Initialized
DEBUG - 2015-03-02 07:02:23 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:02:23 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:02:23 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:02:23 --> URI Class Initialized
DEBUG - 2015-03-02 07:02:23 --> Router Class Initialized
DEBUG - 2015-03-02 07:02:23 --> Loader Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Output Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Config Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:02:24 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:02:24 --> URI Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Router Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Config Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Output Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:02:24 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:02:24 --> Security Class Initialized
DEBUG - 2015-03-02 07:02:24 --> URI Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Input Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Router Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:02:24 --> Security Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Output Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Input Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:02:24 --> Language Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Loader Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Security Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Language Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Input Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:02:24 --> Language Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Loader Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Loader Class Initialized
DEBUG - 2015-03-02 07:02:24 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Controller Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:02:24 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:02:24 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Controller Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:02:24 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:02:24 --> Model Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Model Class Initialized
DEBUG - 2015-03-02 07:02:24 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Controller Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:02:24 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:02:24 --> Model Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Model Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:02:24 --> Model Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Model Class Initialized
DEBUG - 2015-03-02 07:02:24 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Controller Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:02:24 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:02:24 --> Model Class Initialized
DEBUG - 2015-03-02 07:02:24 --> Model Class Initialized
DEBUG - 2015-03-02 07:02:30 --> Config Class Initialized
DEBUG - 2015-03-02 07:02:30 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:02:30 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:02:31 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:02:31 --> URI Class Initialized
DEBUG - 2015-03-02 07:02:31 --> Router Class Initialized
DEBUG - 2015-03-02 07:02:31 --> Output Class Initialized
DEBUG - 2015-03-02 07:02:31 --> Security Class Initialized
DEBUG - 2015-03-02 07:02:31 --> Input Class Initialized
DEBUG - 2015-03-02 07:02:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:02:31 --> Language Class Initialized
DEBUG - 2015-03-02 07:02:31 --> Loader Class Initialized
DEBUG - 2015-03-02 07:02:31 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:02:31 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:02:31 --> Controller Class Initialized
DEBUG - 2015-03-02 07:02:31 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:02:31 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:02:31 --> Model Class Initialized
DEBUG - 2015-03-02 07:02:31 --> Model Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Config Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:04:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:04:45 --> URI Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Router Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Output Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Security Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Config Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:04:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:04:45 --> Config Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:04:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:04:45 --> URI Class Initialized
DEBUG - 2015-03-02 07:04:45 --> URI Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Router Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Output Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Router Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Security Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Output Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Input Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:04:45 --> Language Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Security Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Input Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:04:45 --> Language Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Loader Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Loader Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Input Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:04:45 --> Language Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Loader Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:04:45 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:04:45 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Controller Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:04:45 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:04:45 --> Model Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Model Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Config Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:04:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:04:45 --> URI Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Router Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Output Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Security Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Input Class Initialized
DEBUG - 2015-03-02 07:04:45 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Controller Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:04:45 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:04:45 --> Model Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Model Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Controller Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:04:45 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:04:45 --> Language Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:04:45 --> Model Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Model Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Loader Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:04:45 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Controller Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:04:45 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:04:45 --> Model Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Model Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Config Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:04:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:04:45 --> URI Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Router Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Config Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Config Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Output Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:04:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:04:45 --> URI Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Security Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Router Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Input Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:04:45 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:04:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:04:45 --> Language Class Initialized
DEBUG - 2015-03-02 07:04:45 --> URI Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Router Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Output Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Security Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Loader Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Input Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:04:45 --> Language Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Loader Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Config Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:04:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:04:45 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Controller Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:04:45 --> Output Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:04:45 --> Model Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Security Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Model Class Initialized
DEBUG - 2015-03-02 07:04:45 --> URI Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Input Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:04:45 --> Language Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Router Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Loader Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Output Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Security Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Input Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:04:45 --> Language Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Loader Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:04:45 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Controller Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:04:45 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:04:45 --> Model Class Initialized
DEBUG - 2015-03-02 07:04:45 --> Model Class Initialized
DEBUG - 2015-03-02 07:04:46 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:04:46 --> Controller Class Initialized
DEBUG - 2015-03-02 07:04:46 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:04:46 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:04:46 --> Model Class Initialized
DEBUG - 2015-03-02 07:04:46 --> Model Class Initialized
DEBUG - 2015-03-02 07:04:46 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:04:46 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:04:46 --> Controller Class Initialized
DEBUG - 2015-03-02 07:04:46 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:04:46 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:04:46 --> Model Class Initialized
DEBUG - 2015-03-02 07:04:46 --> Model Class Initialized
DEBUG - 2015-03-02 07:04:50 --> Config Class Initialized
DEBUG - 2015-03-02 07:04:50 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:04:50 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:04:50 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:04:50 --> URI Class Initialized
DEBUG - 2015-03-02 07:04:50 --> Router Class Initialized
DEBUG - 2015-03-02 07:04:50 --> Output Class Initialized
DEBUG - 2015-03-02 07:04:50 --> Security Class Initialized
DEBUG - 2015-03-02 07:04:50 --> Input Class Initialized
DEBUG - 2015-03-02 07:04:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:04:50 --> Language Class Initialized
DEBUG - 2015-03-02 07:04:50 --> Loader Class Initialized
DEBUG - 2015-03-02 07:04:50 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:04:50 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:04:50 --> Controller Class Initialized
DEBUG - 2015-03-02 07:04:50 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:04:50 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:04:50 --> Model Class Initialized
DEBUG - 2015-03-02 07:04:50 --> Model Class Initialized
DEBUG - 2015-03-02 07:09:06 --> Config Class Initialized
DEBUG - 2015-03-02 07:09:06 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:09:06 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:09:06 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:09:06 --> URI Class Initialized
DEBUG - 2015-03-02 07:09:06 --> Router Class Initialized
DEBUG - 2015-03-02 07:09:06 --> Output Class Initialized
DEBUG - 2015-03-02 07:09:06 --> Security Class Initialized
DEBUG - 2015-03-02 07:09:06 --> Input Class Initialized
DEBUG - 2015-03-02 07:09:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:09:06 --> Language Class Initialized
DEBUG - 2015-03-02 07:09:06 --> Config Class Initialized
DEBUG - 2015-03-02 07:09:06 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:09:06 --> Loader Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:09:07 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:09:07 --> URI Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Router Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Output Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Security Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Input Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:09:07 --> Language Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Loader Class Initialized
DEBUG - 2015-03-02 07:09:07 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Controller Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:09:07 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:09:07 --> Model Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Model Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:09:07 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Controller Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:09:07 --> Config Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:09:07 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:09:07 --> URI Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Router Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:09:07 --> Model Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Model Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Config Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Output Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:09:07 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:09:07 --> URI Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Router Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Security Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Input Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:09:07 --> Language Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Loader Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:09:07 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Controller Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:09:07 --> Output Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Security Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Input Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:09:07 --> Language Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Loader Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:09:07 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Controller Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:09:07 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:09:07 --> Model Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Model Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:09:07 --> Model Class Initialized
DEBUG - 2015-03-02 07:09:07 --> Model Class Initialized
DEBUG - 2015-03-02 07:09:23 --> Config Class Initialized
DEBUG - 2015-03-02 07:09:23 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:09:23 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:09:23 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:09:23 --> URI Class Initialized
DEBUG - 2015-03-02 07:09:23 --> Router Class Initialized
DEBUG - 2015-03-02 07:09:23 --> Output Class Initialized
DEBUG - 2015-03-02 07:09:23 --> Security Class Initialized
DEBUG - 2015-03-02 07:09:23 --> Input Class Initialized
DEBUG - 2015-03-02 07:09:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:09:23 --> Language Class Initialized
DEBUG - 2015-03-02 07:09:23 --> Loader Class Initialized
DEBUG - 2015-03-02 07:09:23 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:09:23 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:09:23 --> Controller Class Initialized
DEBUG - 2015-03-02 07:09:23 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:09:23 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:09:23 --> Model Class Initialized
DEBUG - 2015-03-02 07:09:23 --> Model Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Config Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:10:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:10:47 --> URI Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Router Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Output Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Security Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Input Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:10:47 --> Language Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Config Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:10:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:10:47 --> URI Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Router Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Loader Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Config Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:10:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:10:47 --> Output Class Initialized
DEBUG - 2015-03-02 07:10:47 --> URI Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Security Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Router Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Input Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:10:47 --> Language Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Output Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Security Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Input Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:10:47 --> Language Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Loader Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Loader Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:10:47 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Controller Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:10:47 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Controller Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:10:47 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:10:47 --> Model Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Model Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:10:47 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:10:47 --> Controller Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Model Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:10:47 --> Model Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:10:47 --> Model Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Model Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Config Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:10:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:10:47 --> URI Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Router Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Output Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Security Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Input Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:10:47 --> Language Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Loader Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:10:47 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Controller Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:10:47 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:10:47 --> Model Class Initialized
DEBUG - 2015-03-02 07:10:47 --> Model Class Initialized
DEBUG - 2015-03-02 07:10:49 --> Config Class Initialized
DEBUG - 2015-03-02 07:10:49 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:10:49 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:10:49 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:10:49 --> URI Class Initialized
DEBUG - 2015-03-02 07:10:49 --> Router Class Initialized
DEBUG - 2015-03-02 07:10:49 --> Output Class Initialized
DEBUG - 2015-03-02 07:10:49 --> Security Class Initialized
DEBUG - 2015-03-02 07:10:49 --> Input Class Initialized
DEBUG - 2015-03-02 07:10:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:10:49 --> Language Class Initialized
DEBUG - 2015-03-02 07:10:49 --> Loader Class Initialized
DEBUG - 2015-03-02 07:10:49 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:10:49 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:10:49 --> Controller Class Initialized
DEBUG - 2015-03-02 07:10:49 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:10:49 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:10:49 --> Model Class Initialized
DEBUG - 2015-03-02 07:10:49 --> Model Class Initialized
DEBUG - 2015-03-02 07:10:49 --> DB Transaction Failure
ERROR - 2015-03-02 07:10:49 --> Query error: Table 'nyc.sers' doesn't exist
DEBUG - 2015-03-02 07:10:49 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-02 07:13:32 --> Config Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:13:32 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:13:32 --> URI Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Router Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Output Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Security Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Input Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:13:32 --> Language Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Loader Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:13:32 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Controller Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:13:32 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:13:32 --> Model Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Model Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Config Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:13:32 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:13:32 --> URI Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Router Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Output Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Security Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Config Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:13:32 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:13:32 --> URI Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Input Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:13:32 --> Language Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Loader Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Router Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Output Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Security Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Input Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:13:32 --> Language Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Loader Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Config Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:13:32 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:13:32 --> URI Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Router Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Output Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Security Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Input Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:13:32 --> Language Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Loader Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:13:32 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Controller Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:13:32 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:13:32 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Controller Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:13:32 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:13:32 --> Model Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Model Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:13:32 --> Model Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Model Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:13:32 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Controller Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:13:32 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:13:32 --> Model Class Initialized
DEBUG - 2015-03-02 07:13:32 --> Model Class Initialized
DEBUG - 2015-03-02 07:13:39 --> Config Class Initialized
DEBUG - 2015-03-02 07:13:39 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:13:39 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:13:39 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:13:39 --> URI Class Initialized
DEBUG - 2015-03-02 07:13:39 --> Router Class Initialized
DEBUG - 2015-03-02 07:13:39 --> Output Class Initialized
DEBUG - 2015-03-02 07:13:39 --> Security Class Initialized
DEBUG - 2015-03-02 07:13:39 --> Input Class Initialized
DEBUG - 2015-03-02 07:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:13:39 --> Language Class Initialized
DEBUG - 2015-03-02 07:13:39 --> Loader Class Initialized
DEBUG - 2015-03-02 07:13:39 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:13:39 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:13:39 --> Controller Class Initialized
DEBUG - 2015-03-02 07:13:39 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:13:39 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:13:39 --> Model Class Initialized
DEBUG - 2015-03-02 07:13:39 --> Model Class Initialized
DEBUG - 2015-03-02 07:13:39 --> DB Transaction Failure
ERROR - 2015-03-02 07:13:39 --> Query error: Table 'nyc.sers' doesn't exist
DEBUG - 2015-03-02 07:13:39 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-02 07:14:13 --> Config Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Config Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:14:13 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:14:13 --> URI Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Router Class Initialized
DEBUG - 2015-03-02 07:14:13 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:14:13 --> URI Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Router Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Output Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Security Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Input Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:14:13 --> Language Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Loader Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:14:13 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Controller Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:14:13 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:14:13 --> Model Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Model Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Output Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Security Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Input Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Config Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Config Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:14:13 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Language Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:14:13 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:14:13 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:14:13 --> URI Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Router Class Initialized
DEBUG - 2015-03-02 07:14:13 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:14:13 --> URI Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Output Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Router Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Loader Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Security Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Input Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:14:13 --> Language Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Output Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Security Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Input Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:14:13 --> Language Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Loader Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Loader Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:14:13 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Controller Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:14:13 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:14:13 --> Model Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Model Class Initialized
DEBUG - 2015-03-02 07:14:13 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Controller Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:14:13 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:14:13 --> Model Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Model Class Initialized
DEBUG - 2015-03-02 07:14:13 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Controller Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:14:13 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:14:13 --> Model Class Initialized
DEBUG - 2015-03-02 07:14:13 --> Model Class Initialized
DEBUG - 2015-03-02 07:14:16 --> Config Class Initialized
DEBUG - 2015-03-02 07:14:16 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:14:16 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:14:16 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:14:16 --> URI Class Initialized
DEBUG - 2015-03-02 07:14:16 --> Router Class Initialized
DEBUG - 2015-03-02 07:14:16 --> Output Class Initialized
DEBUG - 2015-03-02 07:14:16 --> Security Class Initialized
DEBUG - 2015-03-02 07:14:16 --> Input Class Initialized
DEBUG - 2015-03-02 07:14:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:14:16 --> Language Class Initialized
DEBUG - 2015-03-02 07:14:16 --> Loader Class Initialized
DEBUG - 2015-03-02 07:14:17 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:14:17 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:14:17 --> Controller Class Initialized
DEBUG - 2015-03-02 07:14:17 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:14:17 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:14:17 --> Model Class Initialized
DEBUG - 2015-03-02 07:14:17 --> Model Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Config Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:14:36 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:14:36 --> URI Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Router Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Output Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Security Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Input Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:14:36 --> Language Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Loader Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:14:36 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Config Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:14:36 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:14:36 --> URI Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Router Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Output Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Security Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Input Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:14:36 --> Language Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Loader Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Config Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:14:36 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:14:36 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:14:36 --> URI Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Controller Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:14:36 --> Config Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Router Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Output Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Security Class Initialized
DEBUG - 2015-03-02 07:14:36 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Controller Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Input Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:14:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:14:36 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:14:36 --> Language Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Model Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:14:36 --> Model Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:14:36 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:14:36 --> Model Class Initialized
DEBUG - 2015-03-02 07:14:36 --> URI Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Loader Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Router Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Output Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Security Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Input Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:14:36 --> Language Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Model Class Initialized
DEBUG - 2015-03-02 07:14:36 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Controller Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:14:36 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:14:36 --> Model Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Model Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Loader Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:14:36 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Controller Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:14:36 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:14:36 --> Model Class Initialized
DEBUG - 2015-03-02 07:14:36 --> Model Class Initialized
DEBUG - 2015-03-02 07:14:39 --> Config Class Initialized
DEBUG - 2015-03-02 07:14:39 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:14:39 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:14:39 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:14:39 --> URI Class Initialized
DEBUG - 2015-03-02 07:14:39 --> Router Class Initialized
DEBUG - 2015-03-02 07:14:39 --> Output Class Initialized
DEBUG - 2015-03-02 07:14:39 --> Security Class Initialized
DEBUG - 2015-03-02 07:14:39 --> Input Class Initialized
DEBUG - 2015-03-02 07:14:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:14:39 --> Language Class Initialized
DEBUG - 2015-03-02 07:14:39 --> Loader Class Initialized
DEBUG - 2015-03-02 07:14:39 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:14:39 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:14:39 --> Controller Class Initialized
DEBUG - 2015-03-02 07:14:39 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:14:39 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:14:39 --> Model Class Initialized
DEBUG - 2015-03-02 07:14:39 --> Model Class Initialized
DEBUG - 2015-03-02 07:14:39 --> DB Transaction Failure
ERROR - 2015-03-02 07:14:39 --> Query error: Table 'nyc.sers' doesn't exist
DEBUG - 2015-03-02 07:14:39 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-02 07:22:22 --> Config Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:22:22 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:22:22 --> URI Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Router Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Output Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Security Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Input Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:22:22 --> Language Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Loader Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Config Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:22:22 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:22:22 --> URI Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Router Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Output Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Security Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Input Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:22:22 --> Language Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Loader Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Config Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:22:22 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:22:22 --> URI Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Router Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Config Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:22:22 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:22:22 --> Output Class Initialized
DEBUG - 2015-03-02 07:22:22 --> URI Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Security Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Router Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Input Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:22:22 --> Language Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Output Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Security Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Input Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:22:22 --> Language Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Loader Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Loader Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:22:22 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Controller Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:22:22 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:22:22 --> Controller Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Model Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:22:22 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:22:22 --> Model Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Model Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Model Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:22:22 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Controller Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:22:22 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:22:22 --> Model Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Model Class Initialized
DEBUG - 2015-03-02 07:22:22 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Controller Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:22:22 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:22:22 --> Model Class Initialized
DEBUG - 2015-03-02 07:22:22 --> Model Class Initialized
DEBUG - 2015-03-02 07:22:31 --> Config Class Initialized
DEBUG - 2015-03-02 07:22:31 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:22:31 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:22:31 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:22:31 --> URI Class Initialized
DEBUG - 2015-03-02 07:22:31 --> Router Class Initialized
DEBUG - 2015-03-02 07:22:31 --> Output Class Initialized
DEBUG - 2015-03-02 07:22:31 --> Security Class Initialized
DEBUG - 2015-03-02 07:22:31 --> Input Class Initialized
DEBUG - 2015-03-02 07:22:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:22:31 --> Language Class Initialized
DEBUG - 2015-03-02 07:22:31 --> Loader Class Initialized
DEBUG - 2015-03-02 07:22:31 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:22:31 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:22:31 --> Controller Class Initialized
DEBUG - 2015-03-02 07:22:31 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:22:31 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:22:31 --> Model Class Initialized
DEBUG - 2015-03-02 07:22:31 --> Model Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Config Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:28:39 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:28:39 --> URI Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Router Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Output Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Security Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Input Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:28:39 --> Language Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Loader Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:28:39 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Controller Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:28:39 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:28:39 --> Model Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Model Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Config Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:28:39 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:28:39 --> URI Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Router Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Output Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Security Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Input Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:28:39 --> Language Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Loader Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Config Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:28:39 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:28:39 --> URI Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Router Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Output Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Security Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Input Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:28:39 --> Config Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Language Class Initialized
DEBUG - 2015-03-02 07:28:39 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Controller Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:28:39 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:28:39 --> Model Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Model Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Loader Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:28:39 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:28:39 --> URI Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Router Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Output Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Security Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Input Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:28:39 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Language Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Loader Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:28:39 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Controller Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:28:39 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:28:39 --> Model Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Model Class Initialized
DEBUG - 2015-03-02 07:28:39 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Controller Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:28:39 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:28:39 --> Model Class Initialized
DEBUG - 2015-03-02 07:28:39 --> Model Class Initialized
DEBUG - 2015-03-02 07:28:42 --> Config Class Initialized
DEBUG - 2015-03-02 07:28:42 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:28:42 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:28:42 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:28:42 --> URI Class Initialized
DEBUG - 2015-03-02 07:28:42 --> Router Class Initialized
DEBUG - 2015-03-02 07:28:42 --> Output Class Initialized
DEBUG - 2015-03-02 07:28:42 --> Security Class Initialized
DEBUG - 2015-03-02 07:28:42 --> Input Class Initialized
DEBUG - 2015-03-02 07:28:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:28:42 --> Language Class Initialized
DEBUG - 2015-03-02 07:28:42 --> Loader Class Initialized
DEBUG - 2015-03-02 07:28:42 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:28:42 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:28:42 --> Controller Class Initialized
DEBUG - 2015-03-02 07:28:42 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:28:42 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:28:42 --> Model Class Initialized
DEBUG - 2015-03-02 07:28:42 --> Model Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Config Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:29:41 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:29:41 --> URI Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Router Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Output Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Security Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Input Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:29:41 --> Language Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Loader Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Config Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:29:41 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:29:41 --> URI Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Router Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Output Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Security Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Input Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:29:41 --> Language Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Config Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Loader Class Initialized
DEBUG - 2015-03-02 07:29:41 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Controller Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:29:41 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:29:41 --> Model Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Model Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:29:41 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:29:41 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:29:41 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Controller Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:29:41 --> URI Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:29:41 --> Model Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Model Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Router Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Output Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Security Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Input Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:29:41 --> Language Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Loader Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Config Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:29:41 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:29:41 --> URI Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Router Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Output Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Security Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Input Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:29:41 --> Language Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Loader Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:29:41 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Controller Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:29:41 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Controller Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:29:41 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:29:41 --> Model Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:29:41 --> Model Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Model Class Initialized
DEBUG - 2015-03-02 07:29:41 --> Model Class Initialized
DEBUG - 2015-03-02 07:29:47 --> Config Class Initialized
DEBUG - 2015-03-02 07:29:47 --> Hooks Class Initialized
DEBUG - 2015-03-02 07:29:47 --> Utf8 Class Initialized
DEBUG - 2015-03-02 07:29:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 07:29:47 --> URI Class Initialized
DEBUG - 2015-03-02 07:29:47 --> Router Class Initialized
DEBUG - 2015-03-02 07:29:47 --> Output Class Initialized
DEBUG - 2015-03-02 07:29:47 --> Security Class Initialized
DEBUG - 2015-03-02 07:29:47 --> Input Class Initialized
DEBUG - 2015-03-02 07:29:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 07:29:47 --> Language Class Initialized
DEBUG - 2015-03-02 07:29:47 --> Loader Class Initialized
DEBUG - 2015-03-02 07:29:47 --> Database Driver Class Initialized
DEBUG - 2015-03-02 07:29:47 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 07:29:47 --> Controller Class Initialized
DEBUG - 2015-03-02 07:29:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 07:29:47 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 07:29:47 --> Model Class Initialized
DEBUG - 2015-03-02 07:29:47 --> Model Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Config Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Hooks Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Utf8 Class Initialized
DEBUG - 2015-03-02 13:54:48 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 13:54:48 --> URI Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Config Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Hooks Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Router Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Utf8 Class Initialized
DEBUG - 2015-03-02 13:54:48 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 13:54:48 --> URI Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Router Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Output Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Security Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Output Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Input Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Security Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 13:54:48 --> Language Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Input Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 13:54:48 --> Language Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Loader Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Loader Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Database Driver Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Database Driver Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Config Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Hooks Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Utf8 Class Initialized
DEBUG - 2015-03-02 13:54:48 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 13:54:48 --> URI Class Initialized
DEBUG - 2015-03-02 13:54:48 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Controller Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Config Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Router Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Hooks Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Output Class Initialized
DEBUG - 2015-03-02 13:54:48 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 13:54:48 --> Security Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Input Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Controller Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 13:54:48 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 13:54:48 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 13:54:48 --> Language Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Utf8 Class Initialized
DEBUG - 2015-03-02 13:54:48 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 13:54:48 --> URI Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Router Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Loader Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Output Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Security Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Input Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 13:54:48 --> Language Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Database Driver Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Model Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Model Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 13:54:48 --> Model Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Loader Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Model Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Database Driver Class Initialized
DEBUG - 2015-03-02 13:54:48 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Controller Class Initialized
DEBUG - 2015-03-02 13:54:48 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Controller Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 13:54:48 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 13:54:48 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 13:54:48 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 13:54:48 --> Model Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Model Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Model Class Initialized
DEBUG - 2015-03-02 13:54:48 --> Model Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Config Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Hooks Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Utf8 Class Initialized
DEBUG - 2015-03-02 13:55:06 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 13:55:06 --> URI Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Router Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Output Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Security Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Input Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 13:55:06 --> Language Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Loader Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Config Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Hooks Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Utf8 Class Initialized
DEBUG - 2015-03-02 13:55:06 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 13:55:06 --> URI Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Router Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Output Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Security Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Input Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 13:55:06 --> Language Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Loader Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Database Driver Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Config Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Hooks Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Utf8 Class Initialized
DEBUG - 2015-03-02 13:55:06 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 13:55:06 --> URI Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Router Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Config Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Output Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Hooks Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Utf8 Class Initialized
DEBUG - 2015-03-02 13:55:06 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 13:55:06 --> Security Class Initialized
DEBUG - 2015-03-02 13:55:06 --> URI Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Input Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 13:55:06 --> Language Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Router Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Loader Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Output Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Security Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Input Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 13:55:06 --> Language Class Initialized
DEBUG - 2015-03-02 13:55:06 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Controller Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 13:55:06 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 13:55:06 --> Model Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Model Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Database Driver Class Initialized
DEBUG - 2015-03-02 13:55:06 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Controller Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 13:55:06 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 13:55:06 --> Model Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Model Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Database Driver Class Initialized
DEBUG - 2015-03-02 13:55:06 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Controller Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 13:55:06 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 13:55:06 --> Model Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Model Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Loader Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Database Driver Class Initialized
DEBUG - 2015-03-02 13:55:06 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Controller Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 13:55:06 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 13:55:06 --> Model Class Initialized
DEBUG - 2015-03-02 13:55:06 --> Model Class Initialized
DEBUG - 2015-03-02 13:55:09 --> Config Class Initialized
DEBUG - 2015-03-02 13:55:09 --> Hooks Class Initialized
DEBUG - 2015-03-02 13:55:09 --> Utf8 Class Initialized
DEBUG - 2015-03-02 13:55:09 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 13:55:09 --> URI Class Initialized
DEBUG - 2015-03-02 13:55:09 --> Router Class Initialized
DEBUG - 2015-03-02 13:55:09 --> Output Class Initialized
DEBUG - 2015-03-02 13:55:09 --> Security Class Initialized
DEBUG - 2015-03-02 13:55:09 --> Input Class Initialized
DEBUG - 2015-03-02 13:55:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 13:55:09 --> Language Class Initialized
DEBUG - 2015-03-02 13:55:09 --> Loader Class Initialized
DEBUG - 2015-03-02 13:55:09 --> Database Driver Class Initialized
DEBUG - 2015-03-02 13:55:09 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 13:55:09 --> Controller Class Initialized
DEBUG - 2015-03-02 13:55:09 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 13:55:09 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 13:55:09 --> Model Class Initialized
DEBUG - 2015-03-02 13:55:09 --> Model Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Config Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Config Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Config Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Config Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:44:44 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:44:44 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:44:44 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:44:44 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:44:44 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:44:44 --> URI Class Initialized
DEBUG - 2015-03-02 10:44:44 --> URI Class Initialized
DEBUG - 2015-03-02 10:44:44 --> URI Class Initialized
DEBUG - 2015-03-02 10:44:44 --> URI Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Router Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Router Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Router Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Router Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Output Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Output Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Output Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Output Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Security Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Security Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Security Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Input Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:44:44 --> Security Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Input Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:44:44 --> Language Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Input Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Language Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:44:44 --> Input Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:44:44 --> Language Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Language Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Loader Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Loader Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Loader Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Loader Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Database Driver Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Database Driver Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:44:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-02 10:44:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-02 10:44:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:44:44 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:44:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:44:44 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Controller Class Initialized
DEBUG - 2015-03-02 10:44:44 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Controller Class Initialized
DEBUG - 2015-03-02 10:44:44 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Controller Class Initialized
DEBUG - 2015-03-02 10:44:44 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:44:44 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:44:44 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:44:44 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:44:44 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:44:44 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:44:44 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:44:45 --> Model Class Initialized
DEBUG - 2015-03-02 10:44:45 --> Model Class Initialized
DEBUG - 2015-03-02 10:44:45 --> Controller Class Initialized
DEBUG - 2015-03-02 10:44:45 --> Model Class Initialized
DEBUG - 2015-03-02 10:44:45 --> Model Class Initialized
DEBUG - 2015-03-02 10:44:45 --> Model Class Initialized
DEBUG - 2015-03-02 10:44:45 --> Model Class Initialized
DEBUG - 2015-03-02 10:44:45 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:44:45 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:44:45 --> Model Class Initialized
DEBUG - 2015-03-02 10:44:45 --> Model Class Initialized
DEBUG - 2015-03-02 10:44:47 --> Config Class Initialized
DEBUG - 2015-03-02 10:44:47 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:44:47 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:44:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:44:47 --> URI Class Initialized
DEBUG - 2015-03-02 10:44:47 --> Router Class Initialized
DEBUG - 2015-03-02 10:44:47 --> Output Class Initialized
DEBUG - 2015-03-02 10:44:47 --> Security Class Initialized
DEBUG - 2015-03-02 10:44:47 --> Input Class Initialized
DEBUG - 2015-03-02 10:44:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:44:47 --> Language Class Initialized
DEBUG - 2015-03-02 10:44:47 --> Loader Class Initialized
DEBUG - 2015-03-02 10:44:47 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:44:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:44:47 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:44:47 --> Controller Class Initialized
DEBUG - 2015-03-02 10:44:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:44:47 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:44:47 --> Model Class Initialized
DEBUG - 2015-03-02 10:44:47 --> Model Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Config Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:44:59 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:44:59 --> Config Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:44:59 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:44:59 --> URI Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Config Class Initialized
DEBUG - 2015-03-02 10:44:59 --> URI Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Router Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:44:59 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:44:59 --> Router Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Config Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:44:59 --> URI Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Router Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Output Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Output Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Security Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Security Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Output Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Input Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:44:59 --> Input Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:44:59 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:44:59 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:44:59 --> Language Class Initialized
DEBUG - 2015-03-02 10:44:59 --> URI Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Security Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Language Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Input Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:44:59 --> Language Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Router Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Output Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Loader Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Security Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Loader Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Input Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:44:59 --> Language Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Loader Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Database Driver Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Loader Class Initialized
ERROR - 2015-03-02 10:44:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:44:59 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:44:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:44:59 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:44:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:44:59 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Controller Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:44:59 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:44:59 --> Model Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Model Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Controller Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:44:59 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:44:59 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Controller Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Model Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Model Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:44:59 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:44:59 --> Model Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Model Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:44:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:44:59 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Controller Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:44:59 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:44:59 --> Model Class Initialized
DEBUG - 2015-03-02 10:44:59 --> Model Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Config Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Config Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:45:42 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:45:42 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Config Class Initialized
DEBUG - 2015-03-02 10:45:42 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:45:42 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:45:42 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:45:42 --> URI Class Initialized
DEBUG - 2015-03-02 10:45:42 --> URI Class Initialized
DEBUG - 2015-03-02 10:45:42 --> URI Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Router Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Router Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Router Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Output Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Output Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Security Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Security Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Config Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Input Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:45:42 --> Language Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Output Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Security Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Input Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Input Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:45:42 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:45:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:45:42 --> Language Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Language Class Initialized
DEBUG - 2015-03-02 10:45:42 --> URI Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Router Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Output Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Security Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Loader Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Loader Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Loader Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Input Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:45:42 --> Language Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:45:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:45:42 --> Database Driver Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Database Driver Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Loader Class Initialized
ERROR - 2015-03-02 10:45:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-02 10:45:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:45:42 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Controller Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:45:42 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:45:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:45:42 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Controller Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:45:42 --> Controller Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:45:42 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:45:42 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Controller Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Model Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:45:42 --> Model Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:45:42 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:45:42 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:45:42 --> Model Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Model Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Model Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Model Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Model Class Initialized
DEBUG - 2015-03-02 10:45:42 --> Model Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Config Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:46:17 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:46:17 --> Config Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:46:17 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:46:17 --> Config Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:46:17 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:46:17 --> URI Class Initialized
DEBUG - 2015-03-02 10:46:17 --> URI Class Initialized
DEBUG - 2015-03-02 10:46:17 --> URI Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Router Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Router Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Router Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Config Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Output Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:46:17 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:46:17 --> Security Class Initialized
DEBUG - 2015-03-02 10:46:17 --> URI Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Output Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Input Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:46:17 --> Language Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Router Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Security Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Output Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Input Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:46:17 --> Output Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Security Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Language Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Security Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Input Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:46:17 --> Language Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Input Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:46:17 --> Language Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Loader Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Loader Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Loader Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:46:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:46:17 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:46:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:46:17 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Controller Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:46:17 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Controller Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:46:17 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:46:17 --> Model Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Model Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:46:17 --> Model Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Model Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Loader Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:46:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:46:17 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Controller Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:46:17 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:46:17 --> Model Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Model Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:46:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:46:17 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Controller Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:46:17 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:46:17 --> Model Class Initialized
DEBUG - 2015-03-02 10:46:17 --> Model Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Config Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Config Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:46:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:46:29 --> Config Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:46:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:46:29 --> URI Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:46:29 --> URI Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Router Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:46:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:46:29 --> Output Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Config Class Initialized
DEBUG - 2015-03-02 10:46:29 --> URI Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Router Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:46:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:46:29 --> Router Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Output Class Initialized
DEBUG - 2015-03-02 10:46:29 --> URI Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Output Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Router Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Security Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Security Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Security Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Output Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Input Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:46:29 --> Language Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Security Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Input Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:46:29 --> Language Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Input Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:46:29 --> Language Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Input Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:46:29 --> Language Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Loader Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Loader Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Loader Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Loader Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:46:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:46:29 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:46:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:46:29 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:46:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:46:29 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:46:29 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Controller Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Controller Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:46:29 --> Database Driver Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Config file loaded: application/config/rest.php
ERROR - 2015-03-02 10:46:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:46:29 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:46:29 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:46:29 --> Model Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Model Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Model Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Model Class Initialized
DEBUG - 2015-03-02 10:46:29 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Controller Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:46:29 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:46:29 --> Model Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Model Class Initialized
DEBUG - 2015-03-02 10:46:29 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Controller Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:46:29 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:46:29 --> Model Class Initialized
DEBUG - 2015-03-02 10:46:29 --> Model Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Config Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Config Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:46:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:46:56 --> Config Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:46:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:46:56 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:46:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:46:56 --> URI Class Initialized
DEBUG - 2015-03-02 10:46:56 --> URI Class Initialized
DEBUG - 2015-03-02 10:46:56 --> URI Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Config Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Router Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Router Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Router Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:46:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:46:56 --> Output Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Output Class Initialized
DEBUG - 2015-03-02 10:46:56 --> URI Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Output Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Security Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Security Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Router Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Security Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Input Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Input Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:46:56 --> Language Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Language Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Input Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Output Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:46:56 --> Language Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Security Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Loader Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Input Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:46:56 --> Loader Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Language Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Loader Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:46:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:46:56 --> Loader Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:46:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:46:56 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:46:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:46:56 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Controller Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:46:56 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Controller Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:46:56 --> Model Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Model Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:46:56 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Controller Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:46:56 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:46:56 --> Model Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Database Driver Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Model Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:46:56 --> Model Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Model Class Initialized
ERROR - 2015-03-02 10:46:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:46:56 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Controller Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:46:56 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:46:56 --> Model Class Initialized
DEBUG - 2015-03-02 10:46:56 --> Model Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Config Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:47:10 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:47:10 --> URI Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Config Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Config Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:47:10 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:47:10 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Router Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:47:10 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:47:10 --> URI Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Config Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Router Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Output Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Output Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Security Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:47:10 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:47:10 --> Security Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Input Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:47:10 --> URI Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Language Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Router Class Initialized
DEBUG - 2015-03-02 10:47:10 --> URI Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Input Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:47:10 --> Router Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Language Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Output Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Security Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Input Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:47:10 --> Language Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Loader Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Output Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Security Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Input Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:47:10 --> Language Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Loader Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Loader Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Loader Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:47:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:47:10 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:47:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:47:10 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Controller Class Initialized
DEBUG - 2015-03-02 10:47:10 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:47:10 --> Controller Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:47:10 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:47:10 --> Model Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:47:10 --> Model Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Model Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Model Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:47:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:47:10 --> Database Driver Class Initialized
DEBUG - 2015-03-02 10:47:10 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Controller Class Initialized
ERROR - 2015-03-02 10:47:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:47:10 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:47:10 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:47:10 --> Model Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Model Class Initialized
DEBUG - 2015-03-02 10:47:10 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Controller Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:47:10 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:47:10 --> Model Class Initialized
DEBUG - 2015-03-02 10:47:10 --> Model Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Config Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Config Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:50:10 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:50:10 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:50:10 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:50:10 --> URI Class Initialized
DEBUG - 2015-03-02 10:50:10 --> URI Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Router Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Config Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:50:10 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:50:10 --> Router Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Output Class Initialized
DEBUG - 2015-03-02 10:50:10 --> URI Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Output Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Router Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Security Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Security Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Input Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Output Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:50:10 --> Config Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Input Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Language Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:50:10 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Security Class Initialized
DEBUG - 2015-03-02 10:50:10 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:50:10 --> Language Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Input Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:50:10 --> Language Class Initialized
DEBUG - 2015-03-02 10:50:10 --> URI Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Router Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Loader Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Loader Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Output Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Security Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Input Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:50:10 --> Loader Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Database Driver Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Language Class Initialized
ERROR - 2015-03-02 10:50:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:50:10 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Controller Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:50:10 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:50:10 --> Model Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Model Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Loader Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:50:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:50:10 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:50:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:50:10 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Controller Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:50:10 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Controller Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:50:10 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:50:10 --> Database Driver Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Model Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:50:10 --> Model Class Initialized
ERROR - 2015-03-02 10:50:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:50:10 --> Model Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Model Class Initialized
DEBUG - 2015-03-02 10:50:10 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Controller Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:50:10 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:50:10 --> Model Class Initialized
DEBUG - 2015-03-02 10:50:10 --> Model Class Initialized
DEBUG - 2015-03-02 10:50:15 --> Config Class Initialized
DEBUG - 2015-03-02 10:50:15 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:50:15 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:50:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:50:15 --> URI Class Initialized
DEBUG - 2015-03-02 10:50:15 --> Router Class Initialized
DEBUG - 2015-03-02 10:50:15 --> Output Class Initialized
DEBUG - 2015-03-02 10:50:15 --> Security Class Initialized
DEBUG - 2015-03-02 10:50:15 --> Input Class Initialized
DEBUG - 2015-03-02 10:50:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:50:15 --> Language Class Initialized
DEBUG - 2015-03-02 10:50:15 --> Loader Class Initialized
DEBUG - 2015-03-02 10:50:15 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:50:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:50:15 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:50:15 --> Controller Class Initialized
DEBUG - 2015-03-02 10:50:15 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:50:15 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:50:15 --> Model Class Initialized
DEBUG - 2015-03-02 10:50:15 --> Model Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Config Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Config Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:55:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:55:29 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:55:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:55:29 --> URI Class Initialized
DEBUG - 2015-03-02 10:55:29 --> URI Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Config Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Config Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Router Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Router Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:55:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:55:29 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:55:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:55:29 --> Output Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Output Class Initialized
DEBUG - 2015-03-02 10:55:29 --> URI Class Initialized
DEBUG - 2015-03-02 10:55:29 --> URI Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Security Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Security Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Router Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Router Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Input Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Input Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:55:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:55:29 --> Language Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Language Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Output Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Output Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Security Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Security Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Input Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:55:29 --> Input Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Language Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:55:29 --> Language Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Loader Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Loader Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Loader Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Loader Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:55:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:55:29 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:55:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:55:29 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Controller Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:55:29 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:55:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:55:29 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Controller Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:55:29 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:55:29 --> Model Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Model Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:55:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:55:29 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:55:29 --> Model Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Model Class Initialized
DEBUG - 2015-03-02 10:55:29 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Controller Class Initialized
DEBUG - 2015-03-02 10:55:29 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Controller Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:55:29 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:55:29 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:55:29 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:55:29 --> Model Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Model Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Model Class Initialized
DEBUG - 2015-03-02 10:55:29 --> Model Class Initialized
DEBUG - 2015-03-02 10:55:43 --> Config Class Initialized
DEBUG - 2015-03-02 10:55:43 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:55:43 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:55:43 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:55:43 --> URI Class Initialized
DEBUG - 2015-03-02 10:55:43 --> Router Class Initialized
DEBUG - 2015-03-02 10:55:43 --> Output Class Initialized
DEBUG - 2015-03-02 10:55:43 --> Security Class Initialized
DEBUG - 2015-03-02 10:55:43 --> Input Class Initialized
DEBUG - 2015-03-02 10:55:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:55:43 --> Language Class Initialized
DEBUG - 2015-03-02 10:55:43 --> Loader Class Initialized
DEBUG - 2015-03-02 10:55:43 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:55:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:55:43 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:55:43 --> Controller Class Initialized
DEBUG - 2015-03-02 10:55:43 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:55:43 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:55:43 --> Model Class Initialized
DEBUG - 2015-03-02 10:55:43 --> Model Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Config Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Config Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:56:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:56:29 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:56:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:56:29 --> Config Class Initialized
DEBUG - 2015-03-02 10:56:29 --> URI Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:56:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:56:29 --> URI Class Initialized
DEBUG - 2015-03-02 10:56:29 --> URI Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Router Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Config Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Output Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:56:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:56:29 --> Router Class Initialized
DEBUG - 2015-03-02 10:56:29 --> URI Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Security Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Router Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Input Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:56:29 --> Router Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Language Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Output Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Security Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Output Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Output Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Input Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:56:29 --> Security Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Language Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Security Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Input Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Input Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:56:29 --> Language Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Language Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Loader Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Loader Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Loader Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Loader Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:56:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:56:29 --> Database Driver Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:56:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-02 10:56:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:56:29 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:56:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:56:29 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Controller Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:56:29 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Controller Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:56:29 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:56:29 --> Model Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:56:29 --> Model Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Model Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Model Class Initialized
DEBUG - 2015-03-02 10:56:29 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Controller Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:56:29 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:56:29 --> Model Class Initialized
DEBUG - 2015-03-02 10:56:29 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Model Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Controller Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:56:29 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:56:29 --> Model Class Initialized
DEBUG - 2015-03-02 10:56:29 --> Model Class Initialized
DEBUG - 2015-03-02 10:56:34 --> Config Class Initialized
DEBUG - 2015-03-02 10:56:34 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:56:34 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:56:34 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:56:34 --> URI Class Initialized
DEBUG - 2015-03-02 10:56:34 --> Router Class Initialized
DEBUG - 2015-03-02 10:56:34 --> Output Class Initialized
DEBUG - 2015-03-02 10:56:34 --> Security Class Initialized
DEBUG - 2015-03-02 10:56:34 --> Input Class Initialized
DEBUG - 2015-03-02 10:56:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:56:34 --> Language Class Initialized
DEBUG - 2015-03-02 10:56:34 --> Loader Class Initialized
DEBUG - 2015-03-02 10:56:35 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:56:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:56:35 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:56:35 --> Controller Class Initialized
DEBUG - 2015-03-02 10:56:35 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:56:35 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:56:35 --> Model Class Initialized
DEBUG - 2015-03-02 10:56:35 --> Model Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Config Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Config Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:59:06 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:59:06 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:59:06 --> Config Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:59:06 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:59:06 --> URI Class Initialized
DEBUG - 2015-03-02 10:59:06 --> URI Class Initialized
DEBUG - 2015-03-02 10:59:06 --> URI Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Router Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Router Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Router Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Output Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Output Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Output Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Security Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Security Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Security Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Input Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:59:06 --> Input Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:59:06 --> Language Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Input Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Config Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:59:06 --> Language Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Language Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:59:06 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:59:06 --> URI Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Loader Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Loader Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Loader Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Router Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Output Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Security Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Input Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:59:06 --> Language Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Database Driver Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:59:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-02 10:59:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:59:06 --> Database Driver Class Initialized
DEBUG - 2015-03-02 10:59:06 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Loader Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Controller Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Config file loaded: application/config/rest.php
ERROR - 2015-03-02 10:59:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:59:06 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:59:06 --> Controller Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Model Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:59:06 --> Model Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:59:06 --> Model Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Model Class Initialized
DEBUG - 2015-03-02 10:59:06 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Controller Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:59:06 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:59:06 --> Model Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Model Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:59:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:59:06 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Controller Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:59:06 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:59:06 --> Model Class Initialized
DEBUG - 2015-03-02 10:59:06 --> Model Class Initialized
DEBUG - 2015-03-02 10:59:15 --> Config Class Initialized
DEBUG - 2015-03-02 10:59:15 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:59:15 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:59:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:59:15 --> URI Class Initialized
DEBUG - 2015-03-02 10:59:15 --> Router Class Initialized
DEBUG - 2015-03-02 10:59:15 --> Output Class Initialized
DEBUG - 2015-03-02 10:59:15 --> Security Class Initialized
DEBUG - 2015-03-02 10:59:15 --> Input Class Initialized
DEBUG - 2015-03-02 10:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:59:15 --> Language Class Initialized
DEBUG - 2015-03-02 10:59:15 --> Loader Class Initialized
DEBUG - 2015-03-02 10:59:15 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:59:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:59:15 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:59:15 --> Controller Class Initialized
DEBUG - 2015-03-02 10:59:15 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:59:15 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:59:15 --> Model Class Initialized
DEBUG - 2015-03-02 10:59:15 --> Model Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Config Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:59:41 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:59:41 --> Config Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:59:41 --> URI Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Config Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Config Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:59:41 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:59:41 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:59:41 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:59:41 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:59:41 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:59:41 --> URI Class Initialized
DEBUG - 2015-03-02 10:59:41 --> URI Class Initialized
DEBUG - 2015-03-02 10:59:41 --> URI Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Router Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Router Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Router Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Output Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Output Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Router Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Security Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Output Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Security Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Output Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Input Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:59:41 --> Security Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Input Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Language Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Security Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:59:41 --> Language Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Input Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:59:41 --> Input Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:59:41 --> Language Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Language Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Loader Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Loader Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Loader Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Loader Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:59:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:59:41 --> Database Driver Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:59:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-02 10:59:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:59:41 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:59:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:59:41 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:59:41 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:59:41 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Controller Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Controller Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Controller Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:59:41 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:59:41 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:59:41 --> Model Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:59:41 --> Model Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Model Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:59:41 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Controller Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Model Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:59:41 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:59:41 --> Model Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Model Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:59:41 --> Model Class Initialized
DEBUG - 2015-03-02 10:59:41 --> Model Class Initialized
DEBUG - 2015-03-02 10:59:49 --> Config Class Initialized
DEBUG - 2015-03-02 10:59:49 --> Hooks Class Initialized
DEBUG - 2015-03-02 10:59:49 --> Utf8 Class Initialized
DEBUG - 2015-03-02 10:59:49 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 10:59:49 --> URI Class Initialized
DEBUG - 2015-03-02 10:59:49 --> Router Class Initialized
DEBUG - 2015-03-02 10:59:49 --> Output Class Initialized
DEBUG - 2015-03-02 10:59:49 --> Security Class Initialized
DEBUG - 2015-03-02 10:59:49 --> Input Class Initialized
DEBUG - 2015-03-02 10:59:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 10:59:49 --> Language Class Initialized
DEBUG - 2015-03-02 10:59:49 --> Loader Class Initialized
DEBUG - 2015-03-02 10:59:49 --> Database Driver Class Initialized
ERROR - 2015-03-02 10:59:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 10:59:49 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 10:59:49 --> Controller Class Initialized
DEBUG - 2015-03-02 10:59:49 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 10:59:49 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 10:59:49 --> Model Class Initialized
DEBUG - 2015-03-02 10:59:49 --> Model Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Config Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Config Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Config Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Hooks Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Hooks Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Hooks Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Config Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Hooks Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Utf8 Class Initialized
DEBUG - 2015-03-02 12:51:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 12:51:45 --> Utf8 Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Utf8 Class Initialized
DEBUG - 2015-03-02 12:51:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 12:51:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 12:51:45 --> Utf8 Class Initialized
DEBUG - 2015-03-02 12:51:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 12:51:45 --> URI Class Initialized
DEBUG - 2015-03-02 12:51:45 --> URI Class Initialized
DEBUG - 2015-03-02 12:51:45 --> URI Class Initialized
DEBUG - 2015-03-02 12:51:45 --> URI Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Router Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Router Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Router Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Router Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Output Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Output Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Output Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Output Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Security Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Security Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Security Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Security Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Input Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Input Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 12:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 12:51:45 --> Language Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Language Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Input Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Input Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 12:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 12:51:45 --> Language Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Language Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Loader Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Loader Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Loader Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Loader Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Database Driver Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Database Driver Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Database Driver Class Initialized
ERROR - 2015-03-02 12:51:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-02 12:51:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-02 12:51:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 12:51:45 --> Database Driver Class Initialized
DEBUG - 2015-03-02 12:51:45 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Controller Class Initialized
ERROR - 2015-03-02 12:51:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 12:51:45 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Controller Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 12:51:45 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 12:51:45 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Controller Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 12:51:45 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Controller Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 12:51:45 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 12:51:45 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 12:51:45 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 12:51:45 --> Model Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Model Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Model Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 12:51:45 --> Model Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Model Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Model Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Model Class Initialized
DEBUG - 2015-03-02 12:51:45 --> Model Class Initialized
DEBUG - 2015-03-02 12:51:50 --> Config Class Initialized
DEBUG - 2015-03-02 12:51:50 --> Hooks Class Initialized
DEBUG - 2015-03-02 12:51:50 --> Utf8 Class Initialized
DEBUG - 2015-03-02 12:51:50 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 12:51:50 --> URI Class Initialized
DEBUG - 2015-03-02 12:51:50 --> Router Class Initialized
DEBUG - 2015-03-02 12:51:50 --> Output Class Initialized
DEBUG - 2015-03-02 12:51:50 --> Security Class Initialized
DEBUG - 2015-03-02 12:51:50 --> Input Class Initialized
DEBUG - 2015-03-02 12:51:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 12:51:50 --> Language Class Initialized
DEBUG - 2015-03-02 12:51:50 --> Loader Class Initialized
DEBUG - 2015-03-02 12:51:50 --> Database Driver Class Initialized
ERROR - 2015-03-02 12:51:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 12:51:50 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 12:51:50 --> Controller Class Initialized
DEBUG - 2015-03-02 12:51:50 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 12:51:50 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 12:51:50 --> Model Class Initialized
DEBUG - 2015-03-02 12:51:50 --> Model Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Config Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Hooks Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Utf8 Class Initialized
DEBUG - 2015-03-02 12:57:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 12:57:15 --> Config Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Hooks Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Utf8 Class Initialized
DEBUG - 2015-03-02 12:57:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 12:57:15 --> URI Class Initialized
DEBUG - 2015-03-02 12:57:15 --> URI Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Config Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Hooks Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Router Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Utf8 Class Initialized
DEBUG - 2015-03-02 12:57:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 12:57:15 --> Config Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Hooks Class Initialized
DEBUG - 2015-03-02 12:57:15 --> URI Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Utf8 Class Initialized
DEBUG - 2015-03-02 12:57:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 12:57:15 --> Router Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Router Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Output Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Output Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Output Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Security Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Security Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Security Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Input Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 12:57:15 --> Input Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 12:57:15 --> Language Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Language Class Initialized
DEBUG - 2015-03-02 12:57:15 --> URI Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Input Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Router Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Output Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Security Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Input Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 12:57:15 --> Language Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Loader Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Loader Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 12:57:15 --> Language Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Loader Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Loader Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Database Driver Class Initialized
ERROR - 2015-03-02 12:57:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 12:57:15 --> Database Driver Class Initialized
ERROR - 2015-03-02 12:57:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 12:57:15 --> Database Driver Class Initialized
ERROR - 2015-03-02 12:57:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 12:57:15 --> Database Driver Class Initialized
ERROR - 2015-03-02 12:57:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 12:57:15 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Controller Class Initialized
DEBUG - 2015-03-02 12:57:15 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 12:57:15 --> Controller Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 12:57:15 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 12:57:15 --> Model Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 12:57:15 --> Model Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Model Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Model Class Initialized
DEBUG - 2015-03-02 12:57:15 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Controller Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 12:57:15 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 12:57:15 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Controller Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 12:57:15 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 12:57:15 --> Model Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Model Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Model Class Initialized
DEBUG - 2015-03-02 12:57:15 --> Model Class Initialized
DEBUG - 2015-03-02 12:57:28 --> Config Class Initialized
DEBUG - 2015-03-02 12:57:28 --> Hooks Class Initialized
DEBUG - 2015-03-02 12:57:28 --> Utf8 Class Initialized
DEBUG - 2015-03-02 12:57:28 --> UTF-8 Support Enabled
DEBUG - 2015-03-02 12:57:28 --> URI Class Initialized
DEBUG - 2015-03-02 12:57:28 --> Router Class Initialized
DEBUG - 2015-03-02 12:57:28 --> Output Class Initialized
DEBUG - 2015-03-02 12:57:28 --> Security Class Initialized
DEBUG - 2015-03-02 12:57:28 --> Input Class Initialized
DEBUG - 2015-03-02 12:57:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-02 12:57:28 --> Language Class Initialized
DEBUG - 2015-03-02 12:57:28 --> Loader Class Initialized
DEBUG - 2015-03-02 12:57:28 --> Database Driver Class Initialized
ERROR - 2015-03-02 12:57:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-02 12:57:28 --> XML-RPC Class Initialized
DEBUG - 2015-03-02 12:57:28 --> Controller Class Initialized
DEBUG - 2015-03-02 12:57:28 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-02 12:57:28 --> Helper loaded: inflector_helper
DEBUG - 2015-03-02 12:57:28 --> Model Class Initialized
DEBUG - 2015-03-02 12:57:28 --> Model Class Initialized
