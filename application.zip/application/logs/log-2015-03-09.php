<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-03-09 01:12:43 --> Config Class Initialized
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-03-09 01:12:43 --> Config Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Hooks Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Hooks Class Initialized
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-03-09 01:12:43 --> Config Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Hooks Class Initialized
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-03-09 01:12:43 --> Config Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Hooks Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Utf8 Class Initialized
DEBUG - 2015-03-09 01:12:43 --> UTF-8 Support Enabled
DEBUG - 2015-03-09 01:12:43 --> URI Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Router Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Utf8 Class Initialized
DEBUG - 2015-03-09 01:12:43 --> UTF-8 Support Enabled
DEBUG - 2015-03-09 01:12:43 --> Utf8 Class Initialized
DEBUG - 2015-03-09 01:12:43 --> UTF-8 Support Enabled
DEBUG - 2015-03-09 01:12:43 --> URI Class Initialized
DEBUG - 2015-03-09 01:12:43 --> URI Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Router Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Router Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Utf8 Class Initialized
DEBUG - 2015-03-09 01:12:43 --> UTF-8 Support Enabled
DEBUG - 2015-03-09 01:12:43 --> URI Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Router Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Output Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Output Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Security Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Security Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Output Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Output Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Security Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Security Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Input Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-09 01:12:43 --> Input Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-09 01:12:43 --> Input Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-09 01:12:43 --> Input Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-09 01:12:43 --> Language Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Language Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Language Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Language Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Loader Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Loader Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Loader Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Loader Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Database Driver Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Database Driver Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Database Driver Class Initialized
DEBUG - 2015-03-09 01:12:43 --> Database Driver Class Initialized
DEBUG - 2015-03-09 01:12:45 --> XML-RPC Class Initialized
DEBUG - 2015-03-09 01:12:45 --> XML-RPC Class Initialized
DEBUG - 2015-03-09 01:12:45 --> XML-RPC Class Initialized
DEBUG - 2015-03-09 01:12:45 --> XML-RPC Class Initialized
DEBUG - 2015-03-09 01:12:45 --> Controller Class Initialized
DEBUG - 2015-03-09 01:12:45 --> Controller Class Initialized
DEBUG - 2015-03-09 01:12:45 --> Controller Class Initialized
DEBUG - 2015-03-09 01:12:45 --> Controller Class Initialized
DEBUG - 2015-03-09 01:12:45 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-09 01:12:45 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-09 01:12:45 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-09 01:12:45 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-09 01:12:45 --> Helper loaded: inflector_helper
DEBUG - 2015-03-09 01:12:45 --> Helper loaded: inflector_helper
DEBUG - 2015-03-09 01:12:45 --> Helper loaded: inflector_helper
DEBUG - 2015-03-09 01:12:45 --> Helper loaded: inflector_helper
DEBUG - 2015-03-09 01:12:45 --> Model Class Initialized
DEBUG - 2015-03-09 01:12:45 --> Model Class Initialized
DEBUG - 2015-03-09 01:12:45 --> Model Class Initialized
DEBUG - 2015-03-09 01:12:45 --> Model Class Initialized
DEBUG - 2015-03-09 01:12:45 --> Model Class Initialized
DEBUG - 2015-03-09 01:12:45 --> Model Class Initialized
DEBUG - 2015-03-09 01:12:45 --> Model Class Initialized
DEBUG - 2015-03-09 01:12:45 --> Model Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Config Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Hooks Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Utf8 Class Initialized
DEBUG - 2015-03-09 01:20:05 --> UTF-8 Support Enabled
DEBUG - 2015-03-09 01:20:05 --> URI Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Router Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Config Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Hooks Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Utf8 Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Output Class Initialized
DEBUG - 2015-03-09 01:20:05 --> UTF-8 Support Enabled
DEBUG - 2015-03-09 01:20:05 --> URI Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Security Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Input Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-09 01:20:05 --> Language Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Loader Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Config Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Hooks Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Database Driver Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Utf8 Class Initialized
DEBUG - 2015-03-09 01:20:05 --> UTF-8 Support Enabled
DEBUG - 2015-03-09 01:20:05 --> URI Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Router Class Initialized
DEBUG - 2015-03-09 01:20:05 --> XML-RPC Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Controller Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-09 01:20:05 --> Config Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Hooks Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Helper loaded: inflector_helper
DEBUG - 2015-03-09 01:20:05 --> Model Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Model Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Utf8 Class Initialized
DEBUG - 2015-03-09 01:20:05 --> UTF-8 Support Enabled
DEBUG - 2015-03-09 01:20:05 --> URI Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Router Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Output Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Security Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Output Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Input Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-09 01:20:05 --> Security Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Language Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Input Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-09 01:20:05 --> Language Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Loader Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Loader Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Database Driver Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Database Driver Class Initialized
DEBUG - 2015-03-09 01:20:05 --> XML-RPC Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Controller Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-09 01:20:05 --> XML-RPC Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Controller Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Helper loaded: inflector_helper
DEBUG - 2015-03-09 01:20:05 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-09 01:20:05 --> Model Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Model Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Helper loaded: inflector_helper
DEBUG - 2015-03-09 01:20:05 --> Model Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Model Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Router Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Output Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Security Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Input Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-09 01:20:05 --> Language Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Loader Class Initialized
DEBUG - 2015-03-09 01:20:05 --> Database Driver Class Initialized
DEBUG - 2015-03-09 01:20:06 --> XML-RPC Class Initialized
DEBUG - 2015-03-09 01:20:06 --> Controller Class Initialized
DEBUG - 2015-03-09 01:20:06 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-09 01:20:06 --> Helper loaded: inflector_helper
DEBUG - 2015-03-09 01:20:06 --> Model Class Initialized
DEBUG - 2015-03-09 01:20:06 --> Model Class Initialized
