<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-12-15 12:20:14 --> Config Class Initialized
DEBUG - 2014-12-15 12:20:14 --> Hooks Class Initialized
DEBUG - 2014-12-15 12:20:14 --> Utf8 Class Initialized
DEBUG - 2014-12-15 12:20:14 --> UTF-8 Support Enabled
DEBUG - 2014-12-15 12:20:14 --> URI Class Initialized
DEBUG - 2014-12-15 12:20:14 --> Router Class Initialized
DEBUG - 2014-12-15 12:20:14 --> Output Class Initialized
DEBUG - 2014-12-15 12:20:14 --> Security Class Initialized
DEBUG - 2014-12-15 12:20:14 --> Input Class Initialized
DEBUG - 2014-12-15 12:20:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-15 12:20:14 --> Language Class Initialized
DEBUG - 2014-12-15 12:20:15 --> Loader Class Initialized
DEBUG - 2014-12-15 12:20:15 --> Database Driver Class Initialized
ERROR - 2014-12-15 12:20:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-15 12:20:15 --> XML-RPC Class Initialized
DEBUG - 2014-12-15 12:20:15 --> Controller Class Initialized
DEBUG - 2014-12-15 12:20:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-15 12:20:16 --> Helper loaded: inflector_helper
DEBUG - 2014-12-15 12:20:16 --> Model Class Initialized
DEBUG - 2014-12-15 12:20:16 --> Model Class Initialized
ERROR - 2014-12-15 12:20:19 --> Severity: 4096  --> Object of class stdClass could not be converted to string /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 552
DEBUG - 2014-12-15 12:20:19 --> DB Transaction Failure
ERROR - 2014-12-15 12:20:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' '7c222fb2927d828af22f592134e8932480637c0d', 'FirstName', 'LastName', '1982-12-1' at line 1
DEBUG - 2014-12-15 12:20:19 --> Language file loaded: language/english/db_lang.php
ERROR - 2014-12-15 12:20:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Common.php 442
DEBUG - 2014-12-15 12:21:23 --> Config Class Initialized
DEBUG - 2014-12-15 12:21:23 --> Hooks Class Initialized
DEBUG - 2014-12-15 12:21:23 --> Utf8 Class Initialized
DEBUG - 2014-12-15 12:21:23 --> UTF-8 Support Enabled
DEBUG - 2014-12-15 12:21:23 --> URI Class Initialized
DEBUG - 2014-12-15 12:21:23 --> Router Class Initialized
DEBUG - 2014-12-15 12:21:24 --> No URI present. Default controller set.
DEBUG - 2014-12-15 12:21:24 --> Output Class Initialized
DEBUG - 2014-12-15 12:21:24 --> Security Class Initialized
DEBUG - 2014-12-15 12:21:24 --> Input Class Initialized
DEBUG - 2014-12-15 12:21:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-15 12:21:24 --> Language Class Initialized
DEBUG - 2014-12-15 12:21:24 --> Loader Class Initialized
DEBUG - 2014-12-15 12:21:24 --> Database Driver Class Initialized
ERROR - 2014-12-15 12:21:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-15 12:21:24 --> XML-RPC Class Initialized
DEBUG - 2014-12-15 12:21:24 --> Controller Class Initialized
DEBUG - 2014-12-15 12:21:24 --> Helper loaded: url_helper
DEBUG - 2014-12-15 12:21:24 --> File loaded: application/views/welcome_message.php
DEBUG - 2014-12-15 12:21:24 --> Final output sent to browser
DEBUG - 2014-12-15 12:21:24 --> Total execution time: 0.4387
DEBUG - 2014-12-15 12:21:29 --> Config Class Initialized
DEBUG - 2014-12-15 12:21:29 --> Hooks Class Initialized
DEBUG - 2014-12-15 12:21:29 --> Utf8 Class Initialized
DEBUG - 2014-12-15 12:21:29 --> UTF-8 Support Enabled
DEBUG - 2014-12-15 12:21:29 --> URI Class Initialized
DEBUG - 2014-12-15 12:21:29 --> Router Class Initialized
ERROR - 2014-12-15 12:21:29 --> 404 Page Not Found --> user
DEBUG - 2014-12-15 12:21:36 --> Config Class Initialized
DEBUG - 2014-12-15 12:21:36 --> Hooks Class Initialized
DEBUG - 2014-12-15 12:21:36 --> Utf8 Class Initialized
DEBUG - 2014-12-15 12:21:36 --> UTF-8 Support Enabled
DEBUG - 2014-12-15 12:21:36 --> URI Class Initialized
DEBUG - 2014-12-15 12:21:36 --> Router Class Initialized
ERROR - 2014-12-15 12:21:36 --> 404 Page Not Found --> users
DEBUG - 2014-12-15 12:21:42 --> Config Class Initialized
DEBUG - 2014-12-15 12:21:42 --> Hooks Class Initialized
DEBUG - 2014-12-15 12:21:42 --> Utf8 Class Initialized
DEBUG - 2014-12-15 12:21:42 --> UTF-8 Support Enabled
DEBUG - 2014-12-15 12:21:42 --> URI Class Initialized
DEBUG - 2014-12-15 12:21:42 --> Router Class Initialized
ERROR - 2014-12-15 12:21:42 --> 404 Page Not Found --> users
DEBUG - 2014-12-15 12:21:53 --> Config Class Initialized
DEBUG - 2014-12-15 12:21:53 --> Hooks Class Initialized
DEBUG - 2014-12-15 12:21:53 --> Utf8 Class Initialized
DEBUG - 2014-12-15 12:21:53 --> UTF-8 Support Enabled
DEBUG - 2014-12-15 12:21:53 --> URI Class Initialized
DEBUG - 2014-12-15 12:21:53 --> Router Class Initialized
ERROR - 2014-12-15 12:21:53 --> 404 Page Not Found --> spi
DEBUG - 2014-12-15 12:21:59 --> Config Class Initialized
DEBUG - 2014-12-15 12:21:59 --> Hooks Class Initialized
DEBUG - 2014-12-15 12:21:59 --> Utf8 Class Initialized
DEBUG - 2014-12-15 12:21:59 --> UTF-8 Support Enabled
DEBUG - 2014-12-15 12:21:59 --> URI Class Initialized
DEBUG - 2014-12-15 12:21:59 --> Router Class Initialized
DEBUG - 2014-12-15 12:21:59 --> Output Class Initialized
DEBUG - 2014-12-15 12:21:59 --> Security Class Initialized
DEBUG - 2014-12-15 12:21:59 --> Input Class Initialized
DEBUG - 2014-12-15 12:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-15 12:21:59 --> Language Class Initialized
DEBUG - 2014-12-15 12:21:59 --> Loader Class Initialized
DEBUG - 2014-12-15 12:21:59 --> Database Driver Class Initialized
ERROR - 2014-12-15 12:21:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-15 12:21:59 --> XML-RPC Class Initialized
DEBUG - 2014-12-15 12:21:59 --> Controller Class Initialized
DEBUG - 2014-12-15 12:21:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-15 12:21:59 --> Helper loaded: inflector_helper
DEBUG - 2014-12-15 12:21:59 --> Model Class Initialized
DEBUG - 2014-12-15 12:21:59 --> Model Class Initialized
DEBUG - 2014-12-15 12:29:23 --> Config Class Initialized
DEBUG - 2014-12-15 12:29:23 --> Hooks Class Initialized
DEBUG - 2014-12-15 12:29:23 --> Utf8 Class Initialized
DEBUG - 2014-12-15 12:29:23 --> UTF-8 Support Enabled
DEBUG - 2014-12-15 12:29:23 --> URI Class Initialized
DEBUG - 2014-12-15 12:29:23 --> Router Class Initialized
DEBUG - 2014-12-15 12:29:23 --> Output Class Initialized
DEBUG - 2014-12-15 12:29:23 --> Security Class Initialized
DEBUG - 2014-12-15 12:29:23 --> Input Class Initialized
DEBUG - 2014-12-15 12:29:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-15 12:29:23 --> Language Class Initialized
DEBUG - 2014-12-15 12:29:23 --> Loader Class Initialized
DEBUG - 2014-12-15 12:29:23 --> Database Driver Class Initialized
ERROR - 2014-12-15 12:29:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-15 12:29:23 --> XML-RPC Class Initialized
DEBUG - 2014-12-15 12:29:23 --> Controller Class Initialized
DEBUG - 2014-12-15 12:29:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-15 12:29:23 --> Helper loaded: inflector_helper
DEBUG - 2014-12-15 12:29:23 --> Model Class Initialized
DEBUG - 2014-12-15 12:29:23 --> Model Class Initialized
ERROR - 2014-12-15 12:29:26 --> Severity: 4096  --> Object of class stdClass could not be converted to string /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 552
DEBUG - 2014-12-15 12:29:26 --> DB Transaction Failure
ERROR - 2014-12-15 12:29:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' '7c222fb2927d828af22f592134e8932480637c0d', 'FirstName', 'LastName', '1982-12-1' at line 1
DEBUG - 2014-12-15 12:29:26 --> Language file loaded: language/english/db_lang.php
ERROR - 2014-12-15 12:29:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Common.php 442
DEBUG - 2014-12-15 12:38:45 --> Config Class Initialized
DEBUG - 2014-12-15 12:38:46 --> Hooks Class Initialized
DEBUG - 2014-12-15 12:38:46 --> Utf8 Class Initialized
DEBUG - 2014-12-15 12:38:46 --> UTF-8 Support Enabled
DEBUG - 2014-12-15 12:38:46 --> URI Class Initialized
DEBUG - 2014-12-15 12:38:46 --> Router Class Initialized
DEBUG - 2014-12-15 12:38:46 --> Output Class Initialized
DEBUG - 2014-12-15 12:38:46 --> Security Class Initialized
DEBUG - 2014-12-15 12:38:46 --> Input Class Initialized
DEBUG - 2014-12-15 12:38:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-15 12:38:46 --> Language Class Initialized
DEBUG - 2014-12-15 12:38:46 --> Loader Class Initialized
DEBUG - 2014-12-15 12:38:46 --> Database Driver Class Initialized
ERROR - 2014-12-15 12:38:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-15 12:38:46 --> XML-RPC Class Initialized
DEBUG - 2014-12-15 12:38:46 --> Controller Class Initialized
DEBUG - 2014-12-15 12:38:46 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-15 12:38:46 --> Helper loaded: inflector_helper
DEBUG - 2014-12-15 12:38:46 --> Model Class Initialized
DEBUG - 2014-12-15 12:38:46 --> Model Class Initialized
ERROR - 2014-12-15 12:38:49 --> Severity: 4096  --> Object of class stdClass could not be converted to string /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 552
DEBUG - 2014-12-15 12:38:49 --> DB Transaction Failure
ERROR - 2014-12-15 12:38:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' '7c222fb2927d828af22f592134e8932480637c0d', 'FirstName', 'LastName', '1982-12-1' at line 1
DEBUG - 2014-12-15 12:38:49 --> Language file loaded: language/english/db_lang.php
ERROR - 2014-12-15 12:38:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Common.php 442
