DEBUG - 2015-03-05 02:51:26 --> Config Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Hooks Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Utf8 Class Initialized
DEBUG - 2015-03-05 02:51:26 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 02:51:26 --> Config Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Config Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Hooks Class Initialized
DEBUG - 2015-03-05 02:51:26 --> URI Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Utf8 Class Initialized
DEBUG - 2015-03-05 02:51:26 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 02:51:26 --> Router Class Initialized
DEBUG - 2015-03-05 02:51:26 --> URI Class Initialized
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-03-05 02:51:26 --> Config Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Output Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Router Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Security Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Output Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Hooks Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Input Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 02:51:26 --> Utf8 Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Language Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Hooks Class Initialized
DEBUG - 2015-03-05 02:51:26 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 02:51:26 --> Security Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Input Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 02:51:26 --> Language Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Loader Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Loader Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Database Driver Class Initialized
DEBUG - 2015-03-05 02:51:26 --> URI Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Router Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Output Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Security Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Input Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 02:51:26 --> Language Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Utf8 Class Initialized
DEBUG - 2015-03-05 02:51:26 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 02:51:26 --> URI Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Router Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Output Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Security Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Input Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 02:51:26 --> Language Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Loader Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Database Driver Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Database Driver Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Loader Class Initialized
DEBUG - 2015-03-05 02:51:26 --> Database Driver Class Initialized
ERROR - 2015-03-05 02:51:27 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'root'@'localhost' (using password: YES) D:\www\nyc\server\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-05 02:51:27 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'root'@'localhost' (using password: YES) D:\www\nyc\server\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-05 02:51:27 --> Unable to connect to the database
ERROR - 2015-03-05 02:51:27 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'root'@'localhost' (using password: YES) D:\www\nyc\server\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-05 02:51:27 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'root'@'localhost' (using password: YES) D:\www\nyc\server\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2015-03-05 02:51:27 --> Language file loaded: language/english/db_lang.php
ERROR - 2015-03-05 02:51:27 --> Unable to connect to the database
ERROR - 2015-03-05 02:51:27 --> Unable to connect to the database
ERROR - 2015-03-05 02:51:27 --> Unable to connect to the database
DEBUG - 2015-03-05 02:51:27 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-05 02:51:27 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-05 02:51:27 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-05 02:55:09 --> Config Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Hooks Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Config Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Utf8 Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Config Class Initialized
DEBUG - 2015-03-05 02:55:09 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 02:55:09 --> Hooks Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Hooks Class Initialized
DEBUG - 2015-03-05 02:55:09 --> URI Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Utf8 Class Initialized
DEBUG - 2015-03-05 02:55:09 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 02:55:09 --> Router Class Initialized
DEBUG - 2015-03-05 02:55:09 --> URI Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Router Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Output Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Output Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Security Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Utf8 Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Security Class Initialized
DEBUG - 2015-03-05 02:55:09 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 02:55:09 --> Input Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Input Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 02:55:09 --> URI Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Language Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 02:55:09 --> Language Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Loader Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Router Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Loader Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Database Driver Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Database Driver Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Output Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Security Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Input Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 02:55:09 --> Language Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Loader Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Database Driver Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Config Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Hooks Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Utf8 Class Initialized
DEBUG - 2015-03-05 02:55:09 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 02:55:09 --> URI Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Router Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Output Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Security Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Input Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 02:55:09 --> Language Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Loader Class Initialized
DEBUG - 2015-03-05 02:55:09 --> Database Driver Class Initialized
ERROR - 2015-03-05 02:55:10 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'root'@'localhost' (using password: YES) D:\www\nyc\server\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-05 02:55:10 --> Unable to connect to the database
DEBUG - 2015-03-05 02:55:10 --> Language file loaded: language/english/db_lang.php
ERROR - 2015-03-05 02:55:10 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'root'@'localhost' (using password: YES) D:\www\nyc\server\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-05 02:55:10 --> Unable to connect to the database
DEBUG - 2015-03-05 02:55:10 --> Language file loaded: language/english/db_lang.php
ERROR - 2015-03-05 02:55:10 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'root'@'localhost' (using password: YES) D:\www\nyc\server\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-05 02:55:10 --> Unable to connect to the database
DEBUG - 2015-03-05 02:55:10 --> Language file loaded: language/english/db_lang.php
ERROR - 2015-03-05 02:55:10 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'root'@'localhost' (using password: YES) D:\www\nyc\server\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-05 02:55:10 --> Unable to connect to the database
DEBUG - 2015-03-05 02:55:10 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-03-05 02:56:46 --> Config Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Hooks Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Utf8 Class Initialized
DEBUG - 2015-03-05 02:56:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 02:56:46 --> URI Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Router Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Config Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Config Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Output Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Hooks Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Hooks Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Utf8 Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Security Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Utf8 Class Initialized
DEBUG - 2015-03-05 02:56:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 02:56:46 --> Input Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 02:56:46 --> Language Class Initialized
DEBUG - 2015-03-05 02:56:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 02:56:46 --> URI Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Router Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Output Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Security Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Loader Class Initialized
DEBUG - 2015-03-05 02:56:46 --> URI Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Input Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Database Driver Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 02:56:46 --> Router Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Config Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Hooks Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Language Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Utf8 Class Initialized
DEBUG - 2015-03-05 02:56:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 02:56:46 --> URI Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Router Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Output Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Loader Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Security Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Input Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 02:56:46 --> Language Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Output Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Loader Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Security Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Input Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 02:56:46 --> Language Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Database Driver Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Loader Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Database Driver Class Initialized
DEBUG - 2015-03-05 02:56:46 --> Database Driver Class Initialized
DEBUG - 2015-03-05 02:56:47 --> XML-RPC Class Initialized
DEBUG - 2015-03-05 02:56:47 --> Controller Class Initialized
DEBUG - 2015-03-05 02:56:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-05 02:56:47 --> Helper loaded: inflector_helper
DEBUG - 2015-03-05 02:56:47 --> XML-RPC Class Initialized
DEBUG - 2015-03-05 02:56:47 --> Controller Class Initialized
DEBUG - 2015-03-05 02:56:47 --> Model Class Initialized
DEBUG - 2015-03-05 02:56:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-05 02:56:47 --> Model Class Initialized
DEBUG - 2015-03-05 02:56:47 --> XML-RPC Class Initialized
DEBUG - 2015-03-05 02:56:47 --> Controller Class Initialized
DEBUG - 2015-03-05 02:56:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-05 02:56:47 --> Helper loaded: inflector_helper
DEBUG - 2015-03-05 02:56:47 --> Model Class Initialized
DEBUG - 2015-03-05 02:56:47 --> Model Class Initialized
DEBUG - 2015-03-05 02:56:47 --> Helper loaded: inflector_helper
DEBUG - 2015-03-05 02:56:47 --> Model Class Initialized
DEBUG - 2015-03-05 02:56:47 --> Model Class Initialized
DEBUG - 2015-03-05 02:56:47 --> XML-RPC Class Initialized
DEBUG - 2015-03-05 02:56:47 --> Controller Class Initialized
DEBUG - 2015-03-05 02:56:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-05 02:56:47 --> Helper loaded: inflector_helper
DEBUG - 2015-03-05 02:56:47 --> Model Class Initialized
DEBUG - 2015-03-05 02:56:47 --> Model Class Initialized
DEBUG - 2015-03-05 02:57:52 --> Config Class Initialized
DEBUG - 2015-03-05 02:57:52 --> Hooks Class Initialized
DEBUG - 2015-03-05 02:57:52 --> Utf8 Class Initialized
DEBUG - 2015-03-05 02:57:52 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 02:57:52 --> URI Class Initialized
DEBUG - 2015-03-05 02:57:52 --> Router Class Initialized
DEBUG - 2015-03-05 02:57:52 --> Output Class Initialized
DEBUG - 2015-03-05 02:57:52 --> Security Class Initialized
DEBUG - 2015-03-05 02:57:52 --> Input Class Initialized
DEBUG - 2015-03-05 02:57:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 02:57:52 --> Language Class Initialized
DEBUG - 2015-03-05 02:57:52 --> Loader Class Initialized
DEBUG - 2015-03-05 02:57:52 --> Database Driver Class Initialized
DEBUG - 2015-03-05 02:57:53 --> Config Class Initialized
DEBUG - 2015-03-05 02:57:53 --> Hooks Class Initialized
DEBUG - 2015-03-05 02:57:53 --> Utf8 Class Initialized
DEBUG - 2015-03-05 02:57:53 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 02:57:53 --> URI Class Initialized
DEBUG - 2015-03-05 02:57:53 --> Router Class Initialized
DEBUG - 2015-03-05 02:57:53 --> Output Class Initialized
DEBUG - 2015-03-05 02:57:53 --> Security Class Initialized
DEBUG - 2015-03-05 02:57:53 --> Input Class Initialized
DEBUG - 2015-03-05 02:57:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 02:57:53 --> Language Class Initialized
DEBUG - 2015-03-05 02:57:53 --> Loader Class Initialized
DEBUG - 2015-03-05 02:57:53 --> Database Driver Class Initialized
DEBUG - 2015-03-05 02:57:53 --> XML-RPC Class Initialized
DEBUG - 2015-03-05 02:57:53 --> Controller Class Initialized
DEBUG - 2015-03-05 02:57:53 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-05 02:57:53 --> Helper loaded: inflector_helper
DEBUG - 2015-03-05 02:57:53 --> Model Class Initialized
DEBUG - 2015-03-05 02:57:53 --> Model Class Initialized
DEBUG - 2015-03-05 02:57:53 --> XML-RPC Class Initialized
DEBUG - 2015-03-05 02:57:53 --> Controller Class Initialized
DEBUG - 2015-03-05 02:57:53 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-05 02:57:53 --> Helper loaded: inflector_helper
DEBUG - 2015-03-05 02:57:53 --> Model Class Initialized
DEBUG - 2015-03-05 02:57:53 --> Model Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Config Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Hooks Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Config Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Hooks Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Utf8 Class Initialized
DEBUG - 2015-03-05 03:17:24 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 03:17:24 --> Utf8 Class Initialized
DEBUG - 2015-03-05 03:17:24 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 03:17:24 --> URI Class Initialized
DEBUG - 2015-03-05 03:17:24 --> URI Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Router Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Router Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Output Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Output Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Security Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Security Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Input Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Input Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 03:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 03:17:24 --> Language Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Loader Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Language Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Loader Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Config Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Hooks Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Utf8 Class Initialized
DEBUG - 2015-03-05 03:17:24 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 03:17:24 --> URI Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Router Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Output Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Security Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Config Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Hooks Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Input Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 03:17:24 --> Utf8 Class Initialized
DEBUG - 2015-03-05 03:17:24 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 03:17:24 --> Language Class Initialized
DEBUG - 2015-03-05 03:17:24 --> URI Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Router Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Output Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Security Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Loader Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Input Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 03:17:24 --> Language Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Database Driver Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Loader Class Initialized
DEBUG - 2015-03-05 03:17:24 --> XML-RPC Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Controller Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-05 03:17:24 --> Database Driver Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Helper loaded: inflector_helper
DEBUG - 2015-03-05 03:17:24 --> Model Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Model Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Database Driver Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Database Driver Class Initialized
DEBUG - 2015-03-05 03:17:24 --> XML-RPC Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Controller Class Initialized
DEBUG - 2015-03-05 03:17:24 --> XML-RPC Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Controller Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-05 03:17:24 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-05 03:17:24 --> Helper loaded: inflector_helper
DEBUG - 2015-03-05 03:17:24 --> Helper loaded: inflector_helper
DEBUG - 2015-03-05 03:17:24 --> Model Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Model Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Model Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Model Class Initialized
DEBUG - 2015-03-05 03:17:24 --> XML-RPC Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Controller Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-05 03:17:24 --> Helper loaded: inflector_helper
DEBUG - 2015-03-05 03:17:24 --> Model Class Initialized
DEBUG - 2015-03-05 03:17:24 --> Model Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Config Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Hooks Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Utf8 Class Initialized
DEBUG - 2015-03-05 03:17:37 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 03:17:37 --> URI Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Router Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Config Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Hooks Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Output Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Utf8 Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Config Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Hooks Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Security Class Initialized
DEBUG - 2015-03-05 03:17:37 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 03:17:37 --> Input Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 03:17:37 --> Utf8 Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Language Class Initialized
DEBUG - 2015-03-05 03:17:37 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 03:17:37 --> URI Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Router Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Output Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Security Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Loader Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Input Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 03:17:37 --> Language Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Database Driver Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Loader Class Initialized
DEBUG - 2015-03-05 03:17:37 --> URI Class Initialized
DEBUG - 2015-03-05 03:17:37 --> XML-RPC Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Controller Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-05 03:17:37 --> Helper loaded: inflector_helper
DEBUG - 2015-03-05 03:17:37 --> Model Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Router Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Output Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Security Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Input Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 03:17:37 --> Language Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Database Driver Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Loader Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Config Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Hooks Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Utf8 Class Initialized
DEBUG - 2015-03-05 03:17:37 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 03:17:37 --> URI Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Model Class Initialized
DEBUG - 2015-03-05 03:17:37 --> XML-RPC Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Controller Class Initialized
DEBUG - 2015-03-05 03:17:37 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-05 03:17:38 --> Database Driver Class Initialized
DEBUG - 2015-03-05 03:17:38 --> Helper loaded: inflector_helper
DEBUG - 2015-03-05 03:17:38 --> Model Class Initialized
DEBUG - 2015-03-05 03:17:38 --> Model Class Initialized
DEBUG - 2015-03-05 03:17:38 --> XML-RPC Class Initialized
DEBUG - 2015-03-05 03:17:38 --> Controller Class Initialized
DEBUG - 2015-03-05 03:17:38 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-05 03:17:38 --> Helper loaded: inflector_helper
DEBUG - 2015-03-05 03:17:38 --> Model Class Initialized
DEBUG - 2015-03-05 03:17:38 --> Model Class Initialized
DEBUG - 2015-03-05 03:17:38 --> Router Class Initialized
DEBUG - 2015-03-05 03:17:38 --> Output Class Initialized
DEBUG - 2015-03-05 03:17:38 --> Security Class Initialized
DEBUG - 2015-03-05 03:17:38 --> Input Class Initialized
DEBUG - 2015-03-05 03:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 03:17:38 --> Language Class Initialized
DEBUG - 2015-03-05 03:17:38 --> Loader Class Initialized
DEBUG - 2015-03-05 03:17:38 --> Database Driver Class Initialized
DEBUG - 2015-03-05 03:17:38 --> XML-RPC Class Initialized
DEBUG - 2015-03-05 03:17:38 --> Controller Class Initialized
DEBUG - 2015-03-05 03:17:38 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-05 03:17:38 --> Helper loaded: inflector_helper
DEBUG - 2015-03-05 03:17:38 --> Model Class Initialized
DEBUG - 2015-03-05 03:17:38 --> Model Class Initialized
DEBUG - 2015-03-05 03:18:13 --> Config Class Initialized
DEBUG - 2015-03-05 03:18:13 --> Hooks Class Initialized
DEBUG - 2015-03-05 03:18:13 --> Utf8 Class Initialized
DEBUG - 2015-03-05 03:18:13 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 03:18:13 --> URI Class Initialized
DEBUG - 2015-03-05 03:18:13 --> Router Class Initialized
DEBUG - 2015-03-05 03:18:13 --> Output Class Initialized
DEBUG - 2015-03-05 03:18:13 --> Security Class Initialized
DEBUG - 2015-03-05 03:18:13 --> Input Class Initialized
DEBUG - 2015-03-05 03:18:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 03:18:13 --> Language Class Initialized
DEBUG - 2015-03-05 03:18:13 --> Loader Class Initialized
DEBUG - 2015-03-05 03:18:13 --> Database Driver Class Initialized
DEBUG - 2015-03-05 03:18:13 --> XML-RPC Class Initialized
DEBUG - 2015-03-05 03:18:13 --> Controller Class Initialized
DEBUG - 2015-03-05 03:18:13 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-05 03:18:13 --> Helper loaded: inflector_helper
DEBUG - 2015-03-05 03:18:13 --> Model Class Initialized
DEBUG - 2015-03-05 03:18:13 --> Model Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Config Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Config Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Hooks Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Hooks Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Utf8 Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Utf8 Class Initialized
DEBUG - 2015-03-05 03:20:20 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 03:20:20 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 03:20:20 --> URI Class Initialized
DEBUG - 2015-03-05 03:20:20 --> URI Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Router Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Output Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Security Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Input Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 03:20:20 --> Config Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Hooks Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Utf8 Class Initialized
DEBUG - 2015-03-05 03:20:20 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 03:20:20 --> URI Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Router Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Language Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Router Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Output Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Security Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Input Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Loader Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 03:20:20 --> Output Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Security Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Input Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 03:20:20 --> Language Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Database Driver Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Language Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Loader Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Config Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Hooks Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Utf8 Class Initialized
DEBUG - 2015-03-05 03:20:20 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 03:20:20 --> URI Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Router Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Loader Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Output Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Security Class Initialized
DEBUG - 2015-03-05 03:20:20 --> XML-RPC Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Controller Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Database Driver Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-05 03:20:20 --> Database Driver Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Helper loaded: inflector_helper
DEBUG - 2015-03-05 03:20:20 --> Model Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Model Class Initialized
DEBUG - 2015-03-05 03:20:20 --> XML-RPC Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Controller Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-05 03:20:20 --> Helper loaded: inflector_helper
DEBUG - 2015-03-05 03:20:20 --> Model Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Model Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Input Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 03:20:20 --> Language Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Loader Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Database Driver Class Initialized
DEBUG - 2015-03-05 03:20:20 --> XML-RPC Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Controller Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-05 03:20:20 --> Helper loaded: inflector_helper
DEBUG - 2015-03-05 03:20:20 --> Model Class Initialized
DEBUG - 2015-03-05 03:20:20 --> Model Class Initialized
DEBUG - 2015-03-05 03:20:21 --> XML-RPC Class Initialized
DEBUG - 2015-03-05 03:20:21 --> Controller Class Initialized
DEBUG - 2015-03-05 03:20:21 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-05 03:20:21 --> Helper loaded: inflector_helper
DEBUG - 2015-03-05 03:20:21 --> Model Class Initialized
DEBUG - 2015-03-05 03:20:21 --> Model Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Config Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Hooks Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Utf8 Class Initialized
DEBUG - 2015-03-05 03:22:08 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 03:22:08 --> URI Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Router Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Output Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Security Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Input Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 03:22:08 --> Language Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Loader Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Database Driver Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Config Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Hooks Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Utf8 Class Initialized
DEBUG - 2015-03-05 03:22:08 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 03:22:08 --> URI Class Initialized
DEBUG - 2015-03-05 03:22:08 --> XML-RPC Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Controller Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Router Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-05 03:22:08 --> Helper loaded: inflector_helper
DEBUG - 2015-03-05 03:22:08 --> Output Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Model Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Model Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Config Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Hooks Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Utf8 Class Initialized
DEBUG - 2015-03-05 03:22:08 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 03:22:08 --> Security Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Input Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Config Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Hooks Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Utf8 Class Initialized
DEBUG - 2015-03-05 03:22:08 --> UTF-8 Support Enabled
DEBUG - 2015-03-05 03:22:08 --> URI Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Router Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 03:22:08 --> Language Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Output Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Security Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Input Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 03:22:08 --> Language Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Loader Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Loader Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Database Driver Class Initialized
DEBUG - 2015-03-05 03:22:08 --> URI Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Router Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Output Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Database Driver Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Security Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Input Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-05 03:22:08 --> Language Class Initialized
DEBUG - 2015-03-05 03:22:08 --> XML-RPC Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Controller Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-05 03:22:08 --> Helper loaded: inflector_helper
DEBUG - 2015-03-05 03:22:08 --> Model Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Model Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Loader Class Initialized
DEBUG - 2015-03-05 03:22:08 --> XML-RPC Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Controller Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-05 03:22:08 --> Helper loaded: inflector_helper
DEBUG - 2015-03-05 03:22:08 --> Model Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Model Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Database Driver Class Initialized
DEBUG - 2015-03-05 03:22:08 --> XML-RPC Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Controller Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-05 03:22:08 --> Helper loaded: inflector_helper
DEBUG - 2015-03-05 03:22:08 --> Model Class Initialized
DEBUG - 2015-03-05 03:22:08 --> Model Class Initialized
