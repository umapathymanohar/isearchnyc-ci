<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-12-13 15:06:18 --> Config Class Initialized
DEBUG - 2014-12-13 15:06:18 --> Hooks Class Initialized
DEBUG - 2014-12-13 15:06:18 --> Utf8 Class Initialized
DEBUG - 2014-12-13 15:06:18 --> UTF-8 Support Enabled
DEBUG - 2014-12-13 15:06:18 --> URI Class Initialized
DEBUG - 2014-12-13 15:06:18 --> Router Class Initialized
DEBUG - 2014-12-13 15:06:18 --> Output Class Initialized
DEBUG - 2014-12-13 15:06:19 --> Security Class Initialized
DEBUG - 2014-12-13 15:06:19 --> Input Class Initialized
DEBUG - 2014-12-13 15:06:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-13 15:06:19 --> Language Class Initialized
DEBUG - 2014-12-13 15:06:19 --> Loader Class Initialized
DEBUG - 2014-12-13 15:06:19 --> Database Driver Class Initialized
ERROR - 2014-12-13 15:06:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-13 15:06:19 --> XML-RPC Class Initialized
DEBUG - 2014-12-13 15:06:19 --> Controller Class Initialized
DEBUG - 2014-12-13 15:06:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-13 15:06:19 --> Helper loaded: inflector_helper
DEBUG - 2014-12-13 15:06:19 --> Model Class Initialized
DEBUG - 2014-12-13 15:06:19 --> Model Class Initialized
DEBUG - 2014-12-13 15:06:26 --> Config Class Initialized
DEBUG - 2014-12-13 15:06:26 --> Hooks Class Initialized
DEBUG - 2014-12-13 15:06:26 --> Utf8 Class Initialized
DEBUG - 2014-12-13 15:06:26 --> UTF-8 Support Enabled
DEBUG - 2014-12-13 15:06:26 --> URI Class Initialized
DEBUG - 2014-12-13 15:06:26 --> Router Class Initialized
DEBUG - 2014-12-13 15:06:26 --> Output Class Initialized
DEBUG - 2014-12-13 15:06:26 --> Security Class Initialized
DEBUG - 2014-12-13 15:06:26 --> Input Class Initialized
DEBUG - 2014-12-13 15:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-13 15:06:26 --> Language Class Initialized
DEBUG - 2014-12-13 15:06:26 --> Loader Class Initialized
DEBUG - 2014-12-13 15:06:26 --> Database Driver Class Initialized
ERROR - 2014-12-13 15:06:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-13 15:06:27 --> XML-RPC Class Initialized
DEBUG - 2014-12-13 15:06:27 --> Controller Class Initialized
DEBUG - 2014-12-13 15:06:27 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-13 15:06:27 --> Helper loaded: inflector_helper
DEBUG - 2014-12-13 15:06:27 --> Model Class Initialized
DEBUG - 2014-12-13 15:06:27 --> Model Class Initialized
DEBUG - 2014-12-13 15:06:36 --> Config Class Initialized
DEBUG - 2014-12-13 15:06:36 --> Hooks Class Initialized
DEBUG - 2014-12-13 15:06:36 --> Utf8 Class Initialized
DEBUG - 2014-12-13 15:06:36 --> UTF-8 Support Enabled
DEBUG - 2014-12-13 15:06:36 --> URI Class Initialized
DEBUG - 2014-12-13 15:06:36 --> Router Class Initialized
DEBUG - 2014-12-13 15:06:36 --> Output Class Initialized
DEBUG - 2014-12-13 15:06:36 --> Security Class Initialized
DEBUG - 2014-12-13 15:06:36 --> Input Class Initialized
DEBUG - 2014-12-13 15:06:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-13 15:06:36 --> Language Class Initialized
DEBUG - 2014-12-13 15:06:36 --> Loader Class Initialized
DEBUG - 2014-12-13 15:06:36 --> Database Driver Class Initialized
ERROR - 2014-12-13 15:06:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-13 15:06:36 --> XML-RPC Class Initialized
DEBUG - 2014-12-13 15:06:36 --> Controller Class Initialized
DEBUG - 2014-12-13 15:06:36 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-13 15:06:36 --> Helper loaded: inflector_helper
DEBUG - 2014-12-13 15:06:36 --> Model Class Initialized
DEBUG - 2014-12-13 15:06:36 --> Model Class Initialized
