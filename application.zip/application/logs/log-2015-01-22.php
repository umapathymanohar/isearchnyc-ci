<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-01-22 15:42:21 --> Config Class Initialized
DEBUG - 2015-01-22 15:42:21 --> Hooks Class Initialized
DEBUG - 2015-01-22 15:42:21 --> Utf8 Class Initialized
DEBUG - 2015-01-22 15:42:21 --> UTF-8 Support Enabled
DEBUG - 2015-01-22 15:42:21 --> URI Class Initialized
DEBUG - 2015-01-22 15:42:21 --> Router Class Initialized
DEBUG - 2015-01-22 15:42:21 --> Output Class Initialized
DEBUG - 2015-01-22 15:42:21 --> Security Class Initialized
DEBUG - 2015-01-22 15:42:21 --> Input Class Initialized
DEBUG - 2015-01-22 15:42:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-01-22 15:42:21 --> Language Class Initialized
DEBUG - 2015-01-22 15:42:21 --> Loader Class Initialized
DEBUG - 2015-01-22 15:42:21 --> Database Driver Class Initialized
ERROR - 2015-01-22 15:42:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-01-22 15:42:21 --> XML-RPC Class Initialized
DEBUG - 2015-01-22 15:42:21 --> Controller Class Initialized
DEBUG - 2015-01-22 15:42:21 --> Config file loaded: application/config/rest.php
DEBUG - 2015-01-22 15:42:21 --> Helper loaded: inflector_helper
DEBUG - 2015-01-22 15:42:37 --> Config Class Initialized
DEBUG - 2015-01-22 15:42:37 --> Hooks Class Initialized
DEBUG - 2015-01-22 15:42:37 --> Utf8 Class Initialized
DEBUG - 2015-01-22 15:42:37 --> UTF-8 Support Enabled
DEBUG - 2015-01-22 15:42:37 --> URI Class Initialized
DEBUG - 2015-01-22 15:42:37 --> Router Class Initialized
DEBUG - 2015-01-22 15:42:37 --> Output Class Initialized
DEBUG - 2015-01-22 15:42:37 --> Security Class Initialized
DEBUG - 2015-01-22 15:42:37 --> Input Class Initialized
DEBUG - 2015-01-22 15:42:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-01-22 15:42:37 --> Language Class Initialized
DEBUG - 2015-01-22 15:42:37 --> Loader Class Initialized
DEBUG - 2015-01-22 15:42:37 --> Database Driver Class Initialized
ERROR - 2015-01-22 15:42:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-01-22 15:42:37 --> XML-RPC Class Initialized
DEBUG - 2015-01-22 15:42:37 --> Controller Class Initialized
DEBUG - 2015-01-22 15:42:37 --> Config file loaded: application/config/rest.php
DEBUG - 2015-01-22 15:42:37 --> Helper loaded: inflector_helper
DEBUG - 2015-01-22 15:44:35 --> Config Class Initialized
DEBUG - 2015-01-22 15:44:35 --> Hooks Class Initialized
DEBUG - 2015-01-22 15:44:35 --> Utf8 Class Initialized
DEBUG - 2015-01-22 15:44:35 --> UTF-8 Support Enabled
DEBUG - 2015-01-22 15:44:35 --> URI Class Initialized
DEBUG - 2015-01-22 15:44:35 --> Router Class Initialized
DEBUG - 2015-01-22 15:44:35 --> No URI present. Default controller set.
DEBUG - 2015-01-22 15:44:35 --> Output Class Initialized
DEBUG - 2015-01-22 15:44:35 --> Security Class Initialized
DEBUG - 2015-01-22 15:44:35 --> Input Class Initialized
DEBUG - 2015-01-22 15:44:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-01-22 15:44:35 --> Language Class Initialized
DEBUG - 2015-01-22 15:44:35 --> Loader Class Initialized
DEBUG - 2015-01-22 15:44:35 --> Database Driver Class Initialized
ERROR - 2015-01-22 15:44:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-01-22 15:44:35 --> XML-RPC Class Initialized
DEBUG - 2015-01-22 15:44:35 --> Controller Class Initialized
DEBUG - 2015-01-22 15:44:35 --> Config file loaded: application/config/rest.php
DEBUG - 2015-01-22 15:44:35 --> Helper loaded: inflector_helper
DEBUG - 2015-01-22 15:44:48 --> Config Class Initialized
DEBUG - 2015-01-22 15:44:48 --> Hooks Class Initialized
DEBUG - 2015-01-22 15:44:48 --> Utf8 Class Initialized
DEBUG - 2015-01-22 15:44:48 --> UTF-8 Support Enabled
DEBUG - 2015-01-22 15:44:48 --> URI Class Initialized
DEBUG - 2015-01-22 15:44:48 --> Router Class Initialized
DEBUG - 2015-01-22 15:44:48 --> Output Class Initialized
DEBUG - 2015-01-22 15:44:48 --> Security Class Initialized
DEBUG - 2015-01-22 15:44:48 --> Input Class Initialized
DEBUG - 2015-01-22 15:44:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-01-22 15:44:48 --> Language Class Initialized
DEBUG - 2015-01-22 15:44:48 --> Loader Class Initialized
DEBUG - 2015-01-22 15:44:48 --> Database Driver Class Initialized
ERROR - 2015-01-22 15:44:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-01-22 15:44:48 --> XML-RPC Class Initialized
DEBUG - 2015-01-22 15:44:48 --> Controller Class Initialized
DEBUG - 2015-01-22 15:44:48 --> Config file loaded: application/config/rest.php
DEBUG - 2015-01-22 15:44:48 --> Helper loaded: inflector_helper
DEBUG - 2015-01-22 15:45:00 --> Config Class Initialized
DEBUG - 2015-01-22 15:45:00 --> Hooks Class Initialized
DEBUG - 2015-01-22 15:45:00 --> Utf8 Class Initialized
DEBUG - 2015-01-22 15:45:00 --> UTF-8 Support Enabled
DEBUG - 2015-01-22 15:45:00 --> URI Class Initialized
DEBUG - 2015-01-22 15:45:00 --> Router Class Initialized
DEBUG - 2015-01-22 15:45:00 --> Output Class Initialized
DEBUG - 2015-01-22 15:45:00 --> Security Class Initialized
DEBUG - 2015-01-22 15:45:00 --> Input Class Initialized
DEBUG - 2015-01-22 15:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-01-22 15:45:00 --> Language Class Initialized
DEBUG - 2015-01-22 15:45:00 --> Loader Class Initialized
DEBUG - 2015-01-22 15:45:00 --> Database Driver Class Initialized
ERROR - 2015-01-22 15:45:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-01-22 15:45:00 --> XML-RPC Class Initialized
DEBUG - 2015-01-22 15:45:00 --> Controller Class Initialized
DEBUG - 2015-01-22 15:45:00 --> Config file loaded: application/config/rest.php
DEBUG - 2015-01-22 15:45:00 --> Helper loaded: inflector_helper
DEBUG - 2015-01-22 15:45:24 --> Config Class Initialized
DEBUG - 2015-01-22 15:45:24 --> Hooks Class Initialized
DEBUG - 2015-01-22 15:45:24 --> Utf8 Class Initialized
DEBUG - 2015-01-22 15:45:24 --> UTF-8 Support Enabled
DEBUG - 2015-01-22 15:45:24 --> URI Class Initialized
DEBUG - 2015-01-22 15:45:24 --> Router Class Initialized
DEBUG - 2015-01-22 15:45:24 --> Output Class Initialized
DEBUG - 2015-01-22 15:45:24 --> Security Class Initialized
DEBUG - 2015-01-22 15:45:24 --> Input Class Initialized
DEBUG - 2015-01-22 15:45:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-01-22 15:45:24 --> Language Class Initialized
DEBUG - 2015-01-22 15:45:24 --> Loader Class Initialized
DEBUG - 2015-01-22 15:45:24 --> Database Driver Class Initialized
ERROR - 2015-01-22 15:45:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-01-22 15:45:24 --> XML-RPC Class Initialized
DEBUG - 2015-01-22 15:45:24 --> Controller Class Initialized
DEBUG - 2015-01-22 15:45:24 --> Config file loaded: application/config/rest.php
DEBUG - 2015-01-22 15:45:24 --> Helper loaded: inflector_helper
DEBUG - 2015-01-22 15:45:28 --> Config Class Initialized
DEBUG - 2015-01-22 15:45:28 --> Hooks Class Initialized
DEBUG - 2015-01-22 15:45:28 --> Utf8 Class Initialized
DEBUG - 2015-01-22 15:45:28 --> UTF-8 Support Enabled
DEBUG - 2015-01-22 15:45:28 --> URI Class Initialized
DEBUG - 2015-01-22 15:45:28 --> Router Class Initialized
DEBUG - 2015-01-22 15:45:28 --> Output Class Initialized
DEBUG - 2015-01-22 15:45:28 --> Security Class Initialized
DEBUG - 2015-01-22 15:45:28 --> Input Class Initialized
DEBUG - 2015-01-22 15:45:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-01-22 15:45:28 --> Language Class Initialized
DEBUG - 2015-01-22 15:45:29 --> Loader Class Initialized
DEBUG - 2015-01-22 15:45:29 --> Database Driver Class Initialized
ERROR - 2015-01-22 15:45:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-01-22 15:45:29 --> XML-RPC Class Initialized
DEBUG - 2015-01-22 15:45:29 --> Controller Class Initialized
DEBUG - 2015-01-22 15:45:29 --> Config file loaded: application/config/rest.php
DEBUG - 2015-01-22 15:45:29 --> Helper loaded: inflector_helper
DEBUG - 2015-01-22 15:47:06 --> Model Class Initialized
DEBUG - 2015-01-22 15:47:06 --> Model Class Initialized
DEBUG - 2015-01-22 15:47:18 --> Model Class Initialized
DEBUG - 2015-01-22 15:47:18 --> Model Class Initialized
DEBUG - 2015-01-22 15:47:31 --> Model Class Initialized
DEBUG - 2015-01-22 15:47:31 --> Model Class Initialized
DEBUG - 2015-01-22 15:47:55 --> Model Class Initialized
DEBUG - 2015-01-22 15:47:55 --> Model Class Initialized
DEBUG - 2015-01-22 15:47:59 --> Model Class Initialized
DEBUG - 2015-01-22 15:47:59 --> Model Class Initialized
