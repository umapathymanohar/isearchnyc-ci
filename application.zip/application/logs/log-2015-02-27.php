<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-02-27 03:16:59 --> Config Class Initialized
DEBUG - 2015-02-27 03:16:59 --> Hooks Class Initialized
DEBUG - 2015-02-27 03:16:59 --> Utf8 Class Initialized
DEBUG - 2015-02-27 03:16:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-27 03:16:59 --> URI Class Initialized
DEBUG - 2015-02-27 03:16:59 --> Router Class Initialized
DEBUG - 2015-02-27 03:16:59 --> Output Class Initialized
DEBUG - 2015-02-27 03:16:59 --> Security Class Initialized
DEBUG - 2015-02-27 03:16:59 --> Input Class Initialized
DEBUG - 2015-02-27 03:16:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-27 03:16:59 --> Language Class Initialized
DEBUG - 2015-02-27 03:16:59 --> Loader Class Initialized
DEBUG - 2015-02-27 03:16:59 --> Database Driver Class Initialized
DEBUG - 2015-02-27 03:17:00 --> XML-RPC Class Initialized
DEBUG - 2015-02-27 03:17:00 --> Controller Class Initialized
DEBUG - 2015-02-27 03:17:00 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-27 03:17:00 --> Helper loaded: inflector_helper
DEBUG - 2015-02-27 03:17:00 --> Model Class Initialized
DEBUG - 2015-02-27 03:17:01 --> Model Class Initialized
ERROR - 2015-02-27 03:17:01 --> Severity: Notice  --> Undefined index: callname D:\www\nyc\server\application\models\users_model.php 124
ERROR - 2015-02-27 03:17:01 --> Severity: Notice  --> Undefined index: missing D:\www\nyc\server\application\controllers\api\users.php 273
DEBUG - 2015-02-27 03:19:12 --> Config Class Initialized
DEBUG - 2015-02-27 03:19:12 --> Hooks Class Initialized
DEBUG - 2015-02-27 03:19:12 --> Utf8 Class Initialized
DEBUG - 2015-02-27 03:19:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-27 03:19:12 --> URI Class Initialized
DEBUG - 2015-02-27 03:19:12 --> Router Class Initialized
DEBUG - 2015-02-27 03:19:12 --> Output Class Initialized
DEBUG - 2015-02-27 03:19:12 --> Security Class Initialized
DEBUG - 2015-02-27 03:19:12 --> Input Class Initialized
DEBUG - 2015-02-27 03:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-27 03:19:12 --> Language Class Initialized
DEBUG - 2015-02-27 03:19:12 --> Loader Class Initialized
DEBUG - 2015-02-27 03:19:12 --> Database Driver Class Initialized
DEBUG - 2015-02-27 03:19:14 --> XML-RPC Class Initialized
DEBUG - 2015-02-27 03:19:14 --> Controller Class Initialized
DEBUG - 2015-02-27 03:19:14 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-27 03:19:14 --> Helper loaded: inflector_helper
DEBUG - 2015-02-27 03:19:14 --> Model Class Initialized
DEBUG - 2015-02-27 03:19:14 --> Model Class Initialized
ERROR - 2015-02-27 03:19:14 --> Severity: Notice  --> Undefined index: callname D:\www\nyc\server\application\models\users_model.php 124
ERROR - 2015-02-27 03:19:14 --> Severity: Notice  --> Undefined index: missing D:\www\nyc\server\application\controllers\api\users.php 273
DEBUG - 2015-02-27 03:21:18 --> Config Class Initialized
DEBUG - 2015-02-27 03:21:18 --> Hooks Class Initialized
DEBUG - 2015-02-27 03:21:18 --> Utf8 Class Initialized
DEBUG - 2015-02-27 03:21:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-27 03:21:18 --> URI Class Initialized
DEBUG - 2015-02-27 03:21:18 --> Router Class Initialized
DEBUG - 2015-02-27 03:21:18 --> Output Class Initialized
DEBUG - 2015-02-27 03:21:18 --> Security Class Initialized
DEBUG - 2015-02-27 03:21:18 --> Input Class Initialized
DEBUG - 2015-02-27 03:21:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-27 03:21:18 --> Language Class Initialized
DEBUG - 2015-02-27 03:21:18 --> Loader Class Initialized
DEBUG - 2015-02-27 03:21:18 --> Database Driver Class Initialized
DEBUG - 2015-02-27 03:21:19 --> XML-RPC Class Initialized
DEBUG - 2015-02-27 03:21:19 --> Controller Class Initialized
DEBUG - 2015-02-27 03:21:19 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-27 03:21:19 --> Helper loaded: inflector_helper
DEBUG - 2015-02-27 03:21:19 --> Model Class Initialized
DEBUG - 2015-02-27 03:21:19 --> Model Class Initialized
DEBUG - 2015-02-27 03:21:19 --> DB Transaction Failure
ERROR - 2015-02-27 03:21:19 --> Query error: Unknown column 'username' in 'where clause'
DEBUG - 2015-02-27 03:21:19 --> Language file loaded: language/english/db_lang.php
