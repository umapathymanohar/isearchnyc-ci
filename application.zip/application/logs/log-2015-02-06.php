<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-02-06 07:08:09 --> Config Class Initialized
DEBUG - 2015-02-06 07:08:09 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:08:09 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:08:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:08:09 --> URI Class Initialized
DEBUG - 2015-02-06 07:08:09 --> Router Class Initialized
DEBUG - 2015-02-06 07:08:09 --> Output Class Initialized
DEBUG - 2015-02-06 07:08:09 --> Security Class Initialized
DEBUG - 2015-02-06 07:08:09 --> Input Class Initialized
DEBUG - 2015-02-06 07:08:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 07:08:09 --> Language Class Initialized
DEBUG - 2015-02-06 07:08:09 --> Loader Class Initialized
DEBUG - 2015-02-06 07:08:09 --> Database Driver Class Initialized
ERROR - 2015-02-06 07:08:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 07:08:10 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 07:08:10 --> Controller Class Initialized
DEBUG - 2015-02-06 07:08:10 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 07:08:10 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 07:08:10 --> Model Class Initialized
DEBUG - 2015-02-06 07:08:10 --> Model Class Initialized
DEBUG - 2015-02-06 07:08:44 --> Config Class Initialized
DEBUG - 2015-02-06 07:08:44 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:08:44 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:08:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:08:44 --> URI Class Initialized
DEBUG - 2015-02-06 07:08:44 --> Router Class Initialized
DEBUG - 2015-02-06 07:08:44 --> Output Class Initialized
DEBUG - 2015-02-06 07:08:44 --> Security Class Initialized
DEBUG - 2015-02-06 07:08:44 --> Input Class Initialized
DEBUG - 2015-02-06 07:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 07:08:44 --> Language Class Initialized
DEBUG - 2015-02-06 07:08:44 --> Loader Class Initialized
DEBUG - 2015-02-06 07:08:44 --> Database Driver Class Initialized
ERROR - 2015-02-06 07:08:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 07:08:44 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 07:08:44 --> Controller Class Initialized
DEBUG - 2015-02-06 07:08:44 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 07:08:44 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 07:08:44 --> Model Class Initialized
DEBUG - 2015-02-06 07:08:44 --> Model Class Initialized
DEBUG - 2015-02-06 07:09:05 --> Config Class Initialized
DEBUG - 2015-02-06 07:09:05 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:09:05 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:09:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:09:05 --> URI Class Initialized
DEBUG - 2015-02-06 07:09:05 --> Router Class Initialized
DEBUG - 2015-02-06 07:09:05 --> Output Class Initialized
DEBUG - 2015-02-06 07:09:05 --> Security Class Initialized
DEBUG - 2015-02-06 07:09:05 --> Input Class Initialized
DEBUG - 2015-02-06 07:09:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 07:09:05 --> Language Class Initialized
DEBUG - 2015-02-06 07:09:05 --> Loader Class Initialized
DEBUG - 2015-02-06 07:09:05 --> Database Driver Class Initialized
ERROR - 2015-02-06 07:09:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 07:09:05 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 07:09:05 --> Controller Class Initialized
DEBUG - 2015-02-06 07:09:05 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 07:09:05 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 07:09:05 --> Model Class Initialized
DEBUG - 2015-02-06 07:09:05 --> Model Class Initialized
DEBUG - 2015-02-06 07:09:16 --> Config Class Initialized
DEBUG - 2015-02-06 07:09:16 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:09:16 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:09:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:09:16 --> URI Class Initialized
DEBUG - 2015-02-06 07:09:16 --> Router Class Initialized
DEBUG - 2015-02-06 07:09:16 --> Output Class Initialized
DEBUG - 2015-02-06 07:09:16 --> Security Class Initialized
DEBUG - 2015-02-06 07:09:16 --> Input Class Initialized
DEBUG - 2015-02-06 07:09:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 07:09:16 --> Language Class Initialized
DEBUG - 2015-02-06 07:09:16 --> Loader Class Initialized
DEBUG - 2015-02-06 07:09:16 --> Database Driver Class Initialized
ERROR - 2015-02-06 07:09:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 07:09:16 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 07:09:16 --> Controller Class Initialized
DEBUG - 2015-02-06 07:09:16 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 07:09:16 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 07:09:16 --> Model Class Initialized
DEBUG - 2015-02-06 07:09:16 --> Model Class Initialized
DEBUG - 2015-02-06 07:09:35 --> Config Class Initialized
DEBUG - 2015-02-06 07:09:35 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:09:35 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:09:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:09:35 --> URI Class Initialized
DEBUG - 2015-02-06 07:09:35 --> Router Class Initialized
DEBUG - 2015-02-06 07:09:35 --> Output Class Initialized
DEBUG - 2015-02-06 07:09:35 --> Security Class Initialized
DEBUG - 2015-02-06 07:09:35 --> Input Class Initialized
DEBUG - 2015-02-06 07:09:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 07:09:35 --> Language Class Initialized
DEBUG - 2015-02-06 07:09:35 --> Loader Class Initialized
DEBUG - 2015-02-06 07:09:35 --> Database Driver Class Initialized
ERROR - 2015-02-06 07:09:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 07:09:35 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 07:09:35 --> Controller Class Initialized
DEBUG - 2015-02-06 07:09:35 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 07:09:35 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 07:09:35 --> Model Class Initialized
DEBUG - 2015-02-06 07:09:35 --> Model Class Initialized
DEBUG - 2015-02-06 07:09:50 --> Config Class Initialized
DEBUG - 2015-02-06 07:09:50 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:09:50 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:09:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:09:50 --> URI Class Initialized
DEBUG - 2015-02-06 07:09:50 --> Router Class Initialized
DEBUG - 2015-02-06 07:09:50 --> Output Class Initialized
DEBUG - 2015-02-06 07:09:50 --> Security Class Initialized
DEBUG - 2015-02-06 07:09:50 --> Input Class Initialized
DEBUG - 2015-02-06 07:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 07:09:50 --> Language Class Initialized
DEBUG - 2015-02-06 07:09:50 --> Loader Class Initialized
DEBUG - 2015-02-06 07:09:50 --> Database Driver Class Initialized
ERROR - 2015-02-06 07:09:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 07:09:50 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 07:09:50 --> Controller Class Initialized
DEBUG - 2015-02-06 07:09:50 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 07:09:50 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 07:09:50 --> Model Class Initialized
DEBUG - 2015-02-06 07:09:50 --> Model Class Initialized
DEBUG - 2015-02-06 07:10:02 --> Config Class Initialized
DEBUG - 2015-02-06 07:10:02 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:10:02 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:10:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:10:02 --> URI Class Initialized
DEBUG - 2015-02-06 07:10:02 --> Router Class Initialized
DEBUG - 2015-02-06 07:10:02 --> Output Class Initialized
DEBUG - 2015-02-06 07:10:02 --> Security Class Initialized
DEBUG - 2015-02-06 07:10:02 --> Input Class Initialized
DEBUG - 2015-02-06 07:10:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 07:10:02 --> Language Class Initialized
DEBUG - 2015-02-06 07:10:02 --> Loader Class Initialized
DEBUG - 2015-02-06 07:10:02 --> Database Driver Class Initialized
ERROR - 2015-02-06 07:10:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 07:10:02 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 07:10:02 --> Controller Class Initialized
DEBUG - 2015-02-06 07:10:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 07:10:02 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 07:10:02 --> Model Class Initialized
DEBUG - 2015-02-06 07:10:02 --> Model Class Initialized
DEBUG - 2015-02-06 07:10:17 --> Config Class Initialized
DEBUG - 2015-02-06 07:10:17 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:10:17 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:10:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:10:17 --> URI Class Initialized
DEBUG - 2015-02-06 07:10:17 --> Router Class Initialized
DEBUG - 2015-02-06 07:10:17 --> Output Class Initialized
DEBUG - 2015-02-06 07:10:17 --> Security Class Initialized
DEBUG - 2015-02-06 07:10:17 --> Input Class Initialized
DEBUG - 2015-02-06 07:10:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 07:10:17 --> Language Class Initialized
DEBUG - 2015-02-06 07:10:17 --> Loader Class Initialized
DEBUG - 2015-02-06 07:10:17 --> Database Driver Class Initialized
ERROR - 2015-02-06 07:10:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 07:10:17 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 07:10:17 --> Controller Class Initialized
DEBUG - 2015-02-06 07:10:17 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 07:10:17 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 07:10:17 --> Model Class Initialized
DEBUG - 2015-02-06 07:10:17 --> Model Class Initialized
DEBUG - 2015-02-06 07:10:34 --> Config Class Initialized
DEBUG - 2015-02-06 07:10:34 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:10:34 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:10:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:10:34 --> URI Class Initialized
DEBUG - 2015-02-06 07:10:34 --> Router Class Initialized
DEBUG - 2015-02-06 07:10:34 --> Output Class Initialized
DEBUG - 2015-02-06 07:10:34 --> Security Class Initialized
DEBUG - 2015-02-06 07:10:34 --> Input Class Initialized
DEBUG - 2015-02-06 07:10:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 07:10:34 --> Language Class Initialized
DEBUG - 2015-02-06 07:10:34 --> Loader Class Initialized
DEBUG - 2015-02-06 07:10:34 --> Database Driver Class Initialized
ERROR - 2015-02-06 07:10:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 07:10:34 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 07:10:34 --> Controller Class Initialized
DEBUG - 2015-02-06 07:10:34 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 07:10:34 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 07:10:34 --> Model Class Initialized
DEBUG - 2015-02-06 07:10:34 --> Model Class Initialized
DEBUG - 2015-02-06 07:11:04 --> Config Class Initialized
DEBUG - 2015-02-06 07:11:04 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:11:04 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:11:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:11:04 --> URI Class Initialized
DEBUG - 2015-02-06 07:11:04 --> Router Class Initialized
DEBUG - 2015-02-06 07:11:04 --> Output Class Initialized
DEBUG - 2015-02-06 07:11:04 --> Security Class Initialized
DEBUG - 2015-02-06 07:11:04 --> Input Class Initialized
DEBUG - 2015-02-06 07:11:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 07:11:04 --> Language Class Initialized
DEBUG - 2015-02-06 07:11:04 --> Loader Class Initialized
DEBUG - 2015-02-06 07:11:04 --> Database Driver Class Initialized
ERROR - 2015-02-06 07:11:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 07:11:04 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 07:11:04 --> Controller Class Initialized
DEBUG - 2015-02-06 07:11:04 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 07:11:04 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 07:11:04 --> Model Class Initialized
DEBUG - 2015-02-06 07:11:04 --> Model Class Initialized
DEBUG - 2015-02-06 07:18:16 --> Config Class Initialized
DEBUG - 2015-02-06 07:18:16 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:18:16 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:18:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:18:16 --> URI Class Initialized
DEBUG - 2015-02-06 07:18:16 --> Router Class Initialized
DEBUG - 2015-02-06 07:18:16 --> Output Class Initialized
DEBUG - 2015-02-06 07:18:16 --> Security Class Initialized
DEBUG - 2015-02-06 07:18:16 --> Input Class Initialized
DEBUG - 2015-02-06 07:18:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 07:18:16 --> Language Class Initialized
DEBUG - 2015-02-06 07:18:16 --> Loader Class Initialized
DEBUG - 2015-02-06 07:18:16 --> Database Driver Class Initialized
ERROR - 2015-02-06 07:18:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 07:18:16 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 07:18:16 --> Controller Class Initialized
DEBUG - 2015-02-06 07:18:16 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 07:18:16 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 07:18:16 --> Model Class Initialized
DEBUG - 2015-02-06 07:18:16 --> Model Class Initialized
DEBUG - 2015-02-06 07:18:34 --> Config Class Initialized
DEBUG - 2015-02-06 07:18:34 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:18:34 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:18:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:18:34 --> URI Class Initialized
DEBUG - 2015-02-06 07:18:34 --> Router Class Initialized
DEBUG - 2015-02-06 07:18:34 --> Output Class Initialized
DEBUG - 2015-02-06 07:18:34 --> Security Class Initialized
DEBUG - 2015-02-06 07:18:34 --> Input Class Initialized
DEBUG - 2015-02-06 07:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 07:18:34 --> Language Class Initialized
DEBUG - 2015-02-06 07:18:34 --> Loader Class Initialized
DEBUG - 2015-02-06 07:18:34 --> Database Driver Class Initialized
ERROR - 2015-02-06 07:18:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 07:18:34 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 07:18:34 --> Controller Class Initialized
DEBUG - 2015-02-06 07:18:34 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 07:18:34 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 07:18:34 --> Model Class Initialized
DEBUG - 2015-02-06 07:18:34 --> Model Class Initialized
DEBUG - 2015-02-06 07:18:47 --> Config Class Initialized
DEBUG - 2015-02-06 07:18:47 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:18:47 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:18:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:18:47 --> URI Class Initialized
DEBUG - 2015-02-06 07:18:47 --> Router Class Initialized
DEBUG - 2015-02-06 07:18:47 --> Output Class Initialized
DEBUG - 2015-02-06 07:18:47 --> Security Class Initialized
DEBUG - 2015-02-06 07:18:47 --> Input Class Initialized
DEBUG - 2015-02-06 07:18:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 07:18:47 --> Language Class Initialized
DEBUG - 2015-02-06 07:18:47 --> Loader Class Initialized
DEBUG - 2015-02-06 07:18:47 --> Database Driver Class Initialized
ERROR - 2015-02-06 07:18:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 07:18:47 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 07:18:47 --> Controller Class Initialized
DEBUG - 2015-02-06 07:18:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 07:18:47 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 07:18:47 --> Model Class Initialized
DEBUG - 2015-02-06 07:18:47 --> Model Class Initialized
DEBUG - 2015-02-06 07:18:58 --> Config Class Initialized
DEBUG - 2015-02-06 07:18:58 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:18:58 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:18:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:18:58 --> URI Class Initialized
DEBUG - 2015-02-06 07:18:58 --> Router Class Initialized
DEBUG - 2015-02-06 07:18:58 --> Output Class Initialized
DEBUG - 2015-02-06 07:18:58 --> Security Class Initialized
DEBUG - 2015-02-06 07:18:58 --> Input Class Initialized
DEBUG - 2015-02-06 07:18:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 07:18:58 --> Language Class Initialized
DEBUG - 2015-02-06 07:18:58 --> Loader Class Initialized
DEBUG - 2015-02-06 07:18:58 --> Database Driver Class Initialized
ERROR - 2015-02-06 07:18:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 07:18:58 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 07:18:58 --> Controller Class Initialized
DEBUG - 2015-02-06 07:18:58 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 07:18:58 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 07:18:58 --> Model Class Initialized
DEBUG - 2015-02-06 07:18:58 --> Model Class Initialized
DEBUG - 2015-02-06 07:19:13 --> Config Class Initialized
DEBUG - 2015-02-06 07:19:13 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:19:13 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:19:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:19:13 --> URI Class Initialized
DEBUG - 2015-02-06 07:19:13 --> Router Class Initialized
DEBUG - 2015-02-06 07:19:13 --> Output Class Initialized
DEBUG - 2015-02-06 07:19:13 --> Security Class Initialized
DEBUG - 2015-02-06 07:19:13 --> Input Class Initialized
DEBUG - 2015-02-06 07:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 07:19:13 --> Language Class Initialized
DEBUG - 2015-02-06 07:19:13 --> Loader Class Initialized
DEBUG - 2015-02-06 07:19:13 --> Database Driver Class Initialized
ERROR - 2015-02-06 07:19:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 07:19:13 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 07:19:13 --> Controller Class Initialized
DEBUG - 2015-02-06 07:19:13 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 07:19:13 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 07:19:13 --> Model Class Initialized
DEBUG - 2015-02-06 07:38:34 --> Config Class Initialized
DEBUG - 2015-02-06 07:38:34 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:38:34 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:38:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:38:34 --> URI Class Initialized
DEBUG - 2015-02-06 07:38:34 --> Router Class Initialized
ERROR - 2015-02-06 07:38:34 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-06 07:38:36 --> Config Class Initialized
DEBUG - 2015-02-06 07:38:36 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:38:36 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:38:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:38:36 --> URI Class Initialized
DEBUG - 2015-02-06 07:38:36 --> Router Class Initialized
DEBUG - 2015-02-06 07:38:36 --> Output Class Initialized
DEBUG - 2015-02-06 07:38:36 --> Security Class Initialized
DEBUG - 2015-02-06 07:38:36 --> Input Class Initialized
DEBUG - 2015-02-06 07:38:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 07:38:36 --> Language Class Initialized
DEBUG - 2015-02-06 07:38:36 --> Loader Class Initialized
DEBUG - 2015-02-06 07:38:36 --> Database Driver Class Initialized
ERROR - 2015-02-06 07:38:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 07:38:36 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 07:38:36 --> Controller Class Initialized
DEBUG - 2015-02-06 07:38:36 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 07:38:36 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 07:38:36 --> Model Class Initialized
DEBUG - 2015-02-06 07:38:36 --> Model Class Initialized
DEBUG - 2015-02-06 07:38:39 --> Config Class Initialized
DEBUG - 2015-02-06 07:38:39 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:38:39 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:38:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:38:39 --> URI Class Initialized
DEBUG - 2015-02-06 07:38:39 --> Router Class Initialized
ERROR - 2015-02-06 07:38:39 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-06 07:38:41 --> Config Class Initialized
DEBUG - 2015-02-06 07:38:41 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:38:41 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:38:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:38:41 --> URI Class Initialized
DEBUG - 2015-02-06 07:38:41 --> Router Class Initialized
DEBUG - 2015-02-06 07:38:41 --> Output Class Initialized
DEBUG - 2015-02-06 07:38:41 --> Security Class Initialized
DEBUG - 2015-02-06 07:38:41 --> Input Class Initialized
DEBUG - 2015-02-06 07:38:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 07:38:41 --> Language Class Initialized
DEBUG - 2015-02-06 07:38:41 --> Loader Class Initialized
DEBUG - 2015-02-06 07:38:41 --> Database Driver Class Initialized
ERROR - 2015-02-06 07:38:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 07:38:41 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 07:38:41 --> Controller Class Initialized
DEBUG - 2015-02-06 07:38:41 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 07:38:41 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 07:38:41 --> Model Class Initialized
DEBUG - 2015-02-06 07:38:41 --> Model Class Initialized
DEBUG - 2015-02-06 07:38:43 --> Config Class Initialized
DEBUG - 2015-02-06 07:38:43 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:38:43 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:38:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:38:43 --> URI Class Initialized
DEBUG - 2015-02-06 07:38:43 --> Router Class Initialized
ERROR - 2015-02-06 07:38:43 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-06 07:39:52 --> Config Class Initialized
DEBUG - 2015-02-06 07:39:52 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:39:52 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:39:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:39:52 --> URI Class Initialized
DEBUG - 2015-02-06 07:39:52 --> Router Class Initialized
DEBUG - 2015-02-06 07:39:52 --> Output Class Initialized
DEBUG - 2015-02-06 07:39:52 --> Security Class Initialized
DEBUG - 2015-02-06 07:39:52 --> Input Class Initialized
DEBUG - 2015-02-06 07:39:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 07:39:52 --> Language Class Initialized
DEBUG - 2015-02-06 07:39:52 --> Loader Class Initialized
DEBUG - 2015-02-06 07:39:52 --> Database Driver Class Initialized
ERROR - 2015-02-06 07:39:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 07:39:52 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 07:39:52 --> Controller Class Initialized
DEBUG - 2015-02-06 07:39:52 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 07:39:52 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 07:39:52 --> Model Class Initialized
DEBUG - 2015-02-06 07:39:52 --> Model Class Initialized
DEBUG - 2015-02-06 07:39:57 --> Config Class Initialized
DEBUG - 2015-02-06 07:39:57 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:39:57 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:39:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:39:57 --> URI Class Initialized
DEBUG - 2015-02-06 07:39:57 --> Router Class Initialized
ERROR - 2015-02-06 07:39:57 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-06 07:41:27 --> Config Class Initialized
DEBUG - 2015-02-06 07:41:27 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:41:27 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:41:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:41:27 --> URI Class Initialized
DEBUG - 2015-02-06 07:41:27 --> Router Class Initialized
ERROR - 2015-02-06 07:41:27 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-06 07:41:28 --> Config Class Initialized
DEBUG - 2015-02-06 07:41:28 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:41:28 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:41:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:41:28 --> URI Class Initialized
DEBUG - 2015-02-06 07:41:28 --> Router Class Initialized
ERROR - 2015-02-06 07:41:28 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-06 07:41:28 --> Config Class Initialized
DEBUG - 2015-02-06 07:41:28 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:41:28 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:41:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:41:28 --> URI Class Initialized
DEBUG - 2015-02-06 07:41:28 --> Router Class Initialized
ERROR - 2015-02-06 07:41:28 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-06 07:41:33 --> Config Class Initialized
DEBUG - 2015-02-06 07:41:33 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:41:33 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:41:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:41:33 --> URI Class Initialized
DEBUG - 2015-02-06 07:41:33 --> Router Class Initialized
ERROR - 2015-02-06 07:41:33 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-06 07:41:34 --> Config Class Initialized
DEBUG - 2015-02-06 07:41:34 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:41:34 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:41:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:41:34 --> URI Class Initialized
DEBUG - 2015-02-06 07:41:34 --> Router Class Initialized
ERROR - 2015-02-06 07:41:34 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-06 07:41:39 --> Config Class Initialized
DEBUG - 2015-02-06 07:41:39 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:41:39 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:41:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:41:39 --> URI Class Initialized
DEBUG - 2015-02-06 07:41:39 --> Router Class Initialized
ERROR - 2015-02-06 07:41:39 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-06 07:41:41 --> Config Class Initialized
DEBUG - 2015-02-06 07:41:41 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:41:41 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:41:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:41:41 --> URI Class Initialized
DEBUG - 2015-02-06 07:41:41 --> Router Class Initialized
ERROR - 2015-02-06 07:41:41 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-06 07:48:18 --> Config Class Initialized
DEBUG - 2015-02-06 07:48:18 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:48:18 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:48:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:48:18 --> URI Class Initialized
DEBUG - 2015-02-06 07:48:18 --> Router Class Initialized
DEBUG - 2015-02-06 07:48:18 --> Output Class Initialized
DEBUG - 2015-02-06 07:48:18 --> Security Class Initialized
DEBUG - 2015-02-06 07:48:18 --> Input Class Initialized
DEBUG - 2015-02-06 07:48:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 07:48:18 --> Language Class Initialized
DEBUG - 2015-02-06 07:48:18 --> Loader Class Initialized
DEBUG - 2015-02-06 07:48:18 --> Database Driver Class Initialized
ERROR - 2015-02-06 07:48:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 07:48:18 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 07:48:18 --> Controller Class Initialized
DEBUG - 2015-02-06 07:48:18 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 07:48:18 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 07:48:18 --> Model Class Initialized
DEBUG - 2015-02-06 07:48:18 --> Model Class Initialized
DEBUG - 2015-02-06 07:49:03 --> Config Class Initialized
DEBUG - 2015-02-06 07:49:03 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:49:03 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:49:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:49:03 --> URI Class Initialized
DEBUG - 2015-02-06 07:49:03 --> Router Class Initialized
DEBUG - 2015-02-06 07:49:03 --> Output Class Initialized
DEBUG - 2015-02-06 07:49:03 --> Security Class Initialized
DEBUG - 2015-02-06 07:49:03 --> Input Class Initialized
DEBUG - 2015-02-06 07:49:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 07:49:03 --> Language Class Initialized
DEBUG - 2015-02-06 07:49:03 --> Loader Class Initialized
DEBUG - 2015-02-06 07:49:03 --> Database Driver Class Initialized
ERROR - 2015-02-06 07:49:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 07:49:03 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 07:49:03 --> Controller Class Initialized
DEBUG - 2015-02-06 07:49:03 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 07:49:03 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 07:49:03 --> Model Class Initialized
DEBUG - 2015-02-06 07:49:03 --> Model Class Initialized
DEBUG - 2015-02-06 07:49:07 --> Config Class Initialized
DEBUG - 2015-02-06 07:49:07 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:49:07 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:49:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:49:07 --> URI Class Initialized
DEBUG - 2015-02-06 07:49:07 --> Router Class Initialized
DEBUG - 2015-02-06 07:49:07 --> Output Class Initialized
DEBUG - 2015-02-06 07:49:07 --> Security Class Initialized
DEBUG - 2015-02-06 07:49:07 --> Input Class Initialized
DEBUG - 2015-02-06 07:49:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 07:49:07 --> Language Class Initialized
DEBUG - 2015-02-06 07:49:07 --> Loader Class Initialized
DEBUG - 2015-02-06 07:49:07 --> Database Driver Class Initialized
ERROR - 2015-02-06 07:49:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 07:49:07 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 07:49:07 --> Controller Class Initialized
DEBUG - 2015-02-06 07:49:07 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 07:49:07 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 07:49:07 --> Model Class Initialized
DEBUG - 2015-02-06 07:49:07 --> Model Class Initialized
DEBUG - 2015-02-06 07:49:08 --> Config Class Initialized
DEBUG - 2015-02-06 07:49:08 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:49:08 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:49:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:49:08 --> URI Class Initialized
DEBUG - 2015-02-06 07:49:08 --> Router Class Initialized
DEBUG - 2015-02-06 07:49:08 --> Output Class Initialized
DEBUG - 2015-02-06 07:49:08 --> Security Class Initialized
DEBUG - 2015-02-06 07:49:08 --> Input Class Initialized
DEBUG - 2015-02-06 07:49:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 07:49:08 --> Language Class Initialized
DEBUG - 2015-02-06 07:49:08 --> Loader Class Initialized
DEBUG - 2015-02-06 07:49:08 --> Database Driver Class Initialized
ERROR - 2015-02-06 07:49:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 07:49:08 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 07:49:08 --> Controller Class Initialized
DEBUG - 2015-02-06 07:49:08 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 07:49:08 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 07:49:08 --> Model Class Initialized
DEBUG - 2015-02-06 07:49:08 --> Model Class Initialized
DEBUG - 2015-02-06 07:49:13 --> Config Class Initialized
DEBUG - 2015-02-06 07:49:13 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:49:13 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:49:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:49:13 --> URI Class Initialized
DEBUG - 2015-02-06 07:49:13 --> Router Class Initialized
DEBUG - 2015-02-06 07:49:13 --> Output Class Initialized
DEBUG - 2015-02-06 07:49:13 --> Security Class Initialized
DEBUG - 2015-02-06 07:49:13 --> Input Class Initialized
DEBUG - 2015-02-06 07:49:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 07:49:13 --> Language Class Initialized
DEBUG - 2015-02-06 07:49:13 --> Loader Class Initialized
DEBUG - 2015-02-06 07:49:13 --> Database Driver Class Initialized
ERROR - 2015-02-06 07:49:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 07:49:13 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 07:49:13 --> Controller Class Initialized
DEBUG - 2015-02-06 07:49:13 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 07:49:13 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 07:49:13 --> Model Class Initialized
DEBUG - 2015-02-06 07:49:13 --> Model Class Initialized
DEBUG - 2015-02-06 07:49:18 --> Config Class Initialized
DEBUG - 2015-02-06 07:49:18 --> Hooks Class Initialized
DEBUG - 2015-02-06 07:49:18 --> Utf8 Class Initialized
DEBUG - 2015-02-06 07:49:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 07:49:18 --> URI Class Initialized
DEBUG - 2015-02-06 07:49:18 --> Router Class Initialized
DEBUG - 2015-02-06 07:49:18 --> Output Class Initialized
DEBUG - 2015-02-06 07:49:18 --> Security Class Initialized
DEBUG - 2015-02-06 07:49:18 --> Input Class Initialized
DEBUG - 2015-02-06 07:49:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 07:49:18 --> Language Class Initialized
DEBUG - 2015-02-06 07:49:18 --> Loader Class Initialized
DEBUG - 2015-02-06 07:49:18 --> Database Driver Class Initialized
ERROR - 2015-02-06 07:49:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 07:49:18 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 07:49:18 --> Controller Class Initialized
DEBUG - 2015-02-06 07:49:18 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 07:49:18 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 07:49:18 --> Model Class Initialized
DEBUG - 2015-02-06 07:49:18 --> Model Class Initialized
DEBUG - 2015-02-06 08:08:10 --> Config Class Initialized
DEBUG - 2015-02-06 08:08:10 --> Hooks Class Initialized
DEBUG - 2015-02-06 08:08:10 --> Utf8 Class Initialized
DEBUG - 2015-02-06 08:08:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 08:08:10 --> URI Class Initialized
DEBUG - 2015-02-06 08:08:10 --> Router Class Initialized
DEBUG - 2015-02-06 08:08:10 --> Output Class Initialized
DEBUG - 2015-02-06 08:08:10 --> Security Class Initialized
DEBUG - 2015-02-06 08:08:10 --> Input Class Initialized
DEBUG - 2015-02-06 08:08:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 08:08:10 --> Language Class Initialized
DEBUG - 2015-02-06 08:08:10 --> Loader Class Initialized
DEBUG - 2015-02-06 08:08:10 --> Database Driver Class Initialized
ERROR - 2015-02-06 08:08:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 08:08:10 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 08:08:10 --> Controller Class Initialized
DEBUG - 2015-02-06 08:08:10 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 08:08:10 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 08:08:10 --> Model Class Initialized
DEBUG - 2015-02-06 08:08:10 --> Model Class Initialized
DEBUG - 2015-02-06 08:08:14 --> Config Class Initialized
DEBUG - 2015-02-06 08:08:14 --> Hooks Class Initialized
DEBUG - 2015-02-06 08:08:14 --> Utf8 Class Initialized
DEBUG - 2015-02-06 08:08:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 08:08:14 --> URI Class Initialized
DEBUG - 2015-02-06 08:08:14 --> Router Class Initialized
ERROR - 2015-02-06 08:08:14 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-06 08:08:15 --> Config Class Initialized
DEBUG - 2015-02-06 08:08:15 --> Hooks Class Initialized
DEBUG - 2015-02-06 08:08:15 --> Utf8 Class Initialized
DEBUG - 2015-02-06 08:08:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 08:08:15 --> URI Class Initialized
DEBUG - 2015-02-06 08:08:15 --> Router Class Initialized
ERROR - 2015-02-06 08:08:15 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-06 08:08:15 --> Config Class Initialized
DEBUG - 2015-02-06 08:08:15 --> Hooks Class Initialized
DEBUG - 2015-02-06 08:08:15 --> Utf8 Class Initialized
DEBUG - 2015-02-06 08:08:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 08:08:15 --> URI Class Initialized
DEBUG - 2015-02-06 08:08:15 --> Router Class Initialized
ERROR - 2015-02-06 08:08:15 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-06 08:08:16 --> Config Class Initialized
DEBUG - 2015-02-06 08:08:16 --> Hooks Class Initialized
DEBUG - 2015-02-06 08:08:16 --> Utf8 Class Initialized
DEBUG - 2015-02-06 08:08:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 08:08:16 --> URI Class Initialized
DEBUG - 2015-02-06 08:08:16 --> Router Class Initialized
ERROR - 2015-02-06 08:08:16 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-06 08:08:22 --> Config Class Initialized
DEBUG - 2015-02-06 08:08:22 --> Hooks Class Initialized
DEBUG - 2015-02-06 08:08:22 --> Utf8 Class Initialized
DEBUG - 2015-02-06 08:08:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 08:08:22 --> URI Class Initialized
DEBUG - 2015-02-06 08:08:22 --> Router Class Initialized
ERROR - 2015-02-06 08:08:22 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-06 08:08:41 --> Config Class Initialized
DEBUG - 2015-02-06 08:08:41 --> Hooks Class Initialized
DEBUG - 2015-02-06 08:08:41 --> Utf8 Class Initialized
DEBUG - 2015-02-06 08:08:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 08:08:41 --> URI Class Initialized
DEBUG - 2015-02-06 08:08:41 --> Router Class Initialized
DEBUG - 2015-02-06 08:08:41 --> Output Class Initialized
DEBUG - 2015-02-06 08:08:41 --> Security Class Initialized
DEBUG - 2015-02-06 08:08:41 --> Input Class Initialized
DEBUG - 2015-02-06 08:08:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 08:08:41 --> Language Class Initialized
DEBUG - 2015-02-06 08:08:41 --> Loader Class Initialized
DEBUG - 2015-02-06 08:08:41 --> Database Driver Class Initialized
ERROR - 2015-02-06 08:08:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 08:08:41 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 08:08:41 --> Controller Class Initialized
DEBUG - 2015-02-06 08:08:41 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 08:08:41 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 08:08:41 --> Model Class Initialized
DEBUG - 2015-02-06 08:08:41 --> Model Class Initialized
DEBUG - 2015-02-06 08:08:47 --> Config Class Initialized
DEBUG - 2015-02-06 08:08:47 --> Hooks Class Initialized
DEBUG - 2015-02-06 08:08:47 --> Utf8 Class Initialized
DEBUG - 2015-02-06 08:08:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 08:08:47 --> URI Class Initialized
DEBUG - 2015-02-06 08:08:47 --> Router Class Initialized
ERROR - 2015-02-06 08:08:47 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-06 08:10:16 --> Config Class Initialized
DEBUG - 2015-02-06 08:10:16 --> Hooks Class Initialized
DEBUG - 2015-02-06 08:10:16 --> Utf8 Class Initialized
DEBUG - 2015-02-06 08:10:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 08:10:16 --> URI Class Initialized
DEBUG - 2015-02-06 08:10:16 --> Router Class Initialized
DEBUG - 2015-02-06 08:10:16 --> Output Class Initialized
DEBUG - 2015-02-06 08:10:16 --> Security Class Initialized
DEBUG - 2015-02-06 08:10:16 --> Input Class Initialized
DEBUG - 2015-02-06 08:10:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 08:10:16 --> Language Class Initialized
DEBUG - 2015-02-06 08:10:16 --> Loader Class Initialized
DEBUG - 2015-02-06 08:10:16 --> Database Driver Class Initialized
ERROR - 2015-02-06 08:10:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 08:10:16 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 08:10:16 --> Controller Class Initialized
DEBUG - 2015-02-06 08:10:16 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 08:10:16 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 08:10:16 --> Model Class Initialized
DEBUG - 2015-02-06 08:10:16 --> Model Class Initialized
DEBUG - 2015-02-06 08:10:31 --> Config Class Initialized
DEBUG - 2015-02-06 08:10:31 --> Hooks Class Initialized
DEBUG - 2015-02-06 08:10:31 --> Utf8 Class Initialized
DEBUG - 2015-02-06 08:10:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 08:10:31 --> URI Class Initialized
DEBUG - 2015-02-06 08:10:31 --> Router Class Initialized
DEBUG - 2015-02-06 08:10:31 --> Output Class Initialized
DEBUG - 2015-02-06 08:10:31 --> Security Class Initialized
DEBUG - 2015-02-06 08:10:31 --> Input Class Initialized
DEBUG - 2015-02-06 08:10:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 08:10:31 --> Language Class Initialized
DEBUG - 2015-02-06 08:10:31 --> Loader Class Initialized
DEBUG - 2015-02-06 08:10:31 --> Database Driver Class Initialized
ERROR - 2015-02-06 08:10:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 08:10:31 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 08:10:31 --> Controller Class Initialized
DEBUG - 2015-02-06 08:10:31 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 08:10:31 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 08:10:31 --> Model Class Initialized
DEBUG - 2015-02-06 08:10:31 --> Model Class Initialized
DEBUG - 2015-02-06 08:10:37 --> Config Class Initialized
DEBUG - 2015-02-06 08:10:37 --> Hooks Class Initialized
DEBUG - 2015-02-06 08:10:37 --> Utf8 Class Initialized
DEBUG - 2015-02-06 08:10:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 08:10:37 --> URI Class Initialized
DEBUG - 2015-02-06 08:10:37 --> Router Class Initialized
DEBUG - 2015-02-06 08:10:37 --> Output Class Initialized
DEBUG - 2015-02-06 08:10:37 --> Security Class Initialized
DEBUG - 2015-02-06 08:10:37 --> Input Class Initialized
DEBUG - 2015-02-06 08:10:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 08:10:37 --> Language Class Initialized
DEBUG - 2015-02-06 08:10:37 --> Loader Class Initialized
DEBUG - 2015-02-06 08:10:37 --> Database Driver Class Initialized
ERROR - 2015-02-06 08:10:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 08:10:37 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 08:10:37 --> Controller Class Initialized
DEBUG - 2015-02-06 08:10:37 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 08:10:37 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 08:10:37 --> Model Class Initialized
DEBUG - 2015-02-06 08:10:37 --> Model Class Initialized
DEBUG - 2015-02-06 08:10:43 --> Config Class Initialized
DEBUG - 2015-02-06 08:10:43 --> Hooks Class Initialized
DEBUG - 2015-02-06 08:10:43 --> Utf8 Class Initialized
DEBUG - 2015-02-06 08:10:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 08:10:43 --> URI Class Initialized
DEBUG - 2015-02-06 08:10:43 --> Router Class Initialized
DEBUG - 2015-02-06 08:10:43 --> Output Class Initialized
DEBUG - 2015-02-06 08:10:43 --> Security Class Initialized
DEBUG - 2015-02-06 08:10:43 --> Input Class Initialized
DEBUG - 2015-02-06 08:10:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 08:10:43 --> Language Class Initialized
DEBUG - 2015-02-06 08:10:43 --> Loader Class Initialized
DEBUG - 2015-02-06 08:10:43 --> Database Driver Class Initialized
ERROR - 2015-02-06 08:10:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 08:10:43 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 08:10:43 --> Controller Class Initialized
DEBUG - 2015-02-06 08:10:43 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 08:10:43 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 08:10:43 --> Model Class Initialized
DEBUG - 2015-02-06 08:10:43 --> Model Class Initialized
ERROR - 2015-02-06 08:10:43 --> Severity: Notice  --> Undefined variable: data /Volumes/Data/www/thunderbirds-hub-site/server/application/models/badges_model.php 122
DEBUG - 2015-02-06 08:10:43 --> DB Transaction Failure
ERROR - 2015-02-06 08:10:43 --> Query error: Table 'thunderbirds.user_cbadge_status' doesn't exist
DEBUG - 2015-02-06 08:10:43 --> Language file loaded: language/english/db_lang.php
ERROR - 2015-02-06 08:10:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds-hub-site/server/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds-hub-site/server/system/core/Common.php 442
DEBUG - 2015-02-06 08:13:19 --> Config Class Initialized
DEBUG - 2015-02-06 08:13:19 --> Hooks Class Initialized
DEBUG - 2015-02-06 08:13:19 --> Utf8 Class Initialized
DEBUG - 2015-02-06 08:13:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 08:13:19 --> URI Class Initialized
DEBUG - 2015-02-06 08:13:19 --> Router Class Initialized
DEBUG - 2015-02-06 08:13:19 --> Output Class Initialized
DEBUG - 2015-02-06 08:13:19 --> Security Class Initialized
DEBUG - 2015-02-06 08:13:19 --> Input Class Initialized
DEBUG - 2015-02-06 08:13:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 08:13:19 --> Language Class Initialized
DEBUG - 2015-02-06 08:13:19 --> Loader Class Initialized
DEBUG - 2015-02-06 08:13:19 --> Database Driver Class Initialized
ERROR - 2015-02-06 08:13:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 08:13:19 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 08:13:19 --> Controller Class Initialized
DEBUG - 2015-02-06 08:13:19 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 08:13:19 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 08:13:19 --> Model Class Initialized
DEBUG - 2015-02-06 08:13:19 --> Model Class Initialized
DEBUG - 2015-02-06 08:15:52 --> Config Class Initialized
DEBUG - 2015-02-06 08:15:52 --> Hooks Class Initialized
DEBUG - 2015-02-06 08:15:52 --> Utf8 Class Initialized
DEBUG - 2015-02-06 08:15:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 08:15:52 --> URI Class Initialized
DEBUG - 2015-02-06 08:15:52 --> Router Class Initialized
DEBUG - 2015-02-06 08:15:52 --> Output Class Initialized
DEBUG - 2015-02-06 08:15:52 --> Security Class Initialized
DEBUG - 2015-02-06 08:15:52 --> Input Class Initialized
DEBUG - 2015-02-06 08:15:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 08:15:52 --> Language Class Initialized
DEBUG - 2015-02-06 08:15:52 --> Loader Class Initialized
DEBUG - 2015-02-06 08:15:52 --> Database Driver Class Initialized
ERROR - 2015-02-06 08:15:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 08:15:52 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 08:15:52 --> Controller Class Initialized
DEBUG - 2015-02-06 08:15:52 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 08:15:52 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 08:15:52 --> Model Class Initialized
DEBUG - 2015-02-06 08:15:52 --> Model Class Initialized
DEBUG - 2015-02-06 08:17:50 --> Config Class Initialized
DEBUG - 2015-02-06 08:17:50 --> Hooks Class Initialized
DEBUG - 2015-02-06 08:17:50 --> Utf8 Class Initialized
DEBUG - 2015-02-06 08:17:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 08:17:50 --> URI Class Initialized
DEBUG - 2015-02-06 08:17:50 --> Router Class Initialized
DEBUG - 2015-02-06 08:17:50 --> Output Class Initialized
DEBUG - 2015-02-06 08:17:50 --> Security Class Initialized
DEBUG - 2015-02-06 08:17:50 --> Input Class Initialized
DEBUG - 2015-02-06 08:17:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 08:17:50 --> Language Class Initialized
DEBUG - 2015-02-06 08:17:50 --> Loader Class Initialized
DEBUG - 2015-02-06 08:17:50 --> Database Driver Class Initialized
ERROR - 2015-02-06 08:17:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 08:17:50 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 08:17:50 --> Controller Class Initialized
DEBUG - 2015-02-06 08:17:50 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 08:17:50 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 08:17:50 --> Model Class Initialized
DEBUG - 2015-02-06 08:17:50 --> Model Class Initialized
DEBUG - 2015-02-06 08:24:28 --> Config Class Initialized
DEBUG - 2015-02-06 08:24:28 --> Hooks Class Initialized
DEBUG - 2015-02-06 08:24:28 --> Utf8 Class Initialized
DEBUG - 2015-02-06 08:24:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 08:24:28 --> URI Class Initialized
DEBUG - 2015-02-06 08:24:28 --> Router Class Initialized
DEBUG - 2015-02-06 08:24:28 --> Output Class Initialized
DEBUG - 2015-02-06 08:24:28 --> Security Class Initialized
DEBUG - 2015-02-06 08:24:28 --> Input Class Initialized
DEBUG - 2015-02-06 08:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 08:24:28 --> Language Class Initialized
DEBUG - 2015-02-06 08:24:28 --> Loader Class Initialized
DEBUG - 2015-02-06 08:24:28 --> Database Driver Class Initialized
ERROR - 2015-02-06 08:24:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 08:24:28 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 08:24:28 --> Controller Class Initialized
DEBUG - 2015-02-06 08:24:28 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 08:24:28 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 08:24:28 --> Model Class Initialized
DEBUG - 2015-02-06 08:24:28 --> Model Class Initialized
DEBUG - 2015-02-06 10:32:32 --> Config Class Initialized
DEBUG - 2015-02-06 10:32:32 --> Hooks Class Initialized
DEBUG - 2015-02-06 10:32:32 --> Utf8 Class Initialized
DEBUG - 2015-02-06 10:32:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 10:32:32 --> URI Class Initialized
DEBUG - 2015-02-06 10:32:32 --> Router Class Initialized
DEBUG - 2015-02-06 10:32:32 --> Output Class Initialized
DEBUG - 2015-02-06 10:32:32 --> Security Class Initialized
DEBUG - 2015-02-06 10:32:32 --> Input Class Initialized
DEBUG - 2015-02-06 10:32:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 10:32:32 --> Language Class Initialized
DEBUG - 2015-02-06 10:32:32 --> Loader Class Initialized
DEBUG - 2015-02-06 10:32:32 --> Database Driver Class Initialized
ERROR - 2015-02-06 10:32:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 10:32:32 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 10:32:32 --> Controller Class Initialized
DEBUG - 2015-02-06 10:32:32 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 10:32:32 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 10:32:32 --> Model Class Initialized
DEBUG - 2015-02-06 10:32:32 --> Model Class Initialized
DEBUG - 2015-02-06 10:39:19 --> Config Class Initialized
DEBUG - 2015-02-06 10:39:19 --> Hooks Class Initialized
DEBUG - 2015-02-06 10:39:19 --> Utf8 Class Initialized
DEBUG - 2015-02-06 10:39:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 10:39:19 --> URI Class Initialized
DEBUG - 2015-02-06 10:39:19 --> Router Class Initialized
DEBUG - 2015-02-06 10:39:19 --> Output Class Initialized
DEBUG - 2015-02-06 10:39:19 --> Security Class Initialized
DEBUG - 2015-02-06 10:39:19 --> Input Class Initialized
DEBUG - 2015-02-06 10:39:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 10:39:19 --> Language Class Initialized
DEBUG - 2015-02-06 10:39:19 --> Loader Class Initialized
DEBUG - 2015-02-06 10:39:19 --> Database Driver Class Initialized
ERROR - 2015-02-06 10:39:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 10:39:19 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 10:39:19 --> Controller Class Initialized
DEBUG - 2015-02-06 10:39:19 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 10:39:19 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 10:39:19 --> Model Class Initialized
DEBUG - 2015-02-06 10:39:19 --> Model Class Initialized
DEBUG - 2015-02-06 10:39:21 --> Config Class Initialized
DEBUG - 2015-02-06 10:39:21 --> Hooks Class Initialized
DEBUG - 2015-02-06 10:39:21 --> Utf8 Class Initialized
DEBUG - 2015-02-06 10:39:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 10:39:21 --> URI Class Initialized
DEBUG - 2015-02-06 10:39:21 --> Router Class Initialized
ERROR - 2015-02-06 10:39:21 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-06 10:39:25 --> Config Class Initialized
DEBUG - 2015-02-06 10:39:25 --> Hooks Class Initialized
DEBUG - 2015-02-06 10:39:25 --> Utf8 Class Initialized
DEBUG - 2015-02-06 10:39:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 10:39:25 --> URI Class Initialized
DEBUG - 2015-02-06 10:39:25 --> Router Class Initialized
ERROR - 2015-02-06 10:39:25 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-06 10:39:48 --> Config Class Initialized
DEBUG - 2015-02-06 10:39:48 --> Hooks Class Initialized
DEBUG - 2015-02-06 10:39:48 --> Utf8 Class Initialized
DEBUG - 2015-02-06 10:39:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 10:39:48 --> URI Class Initialized
DEBUG - 2015-02-06 10:39:48 --> Router Class Initialized
DEBUG - 2015-02-06 10:39:48 --> Output Class Initialized
DEBUG - 2015-02-06 10:39:48 --> Security Class Initialized
DEBUG - 2015-02-06 10:39:48 --> Input Class Initialized
DEBUG - 2015-02-06 10:39:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 10:39:48 --> Language Class Initialized
DEBUG - 2015-02-06 10:39:48 --> Loader Class Initialized
DEBUG - 2015-02-06 10:39:48 --> Database Driver Class Initialized
ERROR - 2015-02-06 10:39:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 10:39:48 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 10:39:48 --> Controller Class Initialized
DEBUG - 2015-02-06 10:39:48 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 10:39:48 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 10:39:48 --> Model Class Initialized
DEBUG - 2015-02-06 10:39:48 --> Model Class Initialized
ERROR - 2015-02-06 10:39:48 --> Severity: Notice  --> Undefined index: badge_id /Volumes/Data/www/thunderbirds-hub-site/server/application/models/badges_model.php 7
ERROR - 2015-02-06 10:39:48 --> Severity: Notice  --> Undefined index: missing /Volumes/Data/www/thunderbirds-hub-site/server/application/controllers/api/badges.php 157
ERROR - 2015-02-06 10:39:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds-hub-site/server/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds-hub-site/server/application/libraries/REST_Controller.php 485
ERROR - 2015-02-06 10:39:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds-hub-site/server/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds-hub-site/server/system/core/Common.php 442
ERROR - 2015-02-06 10:39:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds-hub-site/server/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds-hub-site/server/application/libraries/REST_Controller.php 503
DEBUG - 2015-02-06 10:39:51 --> Config Class Initialized
DEBUG - 2015-02-06 10:39:51 --> Hooks Class Initialized
DEBUG - 2015-02-06 10:39:51 --> Utf8 Class Initialized
DEBUG - 2015-02-06 10:39:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 10:39:51 --> URI Class Initialized
DEBUG - 2015-02-06 10:39:51 --> Router Class Initialized
DEBUG - 2015-02-06 10:39:51 --> Output Class Initialized
DEBUG - 2015-02-06 10:39:51 --> Security Class Initialized
DEBUG - 2015-02-06 10:39:51 --> Input Class Initialized
DEBUG - 2015-02-06 10:39:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 10:39:51 --> Language Class Initialized
DEBUG - 2015-02-06 10:39:51 --> Loader Class Initialized
DEBUG - 2015-02-06 10:39:51 --> Database Driver Class Initialized
ERROR - 2015-02-06 10:39:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 10:39:51 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 10:39:51 --> Controller Class Initialized
DEBUG - 2015-02-06 10:39:51 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 10:39:51 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 10:39:51 --> Model Class Initialized
DEBUG - 2015-02-06 10:39:51 --> Model Class Initialized
DEBUG - 2015-02-06 10:39:53 --> Config Class Initialized
DEBUG - 2015-02-06 10:39:53 --> Hooks Class Initialized
DEBUG - 2015-02-06 10:39:53 --> Utf8 Class Initialized
DEBUG - 2015-02-06 10:39:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 10:39:53 --> URI Class Initialized
DEBUG - 2015-02-06 10:39:53 --> Router Class Initialized
DEBUG - 2015-02-06 10:39:53 --> Output Class Initialized
DEBUG - 2015-02-06 10:39:53 --> Security Class Initialized
DEBUG - 2015-02-06 10:39:53 --> Input Class Initialized
DEBUG - 2015-02-06 10:39:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 10:39:53 --> Language Class Initialized
DEBUG - 2015-02-06 10:39:53 --> Loader Class Initialized
DEBUG - 2015-02-06 10:39:53 --> Database Driver Class Initialized
ERROR - 2015-02-06 10:39:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 10:39:53 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 10:39:53 --> Controller Class Initialized
DEBUG - 2015-02-06 10:39:53 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 10:39:53 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 10:39:53 --> Model Class Initialized
DEBUG - 2015-02-06 10:39:53 --> Model Class Initialized
DEBUG - 2015-02-06 10:39:55 --> Config Class Initialized
DEBUG - 2015-02-06 10:39:55 --> Hooks Class Initialized
DEBUG - 2015-02-06 10:39:55 --> Utf8 Class Initialized
DEBUG - 2015-02-06 10:39:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 10:39:55 --> URI Class Initialized
DEBUG - 2015-02-06 10:39:55 --> Router Class Initialized
DEBUG - 2015-02-06 10:39:55 --> Output Class Initialized
DEBUG - 2015-02-06 10:39:55 --> Security Class Initialized
DEBUG - 2015-02-06 10:39:55 --> Input Class Initialized
DEBUG - 2015-02-06 10:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 10:39:55 --> Language Class Initialized
DEBUG - 2015-02-06 10:39:55 --> Loader Class Initialized
DEBUG - 2015-02-06 10:39:55 --> Database Driver Class Initialized
ERROR - 2015-02-06 10:39:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 10:39:55 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 10:39:55 --> Controller Class Initialized
DEBUG - 2015-02-06 10:39:55 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 10:39:55 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 10:39:55 --> Model Class Initialized
DEBUG - 2015-02-06 10:39:55 --> Model Class Initialized
DEBUG - 2015-02-06 10:39:58 --> Config Class Initialized
DEBUG - 2015-02-06 10:39:58 --> Hooks Class Initialized
DEBUG - 2015-02-06 10:39:58 --> Utf8 Class Initialized
DEBUG - 2015-02-06 10:39:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 10:39:58 --> URI Class Initialized
DEBUG - 2015-02-06 10:39:58 --> Router Class Initialized
DEBUG - 2015-02-06 10:39:58 --> Output Class Initialized
DEBUG - 2015-02-06 10:39:58 --> Security Class Initialized
DEBUG - 2015-02-06 10:39:58 --> Input Class Initialized
DEBUG - 2015-02-06 10:39:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 10:39:58 --> Language Class Initialized
DEBUG - 2015-02-06 10:39:58 --> Loader Class Initialized
DEBUG - 2015-02-06 10:39:58 --> Database Driver Class Initialized
ERROR - 2015-02-06 10:39:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 10:39:58 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 10:39:58 --> Controller Class Initialized
DEBUG - 2015-02-06 10:39:58 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 10:39:58 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 10:39:58 --> Model Class Initialized
DEBUG - 2015-02-06 10:39:58 --> Model Class Initialized
DEBUG - 2015-02-06 11:15:20 --> Config Class Initialized
DEBUG - 2015-02-06 11:15:20 --> Hooks Class Initialized
DEBUG - 2015-02-06 11:15:20 --> Utf8 Class Initialized
DEBUG - 2015-02-06 11:15:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 11:15:20 --> URI Class Initialized
DEBUG - 2015-02-06 11:15:20 --> Router Class Initialized
DEBUG - 2015-02-06 11:15:20 --> Output Class Initialized
DEBUG - 2015-02-06 11:15:20 --> Security Class Initialized
DEBUG - 2015-02-06 11:15:20 --> Input Class Initialized
DEBUG - 2015-02-06 11:15:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 11:15:20 --> Language Class Initialized
DEBUG - 2015-02-06 11:15:20 --> Loader Class Initialized
DEBUG - 2015-02-06 11:15:20 --> Database Driver Class Initialized
ERROR - 2015-02-06 11:15:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 11:15:20 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 11:15:20 --> Controller Class Initialized
DEBUG - 2015-02-06 11:15:20 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 11:15:20 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 11:15:20 --> Model Class Initialized
DEBUG - 2015-02-06 11:15:20 --> Model Class Initialized
DEBUG - 2015-02-06 11:37:04 --> Config Class Initialized
DEBUG - 2015-02-06 11:37:04 --> Hooks Class Initialized
DEBUG - 2015-02-06 11:37:04 --> Utf8 Class Initialized
DEBUG - 2015-02-06 11:37:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 11:37:04 --> URI Class Initialized
DEBUG - 2015-02-06 11:37:04 --> Router Class Initialized
DEBUG - 2015-02-06 11:37:04 --> Output Class Initialized
DEBUG - 2015-02-06 11:37:05 --> Security Class Initialized
DEBUG - 2015-02-06 11:37:05 --> Input Class Initialized
DEBUG - 2015-02-06 11:37:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 11:37:05 --> Language Class Initialized
DEBUG - 2015-02-06 11:37:05 --> Loader Class Initialized
DEBUG - 2015-02-06 11:37:05 --> Database Driver Class Initialized
ERROR - 2015-02-06 11:37:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 11:37:05 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 11:37:05 --> Controller Class Initialized
DEBUG - 2015-02-06 11:37:05 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 11:37:05 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 11:37:05 --> Model Class Initialized
DEBUG - 2015-02-06 11:37:05 --> Model Class Initialized
DEBUG - 2015-02-06 11:38:18 --> Config Class Initialized
DEBUG - 2015-02-06 11:38:18 --> Hooks Class Initialized
DEBUG - 2015-02-06 11:38:18 --> Utf8 Class Initialized
DEBUG - 2015-02-06 11:38:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 11:38:18 --> URI Class Initialized
DEBUG - 2015-02-06 11:38:18 --> Router Class Initialized
DEBUG - 2015-02-06 11:38:18 --> Output Class Initialized
DEBUG - 2015-02-06 11:38:18 --> Security Class Initialized
DEBUG - 2015-02-06 11:38:18 --> Input Class Initialized
DEBUG - 2015-02-06 11:38:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 11:38:18 --> Language Class Initialized
DEBUG - 2015-02-06 11:38:18 --> Loader Class Initialized
DEBUG - 2015-02-06 11:38:18 --> Database Driver Class Initialized
ERROR - 2015-02-06 11:38:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 11:38:18 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 11:38:18 --> Controller Class Initialized
DEBUG - 2015-02-06 11:38:18 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 11:38:18 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 11:38:18 --> Model Class Initialized
DEBUG - 2015-02-06 11:38:18 --> Model Class Initialized
DEBUG - 2015-02-06 11:39:58 --> Config Class Initialized
DEBUG - 2015-02-06 11:39:58 --> Hooks Class Initialized
DEBUG - 2015-02-06 11:39:58 --> Utf8 Class Initialized
DEBUG - 2015-02-06 11:39:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 11:39:58 --> URI Class Initialized
DEBUG - 2015-02-06 11:39:58 --> Router Class Initialized
DEBUG - 2015-02-06 11:39:58 --> Output Class Initialized
DEBUG - 2015-02-06 11:39:58 --> Security Class Initialized
DEBUG - 2015-02-06 11:39:58 --> Input Class Initialized
DEBUG - 2015-02-06 11:39:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 11:39:58 --> Language Class Initialized
DEBUG - 2015-02-06 11:39:58 --> Loader Class Initialized
DEBUG - 2015-02-06 11:39:58 --> Database Driver Class Initialized
ERROR - 2015-02-06 11:39:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 11:39:58 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 11:39:58 --> Controller Class Initialized
DEBUG - 2015-02-06 11:39:58 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 11:39:58 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 11:39:58 --> Model Class Initialized
DEBUG - 2015-02-06 11:39:58 --> Model Class Initialized
DEBUG - 2015-02-06 11:41:28 --> Config Class Initialized
DEBUG - 2015-02-06 11:41:28 --> Hooks Class Initialized
DEBUG - 2015-02-06 11:41:28 --> Utf8 Class Initialized
DEBUG - 2015-02-06 11:41:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 11:41:28 --> URI Class Initialized
DEBUG - 2015-02-06 11:41:28 --> Router Class Initialized
DEBUG - 2015-02-06 11:41:28 --> Output Class Initialized
DEBUG - 2015-02-06 11:41:28 --> Security Class Initialized
DEBUG - 2015-02-06 11:41:28 --> Input Class Initialized
DEBUG - 2015-02-06 11:41:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 11:41:28 --> Language Class Initialized
DEBUG - 2015-02-06 11:41:28 --> Loader Class Initialized
DEBUG - 2015-02-06 11:41:28 --> Database Driver Class Initialized
ERROR - 2015-02-06 11:41:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 11:41:28 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 11:41:28 --> Controller Class Initialized
DEBUG - 2015-02-06 11:41:28 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 11:41:28 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 11:41:28 --> Model Class Initialized
DEBUG - 2015-02-06 11:41:28 --> Model Class Initialized
DEBUG - 2015-02-06 11:41:40 --> Config Class Initialized
DEBUG - 2015-02-06 11:41:40 --> Hooks Class Initialized
DEBUG - 2015-02-06 11:41:40 --> Utf8 Class Initialized
DEBUG - 2015-02-06 11:41:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 11:41:40 --> URI Class Initialized
DEBUG - 2015-02-06 11:41:40 --> Router Class Initialized
DEBUG - 2015-02-06 11:41:40 --> Output Class Initialized
DEBUG - 2015-02-06 11:41:40 --> Security Class Initialized
DEBUG - 2015-02-06 11:41:40 --> Input Class Initialized
DEBUG - 2015-02-06 11:41:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 11:41:40 --> Language Class Initialized
DEBUG - 2015-02-06 11:41:40 --> Loader Class Initialized
DEBUG - 2015-02-06 11:41:41 --> Database Driver Class Initialized
ERROR - 2015-02-06 11:41:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 11:41:41 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 11:41:41 --> Controller Class Initialized
DEBUG - 2015-02-06 11:41:41 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 11:41:41 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 11:41:41 --> Model Class Initialized
DEBUG - 2015-02-06 11:41:41 --> Model Class Initialized
DEBUG - 2015-02-06 11:42:05 --> Config Class Initialized
DEBUG - 2015-02-06 11:42:05 --> Hooks Class Initialized
DEBUG - 2015-02-06 11:42:05 --> Utf8 Class Initialized
DEBUG - 2015-02-06 11:42:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 11:42:05 --> URI Class Initialized
DEBUG - 2015-02-06 11:42:05 --> Router Class Initialized
DEBUG - 2015-02-06 11:42:05 --> Output Class Initialized
DEBUG - 2015-02-06 11:42:05 --> Security Class Initialized
DEBUG - 2015-02-06 11:42:05 --> Input Class Initialized
DEBUG - 2015-02-06 11:42:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 11:42:05 --> Language Class Initialized
DEBUG - 2015-02-06 11:42:05 --> Loader Class Initialized
DEBUG - 2015-02-06 11:42:05 --> Database Driver Class Initialized
ERROR - 2015-02-06 11:42:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 11:42:05 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 11:42:05 --> Controller Class Initialized
DEBUG - 2015-02-06 11:42:05 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 11:42:06 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 11:42:06 --> Model Class Initialized
DEBUG - 2015-02-06 11:42:06 --> Model Class Initialized
DEBUG - 2015-02-06 11:42:50 --> Config Class Initialized
DEBUG - 2015-02-06 11:42:50 --> Hooks Class Initialized
DEBUG - 2015-02-06 11:42:50 --> Utf8 Class Initialized
DEBUG - 2015-02-06 11:42:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 11:42:50 --> URI Class Initialized
DEBUG - 2015-02-06 11:42:50 --> Router Class Initialized
DEBUG - 2015-02-06 11:42:50 --> Output Class Initialized
DEBUG - 2015-02-06 11:42:50 --> Security Class Initialized
DEBUG - 2015-02-06 11:42:50 --> Input Class Initialized
DEBUG - 2015-02-06 11:42:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 11:42:50 --> Language Class Initialized
DEBUG - 2015-02-06 11:42:50 --> Loader Class Initialized
DEBUG - 2015-02-06 11:42:50 --> Database Driver Class Initialized
ERROR - 2015-02-06 11:42:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 11:42:50 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 11:42:50 --> Controller Class Initialized
DEBUG - 2015-02-06 11:42:50 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 11:42:50 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 11:42:50 --> Model Class Initialized
DEBUG - 2015-02-06 11:42:50 --> Model Class Initialized
DEBUG - 2015-02-06 11:42:53 --> Config Class Initialized
DEBUG - 2015-02-06 11:42:53 --> Hooks Class Initialized
DEBUG - 2015-02-06 11:42:53 --> Utf8 Class Initialized
DEBUG - 2015-02-06 11:42:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 11:42:53 --> URI Class Initialized
DEBUG - 2015-02-06 11:42:53 --> Router Class Initialized
DEBUG - 2015-02-06 11:42:53 --> Output Class Initialized
DEBUG - 2015-02-06 11:42:53 --> Security Class Initialized
DEBUG - 2015-02-06 11:42:53 --> Input Class Initialized
DEBUG - 2015-02-06 11:42:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 11:42:53 --> Language Class Initialized
DEBUG - 2015-02-06 11:42:53 --> Loader Class Initialized
DEBUG - 2015-02-06 11:42:53 --> Database Driver Class Initialized
ERROR - 2015-02-06 11:42:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 11:42:53 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 11:42:53 --> Controller Class Initialized
DEBUG - 2015-02-06 11:42:53 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 11:42:53 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 11:42:53 --> Model Class Initialized
DEBUG - 2015-02-06 11:42:53 --> Model Class Initialized
DEBUG - 2015-02-06 11:42:58 --> Config Class Initialized
DEBUG - 2015-02-06 11:42:58 --> Hooks Class Initialized
DEBUG - 2015-02-06 11:42:58 --> Utf8 Class Initialized
DEBUG - 2015-02-06 11:42:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 11:42:58 --> URI Class Initialized
DEBUG - 2015-02-06 11:42:58 --> Router Class Initialized
DEBUG - 2015-02-06 11:42:58 --> Output Class Initialized
DEBUG - 2015-02-06 11:42:58 --> Security Class Initialized
DEBUG - 2015-02-06 11:42:58 --> Input Class Initialized
DEBUG - 2015-02-06 11:42:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 11:42:58 --> Language Class Initialized
DEBUG - 2015-02-06 11:42:58 --> Loader Class Initialized
DEBUG - 2015-02-06 11:42:58 --> Database Driver Class Initialized
ERROR - 2015-02-06 11:42:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 11:42:58 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 11:42:58 --> Controller Class Initialized
DEBUG - 2015-02-06 11:42:58 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 11:42:58 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 11:42:58 --> Model Class Initialized
DEBUG - 2015-02-06 11:42:58 --> Model Class Initialized
DEBUG - 2015-02-06 11:44:46 --> Config Class Initialized
DEBUG - 2015-02-06 11:44:46 --> Hooks Class Initialized
DEBUG - 2015-02-06 11:44:46 --> Utf8 Class Initialized
DEBUG - 2015-02-06 11:44:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 11:44:46 --> URI Class Initialized
DEBUG - 2015-02-06 11:44:46 --> Router Class Initialized
DEBUG - 2015-02-06 11:44:46 --> Output Class Initialized
DEBUG - 2015-02-06 11:44:46 --> Security Class Initialized
DEBUG - 2015-02-06 11:44:46 --> Input Class Initialized
DEBUG - 2015-02-06 11:44:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 11:44:46 --> Language Class Initialized
DEBUG - 2015-02-06 11:44:46 --> Loader Class Initialized
DEBUG - 2015-02-06 11:44:46 --> Database Driver Class Initialized
ERROR - 2015-02-06 11:44:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 11:44:46 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 11:44:46 --> Controller Class Initialized
DEBUG - 2015-02-06 11:44:46 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 11:44:46 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 11:44:46 --> Model Class Initialized
DEBUG - 2015-02-06 11:44:46 --> Model Class Initialized
ERROR - 2015-02-06 11:44:46 --> Severity: Warning  --> date() expects at least 1 parameter, 0 given /Volumes/Data/www/thunderbirds-hub-site/server/application/models/adminusers_model.php 170
ERROR - 2015-02-06 11:44:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds-hub-site/server/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds-hub-site/server/application/libraries/REST_Controller.php 485
ERROR - 2015-02-06 11:44:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds-hub-site/server/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds-hub-site/server/system/core/Common.php 442
ERROR - 2015-02-06 11:44:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds-hub-site/server/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds-hub-site/server/application/libraries/REST_Controller.php 503
DEBUG - 2015-02-06 11:46:04 --> Config Class Initialized
DEBUG - 2015-02-06 11:46:04 --> Hooks Class Initialized
DEBUG - 2015-02-06 11:46:04 --> Utf8 Class Initialized
DEBUG - 2015-02-06 11:46:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 11:46:04 --> URI Class Initialized
DEBUG - 2015-02-06 11:46:04 --> Router Class Initialized
DEBUG - 2015-02-06 11:46:04 --> Output Class Initialized
DEBUG - 2015-02-06 11:46:04 --> Security Class Initialized
DEBUG - 2015-02-06 11:46:04 --> Input Class Initialized
DEBUG - 2015-02-06 11:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 11:46:04 --> Language Class Initialized
DEBUG - 2015-02-06 11:46:04 --> Loader Class Initialized
DEBUG - 2015-02-06 11:46:04 --> Database Driver Class Initialized
ERROR - 2015-02-06 11:46:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 11:46:04 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 11:46:04 --> Controller Class Initialized
DEBUG - 2015-02-06 11:46:04 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 11:46:04 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 11:46:04 --> Model Class Initialized
DEBUG - 2015-02-06 11:46:04 --> Model Class Initialized
DEBUG - 2015-02-06 12:05:40 --> Config Class Initialized
DEBUG - 2015-02-06 12:05:40 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:05:40 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:05:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:05:40 --> URI Class Initialized
DEBUG - 2015-02-06 12:05:40 --> Router Class Initialized
DEBUG - 2015-02-06 12:05:40 --> Output Class Initialized
DEBUG - 2015-02-06 12:05:40 --> Security Class Initialized
DEBUG - 2015-02-06 12:05:40 --> Input Class Initialized
DEBUG - 2015-02-06 12:05:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 12:05:40 --> Language Class Initialized
DEBUG - 2015-02-06 12:05:40 --> Loader Class Initialized
DEBUG - 2015-02-06 12:05:40 --> Database Driver Class Initialized
ERROR - 2015-02-06 12:05:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 12:05:40 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 12:05:40 --> Controller Class Initialized
DEBUG - 2015-02-06 12:05:40 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 12:05:40 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 12:05:40 --> Model Class Initialized
DEBUG - 2015-02-06 12:05:40 --> Model Class Initialized
DEBUG - 2015-02-06 13:18:08 --> Config Class Initialized
DEBUG - 2015-02-06 13:18:08 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:18:08 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:18:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:18:08 --> URI Class Initialized
DEBUG - 2015-02-06 13:18:08 --> Router Class Initialized
DEBUG - 2015-02-06 13:18:08 --> Output Class Initialized
DEBUG - 2015-02-06 13:18:08 --> Security Class Initialized
DEBUG - 2015-02-06 13:18:08 --> Input Class Initialized
DEBUG - 2015-02-06 13:18:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 13:18:08 --> Language Class Initialized
DEBUG - 2015-02-06 13:18:08 --> Loader Class Initialized
DEBUG - 2015-02-06 13:18:08 --> Database Driver Class Initialized
ERROR - 2015-02-06 13:18:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 13:18:08 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 13:18:08 --> Controller Class Initialized
DEBUG - 2015-02-06 13:18:08 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 13:18:08 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 13:18:08 --> Model Class Initialized
DEBUG - 2015-02-06 13:18:56 --> Config Class Initialized
DEBUG - 2015-02-06 13:18:56 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:18:56 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:18:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:18:56 --> URI Class Initialized
DEBUG - 2015-02-06 13:18:56 --> Router Class Initialized
DEBUG - 2015-02-06 13:18:56 --> Output Class Initialized
DEBUG - 2015-02-06 13:18:56 --> Security Class Initialized
DEBUG - 2015-02-06 13:18:56 --> Input Class Initialized
DEBUG - 2015-02-06 13:18:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 13:18:56 --> Language Class Initialized
DEBUG - 2015-02-06 13:18:56 --> Loader Class Initialized
DEBUG - 2015-02-06 13:18:56 --> Database Driver Class Initialized
ERROR - 2015-02-06 13:18:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 13:18:56 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 13:18:56 --> Controller Class Initialized
DEBUG - 2015-02-06 13:18:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 13:18:56 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 13:18:56 --> Model Class Initialized
DEBUG - 2015-02-06 13:19:25 --> Config Class Initialized
DEBUG - 2015-02-06 13:19:25 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:19:25 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:19:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:19:25 --> URI Class Initialized
DEBUG - 2015-02-06 13:19:25 --> Router Class Initialized
DEBUG - 2015-02-06 13:19:25 --> Output Class Initialized
DEBUG - 2015-02-06 13:19:25 --> Security Class Initialized
DEBUG - 2015-02-06 13:19:25 --> Input Class Initialized
DEBUG - 2015-02-06 13:19:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 13:19:25 --> Language Class Initialized
DEBUG - 2015-02-06 13:19:25 --> Loader Class Initialized
DEBUG - 2015-02-06 13:19:25 --> Database Driver Class Initialized
ERROR - 2015-02-06 13:19:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 13:19:25 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 13:19:25 --> Controller Class Initialized
DEBUG - 2015-02-06 13:19:25 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 13:19:25 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 13:19:25 --> Model Class Initialized
DEBUG - 2015-02-06 13:19:46 --> Config Class Initialized
DEBUG - 2015-02-06 13:19:46 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:19:46 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:19:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:19:46 --> URI Class Initialized
DEBUG - 2015-02-06 13:19:46 --> Router Class Initialized
DEBUG - 2015-02-06 13:19:47 --> Output Class Initialized
DEBUG - 2015-02-06 13:19:47 --> Security Class Initialized
DEBUG - 2015-02-06 13:19:47 --> Input Class Initialized
DEBUG - 2015-02-06 13:19:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 13:19:47 --> Language Class Initialized
DEBUG - 2015-02-06 13:19:47 --> Loader Class Initialized
DEBUG - 2015-02-06 13:19:47 --> Database Driver Class Initialized
ERROR - 2015-02-06 13:19:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 13:19:47 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 13:19:47 --> Controller Class Initialized
DEBUG - 2015-02-06 13:19:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 13:19:47 --> Helper loaded: inflector_helper
ERROR - 2015-02-06 13:19:47 --> Severity: Notice  --> Undefined property: Users::$sugar_rest /Volumes/Data/www/thunderbirds-hub-site/server/application/controllers/api/users.php 35
DEBUG - 2015-02-06 13:20:09 --> Config Class Initialized
DEBUG - 2015-02-06 13:20:09 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:20:09 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:20:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:20:09 --> URI Class Initialized
DEBUG - 2015-02-06 13:20:09 --> Router Class Initialized
DEBUG - 2015-02-06 13:20:09 --> Output Class Initialized
DEBUG - 2015-02-06 13:20:09 --> Security Class Initialized
DEBUG - 2015-02-06 13:20:09 --> Input Class Initialized
DEBUG - 2015-02-06 13:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 13:20:09 --> Language Class Initialized
DEBUG - 2015-02-06 13:20:09 --> Loader Class Initialized
DEBUG - 2015-02-06 13:20:09 --> Database Driver Class Initialized
ERROR - 2015-02-06 13:20:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 13:20:09 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 13:20:09 --> Controller Class Initialized
DEBUG - 2015-02-06 13:20:09 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 13:20:09 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 13:21:36 --> Config Class Initialized
DEBUG - 2015-02-06 13:21:36 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:21:36 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:21:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:21:36 --> URI Class Initialized
DEBUG - 2015-02-06 13:21:36 --> Router Class Initialized
DEBUG - 2015-02-06 13:21:36 --> Output Class Initialized
DEBUG - 2015-02-06 13:21:36 --> Security Class Initialized
DEBUG - 2015-02-06 13:21:36 --> Input Class Initialized
DEBUG - 2015-02-06 13:21:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 13:21:36 --> Language Class Initialized
DEBUG - 2015-02-06 13:21:36 --> Loader Class Initialized
DEBUG - 2015-02-06 13:21:37 --> Database Driver Class Initialized
ERROR - 2015-02-06 13:21:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 13:21:37 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 13:21:37 --> Controller Class Initialized
DEBUG - 2015-02-06 13:21:37 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 13:21:37 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 13:21:50 --> Config Class Initialized
DEBUG - 2015-02-06 13:21:50 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:21:50 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:21:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:21:50 --> URI Class Initialized
DEBUG - 2015-02-06 13:21:50 --> Router Class Initialized
DEBUG - 2015-02-06 13:21:50 --> Output Class Initialized
DEBUG - 2015-02-06 13:21:50 --> Security Class Initialized
DEBUG - 2015-02-06 13:21:50 --> Input Class Initialized
DEBUG - 2015-02-06 13:21:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 13:21:50 --> Language Class Initialized
DEBUG - 2015-02-06 13:21:50 --> Loader Class Initialized
DEBUG - 2015-02-06 13:21:50 --> Database Driver Class Initialized
ERROR - 2015-02-06 13:21:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 13:21:50 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 13:21:50 --> Controller Class Initialized
DEBUG - 2015-02-06 13:21:50 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 13:21:50 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 13:22:40 --> Model Class Initialized
DEBUG - 2015-02-06 13:24:08 --> Model Class Initialized
DEBUG - 2015-02-06 13:24:21 --> Model Class Initialized
DEBUG - 2015-02-06 13:27:30 --> Config Class Initialized
DEBUG - 2015-02-06 13:27:30 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:27:30 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:27:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:27:30 --> URI Class Initialized
DEBUG - 2015-02-06 13:27:30 --> Router Class Initialized
DEBUG - 2015-02-06 13:27:30 --> Output Class Initialized
DEBUG - 2015-02-06 13:27:30 --> Security Class Initialized
DEBUG - 2015-02-06 13:27:30 --> Input Class Initialized
DEBUG - 2015-02-06 13:27:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 13:27:30 --> Language Class Initialized
DEBUG - 2015-02-06 13:27:30 --> Loader Class Initialized
DEBUG - 2015-02-06 13:27:30 --> Database Driver Class Initialized
ERROR - 2015-02-06 13:27:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 13:27:30 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 13:27:30 --> Controller Class Initialized
DEBUG - 2015-02-06 13:27:30 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 13:27:30 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 13:28:25 --> Config Class Initialized
DEBUG - 2015-02-06 13:28:25 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:28:25 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:28:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:28:25 --> URI Class Initialized
DEBUG - 2015-02-06 13:28:25 --> Router Class Initialized
DEBUG - 2015-02-06 13:28:25 --> Output Class Initialized
DEBUG - 2015-02-06 13:28:25 --> Security Class Initialized
DEBUG - 2015-02-06 13:28:25 --> Input Class Initialized
DEBUG - 2015-02-06 13:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 13:28:25 --> Language Class Initialized
DEBUG - 2015-02-06 13:28:25 --> Loader Class Initialized
DEBUG - 2015-02-06 13:28:25 --> Database Driver Class Initialized
ERROR - 2015-02-06 13:28:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 13:28:25 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 13:28:25 --> Controller Class Initialized
DEBUG - 2015-02-06 13:28:25 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 13:28:25 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 13:28:34 --> Config Class Initialized
DEBUG - 2015-02-06 13:28:34 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:28:34 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:28:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:28:34 --> URI Class Initialized
DEBUG - 2015-02-06 13:28:34 --> Router Class Initialized
DEBUG - 2015-02-06 13:28:34 --> Output Class Initialized
DEBUG - 2015-02-06 13:28:34 --> Security Class Initialized
DEBUG - 2015-02-06 13:28:34 --> Input Class Initialized
DEBUG - 2015-02-06 13:28:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 13:28:34 --> Language Class Initialized
DEBUG - 2015-02-06 13:28:34 --> Loader Class Initialized
DEBUG - 2015-02-06 13:28:34 --> Database Driver Class Initialized
ERROR - 2015-02-06 13:28:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 13:28:34 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 13:28:34 --> Controller Class Initialized
DEBUG - 2015-02-06 13:28:34 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 13:28:34 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 13:28:46 --> Model Class Initialized
DEBUG - 2015-02-06 13:29:42 --> Model Class Initialized
DEBUG - 2015-02-06 13:29:50 --> Model Class Initialized
DEBUG - 2015-02-06 13:37:53 --> Config Class Initialized
DEBUG - 2015-02-06 13:37:53 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:37:53 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:37:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:37:53 --> URI Class Initialized
DEBUG - 2015-02-06 13:37:53 --> Router Class Initialized
DEBUG - 2015-02-06 13:37:54 --> Output Class Initialized
DEBUG - 2015-02-06 13:37:54 --> Security Class Initialized
DEBUG - 2015-02-06 13:37:54 --> Input Class Initialized
DEBUG - 2015-02-06 13:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 13:37:54 --> Language Class Initialized
DEBUG - 2015-02-06 13:37:54 --> Loader Class Initialized
DEBUG - 2015-02-06 13:37:54 --> Database Driver Class Initialized
ERROR - 2015-02-06 13:37:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 13:37:54 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 13:37:54 --> Controller Class Initialized
DEBUG - 2015-02-06 13:37:54 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 13:37:54 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 13:37:54 --> Model Class Initialized
DEBUG - 2015-02-06 13:37:54 --> Model Class Initialized
DEBUG - 2015-02-06 13:38:10 --> Config Class Initialized
DEBUG - 2015-02-06 13:38:10 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:38:10 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:38:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:38:10 --> URI Class Initialized
DEBUG - 2015-02-06 13:38:10 --> Router Class Initialized
ERROR - 2015-02-06 13:38:10 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-06 13:53:05 --> Config Class Initialized
DEBUG - 2015-02-06 13:53:05 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:53:05 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:53:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:53:05 --> URI Class Initialized
DEBUG - 2015-02-06 13:53:05 --> Router Class Initialized
DEBUG - 2015-02-06 13:53:05 --> Output Class Initialized
DEBUG - 2015-02-06 13:53:05 --> Security Class Initialized
DEBUG - 2015-02-06 13:53:05 --> Input Class Initialized
DEBUG - 2015-02-06 13:53:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 13:53:05 --> Language Class Initialized
DEBUG - 2015-02-06 13:53:05 --> Loader Class Initialized
DEBUG - 2015-02-06 13:53:05 --> Database Driver Class Initialized
ERROR - 2015-02-06 13:53:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 13:53:05 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 13:53:05 --> Controller Class Initialized
DEBUG - 2015-02-06 13:53:06 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 13:53:06 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 13:54:24 --> Model Class Initialized
DEBUG - 2015-02-06 13:55:13 --> Config Class Initialized
DEBUG - 2015-02-06 13:55:13 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:55:13 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:55:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:55:13 --> URI Class Initialized
DEBUG - 2015-02-06 13:55:13 --> Router Class Initialized
DEBUG - 2015-02-06 13:55:13 --> Output Class Initialized
DEBUG - 2015-02-06 13:55:13 --> Security Class Initialized
DEBUG - 2015-02-06 13:55:13 --> Input Class Initialized
DEBUG - 2015-02-06 13:55:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 13:55:13 --> Language Class Initialized
DEBUG - 2015-02-06 13:55:13 --> Loader Class Initialized
DEBUG - 2015-02-06 13:55:13 --> Database Driver Class Initialized
ERROR - 2015-02-06 13:55:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 13:55:13 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 13:55:13 --> Controller Class Initialized
DEBUG - 2015-02-06 13:55:13 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 13:55:13 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 13:56:24 --> Config Class Initialized
DEBUG - 2015-02-06 13:56:24 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:56:24 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:56:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:56:24 --> URI Class Initialized
DEBUG - 2015-02-06 13:56:24 --> Router Class Initialized
DEBUG - 2015-02-06 13:56:24 --> Output Class Initialized
DEBUG - 2015-02-06 13:56:24 --> Security Class Initialized
DEBUG - 2015-02-06 13:56:24 --> Input Class Initialized
DEBUG - 2015-02-06 13:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 13:56:24 --> Language Class Initialized
DEBUG - 2015-02-06 13:56:24 --> Loader Class Initialized
DEBUG - 2015-02-06 13:56:24 --> Database Driver Class Initialized
ERROR - 2015-02-06 13:56:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 13:56:24 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 13:56:24 --> Controller Class Initialized
DEBUG - 2015-02-06 13:56:24 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 13:56:24 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 13:56:30 --> Model Class Initialized
DEBUG - 2015-02-06 13:57:14 --> Config Class Initialized
DEBUG - 2015-02-06 13:57:14 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:57:14 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:57:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:57:14 --> URI Class Initialized
DEBUG - 2015-02-06 13:57:14 --> Router Class Initialized
DEBUG - 2015-02-06 13:57:14 --> Output Class Initialized
DEBUG - 2015-02-06 13:57:14 --> Security Class Initialized
DEBUG - 2015-02-06 13:57:14 --> Input Class Initialized
DEBUG - 2015-02-06 13:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 13:57:14 --> Language Class Initialized
DEBUG - 2015-02-06 13:57:14 --> Loader Class Initialized
DEBUG - 2015-02-06 13:57:14 --> Database Driver Class Initialized
ERROR - 2015-02-06 13:57:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 13:57:14 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 13:57:14 --> Controller Class Initialized
DEBUG - 2015-02-06 13:57:14 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 13:57:14 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 13:57:19 --> Config Class Initialized
DEBUG - 2015-02-06 13:57:19 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:57:19 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:57:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:57:19 --> URI Class Initialized
DEBUG - 2015-02-06 13:57:19 --> Router Class Initialized
DEBUG - 2015-02-06 13:57:19 --> Output Class Initialized
DEBUG - 2015-02-06 13:57:19 --> Security Class Initialized
DEBUG - 2015-02-06 13:57:19 --> Input Class Initialized
DEBUG - 2015-02-06 13:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 13:57:19 --> Language Class Initialized
DEBUG - 2015-02-06 13:57:19 --> Loader Class Initialized
DEBUG - 2015-02-06 13:57:19 --> Database Driver Class Initialized
ERROR - 2015-02-06 13:57:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 13:57:19 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 13:57:19 --> Controller Class Initialized
DEBUG - 2015-02-06 13:57:19 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 13:57:19 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 13:57:40 --> Model Class Initialized
DEBUG - 2015-02-06 13:58:19 --> Config Class Initialized
DEBUG - 2015-02-06 13:58:19 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:58:19 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:58:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:58:19 --> URI Class Initialized
DEBUG - 2015-02-06 13:58:19 --> Router Class Initialized
DEBUG - 2015-02-06 13:58:19 --> Output Class Initialized
DEBUG - 2015-02-06 13:58:19 --> Security Class Initialized
DEBUG - 2015-02-06 13:58:19 --> Input Class Initialized
DEBUG - 2015-02-06 13:58:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 13:58:19 --> Language Class Initialized
DEBUG - 2015-02-06 13:58:19 --> Loader Class Initialized
DEBUG - 2015-02-06 13:58:19 --> Database Driver Class Initialized
ERROR - 2015-02-06 13:58:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 13:58:19 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 13:58:19 --> Controller Class Initialized
DEBUG - 2015-02-06 13:58:19 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 13:58:19 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 13:58:30 --> Model Class Initialized
DEBUG - 2015-02-06 13:58:36 --> Model Class Initialized
DEBUG - 2015-02-06 13:58:38 --> Config Class Initialized
DEBUG - 2015-02-06 13:58:38 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:58:38 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:58:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:58:38 --> URI Class Initialized
DEBUG - 2015-02-06 13:58:38 --> Router Class Initialized
DEBUG - 2015-02-06 13:58:38 --> Output Class Initialized
DEBUG - 2015-02-06 13:58:38 --> Security Class Initialized
DEBUG - 2015-02-06 13:58:38 --> Input Class Initialized
DEBUG - 2015-02-06 13:58:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 13:58:38 --> Language Class Initialized
DEBUG - 2015-02-06 13:58:38 --> Loader Class Initialized
DEBUG - 2015-02-06 13:58:38 --> Database Driver Class Initialized
ERROR - 2015-02-06 13:58:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 13:58:38 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 13:58:38 --> Controller Class Initialized
DEBUG - 2015-02-06 13:58:38 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 13:58:38 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 13:58:57 --> Config Class Initialized
DEBUG - 2015-02-06 13:58:57 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:58:57 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:58:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:58:57 --> URI Class Initialized
DEBUG - 2015-02-06 13:58:57 --> Router Class Initialized
DEBUG - 2015-02-06 13:58:57 --> Output Class Initialized
DEBUG - 2015-02-06 13:58:57 --> Security Class Initialized
DEBUG - 2015-02-06 13:58:57 --> Input Class Initialized
DEBUG - 2015-02-06 13:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 13:58:57 --> Language Class Initialized
DEBUG - 2015-02-06 13:58:57 --> Loader Class Initialized
DEBUG - 2015-02-06 13:58:57 --> Database Driver Class Initialized
ERROR - 2015-02-06 13:58:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 13:58:57 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 13:58:57 --> Controller Class Initialized
DEBUG - 2015-02-06 13:58:57 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 13:58:57 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 13:59:36 --> Model Class Initialized
DEBUG - 2015-02-06 13:59:54 --> Model Class Initialized
DEBUG - 2015-02-06 14:00:14 --> Model Class Initialized
DEBUG - 2015-02-06 14:00:16 --> Config Class Initialized
DEBUG - 2015-02-06 14:00:16 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:00:16 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:00:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:00:16 --> URI Class Initialized
DEBUG - 2015-02-06 14:00:16 --> Router Class Initialized
DEBUG - 2015-02-06 14:00:16 --> Output Class Initialized
DEBUG - 2015-02-06 14:00:16 --> Security Class Initialized
DEBUG - 2015-02-06 14:00:16 --> Input Class Initialized
DEBUG - 2015-02-06 14:00:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:00:16 --> Language Class Initialized
DEBUG - 2015-02-06 14:00:16 --> Loader Class Initialized
DEBUG - 2015-02-06 14:00:16 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:00:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:00:16 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:00:16 --> Controller Class Initialized
DEBUG - 2015-02-06 14:00:16 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:00:16 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:00:28 --> Config Class Initialized
DEBUG - 2015-02-06 14:00:28 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:00:28 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:00:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:00:28 --> URI Class Initialized
DEBUG - 2015-02-06 14:00:28 --> Router Class Initialized
DEBUG - 2015-02-06 14:00:28 --> Output Class Initialized
DEBUG - 2015-02-06 14:00:28 --> Security Class Initialized
DEBUG - 2015-02-06 14:00:28 --> Input Class Initialized
DEBUG - 2015-02-06 14:00:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:00:28 --> Language Class Initialized
DEBUG - 2015-02-06 14:00:28 --> Loader Class Initialized
DEBUG - 2015-02-06 14:00:28 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:00:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:00:28 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:00:28 --> Controller Class Initialized
DEBUG - 2015-02-06 14:00:28 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:00:28 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:00:28 --> Model Class Initialized
DEBUG - 2015-02-06 14:01:07 --> Config Class Initialized
DEBUG - 2015-02-06 14:01:07 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:01:07 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:01:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:01:07 --> URI Class Initialized
DEBUG - 2015-02-06 14:01:07 --> Router Class Initialized
DEBUG - 2015-02-06 14:01:07 --> Output Class Initialized
DEBUG - 2015-02-06 14:01:07 --> Security Class Initialized
DEBUG - 2015-02-06 14:01:07 --> Input Class Initialized
DEBUG - 2015-02-06 14:01:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:01:07 --> Language Class Initialized
DEBUG - 2015-02-06 14:01:07 --> Loader Class Initialized
DEBUG - 2015-02-06 14:01:07 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:01:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:01:07 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:01:07 --> Controller Class Initialized
DEBUG - 2015-02-06 14:01:07 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:01:07 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:01:07 --> Model Class Initialized
DEBUG - 2015-02-06 14:01:20 --> Config Class Initialized
DEBUG - 2015-02-06 14:01:20 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:01:20 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:01:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:01:20 --> URI Class Initialized
DEBUG - 2015-02-06 14:01:20 --> Router Class Initialized
DEBUG - 2015-02-06 14:01:20 --> Output Class Initialized
DEBUG - 2015-02-06 14:01:20 --> Security Class Initialized
DEBUG - 2015-02-06 14:01:20 --> Input Class Initialized
DEBUG - 2015-02-06 14:01:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:01:20 --> Language Class Initialized
DEBUG - 2015-02-06 14:01:20 --> Loader Class Initialized
DEBUG - 2015-02-06 14:01:20 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:01:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:01:20 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:01:20 --> Controller Class Initialized
DEBUG - 2015-02-06 14:01:20 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:01:20 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:01:20 --> Model Class Initialized
DEBUG - 2015-02-06 14:01:32 --> Model Class Initialized
DEBUG - 2015-02-06 14:01:32 --> Model Class Initialized
DEBUG - 2015-02-06 14:01:34 --> Config Class Initialized
DEBUG - 2015-02-06 14:01:34 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:01:34 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:01:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:01:34 --> URI Class Initialized
DEBUG - 2015-02-06 14:01:34 --> Router Class Initialized
DEBUG - 2015-02-06 14:01:34 --> Output Class Initialized
DEBUG - 2015-02-06 14:01:34 --> Security Class Initialized
DEBUG - 2015-02-06 14:01:34 --> Input Class Initialized
DEBUG - 2015-02-06 14:01:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:01:34 --> Language Class Initialized
DEBUG - 2015-02-06 14:01:34 --> Loader Class Initialized
DEBUG - 2015-02-06 14:01:34 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:01:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:01:34 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:01:34 --> Controller Class Initialized
DEBUG - 2015-02-06 14:01:34 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:01:34 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:01:34 --> Model Class Initialized
DEBUG - 2015-02-06 14:01:34 --> Model Class Initialized
DEBUG - 2015-02-06 14:01:43 --> Config Class Initialized
DEBUG - 2015-02-06 14:01:43 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:01:43 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:01:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:01:43 --> URI Class Initialized
DEBUG - 2015-02-06 14:01:43 --> Router Class Initialized
DEBUG - 2015-02-06 14:01:43 --> Output Class Initialized
DEBUG - 2015-02-06 14:01:43 --> Security Class Initialized
DEBUG - 2015-02-06 14:01:43 --> Input Class Initialized
DEBUG - 2015-02-06 14:01:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:01:43 --> Language Class Initialized
DEBUG - 2015-02-06 14:01:43 --> Loader Class Initialized
DEBUG - 2015-02-06 14:01:43 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:01:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:01:43 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:01:43 --> Controller Class Initialized
DEBUG - 2015-02-06 14:01:43 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:01:43 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:01:43 --> Model Class Initialized
DEBUG - 2015-02-06 14:01:43 --> Model Class Initialized
DEBUG - 2015-02-06 14:01:43 --> File loaded: application/views/email/registration.php
DEBUG - 2015-02-06 14:01:43 --> Email Class Initialized
DEBUG - 2015-02-06 14:01:50 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-06 14:03:28 --> Config Class Initialized
DEBUG - 2015-02-06 14:03:28 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:03:28 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:03:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:03:28 --> URI Class Initialized
DEBUG - 2015-02-06 14:03:28 --> Router Class Initialized
DEBUG - 2015-02-06 14:03:28 --> Output Class Initialized
DEBUG - 2015-02-06 14:03:28 --> Security Class Initialized
DEBUG - 2015-02-06 14:03:28 --> Input Class Initialized
DEBUG - 2015-02-06 14:03:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:03:28 --> Language Class Initialized
DEBUG - 2015-02-06 14:03:28 --> Loader Class Initialized
DEBUG - 2015-02-06 14:03:28 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:03:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:03:28 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:03:28 --> Controller Class Initialized
DEBUG - 2015-02-06 14:03:28 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:03:28 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:04:45 --> Model Class Initialized
DEBUG - 2015-02-06 14:04:45 --> Model Class Initialized
DEBUG - 2015-02-06 14:06:17 --> Config Class Initialized
DEBUG - 2015-02-06 14:06:17 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:06:17 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:06:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:06:17 --> URI Class Initialized
DEBUG - 2015-02-06 14:06:17 --> Router Class Initialized
DEBUG - 2015-02-06 14:06:17 --> Output Class Initialized
DEBUG - 2015-02-06 14:06:17 --> Security Class Initialized
DEBUG - 2015-02-06 14:06:17 --> Input Class Initialized
DEBUG - 2015-02-06 14:06:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:06:17 --> Language Class Initialized
DEBUG - 2015-02-06 14:06:18 --> Loader Class Initialized
DEBUG - 2015-02-06 14:06:18 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:06:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:06:18 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:06:18 --> Controller Class Initialized
DEBUG - 2015-02-06 14:06:18 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:06:18 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:07:34 --> Model Class Initialized
DEBUG - 2015-02-06 14:07:34 --> Model Class Initialized
DEBUG - 2015-02-06 14:07:34 --> File loaded: application/views/email/registration.php
DEBUG - 2015-02-06 14:07:35 --> Email Class Initialized
DEBUG - 2015-02-06 14:07:37 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-06 14:10:19 --> Config Class Initialized
DEBUG - 2015-02-06 14:10:19 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:10:19 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:10:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:10:19 --> URI Class Initialized
DEBUG - 2015-02-06 14:10:19 --> Router Class Initialized
DEBUG - 2015-02-06 14:10:19 --> Output Class Initialized
DEBUG - 2015-02-06 14:10:19 --> Security Class Initialized
DEBUG - 2015-02-06 14:10:19 --> Input Class Initialized
DEBUG - 2015-02-06 14:10:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:10:19 --> Language Class Initialized
DEBUG - 2015-02-06 14:10:19 --> Loader Class Initialized
DEBUG - 2015-02-06 14:10:19 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:10:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:10:19 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:10:19 --> Controller Class Initialized
DEBUG - 2015-02-06 14:10:19 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:10:19 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:11:34 --> Model Class Initialized
DEBUG - 2015-02-06 14:11:34 --> Model Class Initialized
DEBUG - 2015-02-06 14:11:34 --> File loaded: application/views/email/registration.php
DEBUG - 2015-02-06 14:11:34 --> Email Class Initialized
DEBUG - 2015-02-06 14:11:36 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-06 14:12:32 --> Config Class Initialized
DEBUG - 2015-02-06 14:12:32 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:12:32 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:12:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:12:32 --> URI Class Initialized
DEBUG - 2015-02-06 14:12:32 --> Router Class Initialized
DEBUG - 2015-02-06 14:12:32 --> Output Class Initialized
DEBUG - 2015-02-06 14:12:32 --> Security Class Initialized
DEBUG - 2015-02-06 14:12:32 --> Input Class Initialized
DEBUG - 2015-02-06 14:12:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:12:32 --> Language Class Initialized
DEBUG - 2015-02-06 14:12:32 --> Loader Class Initialized
DEBUG - 2015-02-06 14:12:32 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:12:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:12:32 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:12:32 --> Controller Class Initialized
DEBUG - 2015-02-06 14:12:32 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:12:32 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:13:48 --> Model Class Initialized
DEBUG - 2015-02-06 14:13:48 --> Model Class Initialized
DEBUG - 2015-02-06 14:13:48 --> File loaded: application/views/email/registration.php
DEBUG - 2015-02-06 14:13:48 --> Email Class Initialized
DEBUG - 2015-02-06 14:13:51 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-06 14:22:31 --> Config Class Initialized
DEBUG - 2015-02-06 14:22:31 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:22:31 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:22:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:22:31 --> URI Class Initialized
DEBUG - 2015-02-06 14:22:31 --> Router Class Initialized
ERROR - 2015-02-06 14:22:31 --> 404 Page Not Found --> api/challenge
DEBUG - 2015-02-06 14:23:13 --> Config Class Initialized
DEBUG - 2015-02-06 14:23:13 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:23:13 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:23:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:23:13 --> URI Class Initialized
DEBUG - 2015-02-06 14:23:13 --> Router Class Initialized
DEBUG - 2015-02-06 14:23:13 --> Output Class Initialized
DEBUG - 2015-02-06 14:23:13 --> Security Class Initialized
DEBUG - 2015-02-06 14:23:13 --> Input Class Initialized
DEBUG - 2015-02-06 14:23:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:23:13 --> Language Class Initialized
DEBUG - 2015-02-06 14:23:13 --> Loader Class Initialized
DEBUG - 2015-02-06 14:23:13 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:23:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:23:13 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:23:13 --> Controller Class Initialized
DEBUG - 2015-02-06 14:23:13 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:23:13 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:23:13 --> Model Class Initialized
DEBUG - 2015-02-06 14:23:13 --> Model Class Initialized
DEBUG - 2015-02-06 14:23:13 --> DB Transaction Failure
ERROR - 2015-02-06 14:23:13 --> Query error: Table 'thunderbirds.user_challenge_status' doesn't exist
DEBUG - 2015-02-06 14:23:13 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-06 14:23:53 --> Config Class Initialized
DEBUG - 2015-02-06 14:23:53 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:23:53 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:23:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:23:53 --> URI Class Initialized
DEBUG - 2015-02-06 14:23:53 --> Router Class Initialized
DEBUG - 2015-02-06 14:23:53 --> Output Class Initialized
DEBUG - 2015-02-06 14:23:53 --> Security Class Initialized
DEBUG - 2015-02-06 14:23:53 --> Input Class Initialized
DEBUG - 2015-02-06 14:23:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:23:53 --> Language Class Initialized
DEBUG - 2015-02-06 14:23:53 --> Loader Class Initialized
DEBUG - 2015-02-06 14:23:53 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:23:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:23:53 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:23:53 --> Controller Class Initialized
DEBUG - 2015-02-06 14:23:53 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:23:53 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:23:53 --> Model Class Initialized
DEBUG - 2015-02-06 14:23:53 --> Model Class Initialized
DEBUG - 2015-02-06 14:23:53 --> DB Transaction Failure
ERROR - 2015-02-06 14:23:53 --> Query error: Unknown column 'user_id' in 'field list'
DEBUG - 2015-02-06 14:23:53 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-06 14:24:10 --> Config Class Initialized
DEBUG - 2015-02-06 14:24:10 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:24:10 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:24:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:24:10 --> URI Class Initialized
DEBUG - 2015-02-06 14:24:10 --> Router Class Initialized
DEBUG - 2015-02-06 14:24:10 --> Output Class Initialized
DEBUG - 2015-02-06 14:24:10 --> Security Class Initialized
DEBUG - 2015-02-06 14:24:10 --> Input Class Initialized
DEBUG - 2015-02-06 14:24:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:24:10 --> Language Class Initialized
DEBUG - 2015-02-06 14:24:10 --> Loader Class Initialized
DEBUG - 2015-02-06 14:24:10 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:24:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:24:10 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:24:10 --> Controller Class Initialized
DEBUG - 2015-02-06 14:24:10 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:24:10 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:24:10 --> Model Class Initialized
DEBUG - 2015-02-06 14:24:10 --> Model Class Initialized
DEBUG - 2015-02-06 14:24:10 --> DB Transaction Failure
ERROR - 2015-02-06 14:24:10 --> Query error: Table 'thunderbirds.challenges_relationship' doesn't exist
DEBUG - 2015-02-06 14:24:10 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-06 14:24:53 --> Config Class Initialized
DEBUG - 2015-02-06 14:24:53 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:24:53 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:24:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:24:53 --> URI Class Initialized
DEBUG - 2015-02-06 14:24:53 --> Router Class Initialized
DEBUG - 2015-02-06 14:24:53 --> Output Class Initialized
DEBUG - 2015-02-06 14:24:53 --> Security Class Initialized
DEBUG - 2015-02-06 14:24:53 --> Input Class Initialized
DEBUG - 2015-02-06 14:24:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:24:53 --> Language Class Initialized
DEBUG - 2015-02-06 14:24:53 --> Loader Class Initialized
DEBUG - 2015-02-06 14:24:53 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:24:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:24:53 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:24:53 --> Controller Class Initialized
DEBUG - 2015-02-06 14:24:53 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:24:53 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:24:53 --> Model Class Initialized
DEBUG - 2015-02-06 14:24:53 --> Model Class Initialized
DEBUG - 2015-02-06 14:24:53 --> DB Transaction Failure
ERROR - 2015-02-06 14:24:53 --> Query error: Unknown column 'challenge_status' in 'field list'
DEBUG - 2015-02-06 14:24:53 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-06 14:25:47 --> Config Class Initialized
DEBUG - 2015-02-06 14:25:47 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:25:47 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:25:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:25:47 --> URI Class Initialized
DEBUG - 2015-02-06 14:25:47 --> Router Class Initialized
DEBUG - 2015-02-06 14:25:47 --> Output Class Initialized
DEBUG - 2015-02-06 14:25:47 --> Security Class Initialized
DEBUG - 2015-02-06 14:25:47 --> Input Class Initialized
DEBUG - 2015-02-06 14:25:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:25:47 --> Language Class Initialized
DEBUG - 2015-02-06 14:25:48 --> Loader Class Initialized
DEBUG - 2015-02-06 14:25:48 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:25:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:25:48 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:25:48 --> Controller Class Initialized
DEBUG - 2015-02-06 14:25:48 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:25:48 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:25:48 --> Model Class Initialized
DEBUG - 2015-02-06 14:25:48 --> Model Class Initialized
DEBUG - 2015-02-06 14:25:51 --> Config Class Initialized
DEBUG - 2015-02-06 14:25:51 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:25:51 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:25:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:25:51 --> URI Class Initialized
DEBUG - 2015-02-06 14:25:51 --> Router Class Initialized
DEBUG - 2015-02-06 14:25:51 --> Output Class Initialized
DEBUG - 2015-02-06 14:25:51 --> Security Class Initialized
DEBUG - 2015-02-06 14:25:51 --> Input Class Initialized
DEBUG - 2015-02-06 14:25:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:25:51 --> Language Class Initialized
DEBUG - 2015-02-06 14:25:51 --> Loader Class Initialized
DEBUG - 2015-02-06 14:25:51 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:25:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:25:51 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:25:51 --> Controller Class Initialized
DEBUG - 2015-02-06 14:25:51 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:25:51 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:25:51 --> Model Class Initialized
DEBUG - 2015-02-06 14:25:51 --> Model Class Initialized
DEBUG - 2015-02-06 14:25:54 --> Config Class Initialized
DEBUG - 2015-02-06 14:25:54 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:25:54 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:25:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:25:54 --> URI Class Initialized
DEBUG - 2015-02-06 14:25:54 --> Router Class Initialized
DEBUG - 2015-02-06 14:25:54 --> Output Class Initialized
DEBUG - 2015-02-06 14:25:54 --> Security Class Initialized
DEBUG - 2015-02-06 14:25:54 --> Input Class Initialized
DEBUG - 2015-02-06 14:25:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:25:54 --> Language Class Initialized
DEBUG - 2015-02-06 14:25:54 --> Loader Class Initialized
DEBUG - 2015-02-06 14:25:54 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:25:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:25:54 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:25:54 --> Controller Class Initialized
DEBUG - 2015-02-06 14:25:54 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:25:54 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:25:54 --> Model Class Initialized
DEBUG - 2015-02-06 14:25:54 --> Model Class Initialized
DEBUG - 2015-02-06 14:25:58 --> Config Class Initialized
DEBUG - 2015-02-06 14:25:58 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:25:58 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:25:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:25:58 --> URI Class Initialized
DEBUG - 2015-02-06 14:25:58 --> Router Class Initialized
DEBUG - 2015-02-06 14:25:58 --> Output Class Initialized
DEBUG - 2015-02-06 14:25:58 --> Security Class Initialized
DEBUG - 2015-02-06 14:25:58 --> Input Class Initialized
DEBUG - 2015-02-06 14:25:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:25:58 --> Language Class Initialized
DEBUG - 2015-02-06 14:25:58 --> Loader Class Initialized
DEBUG - 2015-02-06 14:25:58 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:25:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:25:58 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:25:58 --> Controller Class Initialized
DEBUG - 2015-02-06 14:25:58 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:25:58 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:25:58 --> Model Class Initialized
DEBUG - 2015-02-06 14:25:58 --> Model Class Initialized
DEBUG - 2015-02-06 14:26:02 --> Config Class Initialized
DEBUG - 2015-02-06 14:26:02 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:26:02 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:26:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:26:02 --> URI Class Initialized
DEBUG - 2015-02-06 14:26:02 --> Router Class Initialized
DEBUG - 2015-02-06 14:26:02 --> Output Class Initialized
DEBUG - 2015-02-06 14:26:02 --> Security Class Initialized
DEBUG - 2015-02-06 14:26:02 --> Input Class Initialized
DEBUG - 2015-02-06 14:26:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:26:02 --> Language Class Initialized
DEBUG - 2015-02-06 14:26:02 --> Loader Class Initialized
DEBUG - 2015-02-06 14:26:02 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:26:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:26:02 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:26:02 --> Controller Class Initialized
DEBUG - 2015-02-06 14:26:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:26:02 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:26:02 --> Model Class Initialized
DEBUG - 2015-02-06 14:26:02 --> Model Class Initialized
DEBUG - 2015-02-06 14:26:14 --> Config Class Initialized
DEBUG - 2015-02-06 14:26:14 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:26:14 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:26:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:26:14 --> URI Class Initialized
DEBUG - 2015-02-06 14:26:14 --> Router Class Initialized
DEBUG - 2015-02-06 14:26:14 --> Output Class Initialized
DEBUG - 2015-02-06 14:26:14 --> Security Class Initialized
DEBUG - 2015-02-06 14:26:14 --> Input Class Initialized
DEBUG - 2015-02-06 14:26:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:26:14 --> Language Class Initialized
DEBUG - 2015-02-06 14:26:14 --> Loader Class Initialized
DEBUG - 2015-02-06 14:26:14 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:26:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:26:14 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:26:14 --> Controller Class Initialized
DEBUG - 2015-02-06 14:26:14 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:26:14 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:26:14 --> Model Class Initialized
DEBUG - 2015-02-06 14:26:14 --> Model Class Initialized
DEBUG - 2015-02-06 14:28:21 --> Config Class Initialized
DEBUG - 2015-02-06 14:28:21 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:28:21 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:28:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:28:21 --> URI Class Initialized
DEBUG - 2015-02-06 14:28:21 --> Router Class Initialized
DEBUG - 2015-02-06 14:28:21 --> Output Class Initialized
DEBUG - 2015-02-06 14:28:21 --> Security Class Initialized
DEBUG - 2015-02-06 14:28:21 --> Input Class Initialized
DEBUG - 2015-02-06 14:28:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:28:21 --> Language Class Initialized
DEBUG - 2015-02-06 14:28:21 --> Loader Class Initialized
DEBUG - 2015-02-06 14:28:21 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:28:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:28:21 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:28:21 --> Controller Class Initialized
DEBUG - 2015-02-06 14:28:21 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:28:21 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:29:37 --> Model Class Initialized
DEBUG - 2015-02-06 14:29:37 --> Model Class Initialized
DEBUG - 2015-02-06 14:29:51 --> Config Class Initialized
DEBUG - 2015-02-06 14:29:51 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:29:51 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:29:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:29:51 --> URI Class Initialized
DEBUG - 2015-02-06 14:29:51 --> Router Class Initialized
DEBUG - 2015-02-06 14:29:51 --> Output Class Initialized
DEBUG - 2015-02-06 14:29:51 --> Security Class Initialized
DEBUG - 2015-02-06 14:29:51 --> Input Class Initialized
DEBUG - 2015-02-06 14:29:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:29:51 --> Language Class Initialized
DEBUG - 2015-02-06 14:29:51 --> Loader Class Initialized
DEBUG - 2015-02-06 14:29:51 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:29:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:29:51 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:29:51 --> Controller Class Initialized
DEBUG - 2015-02-06 14:29:51 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:29:51 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:31:07 --> Model Class Initialized
DEBUG - 2015-02-06 14:31:07 --> Model Class Initialized
DEBUG - 2015-02-06 14:31:07 --> File loaded: application/views/email/registration.php
DEBUG - 2015-02-06 14:31:07 --> Email Class Initialized
DEBUG - 2015-02-06 14:31:09 --> Language file loaded: language/english/email_lang.php
ERROR - 2015-02-06 14:32:28 --> Severity: Notice  --> Undefined offset: 1 /Volumes/Data/www/thunderbirds-hub-site/server/application/models/users_model.php 621
ERROR - 2015-02-06 14:32:28 --> Severity: Notice  --> Trying to get property of non-object /Volumes/Data/www/thunderbirds-hub-site/server/application/models/users_model.php 547
ERROR - 2015-02-06 14:33:43 --> Severity: Notice  --> Undefined offset: 1 /Volumes/Data/www/thunderbirds-hub-site/server/application/models/users_model.php 621
ERROR - 2015-02-06 14:33:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds-hub-site/server/application/models/users_model.php:622) /Volumes/Data/www/thunderbirds-hub-site/server/application/libraries/REST_Controller.php 485
ERROR - 2015-02-06 14:33:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds-hub-site/server/application/models/users_model.php:622) /Volumes/Data/www/thunderbirds-hub-site/server/system/core/Common.php 442
ERROR - 2015-02-06 14:33:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds-hub-site/server/application/models/users_model.php:622) /Volumes/Data/www/thunderbirds-hub-site/server/application/libraries/REST_Controller.php 503
DEBUG - 2015-02-06 14:39:22 --> Config Class Initialized
DEBUG - 2015-02-06 14:39:22 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:39:22 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:39:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:39:22 --> URI Class Initialized
DEBUG - 2015-02-06 14:39:22 --> Router Class Initialized
DEBUG - 2015-02-06 14:39:22 --> Output Class Initialized
DEBUG - 2015-02-06 14:39:22 --> Security Class Initialized
DEBUG - 2015-02-06 14:39:22 --> Input Class Initialized
DEBUG - 2015-02-06 14:39:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:39:22 --> Language Class Initialized
DEBUG - 2015-02-06 14:39:22 --> Loader Class Initialized
DEBUG - 2015-02-06 14:39:22 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:39:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:39:22 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:39:22 --> Controller Class Initialized
DEBUG - 2015-02-06 14:39:22 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:39:22 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:40:38 --> Model Class Initialized
DEBUG - 2015-02-06 14:40:38 --> Model Class Initialized
DEBUG - 2015-02-06 14:40:55 --> Config Class Initialized
DEBUG - 2015-02-06 14:40:55 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:40:55 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:40:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:40:55 --> URI Class Initialized
DEBUG - 2015-02-06 14:40:55 --> Router Class Initialized
DEBUG - 2015-02-06 14:40:55 --> Output Class Initialized
DEBUG - 2015-02-06 14:40:55 --> Security Class Initialized
DEBUG - 2015-02-06 14:40:55 --> Input Class Initialized
DEBUG - 2015-02-06 14:40:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:40:55 --> Language Class Initialized
DEBUG - 2015-02-06 14:40:55 --> Loader Class Initialized
DEBUG - 2015-02-06 14:40:55 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:40:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:40:55 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:40:55 --> Controller Class Initialized
DEBUG - 2015-02-06 14:40:55 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:40:55 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:40:55 --> Model Class Initialized
DEBUG - 2015-02-06 14:40:55 --> Model Class Initialized
DEBUG - 2015-02-06 14:41:02 --> Config Class Initialized
DEBUG - 2015-02-06 14:41:02 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:41:02 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:41:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:41:02 --> URI Class Initialized
DEBUG - 2015-02-06 14:41:02 --> Router Class Initialized
DEBUG - 2015-02-06 14:41:02 --> Output Class Initialized
DEBUG - 2015-02-06 14:41:02 --> Security Class Initialized
DEBUG - 2015-02-06 14:41:02 --> Input Class Initialized
DEBUG - 2015-02-06 14:41:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:41:02 --> Language Class Initialized
DEBUG - 2015-02-06 14:41:02 --> Loader Class Initialized
DEBUG - 2015-02-06 14:41:02 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:41:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:41:02 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:41:02 --> Controller Class Initialized
DEBUG - 2015-02-06 14:41:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:41:02 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:41:02 --> Model Class Initialized
DEBUG - 2015-02-06 14:41:02 --> Model Class Initialized
DEBUG - 2015-02-06 14:41:02 --> Email Class Initialized
DEBUG - 2015-02-06 14:41:04 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-06 14:41:08 --> Final output sent to browser
DEBUG - 2015-02-06 14:41:08 --> Total execution time: 6.1069
DEBUG - 2015-02-06 14:42:24 --> Config Class Initialized
DEBUG - 2015-02-06 14:42:24 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:42:24 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:42:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:42:24 --> URI Class Initialized
DEBUG - 2015-02-06 14:42:24 --> Router Class Initialized
DEBUG - 2015-02-06 14:42:24 --> Output Class Initialized
DEBUG - 2015-02-06 14:42:24 --> Security Class Initialized
DEBUG - 2015-02-06 14:42:24 --> Input Class Initialized
DEBUG - 2015-02-06 14:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:42:24 --> Language Class Initialized
DEBUG - 2015-02-06 14:42:24 --> Loader Class Initialized
DEBUG - 2015-02-06 14:42:24 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:42:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:42:24 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:42:24 --> Controller Class Initialized
DEBUG - 2015-02-06 14:42:24 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:42:24 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:42:24 --> Model Class Initialized
DEBUG - 2015-02-06 14:42:24 --> Model Class Initialized
DEBUG - 2015-02-06 14:42:24 --> Email Class Initialized
DEBUG - 2015-02-06 14:42:26 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-06 14:42:32 --> Config Class Initialized
DEBUG - 2015-02-06 14:42:32 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:42:32 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:42:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:42:32 --> URI Class Initialized
DEBUG - 2015-02-06 14:42:32 --> Router Class Initialized
DEBUG - 2015-02-06 14:42:32 --> Output Class Initialized
DEBUG - 2015-02-06 14:42:32 --> Security Class Initialized
DEBUG - 2015-02-06 14:42:32 --> Input Class Initialized
DEBUG - 2015-02-06 14:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:42:32 --> Language Class Initialized
DEBUG - 2015-02-06 14:42:32 --> Loader Class Initialized
DEBUG - 2015-02-06 14:42:32 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:42:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:42:32 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:42:32 --> Controller Class Initialized
DEBUG - 2015-02-06 14:42:32 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:42:32 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:42:32 --> Model Class Initialized
DEBUG - 2015-02-06 14:42:32 --> Model Class Initialized
DEBUG - 2015-02-06 14:42:32 --> Email Class Initialized
DEBUG - 2015-02-06 14:42:32 --> Config Class Initialized
DEBUG - 2015-02-06 14:42:32 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:42:32 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:42:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:42:32 --> URI Class Initialized
DEBUG - 2015-02-06 14:42:32 --> Router Class Initialized
DEBUG - 2015-02-06 14:42:32 --> Output Class Initialized
DEBUG - 2015-02-06 14:42:32 --> Security Class Initialized
DEBUG - 2015-02-06 14:42:32 --> Input Class Initialized
DEBUG - 2015-02-06 14:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:42:32 --> Language Class Initialized
DEBUG - 2015-02-06 14:42:32 --> Loader Class Initialized
DEBUG - 2015-02-06 14:42:32 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:42:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:42:32 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:42:32 --> Controller Class Initialized
DEBUG - 2015-02-06 14:42:32 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:42:32 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:42:32 --> Model Class Initialized
DEBUG - 2015-02-06 14:42:32 --> Model Class Initialized
DEBUG - 2015-02-06 14:42:32 --> Email Class Initialized
DEBUG - 2015-02-06 14:42:33 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-06 14:42:34 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-06 14:42:57 --> Config Class Initialized
DEBUG - 2015-02-06 14:42:57 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:42:57 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:42:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:42:57 --> URI Class Initialized
DEBUG - 2015-02-06 14:42:57 --> Router Class Initialized
DEBUG - 2015-02-06 14:42:57 --> Output Class Initialized
DEBUG - 2015-02-06 14:42:57 --> Security Class Initialized
DEBUG - 2015-02-06 14:42:57 --> Input Class Initialized
DEBUG - 2015-02-06 14:42:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:42:57 --> Language Class Initialized
DEBUG - 2015-02-06 14:42:57 --> Loader Class Initialized
DEBUG - 2015-02-06 14:42:57 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:42:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:42:57 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:42:57 --> Controller Class Initialized
DEBUG - 2015-02-06 14:42:57 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:42:57 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:42:57 --> Model Class Initialized
DEBUG - 2015-02-06 14:42:57 --> Model Class Initialized
DEBUG - 2015-02-06 14:42:57 --> Email Class Initialized
DEBUG - 2015-02-06 14:42:59 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-06 14:46:41 --> Config Class Initialized
DEBUG - 2015-02-06 14:46:41 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:46:41 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:46:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:46:41 --> URI Class Initialized
DEBUG - 2015-02-06 14:46:41 --> Router Class Initialized
DEBUG - 2015-02-06 14:46:41 --> Output Class Initialized
DEBUG - 2015-02-06 14:46:41 --> Security Class Initialized
DEBUG - 2015-02-06 14:46:41 --> Input Class Initialized
DEBUG - 2015-02-06 14:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:46:41 --> Language Class Initialized
DEBUG - 2015-02-06 14:46:41 --> Loader Class Initialized
DEBUG - 2015-02-06 14:46:41 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:46:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:46:41 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:46:41 --> Controller Class Initialized
DEBUG - 2015-02-06 14:46:41 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:46:41 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:46:41 --> Model Class Initialized
DEBUG - 2015-02-06 14:46:41 --> Model Class Initialized
DEBUG - 2015-02-06 14:47:33 --> Config Class Initialized
DEBUG - 2015-02-06 14:47:33 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:47:33 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:47:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:47:33 --> URI Class Initialized
DEBUG - 2015-02-06 14:47:33 --> Router Class Initialized
DEBUG - 2015-02-06 14:47:33 --> Output Class Initialized
DEBUG - 2015-02-06 14:47:33 --> Security Class Initialized
DEBUG - 2015-02-06 14:47:33 --> Input Class Initialized
DEBUG - 2015-02-06 14:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:47:33 --> Language Class Initialized
DEBUG - 2015-02-06 14:47:33 --> Loader Class Initialized
DEBUG - 2015-02-06 14:47:33 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:47:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:47:33 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:47:33 --> Controller Class Initialized
DEBUG - 2015-02-06 14:47:33 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:47:33 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:47:33 --> Model Class Initialized
DEBUG - 2015-02-06 14:47:33 --> Model Class Initialized
DEBUG - 2015-02-06 14:47:41 --> Config Class Initialized
DEBUG - 2015-02-06 14:47:41 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:47:41 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:47:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:47:41 --> URI Class Initialized
DEBUG - 2015-02-06 14:47:41 --> Router Class Initialized
DEBUG - 2015-02-06 14:47:41 --> Output Class Initialized
DEBUG - 2015-02-06 14:47:41 --> Security Class Initialized
DEBUG - 2015-02-06 14:47:41 --> Input Class Initialized
DEBUG - 2015-02-06 14:47:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-06 14:47:41 --> Language Class Initialized
DEBUG - 2015-02-06 14:47:41 --> Loader Class Initialized
DEBUG - 2015-02-06 14:47:41 --> Database Driver Class Initialized
ERROR - 2015-02-06 14:47:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-06 14:47:41 --> XML-RPC Class Initialized
DEBUG - 2015-02-06 14:47:41 --> Controller Class Initialized
DEBUG - 2015-02-06 14:47:41 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-06 14:47:41 --> Helper loaded: inflector_helper
DEBUG - 2015-02-06 14:47:41 --> Model Class Initialized
DEBUG - 2015-02-06 14:47:41 --> Model Class Initialized
