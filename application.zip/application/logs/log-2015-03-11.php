<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-03-11 14:35:24 --> Config Class Initialized
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-03-11 14:35:24 --> Config Class Initialized
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-03-11 14:35:24 --> Config Class Initialized
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-03-11 14:35:24 --> Config Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Hooks Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Hooks Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Hooks Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Hooks Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Utf8 Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Utf8 Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Utf8 Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Utf8 Class Initialized
DEBUG - 2015-03-11 14:35:24 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 14:35:24 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 14:35:24 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 14:35:24 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 14:35:24 --> URI Class Initialized
DEBUG - 2015-03-11 14:35:24 --> URI Class Initialized
DEBUG - 2015-03-11 14:35:24 --> URI Class Initialized
DEBUG - 2015-03-11 14:35:24 --> URI Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Router Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Router Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Router Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Router Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Output Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Output Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Output Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Output Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Security Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Security Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Security Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Security Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Input Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Input Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Input Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 14:35:24 --> Input Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 14:35:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 14:35:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 14:35:24 --> Language Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Language Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Language Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Language Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Loader Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Loader Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Loader Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Loader Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Database Driver Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Database Driver Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Database Driver Class Initialized
ERROR - 2015-03-11 14:35:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-11 14:35:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-11 14:35:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 14:35:24 --> Database Driver Class Initialized
ERROR - 2015-03-11 14:35:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 14:35:24 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 14:35:24 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 14:35:24 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Controller Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Controller Class Initialized
DEBUG - 2015-03-11 14:35:24 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Controller Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Controller Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 14:35:24 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 14:35:24 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 14:35:24 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 14:35:24 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 14:35:24 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 14:35:24 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 14:35:24 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 14:35:24 --> Model Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Model Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Model Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Model Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Model Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Model Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Model Class Initialized
DEBUG - 2015-03-11 14:35:24 --> Model Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Config Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Hooks Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Config Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Config Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Hooks Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Config Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Hooks Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Utf8 Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Hooks Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Utf8 Class Initialized
DEBUG - 2015-03-11 14:51:51 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 14:51:51 --> Utf8 Class Initialized
DEBUG - 2015-03-11 14:51:51 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 14:51:51 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 14:51:51 --> Utf8 Class Initialized
DEBUG - 2015-03-11 14:51:51 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 14:51:51 --> URI Class Initialized
DEBUG - 2015-03-11 14:51:51 --> URI Class Initialized
DEBUG - 2015-03-11 14:51:51 --> URI Class Initialized
DEBUG - 2015-03-11 14:51:51 --> URI Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Router Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Router Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Router Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Router Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Output Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Output Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Output Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Output Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Security Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Security Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Security Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Security Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Input Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Input Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 14:51:51 --> Input Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 14:51:51 --> Input Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Language Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 14:51:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 14:51:51 --> Language Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Language Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Language Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Loader Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Loader Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Loader Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Loader Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Database Driver Class Initialized
ERROR - 2015-03-11 14:51:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 14:51:51 --> Database Driver Class Initialized
ERROR - 2015-03-11 14:51:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 14:51:51 --> Database Driver Class Initialized
ERROR - 2015-03-11 14:51:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 14:51:51 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Controller Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Database Driver Class Initialized
ERROR - 2015-03-11 14:51:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 14:51:51 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 14:51:51 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 14:51:51 --> Controller Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Model Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 14:51:51 --> Model Class Initialized
DEBUG - 2015-03-11 14:51:51 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 14:51:51 --> Controller Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Model Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 14:51:51 --> Model Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 14:51:51 --> Model Class Initialized
DEBUG - 2015-03-11 14:51:51 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Controller Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Model Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 14:51:51 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 14:51:51 --> Model Class Initialized
DEBUG - 2015-03-11 14:51:51 --> Model Class Initialized
DEBUG - 2015-03-11 14:55:19 --> Config Class Initialized
DEBUG - 2015-03-11 14:55:19 --> Hooks Class Initialized
DEBUG - 2015-03-11 14:55:19 --> Utf8 Class Initialized
DEBUG - 2015-03-11 14:55:19 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 14:55:19 --> Config Class Initialized
DEBUG - 2015-03-11 14:55:19 --> Hooks Class Initialized
DEBUG - 2015-03-11 14:55:19 --> Utf8 Class Initialized
DEBUG - 2015-03-11 14:55:19 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 14:55:19 --> URI Class Initialized
DEBUG - 2015-03-11 14:55:19 --> URI Class Initialized
DEBUG - 2015-03-11 14:55:19 --> Router Class Initialized
DEBUG - 2015-03-11 14:55:19 --> Router Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Output Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Config Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Config Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Security Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Hooks Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Hooks Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Output Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Utf8 Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Utf8 Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Input Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Security Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 14:55:21 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 14:55:21 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 14:55:21 --> URI Class Initialized
DEBUG - 2015-03-11 14:55:21 --> URI Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Language Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Input Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 14:55:21 --> Router Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Language Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Router Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Output Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Output Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Loader Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Loader Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Security Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Security Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Input Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 14:55:21 --> Language Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Input Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 14:55:21 --> Language Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Database Driver Class Initialized
ERROR - 2015-03-11 14:55:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 14:55:21 --> Loader Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Loader Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Database Driver Class Initialized
DEBUG - 2015-03-11 14:55:21 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Database Driver Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Database Driver Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Controller Class Initialized
ERROR - 2015-03-11 14:55:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-11 14:55:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-11 14:55:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 14:55:21 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 14:55:21 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 14:55:21 --> Model Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Model Class Initialized
DEBUG - 2015-03-11 14:55:21 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Controller Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 14:55:21 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 14:55:21 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Controller Class Initialized
DEBUG - 2015-03-11 14:55:21 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Controller Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 14:55:21 --> Model Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 14:55:21 --> Model Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 14:55:21 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 14:55:21 --> Model Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Model Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Model Class Initialized
DEBUG - 2015-03-11 14:55:21 --> Model Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Config Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Config Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Config Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Config Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Hooks Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Hooks Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Hooks Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Hooks Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Utf8 Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Utf8 Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Utf8 Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Utf8 Class Initialized
DEBUG - 2015-03-11 14:57:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 14:57:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 14:57:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 14:57:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 14:57:56 --> URI Class Initialized
DEBUG - 2015-03-11 14:57:56 --> URI Class Initialized
DEBUG - 2015-03-11 14:57:56 --> URI Class Initialized
DEBUG - 2015-03-11 14:57:56 --> URI Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Router Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Router Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Router Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Router Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Output Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Security Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Output Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Output Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Output Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Input Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 14:57:56 --> Language Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Security Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Security Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Input Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 14:57:56 --> Input Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 14:57:56 --> Language Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Security Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Language Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Input Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 14:57:56 --> Language Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Loader Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Loader Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Loader Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Loader Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Database Driver Class Initialized
ERROR - 2015-03-11 14:57:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 14:57:56 --> Database Driver Class Initialized
ERROR - 2015-03-11 14:57:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 14:57:56 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Controller Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 14:57:56 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Controller Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 14:57:56 --> Database Driver Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Database Driver Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 14:57:56 --> Model Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 14:57:56 --> Model Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Model Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Model Class Initialized
ERROR - 2015-03-11 14:57:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-11 14:57:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 14:57:56 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Controller Class Initialized
DEBUG - 2015-03-11 14:57:56 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Controller Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 14:57:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 14:57:56 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 14:57:56 --> Model Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Model Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 14:57:56 --> Model Class Initialized
DEBUG - 2015-03-11 14:57:56 --> Model Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Config Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Config Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Hooks Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Hooks Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Utf8 Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Utf8 Class Initialized
DEBUG - 2015-03-11 14:58:10 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 14:58:10 --> URI Class Initialized
DEBUG - 2015-03-11 14:58:10 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 14:58:10 --> Config Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Hooks Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Utf8 Class Initialized
DEBUG - 2015-03-11 14:58:10 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 14:58:10 --> URI Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Router Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Config Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Hooks Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Utf8 Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Output Class Initialized
DEBUG - 2015-03-11 14:58:10 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 14:58:10 --> URI Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Security Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Router Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Router Class Initialized
DEBUG - 2015-03-11 14:58:10 --> URI Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Output Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Security Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Input Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 14:58:10 --> Language Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Input Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 14:58:10 --> Language Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Router Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Output Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Output Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Security Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Input Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 14:58:10 --> Language Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Loader Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Loader Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Security Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Input Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 14:58:10 --> Language Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Loader Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Database Driver Class Initialized
ERROR - 2015-03-11 14:58:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 14:58:10 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Controller Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 14:58:10 --> Loader Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 14:58:10 --> Model Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Model Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Database Driver Class Initialized
ERROR - 2015-03-11 14:58:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 14:58:10 --> Database Driver Class Initialized
ERROR - 2015-03-11 14:58:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 14:58:10 --> Database Driver Class Initialized
DEBUG - 2015-03-11 14:58:10 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Controller Class Initialized
ERROR - 2015-03-11 14:58:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 14:58:10 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 14:58:10 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 14:58:10 --> Model Class Initialized
DEBUG - 2015-03-11 14:58:10 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Model Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Controller Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 14:58:10 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Controller Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 14:58:10 --> Model Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Model Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 14:58:10 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 14:58:10 --> Model Class Initialized
DEBUG - 2015-03-11 14:58:10 --> Model Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Config Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Config Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Hooks Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Hooks Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Utf8 Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Utf8 Class Initialized
DEBUG - 2015-03-11 14:59:40 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 14:59:40 --> Config Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Hooks Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Utf8 Class Initialized
DEBUG - 2015-03-11 14:59:40 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 14:59:40 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 14:59:40 --> URI Class Initialized
DEBUG - 2015-03-11 14:59:40 --> URI Class Initialized
DEBUG - 2015-03-11 14:59:40 --> URI Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Router Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Router Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Router Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Config Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Hooks Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Utf8 Class Initialized
DEBUG - 2015-03-11 14:59:40 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 14:59:40 --> Output Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Output Class Initialized
DEBUG - 2015-03-11 14:59:40 --> URI Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Security Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Security Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Router Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Input Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Input Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 14:59:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 14:59:40 --> Output Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Language Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Output Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Language Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Security Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Input Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 14:59:40 --> Language Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Loader Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Loader Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Security Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Input Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 14:59:40 --> Language Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Database Driver Class Initialized
ERROR - 2015-03-11 14:59:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 14:59:40 --> Loader Class Initialized
DEBUG - 2015-03-11 14:59:40 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Controller Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 14:59:40 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 14:59:40 --> Loader Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Model Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Model Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Database Driver Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Database Driver Class Initialized
ERROR - 2015-03-11 14:59:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-11 14:59:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 14:59:40 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Controller Class Initialized
DEBUG - 2015-03-11 14:59:40 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 14:59:40 --> Controller Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 14:59:40 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 14:59:40 --> Model Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Model Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Database Driver Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Helper loaded: inflector_helper
ERROR - 2015-03-11 14:59:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 14:59:40 --> Model Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Model Class Initialized
DEBUG - 2015-03-11 14:59:40 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Controller Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 14:59:40 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 14:59:40 --> Model Class Initialized
DEBUG - 2015-03-11 14:59:40 --> Model Class Initialized
DEBUG - 2015-03-11 14:59:43 --> Config Class Initialized
DEBUG - 2015-03-11 14:59:43 --> Hooks Class Initialized
DEBUG - 2015-03-11 14:59:43 --> Utf8 Class Initialized
DEBUG - 2015-03-11 14:59:43 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 14:59:43 --> URI Class Initialized
DEBUG - 2015-03-11 14:59:43 --> Router Class Initialized
DEBUG - 2015-03-11 14:59:43 --> Output Class Initialized
DEBUG - 2015-03-11 14:59:43 --> Security Class Initialized
DEBUG - 2015-03-11 14:59:43 --> Input Class Initialized
DEBUG - 2015-03-11 14:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 14:59:43 --> Language Class Initialized
DEBUG - 2015-03-11 14:59:43 --> Loader Class Initialized
DEBUG - 2015-03-11 14:59:43 --> Database Driver Class Initialized
ERROR - 2015-03-11 14:59:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 14:59:43 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 14:59:43 --> Controller Class Initialized
DEBUG - 2015-03-11 14:59:43 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 14:59:43 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 14:59:43 --> Model Class Initialized
DEBUG - 2015-03-11 14:59:43 --> Model Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Config Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Config Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Config Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:00:02 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:00:02 --> URI Class Initialized
DEBUG - 2015-03-11 15:00:02 --> URI Class Initialized
DEBUG - 2015-03-11 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:00:02 --> Config Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Router Class Initialized
DEBUG - 2015-03-11 15:00:02 --> URI Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:00:02 --> Router Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Router Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Output Class Initialized
DEBUG - 2015-03-11 15:00:02 --> URI Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Output Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Security Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Router Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Output Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Security Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Input Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:00:02 --> Language Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Output Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Security Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Input Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Security Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:00:02 --> Language Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Input Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:00:02 --> Input Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:00:02 --> Language Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Language Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Loader Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Loader Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Loader Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Loader Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:00:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:00:02 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:00:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:00:02 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:00:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:00:02 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Controller Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:00:02 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Controller Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:00:02 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Controller Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Helper loaded: inflector_helper
ERROR - 2015-03-11 15:00:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:00:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:00:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:00:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:00:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:00:02 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Controller Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:00:02 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:00:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:00:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:04:03 --> Config Class Initialized
DEBUG - 2015-03-11 15:04:03 --> Config Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:04:03 --> Config Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:04:04 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:04:04 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:04:04 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:04:04 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:04:04 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:04:03 --> Config Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:04:04 --> URI Class Initialized
DEBUG - 2015-03-11 15:04:04 --> URI Class Initialized
DEBUG - 2015-03-11 15:04:04 --> URI Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Router Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Router Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Router Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Output Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Output Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Output Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Security Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Security Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Security Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Input Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:04:04 --> Input Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:04:04 --> Language Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Input Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:04:04 --> Language Class Initialized
DEBUG - 2015-03-11 15:04:04 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:04:04 --> Language Class Initialized
DEBUG - 2015-03-11 15:04:04 --> URI Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Loader Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Loader Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Router Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Output Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Security Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Loader Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Input Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:04:04 --> Language Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:04:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:04:04 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:04:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:04:04 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:04:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:04:04 --> Loader Class Initialized
DEBUG - 2015-03-11 15:04:04 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Controller Class Initialized
DEBUG - 2015-03-11 15:04:04 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Controller Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:04:04 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:04:04 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:04:04 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:04:04 --> Model Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Model Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Model Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Model Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:04:04 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Controller Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Config file loaded: application/config/rest.php
ERROR - 2015-03-11 15:04:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:04:04 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:04:04 --> Model Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Model Class Initialized
DEBUG - 2015-03-11 15:04:04 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Controller Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:04:04 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:04:04 --> Model Class Initialized
DEBUG - 2015-03-11 15:04:04 --> Model Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Config Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Config Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:04:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:04:29 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:04:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:04:29 --> URI Class Initialized
DEBUG - 2015-03-11 15:04:29 --> URI Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Router Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Config Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Router Class Initialized
DEBUG - 2015-03-11 15:04:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:04:29 --> Output Class Initialized
DEBUG - 2015-03-11 15:04:29 --> URI Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Security Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Output Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Router Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Config Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:04:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:04:29 --> Security Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Output Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Input Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:04:29 --> URI Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Language Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Input Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:04:29 --> Security Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Language Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Router Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Input Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:04:29 --> Language Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Loader Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Loader Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Output Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Loader Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:04:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:04:29 --> Security Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Input Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:04:29 --> Language Class Initialized
ERROR - 2015-03-11 15:04:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:04:29 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:04:29 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Controller Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Controller Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:04:29 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:04:29 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:04:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:04:29 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:04:29 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:04:29 --> Model Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Model Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Loader Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Model Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Model Class Initialized
DEBUG - 2015-03-11 15:04:29 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Controller Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:04:29 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:04:29 --> Model Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Model Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:04:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:04:29 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Controller Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:04:29 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:04:29 --> Model Class Initialized
DEBUG - 2015-03-11 15:04:29 --> Model Class Initialized
DEBUG - 2015-03-11 15:17:41 --> Config Class Initialized
DEBUG - 2015-03-11 15:17:41 --> Config Class Initialized
DEBUG - 2015-03-11 15:17:41 --> Config Class Initialized
DEBUG - 2015-03-11 15:17:41 --> Config Class Initialized
DEBUG - 2015-03-11 15:17:41 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:17:41 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:17:41 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:17:41 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:17:41 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:17:41 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:17:41 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:17:41 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:17:41 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:17:41 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:17:41 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:17:41 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:17:41 --> URI Class Initialized
DEBUG - 2015-03-11 15:17:41 --> URI Class Initialized
DEBUG - 2015-03-11 15:17:41 --> URI Class Initialized
DEBUG - 2015-03-11 15:17:41 --> URI Class Initialized
DEBUG - 2015-03-11 15:17:41 --> Router Class Initialized
DEBUG - 2015-03-11 15:17:41 --> Router Class Initialized
DEBUG - 2015-03-11 15:17:41 --> Router Class Initialized
DEBUG - 2015-03-11 15:17:41 --> Router Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Output Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Output Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Output Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Output Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Security Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Security Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Security Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Security Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Input Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Input Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Input Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:17:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:17:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:17:42 --> Input Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:17:42 --> Language Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Language Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Language Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Language Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Loader Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Loader Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Loader Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Loader Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:17:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:17:42 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:17:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:17:42 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:17:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-11 15:17:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:17:42 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:17:42 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Controller Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Controller Class Initialized
DEBUG - 2015-03-11 15:17:42 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Controller Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:17:42 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:17:42 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:17:42 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Controller Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:17:42 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:17:42 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:17:42 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:17:42 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:17:42 --> Model Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Model Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Model Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Model Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Model Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Model Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Model Class Initialized
DEBUG - 2015-03-11 15:17:42 --> Model Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Config Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Config Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Config Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:18:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:18:02 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:18:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:18:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:18:02 --> URI Class Initialized
DEBUG - 2015-03-11 15:18:02 --> URI Class Initialized
DEBUG - 2015-03-11 15:18:02 --> URI Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Router Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Router Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Router Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Output Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Output Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Output Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Security Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Security Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Security Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Input Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Config Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:18:02 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:18:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:18:02 --> Input Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Language Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Input Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:18:02 --> Language Class Initialized
DEBUG - 2015-03-11 15:18:02 --> URI Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Router Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:18:02 --> Language Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Output Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Security Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Input Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:18:02 --> Loader Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Loader Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Language Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Loader Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Loader Class Initialized
ERROR - 2015-03-11 15:18:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:18:02 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:18:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:18:02 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:18:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:18:02 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Controller Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:18:02 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Controller Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:18:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:18:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:18:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:18:02 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Controller Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:18:02 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:18:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:18:02 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:18:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:18:02 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Controller Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:18:02 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:18:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:18:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:18:21 --> Config Class Initialized
DEBUG - 2015-03-11 15:18:21 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:18:21 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:18:21 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:18:21 --> URI Class Initialized
DEBUG - 2015-03-11 15:18:21 --> Router Class Initialized
DEBUG - 2015-03-11 15:18:21 --> Output Class Initialized
DEBUG - 2015-03-11 15:18:21 --> Security Class Initialized
DEBUG - 2015-03-11 15:18:21 --> Input Class Initialized
DEBUG - 2015-03-11 15:18:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:18:21 --> Language Class Initialized
DEBUG - 2015-03-11 15:18:21 --> Loader Class Initialized
DEBUG - 2015-03-11 15:18:21 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:18:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:18:21 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:18:21 --> Controller Class Initialized
DEBUG - 2015-03-11 15:18:21 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:18:21 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:18:21 --> Model Class Initialized
DEBUG - 2015-03-11 15:18:21 --> Model Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Config Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Config Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:19:12 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:19:12 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:19:12 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:19:12 --> Config Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:19:12 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:19:12 --> URI Class Initialized
DEBUG - 2015-03-11 15:19:12 --> URI Class Initialized
DEBUG - 2015-03-11 15:19:12 --> URI Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Router Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Router Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Router Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Output Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Output Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Security Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Security Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Output Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Input Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Input Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:19:12 --> Security Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Language Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Language Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Input Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:19:12 --> Language Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Config Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:19:12 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:19:12 --> Loader Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Loader Class Initialized
DEBUG - 2015-03-11 15:19:12 --> URI Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Router Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Loader Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Output Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Security Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Input Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:19:12 --> Language Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:19:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:19:12 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:19:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:19:12 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:19:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:19:12 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Controller Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:19:12 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:19:12 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:19:12 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Controller Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Controller Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Model Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:19:12 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:19:12 --> Model Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:19:12 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:19:12 --> Loader Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Model Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Model Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Model Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Model Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:19:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:19:12 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Controller Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:19:12 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:19:12 --> Model Class Initialized
DEBUG - 2015-03-11 15:19:12 --> Model Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Config Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Config Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Config Class Initialized
DEBUG - 2015-03-11 15:19:24 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:19:24 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:19:24 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:19:24 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:19:24 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:19:24 --> URI Class Initialized
DEBUG - 2015-03-11 15:19:24 --> URI Class Initialized
DEBUG - 2015-03-11 15:19:24 --> URI Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Router Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Router Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Config Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Router Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:19:24 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:19:24 --> Output Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Output Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Output Class Initialized
DEBUG - 2015-03-11 15:19:24 --> URI Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Security Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Router Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Security Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Security Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Input Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Input Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Input Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:19:24 --> Output Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Language Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Language Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Language Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Security Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Input Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:19:24 --> Language Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Loader Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Loader Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Loader Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Loader Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:19:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-11 15:19:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:19:24 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:19:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:19:24 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:19:24 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Controller Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Controller Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:19:24 --> Config file loaded: application/config/rest.php
ERROR - 2015-03-11 15:19:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:19:24 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Controller Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:19:24 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:19:24 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:19:24 --> Model Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Model Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Model Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Model Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:19:24 --> Model Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Model Class Initialized
DEBUG - 2015-03-11 15:19:24 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Controller Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:19:24 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:19:24 --> Model Class Initialized
DEBUG - 2015-03-11 15:19:24 --> Model Class Initialized
DEBUG - 2015-03-11 15:24:15 --> Config Class Initialized
DEBUG - 2015-03-11 15:24:15 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:24:15 --> Config Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:24:15 --> Config Class Initialized
DEBUG - 2015-03-11 15:24:15 --> Config Class Initialized
DEBUG - 2015-03-11 15:24:16 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:24:16 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:24:16 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:24:16 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:24:16 --> URI Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:24:16 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:24:16 --> URI Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Router Class Initialized
DEBUG - 2015-03-11 15:24:16 --> URI Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Router Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Output Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Router Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Security Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Output Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Output Class Initialized
DEBUG - 2015-03-11 15:24:16 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:24:16 --> Input Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:24:16 --> Security Class Initialized
DEBUG - 2015-03-11 15:24:16 --> URI Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Language Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Security Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Input Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:24:16 --> Language Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Router Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Input Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:24:16 --> Output Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Language Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Security Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Input Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:24:16 --> Language Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Loader Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Loader Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Loader Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Loader Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:24:16 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:24:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-11 15:24:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-11 15:24:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:24:16 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:24:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:24:17 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:24:17 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:24:17 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:24:17 --> Controller Class Initialized
DEBUG - 2015-03-11 15:24:17 --> Controller Class Initialized
DEBUG - 2015-03-11 15:24:17 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:24:17 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:24:17 --> Controller Class Initialized
DEBUG - 2015-03-11 15:24:17 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:24:17 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:24:17 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:24:17 --> Model Class Initialized
DEBUG - 2015-03-11 15:24:17 --> Model Class Initialized
DEBUG - 2015-03-11 15:24:17 --> Model Class Initialized
DEBUG - 2015-03-11 15:24:17 --> Model Class Initialized
DEBUG - 2015-03-11 15:24:17 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:24:17 --> Model Class Initialized
DEBUG - 2015-03-11 15:24:17 --> Model Class Initialized
DEBUG - 2015-03-11 15:24:17 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:24:17 --> Controller Class Initialized
DEBUG - 2015-03-11 15:24:17 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:24:17 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:24:17 --> Model Class Initialized
DEBUG - 2015-03-11 15:24:17 --> Model Class Initialized
DEBUG - 2015-03-11 15:33:45 --> Config Class Initialized
DEBUG - 2015-03-11 15:33:45 --> Config Class Initialized
DEBUG - 2015-03-11 15:33:45 --> Config Class Initialized
DEBUG - 2015-03-11 15:33:45 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:33:45 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:33:45 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:33:45 --> Config Class Initialized
DEBUG - 2015-03-11 15:33:45 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:33:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:33:46 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:33:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:33:46 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:33:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:33:46 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:33:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:33:46 --> URI Class Initialized
DEBUG - 2015-03-11 15:33:46 --> URI Class Initialized
DEBUG - 2015-03-11 15:33:46 --> URI Class Initialized
DEBUG - 2015-03-11 15:33:46 --> URI Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Router Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Router Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Router Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Router Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Output Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Output Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Output Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Security Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Output Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Security Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Security Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Input Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:33:46 --> Security Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Input Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:33:46 --> Language Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Input Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Language Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:33:46 --> Input Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:33:46 --> Language Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Language Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Loader Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Loader Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Loader Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Loader Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:33:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-11 15:33:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-11 15:33:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:33:46 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:33:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:33:46 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:33:46 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Controller Class Initialized
DEBUG - 2015-03-11 15:33:46 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Controller Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Controller Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:33:46 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:33:46 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:33:46 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Controller Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:33:46 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:33:46 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:33:46 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:33:46 --> Model Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Model Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Model Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Model Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:33:46 --> Model Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Model Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Model Class Initialized
DEBUG - 2015-03-11 15:33:46 --> Model Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Config Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:33:59 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:33:59 --> URI Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Config Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Config Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:33:59 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:33:59 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:33:59 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:33:59 --> URI Class Initialized
DEBUG - 2015-03-11 15:33:59 --> URI Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Config Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Router Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Router Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Router Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Output Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Output Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Output Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Security Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Security Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Security Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Input Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:33:59 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:33:59 --> Input Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Language Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:33:59 --> Language Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Input Class Initialized
DEBUG - 2015-03-11 15:33:59 --> URI Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:33:59 --> Language Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Router Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Output Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Security Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Loader Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Loader Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Input Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:33:59 --> Language Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Loader Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Loader Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:33:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-11 15:33:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:33:59 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:33:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:33:59 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Controller Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:33:59 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Controller Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:33:59 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:33:59 --> Model Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Model Class Initialized
DEBUG - 2015-03-11 15:33:59 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Controller Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:33:59 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:33:59 --> Model Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Model Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:33:59 --> Model Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Model Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:33:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:33:59 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Controller Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:33:59 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:33:59 --> Model Class Initialized
DEBUG - 2015-03-11 15:33:59 --> Model Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Config Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:36:19 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:36:19 --> Config Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:36:19 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:36:19 --> URI Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Config Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:36:19 --> URI Class Initialized
DEBUG - 2015-03-11 15:36:19 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:36:19 --> Router Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Config Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:36:19 --> URI Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:36:19 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:36:19 --> Router Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Output Class Initialized
DEBUG - 2015-03-11 15:36:19 --> URI Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Security Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Output Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Router Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Security Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Input Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:36:19 --> Language Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Output Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Input Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:36:19 --> Language Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Security Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Input Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:36:19 --> Language Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Router Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Config Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Loader Class Initialized
DEBUG - 2015-03-11 15:36:19 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:36:19 --> Output Class Initialized
DEBUG - 2015-03-11 15:36:19 --> URI Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Security Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Router Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Input Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:36:19 --> Output Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Language Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Loader Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Security Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Input Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:36:19 --> Language Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Loader Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Loader Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Loader Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:36:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:36:19 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:36:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:36:19 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Controller Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:36:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:36:19 --> Config file loaded: application/config/rest.php
ERROR - 2015-03-11 15:36:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:36:19 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:36:19 --> Model Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Model Class Initialized
DEBUG - 2015-03-11 15:36:19 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Controller Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:36:19 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:36:19 --> Controller Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Model Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:36:19 --> Model Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:36:19 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Controller Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:36:19 --> Model Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:36:19 --> Model Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:36:19 --> Model Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Model Class Initialized
ERROR - 2015-03-11 15:36:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:36:19 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Controller Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:36:19 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:36:19 --> Model Class Initialized
DEBUG - 2015-03-11 15:36:19 --> Model Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Config Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Config Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:39:36 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:39:36 --> Config Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:39:36 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:39:36 --> URI Class Initialized
DEBUG - 2015-03-11 15:39:36 --> URI Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Router Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Config Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Config Class Initialized
DEBUG - 2015-03-11 15:39:36 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:39:36 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:39:36 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:39:36 --> Output Class Initialized
DEBUG - 2015-03-11 15:39:36 --> URI Class Initialized
DEBUG - 2015-03-11 15:39:36 --> URI Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Security Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Router Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Router Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Router Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:39:36 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:39:36 --> Output Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Output Class Initialized
DEBUG - 2015-03-11 15:39:36 --> URI Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Output Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Security Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Router Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Security Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Security Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Output Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Input Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Input Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:39:36 --> Language Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Language Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Security Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Input Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:39:36 --> Input Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:39:36 --> Language Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Input Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:39:36 --> Language Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Language Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Loader Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Loader Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Loader Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Loader Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Loader Class Initialized
ERROR - 2015-03-11 15:39:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-11 15:39:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:39:36 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:39:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:39:36 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:39:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:39:36 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Controller Class Initialized
DEBUG - 2015-03-11 15:39:36 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Controller Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:39:36 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:39:36 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:39:36 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:39:36 --> Model Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Model Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Model Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Model Class Initialized
DEBUG - 2015-03-11 15:39:36 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Controller Class Initialized
DEBUG - 2015-03-11 15:39:36 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Controller Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:39:36 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:39:36 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:39:36 --> Model Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Model Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Helper loaded: inflector_helper
ERROR - 2015-03-11 15:39:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:39:36 --> Model Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Model Class Initialized
DEBUG - 2015-03-11 15:39:36 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Controller Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:39:36 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:39:36 --> Model Class Initialized
DEBUG - 2015-03-11 15:39:36 --> Model Class Initialized
DEBUG - 2015-03-11 15:40:15 --> Config Class Initialized
DEBUG - 2015-03-11 15:40:15 --> Config Class Initialized
DEBUG - 2015-03-11 15:40:15 --> Config Class Initialized
DEBUG - 2015-03-11 15:40:15 --> Config Class Initialized
DEBUG - 2015-03-11 15:40:15 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:40:15 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:40:15 --> Config Class Initialized
DEBUG - 2015-03-11 15:40:15 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:40:15 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:40:15 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:40:15 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:40:15 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:40:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:40:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:40:15 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:40:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:40:15 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:40:15 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:40:15 --> URI Class Initialized
DEBUG - 2015-03-11 15:40:15 --> URI Class Initialized
DEBUG - 2015-03-11 15:40:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:40:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:40:15 --> URI Class Initialized
DEBUG - 2015-03-11 15:40:15 --> URI Class Initialized
DEBUG - 2015-03-11 15:40:15 --> URI Class Initialized
DEBUG - 2015-03-11 15:40:15 --> Router Class Initialized
DEBUG - 2015-03-11 15:40:15 --> Router Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Router Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Router Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Router Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Output Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Output Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Output Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Output Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Output Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Security Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Security Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Security Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Security Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Security Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Input Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Input Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:40:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:40:16 --> Input Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Input Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Language Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Input Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Language Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:40:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:40:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:40:16 --> Language Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Language Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Language Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Loader Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Loader Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Loader Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Loader Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Loader Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:40:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-11 15:40:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-11 15:40:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-11 15:40:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:40:16 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:40:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:40:16 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:40:16 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Controller Class Initialized
DEBUG - 2015-03-11 15:40:16 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Controller Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Controller Class Initialized
DEBUG - 2015-03-11 15:40:16 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:40:16 --> Controller Class Initialized
DEBUG - 2015-03-11 15:40:17 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:40:17 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:40:17 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:40:16 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:40:17 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:40:17 --> Controller Class Initialized
DEBUG - 2015-03-11 15:40:17 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:40:17 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:40:17 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:40:17 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:40:17 --> Model Class Initialized
DEBUG - 2015-03-11 15:40:17 --> Model Class Initialized
DEBUG - 2015-03-11 15:40:17 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:40:17 --> Model Class Initialized
DEBUG - 2015-03-11 15:40:17 --> Model Class Initialized
DEBUG - 2015-03-11 15:40:17 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:40:17 --> Model Class Initialized
DEBUG - 2015-03-11 15:40:17 --> Model Class Initialized
DEBUG - 2015-03-11 15:40:17 --> Model Class Initialized
DEBUG - 2015-03-11 15:40:17 --> Model Class Initialized
DEBUG - 2015-03-11 15:40:17 --> Model Class Initialized
DEBUG - 2015-03-11 15:40:17 --> Model Class Initialized
DEBUG - 2015-03-11 15:40:19 --> Config Class Initialized
DEBUG - 2015-03-11 15:40:19 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:40:19 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:40:19 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:40:19 --> URI Class Initialized
DEBUG - 2015-03-11 15:40:19 --> Router Class Initialized
DEBUG - 2015-03-11 15:40:19 --> Output Class Initialized
DEBUG - 2015-03-11 15:40:19 --> Security Class Initialized
DEBUG - 2015-03-11 15:40:19 --> Input Class Initialized
DEBUG - 2015-03-11 15:40:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:40:19 --> Language Class Initialized
DEBUG - 2015-03-11 15:40:19 --> Loader Class Initialized
DEBUG - 2015-03-11 15:40:19 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:40:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:40:19 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:40:19 --> Controller Class Initialized
DEBUG - 2015-03-11 15:40:19 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:40:19 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:40:19 --> Model Class Initialized
DEBUG - 2015-03-11 15:40:19 --> Model Class Initialized
DEBUG - 2015-03-11 15:42:47 --> Config Class Initialized
DEBUG - 2015-03-11 15:42:47 --> Config Class Initialized
DEBUG - 2015-03-11 15:42:47 --> Config Class Initialized
DEBUG - 2015-03-11 15:42:47 --> Config Class Initialized
DEBUG - 2015-03-11 15:42:47 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:42:47 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:42:47 --> Config Class Initialized
DEBUG - 2015-03-11 15:42:47 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:42:47 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:42:47 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:42:47 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:42:47 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:42:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:42:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:42:47 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:42:47 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:42:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:42:47 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:42:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:42:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:42:47 --> URI Class Initialized
DEBUG - 2015-03-11 15:42:47 --> URI Class Initialized
DEBUG - 2015-03-11 15:42:47 --> URI Class Initialized
DEBUG - 2015-03-11 15:42:47 --> URI Class Initialized
DEBUG - 2015-03-11 15:42:47 --> URI Class Initialized
DEBUG - 2015-03-11 15:42:47 --> Router Class Initialized
DEBUG - 2015-03-11 15:42:47 --> Router Class Initialized
DEBUG - 2015-03-11 15:42:47 --> Router Class Initialized
DEBUG - 2015-03-11 15:42:47 --> Router Class Initialized
DEBUG - 2015-03-11 15:42:47 --> Router Class Initialized
DEBUG - 2015-03-11 15:42:47 --> Output Class Initialized
DEBUG - 2015-03-11 15:42:47 --> Output Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Output Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Output Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Security Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Security Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Security Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Output Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Security Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Security Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Input Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Input Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Input Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:42:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:42:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:42:48 --> Input Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Input Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:42:48 --> Language Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:42:48 --> Language Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Language Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Language Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Language Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Loader Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Loader Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Loader Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Loader Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Loader Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:42:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:42:48 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:42:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-11 15:42:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-11 15:42:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-11 15:42:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:42:48 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Controller Class Initialized
DEBUG - 2015-03-11 15:42:48 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:42:48 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Controller Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:42:48 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:42:48 --> Controller Class Initialized
DEBUG - 2015-03-11 15:42:48 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:42:48 --> Controller Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:42:48 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:42:48 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:42:48 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:42:48 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Controller Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Model Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Model Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:42:48 --> Model Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:42:48 --> Model Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Model Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Model Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Model Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:42:48 --> Model Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Model Class Initialized
DEBUG - 2015-03-11 15:42:48 --> Model Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Config Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Config Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Config Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Config Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Config Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:51:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:51:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:51:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:51:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:51:02 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:51:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:51:02 --> URI Class Initialized
DEBUG - 2015-03-11 15:51:02 --> URI Class Initialized
DEBUG - 2015-03-11 15:51:02 --> URI Class Initialized
DEBUG - 2015-03-11 15:51:02 --> URI Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Router Class Initialized
DEBUG - 2015-03-11 15:51:02 --> URI Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Router Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Router Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Router Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Router Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Output Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Output Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Output Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Output Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Output Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Security Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Security Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Security Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Security Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Security Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Input Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:51:02 --> Input Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:51:02 --> Input Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:51:02 --> Language Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Language Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Language Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Input Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:51:02 --> Input Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Language Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:51:02 --> Language Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Loader Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Loader Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Loader Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Loader Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Loader Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:51:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:51:02 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:51:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-11 15:51:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-11 15:51:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:51:02 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:51:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:51:02 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:51:02 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:51:02 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:51:02 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Controller Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Controller Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Controller Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Controller Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:51:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:51:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:51:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:51:02 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Controller Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:51:02 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:51:02 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:51:02 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:51:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:51:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:51:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:51:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Config Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Config Class Initialized
DEBUG - 2015-03-11 15:51:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:51:46 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:51:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:51:46 --> Config Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:51:46 --> URI Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:51:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:51:46 --> Config Class Initialized
DEBUG - 2015-03-11 15:51:46 --> URI Class Initialized
DEBUG - 2015-03-11 15:51:46 --> URI Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Router Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Router Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Router Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Output Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Output Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Output Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Security Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Security Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Security Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Input Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:51:46 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Language Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:51:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:51:46 --> Input Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Input Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:51:46 --> URI Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Config Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Language Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:51:46 --> Router Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Language Class Initialized
DEBUG - 2015-03-11 15:51:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:51:46 --> URI Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Output Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Router Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Security Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Input Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Output Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:51:46 --> Language Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Security Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Input Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:51:46 --> Loader Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Language Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Loader Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Loader Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Loader Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Loader Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:51:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:51:46 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:51:46 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Controller Class Initialized
ERROR - 2015-03-11 15:51:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:51:46 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:51:46 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:51:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:51:46 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:51:46 --> Model Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Model Class Initialized
ERROR - 2015-03-11 15:51:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:51:46 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Controller Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:51:46 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Controller Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:51:46 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:51:46 --> Model Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Model Class Initialized
DEBUG - 2015-03-11 15:51:46 --> XML-RPC Class Initialized
ERROR - 2015-03-11 15:51:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:51:46 --> Controller Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:51:46 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:51:46 --> Model Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Model Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:51:46 --> Model Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Model Class Initialized
DEBUG - 2015-03-11 15:51:46 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Controller Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:51:46 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:51:46 --> Model Class Initialized
DEBUG - 2015-03-11 15:51:46 --> Model Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Config Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:52:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:52:02 --> Config Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:52:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:52:02 --> URI Class Initialized
DEBUG - 2015-03-11 15:52:02 --> URI Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Router Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Config Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:52:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:52:02 --> URI Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Config Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:52:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:52:02 --> Router Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Output Class Initialized
DEBUG - 2015-03-11 15:52:02 --> URI Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Security Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Router Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Output Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Config Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:52:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:52:02 --> Output Class Initialized
DEBUG - 2015-03-11 15:52:02 --> URI Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Security Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Router Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Security Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Output Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Input Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:52:02 --> Input Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Language Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:52:02 --> Language Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Router Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Output Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Input Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:52:02 --> Language Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Security Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Input Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:52:02 --> Security Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Loader Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Language Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Input Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:52:02 --> Language Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Loader Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Loader Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Loader Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Loader Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:52:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:52:02 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:52:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:52:02 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Controller Class Initialized
DEBUG - 2015-03-11 15:52:02 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Controller Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:52:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:52:02 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:52:02 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:52:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Model Class Initialized
ERROR - 2015-03-11 15:52:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:52:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:52:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-11 15:52:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:52:02 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Controller Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:52:02 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Controller Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:52:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:52:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:52:02 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:52:02 --> Controller Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:52:02 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:52:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:52:02 --> Model Class Initialized
DEBUG - 2015-03-11 15:56:59 --> Config Class Initialized
DEBUG - 2015-03-11 15:56:59 --> Config Class Initialized
DEBUG - 2015-03-11 15:56:59 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:56:59 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:56:59 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:56:59 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:56:59 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:56:59 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:56:59 --> Config Class Initialized
DEBUG - 2015-03-11 15:56:59 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:56:59 --> Config Class Initialized
DEBUG - 2015-03-11 15:56:59 --> URI Class Initialized
DEBUG - 2015-03-11 15:56:59 --> URI Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:57:00 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:57:00 --> Router Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Router Class Initialized
DEBUG - 2015-03-11 15:57:00 --> URI Class Initialized
DEBUG - 2015-03-11 15:56:59 --> Config Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Router Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Output Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Output Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:57:00 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:57:00 --> Security Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Security Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Output Class Initialized
DEBUG - 2015-03-11 15:57:00 --> URI Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Input Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Router Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:57:00 --> Input Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:57:00 --> Language Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Language Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Security Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Output Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Input Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:57:00 --> Security Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Language Class Initialized
DEBUG - 2015-03-11 15:57:00 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:57:00 --> Input Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:57:00 --> URI Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Language Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Router Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Loader Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Output Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Loader Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Loader Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Security Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Input Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:57:00 --> Language Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Loader Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:57:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:57:00 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:57:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-11 15:57:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:57:00 --> Loader Class Initialized
DEBUG - 2015-03-11 15:57:00 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Controller Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:57:00 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Controller Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:57:00 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:57:00 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Model Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Controller Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:57:00 --> Model Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Model Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:57:00 --> Model Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:57:00 --> Model Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Model Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:57:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:57:00 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:57:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:57:00 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Controller Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:57:00 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Controller Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:57:00 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:57:00 --> Model Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:57:00 --> Model Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Model Class Initialized
DEBUG - 2015-03-11 15:57:00 --> Model Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Config Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:57:40 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:57:40 --> Config Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Config Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:57:40 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:57:40 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:57:40 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:57:40 --> URI Class Initialized
DEBUG - 2015-03-11 15:57:40 --> URI Class Initialized
DEBUG - 2015-03-11 15:57:40 --> URI Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Router Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Output Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Router Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Config Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Security Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Output Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Config Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Router Class Initialized
DEBUG - 2015-03-11 15:57:40 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:57:40 --> Security Class Initialized
DEBUG - 2015-03-11 15:57:40 --> URI Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Output Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Input Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:57:40 --> Language Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Security Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Input Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:57:40 --> Language Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Input Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:57:40 --> Language Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Router Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:57:40 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:57:40 --> Output Class Initialized
DEBUG - 2015-03-11 15:57:40 --> URI Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Security Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Router Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Input Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:57:40 --> Language Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Output Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Security Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Loader Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Loader Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Loader Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Loader Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Input Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:57:40 --> Language Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:57:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:57:40 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:57:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:57:40 --> Loader Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:57:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:57:40 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Controller Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:57:40 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:57:40 --> Model Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Model Class Initialized
DEBUG - 2015-03-11 15:57:40 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Controller Class Initialized
DEBUG - 2015-03-11 15:57:40 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Controller Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:57:40 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:57:40 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:57:40 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:57:40 --> Model Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Model Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Model Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Model Class Initialized
ERROR - 2015-03-11 15:57:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:57:40 --> Database Driver Class Initialized
ERROR - 2015-03-11 15:57:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/nyc/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 15:57:40 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Controller Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:57:40 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Controller Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:57:40 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:57:40 --> Model Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Model Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:57:40 --> Model Class Initialized
DEBUG - 2015-03-11 15:57:40 --> Model Class Initialized
DEBUG - 2015-03-11 16:12:45 --> Config Class Initialized
DEBUG - 2015-03-11 16:12:45 --> Hooks Class Initialized
DEBUG - 2015-03-11 16:12:45 --> Utf8 Class Initialized
DEBUG - 2015-03-11 16:12:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 16:12:48 --> URI Class Initialized
DEBUG - 2015-03-11 16:12:48 --> Router Class Initialized
ERROR - 2015-03-11 16:12:48 --> 404 Page Not Found --> server
DEBUG - 2015-03-11 16:13:36 --> Config Class Initialized
DEBUG - 2015-03-11 16:13:36 --> Hooks Class Initialized
DEBUG - 2015-03-11 16:13:36 --> Utf8 Class Initialized
DEBUG - 2015-03-11 16:13:36 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 16:13:36 --> URI Class Initialized
DEBUG - 2015-03-11 16:13:36 --> Router Class Initialized
ERROR - 2015-03-11 16:13:36 --> 404 Page Not Found --> server
DEBUG - 2015-03-11 16:13:40 --> Config Class Initialized
DEBUG - 2015-03-11 16:13:40 --> Hooks Class Initialized
DEBUG - 2015-03-11 16:13:40 --> Utf8 Class Initialized
DEBUG - 2015-03-11 16:13:40 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 16:13:40 --> URI Class Initialized
DEBUG - 2015-03-11 16:13:40 --> Router Class Initialized
ERROR - 2015-03-11 16:13:40 --> 404 Page Not Found --> server
DEBUG - 2015-03-11 16:14:11 --> Config Class Initialized
DEBUG - 2015-03-11 16:14:11 --> Hooks Class Initialized
DEBUG - 2015-03-11 16:14:11 --> Utf8 Class Initialized
DEBUG - 2015-03-11 16:14:11 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 16:14:11 --> URI Class Initialized
DEBUG - 2015-03-11 16:14:11 --> Router Class Initialized
DEBUG - 2015-03-11 16:14:11 --> No URI present. Default controller set.
DEBUG - 2015-03-11 16:14:11 --> Output Class Initialized
DEBUG - 2015-03-11 16:14:11 --> Security Class Initialized
DEBUG - 2015-03-11 16:14:11 --> Input Class Initialized
DEBUG - 2015-03-11 16:14:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 16:14:11 --> Language Class Initialized
DEBUG - 2015-03-11 16:14:11 --> Loader Class Initialized
DEBUG - 2015-03-11 16:14:11 --> Database Driver Class Initialized
ERROR - 2015-03-11 16:14:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/server/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 16:14:11 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 16:14:11 --> Controller Class Initialized
DEBUG - 2015-03-11 16:14:11 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 16:14:11 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 16:14:11 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:11 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:15 --> Config Class Initialized
DEBUG - 2015-03-11 16:14:15 --> Hooks Class Initialized
DEBUG - 2015-03-11 16:14:15 --> Utf8 Class Initialized
DEBUG - 2015-03-11 16:14:15 --> Config Class Initialized
DEBUG - 2015-03-11 16:14:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 16:14:15 --> Hooks Class Initialized
DEBUG - 2015-03-11 16:14:15 --> Utf8 Class Initialized
DEBUG - 2015-03-11 16:14:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 16:14:15 --> URI Class Initialized
DEBUG - 2015-03-11 16:14:15 --> Router Class Initialized
DEBUG - 2015-03-11 16:14:15 --> URI Class Initialized
DEBUG - 2015-03-11 16:14:15 --> Router Class Initialized
DEBUG - 2015-03-11 16:14:15 --> Output Class Initialized
DEBUG - 2015-03-11 16:14:15 --> Security Class Initialized
DEBUG - 2015-03-11 16:14:15 --> Output Class Initialized
DEBUG - 2015-03-11 16:14:15 --> Input Class Initialized
DEBUG - 2015-03-11 16:14:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 16:14:15 --> Security Class Initialized
DEBUG - 2015-03-11 16:14:15 --> Language Class Initialized
DEBUG - 2015-03-11 16:14:15 --> Input Class Initialized
DEBUG - 2015-03-11 16:14:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 16:14:15 --> Language Class Initialized
DEBUG - 2015-03-11 16:14:15 --> Loader Class Initialized
DEBUG - 2015-03-11 16:14:15 --> Database Driver Class Initialized
ERROR - 2015-03-11 16:14:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/server/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 16:14:15 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 16:14:15 --> Controller Class Initialized
DEBUG - 2015-03-11 16:14:15 --> Loader Class Initialized
DEBUG - 2015-03-11 16:14:15 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 16:14:15 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 16:14:15 --> Database Driver Class Initialized
ERROR - 2015-03-11 16:14:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/server/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 16:14:15 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:15 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 16:14:16 --> Controller Class Initialized
DEBUG - 2015-03-11 16:14:16 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:16 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 16:14:16 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 16:14:16 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:16 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:16 --> Config Class Initialized
DEBUG - 2015-03-11 16:14:16 --> Config Class Initialized
DEBUG - 2015-03-11 16:14:16 --> Config Class Initialized
DEBUG - 2015-03-11 16:14:16 --> Hooks Class Initialized
DEBUG - 2015-03-11 16:14:16 --> Hooks Class Initialized
DEBUG - 2015-03-11 16:14:16 --> Hooks Class Initialized
DEBUG - 2015-03-11 16:14:17 --> Utf8 Class Initialized
DEBUG - 2015-03-11 16:14:17 --> Utf8 Class Initialized
DEBUG - 2015-03-11 16:14:17 --> Utf8 Class Initialized
DEBUG - 2015-03-11 16:14:17 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 16:14:17 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 16:14:17 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 16:14:17 --> URI Class Initialized
DEBUG - 2015-03-11 16:14:17 --> URI Class Initialized
DEBUG - 2015-03-11 16:14:17 --> URI Class Initialized
DEBUG - 2015-03-11 16:14:17 --> Router Class Initialized
DEBUG - 2015-03-11 16:14:17 --> Router Class Initialized
DEBUG - 2015-03-11 16:14:17 --> Router Class Initialized
DEBUG - 2015-03-11 16:14:17 --> Output Class Initialized
DEBUG - 2015-03-11 16:14:17 --> Output Class Initialized
DEBUG - 2015-03-11 16:14:17 --> Output Class Initialized
DEBUG - 2015-03-11 16:14:17 --> Security Class Initialized
DEBUG - 2015-03-11 16:14:17 --> Security Class Initialized
DEBUG - 2015-03-11 16:14:17 --> Security Class Initialized
DEBUG - 2015-03-11 16:14:17 --> Input Class Initialized
DEBUG - 2015-03-11 16:14:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 16:14:17 --> Input Class Initialized
DEBUG - 2015-03-11 16:14:17 --> Input Class Initialized
DEBUG - 2015-03-11 16:14:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 16:14:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 16:14:17 --> Language Class Initialized
DEBUG - 2015-03-11 16:14:17 --> Language Class Initialized
DEBUG - 2015-03-11 16:14:17 --> Language Class Initialized
DEBUG - 2015-03-11 16:14:17 --> Loader Class Initialized
DEBUG - 2015-03-11 16:14:18 --> Database Driver Class Initialized
ERROR - 2015-03-11 16:14:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/server/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 16:14:18 --> Loader Class Initialized
DEBUG - 2015-03-11 16:14:18 --> Loader Class Initialized
DEBUG - 2015-03-11 16:14:18 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 16:14:18 --> Database Driver Class Initialized
DEBUG - 2015-03-11 16:14:18 --> Controller Class Initialized
DEBUG - 2015-03-11 16:14:18 --> Database Driver Class Initialized
ERROR - 2015-03-11 16:14:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/server/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-11 16:14:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/server/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 16:14:18 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 16:14:18 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 16:14:18 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 16:14:18 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 16:14:18 --> Controller Class Initialized
DEBUG - 2015-03-11 16:14:18 --> Controller Class Initialized
DEBUG - 2015-03-11 16:14:18 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:18 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 16:14:18 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 16:14:18 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:18 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 16:14:18 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 16:14:18 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:18 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:18 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:18 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Config Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Hooks Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Utf8 Class Initialized
DEBUG - 2015-03-11 16:14:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 16:14:29 --> URI Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Router Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Config Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Hooks Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Utf8 Class Initialized
DEBUG - 2015-03-11 16:14:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 16:14:29 --> Config Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Output Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Hooks Class Initialized
DEBUG - 2015-03-11 16:14:29 --> URI Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Config Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Utf8 Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Hooks Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Router Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Security Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Utf8 Class Initialized
DEBUG - 2015-03-11 16:14:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 16:14:29 --> Input Class Initialized
DEBUG - 2015-03-11 16:14:29 --> URI Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 16:14:29 --> Output Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Language Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Router Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Security Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Output Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Input Class Initialized
DEBUG - 2015-03-11 16:14:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 16:14:29 --> Config Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Hooks Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Security Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Utf8 Class Initialized
DEBUG - 2015-03-11 16:14:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 16:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 16:14:29 --> URI Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Input Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 16:14:29 --> Language Class Initialized
DEBUG - 2015-03-11 16:14:29 --> URI Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Language Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Router Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Router Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Output Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Output Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Security Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Security Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Input Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Loader Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Loader Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Loader Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Input Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 16:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 16:14:29 --> Language Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Language Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Loader Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Loader Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Database Driver Class Initialized
ERROR - 2015-03-11 16:14:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/server/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 16:14:29 --> Database Driver Class Initialized
ERROR - 2015-03-11 16:14:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/server/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 16:14:29 --> Database Driver Class Initialized
ERROR - 2015-03-11 16:14:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/server/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 16:14:29 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Controller Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 16:14:29 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Controller Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 16:14:29 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Controller Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 16:14:29 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 16:14:29 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 16:14:29 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 16:14:29 --> Database Driver Class Initialized
DEBUG - 2015-03-11 16:14:29 --> Model Class Initialized
ERROR - 2015-03-11 16:14:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/server/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 16:14:29 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:30 --> Database Driver Class Initialized
ERROR - 2015-03-11 16:14:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/server/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 16:14:30 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 16:14:30 --> Controller Class Initialized
DEBUG - 2015-03-11 16:14:30 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 16:14:30 --> Controller Class Initialized
DEBUG - 2015-03-11 16:14:30 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 16:14:30 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 16:14:30 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 16:14:30 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:30 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 16:14:30 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:30 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:30 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Config Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Config Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Config Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Config Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Config Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Hooks Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Hooks Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Utf8 Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Utf8 Class Initialized
DEBUG - 2015-03-11 16:14:37 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 16:14:37 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 16:14:37 --> URI Class Initialized
DEBUG - 2015-03-11 16:14:37 --> URI Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Router Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Router Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Hooks Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Hooks Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Output Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Utf8 Class Initialized
DEBUG - 2015-03-11 16:14:37 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 16:14:37 --> Utf8 Class Initialized
DEBUG - 2015-03-11 16:14:37 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 16:14:37 --> Output Class Initialized
DEBUG - 2015-03-11 16:14:37 --> URI Class Initialized
DEBUG - 2015-03-11 16:14:37 --> URI Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Router Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Hooks Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Utf8 Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Router Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Output Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Security Class Initialized
DEBUG - 2015-03-11 16:14:37 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 16:14:37 --> URI Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Security Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Input Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 16:14:37 --> Output Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Language Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Input Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Router Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 16:14:37 --> Security Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Language Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Input Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Output Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 16:14:37 --> Language Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Security Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Input Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 16:14:37 --> Language Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Loader Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Loader Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Loader Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Database Driver Class Initialized
ERROR - 2015-03-11 16:14:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/server/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 16:14:37 --> Database Driver Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Loader Class Initialized
ERROR - 2015-03-11 16:14:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/server/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 16:14:37 --> Security Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Database Driver Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Input Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Database Driver Class Initialized
DEBUG - 2015-03-11 16:14:37 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 16:14:37 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Controller Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 16:14:37 --> Controller Class Initialized
ERROR - 2015-03-11 16:14:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/server/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 16:14:37 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 16:14:37 --> Language Class Initialized
ERROR - 2015-03-11 16:14:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/server/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 16:14:37 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 16:14:37 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 16:14:37 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:37 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Controller Class Initialized
DEBUG - 2015-03-11 16:14:37 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 16:14:37 --> Controller Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 16:14:37 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 16:14:37 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 16:14:37 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 16:14:37 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Loader Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Database Driver Class Initialized
ERROR - 2015-03-11 16:14:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/server/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-03-11 16:14:37 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Controller Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 16:14:37 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 16:14:37 --> Model Class Initialized
DEBUG - 2015-03-11 16:14:37 --> Model Class Initialized
DEBUG - 2015-03-11 15:26:05 --> Config Class Initialized
DEBUG - 2015-03-11 15:26:05 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:26:05 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:26:05 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:26:05 --> URI Class Initialized
DEBUG - 2015-03-11 15:26:05 --> Router Class Initialized
DEBUG - 2015-03-11 15:26:05 --> No URI present. Default controller set.
DEBUG - 2015-03-11 15:26:05 --> Output Class Initialized
DEBUG - 2015-03-11 15:26:05 --> Security Class Initialized
DEBUG - 2015-03-11 15:26:05 --> Input Class Initialized
DEBUG - 2015-03-11 15:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:26:05 --> Language Class Initialized
DEBUG - 2015-03-11 15:26:05 --> Loader Class Initialized
DEBUG - 2015-03-11 15:26:05 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:26:05 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:26:05 --> Controller Class Initialized
DEBUG - 2015-03-11 15:26:05 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:26:05 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:26:05 --> Model Class Initialized
DEBUG - 2015-03-11 15:26:05 --> Model Class Initialized
DEBUG - 2015-03-11 15:26:13 --> Config Class Initialized
DEBUG - 2015-03-11 15:26:13 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:26:13 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:26:13 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:26:14 --> URI Class Initialized
DEBUG - 2015-03-11 15:26:14 --> Router Class Initialized
DEBUG - 2015-03-11 15:26:14 --> No URI present. Default controller set.
DEBUG - 2015-03-11 15:26:14 --> Output Class Initialized
DEBUG - 2015-03-11 15:26:14 --> Security Class Initialized
DEBUG - 2015-03-11 15:26:14 --> Input Class Initialized
DEBUG - 2015-03-11 15:26:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:26:14 --> Language Class Initialized
DEBUG - 2015-03-11 15:26:14 --> Loader Class Initialized
DEBUG - 2015-03-11 15:26:14 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:26:14 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:26:14 --> Controller Class Initialized
DEBUG - 2015-03-11 15:26:14 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:26:14 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:26:14 --> Model Class Initialized
DEBUG - 2015-03-11 15:26:14 --> Model Class Initialized
DEBUG - 2015-03-11 15:26:42 --> Config Class Initialized
DEBUG - 2015-03-11 15:26:42 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:26:42 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:26:42 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:26:42 --> URI Class Initialized
DEBUG - 2015-03-11 15:26:42 --> Router Class Initialized
DEBUG - 2015-03-11 15:26:42 --> No URI present. Default controller set.
DEBUG - 2015-03-11 15:26:42 --> Output Class Initialized
DEBUG - 2015-03-11 15:26:42 --> Security Class Initialized
DEBUG - 2015-03-11 15:26:42 --> Input Class Initialized
DEBUG - 2015-03-11 15:26:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:26:42 --> Language Class Initialized
DEBUG - 2015-03-11 15:26:42 --> Loader Class Initialized
DEBUG - 2015-03-11 15:26:42 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:26:42 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:26:42 --> Controller Class Initialized
DEBUG - 2015-03-11 15:26:42 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:26:42 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:26:42 --> Model Class Initialized
DEBUG - 2015-03-11 15:26:42 --> Model Class Initialized
DEBUG - 2015-03-11 15:26:45 --> Config Class Initialized
DEBUG - 2015-03-11 15:26:45 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:26:45 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:26:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:26:45 --> URI Class Initialized
DEBUG - 2015-03-11 15:26:45 --> Router Class Initialized
DEBUG - 2015-03-11 15:26:45 --> No URI present. Default controller set.
DEBUG - 2015-03-11 15:26:45 --> Output Class Initialized
DEBUG - 2015-03-11 15:26:45 --> Security Class Initialized
DEBUG - 2015-03-11 15:26:45 --> Input Class Initialized
DEBUG - 2015-03-11 15:26:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:26:45 --> Language Class Initialized
DEBUG - 2015-03-11 15:26:45 --> Loader Class Initialized
DEBUG - 2015-03-11 15:26:45 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:26:45 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:26:45 --> Controller Class Initialized
DEBUG - 2015-03-11 15:26:45 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:26:45 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:26:45 --> Model Class Initialized
DEBUG - 2015-03-11 15:26:45 --> Model Class Initialized
DEBUG - 2015-03-11 15:26:48 --> Config Class Initialized
DEBUG - 2015-03-11 15:26:48 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:26:48 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:26:48 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:26:48 --> URI Class Initialized
DEBUG - 2015-03-11 15:26:48 --> Router Class Initialized
DEBUG - 2015-03-11 15:26:48 --> No URI present. Default controller set.
DEBUG - 2015-03-11 15:26:48 --> Output Class Initialized
DEBUG - 2015-03-11 15:26:48 --> Security Class Initialized
DEBUG - 2015-03-11 15:26:48 --> Input Class Initialized
DEBUG - 2015-03-11 15:26:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:26:48 --> Language Class Initialized
DEBUG - 2015-03-11 15:26:48 --> Loader Class Initialized
DEBUG - 2015-03-11 15:26:48 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:26:48 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:26:48 --> Controller Class Initialized
DEBUG - 2015-03-11 15:26:48 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:26:48 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:26:48 --> Model Class Initialized
DEBUG - 2015-03-11 15:26:48 --> Model Class Initialized
DEBUG - 2015-03-11 15:26:56 --> Config Class Initialized
DEBUG - 2015-03-11 15:26:56 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:26:56 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:26:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:26:56 --> URI Class Initialized
DEBUG - 2015-03-11 15:26:56 --> Router Class Initialized
DEBUG - 2015-03-11 15:26:56 --> Output Class Initialized
DEBUG - 2015-03-11 15:26:56 --> Security Class Initialized
DEBUG - 2015-03-11 15:26:56 --> Input Class Initialized
DEBUG - 2015-03-11 15:26:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:26:56 --> Language Class Initialized
DEBUG - 2015-03-11 15:26:56 --> Loader Class Initialized
DEBUG - 2015-03-11 15:26:56 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:26:56 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:26:56 --> Controller Class Initialized
DEBUG - 2015-03-11 15:26:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:26:56 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:26:56 --> Model Class Initialized
DEBUG - 2015-03-11 15:26:56 --> Model Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Config Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:28:04 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:28:04 --> URI Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Router Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Config Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:28:04 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:28:04 --> URI Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Router Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Output Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Security Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Input Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:28:04 --> Language Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Output Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Security Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Input Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:28:04 --> Language Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Loader Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Loader Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:28:04 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Controller Class Initialized
DEBUG - 2015-03-11 15:28:04 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Controller Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:28:04 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:28:04 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:28:04 --> Model Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:28:04 --> Model Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Model Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Model Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Config Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:28:04 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:28:04 --> URI Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Router Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Output Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Security Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Input Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:28:04 --> Language Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Config Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:28:04 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:28:04 --> URI Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Router Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Loader Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Config Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Hooks Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Utf8 Class Initialized
DEBUG - 2015-03-11 15:28:04 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 15:28:04 --> Output Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Security Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Input Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:28:04 --> Language Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:28:04 --> URI Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Router Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Output Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Security Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Input Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 15:28:04 --> Language Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Loader Class Initialized
DEBUG - 2015-03-11 15:28:04 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Controller Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:28:04 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:28:04 --> Model Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Loader Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Model Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Database Driver Class Initialized
DEBUG - 2015-03-11 15:28:04 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Controller Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:28:04 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:28:04 --> Model Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Model Class Initialized
DEBUG - 2015-03-11 15:28:04 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Controller Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 15:28:04 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 15:28:04 --> Model Class Initialized
DEBUG - 2015-03-11 15:28:04 --> Model Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Config Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Hooks Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Config Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Hooks Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Utf8 Class Initialized
DEBUG - 2015-03-11 18:21:12 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 18:21:12 --> Config Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Hooks Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Utf8 Class Initialized
DEBUG - 2015-03-11 18:21:12 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 18:21:12 --> URI Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Config Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Hooks Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Utf8 Class Initialized
DEBUG - 2015-03-11 18:21:12 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 18:21:12 --> URI Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Router Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Utf8 Class Initialized
DEBUG - 2015-03-11 18:21:12 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 18:21:12 --> URI Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Router Class Initialized
DEBUG - 2015-03-11 18:21:12 --> URI Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Router Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Router Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Config Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Hooks Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Utf8 Class Initialized
DEBUG - 2015-03-11 18:21:12 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 18:21:12 --> URI Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Router Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Output Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Output Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Output Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Security Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Output Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Security Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Security Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Input Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 18:21:12 --> Security Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Input Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 18:21:12 --> Input Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Language Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 18:21:12 --> Language Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Input Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 18:21:12 --> Language Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Language Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Output Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Security Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Input Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 18:21:12 --> Language Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Loader Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Loader Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Loader Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Loader Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Loader Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Database Driver Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Database Driver Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Database Driver Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Database Driver Class Initialized
DEBUG - 2015-03-11 18:21:12 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Controller Class Initialized
DEBUG - 2015-03-11 18:21:12 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Controller Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 18:21:12 --> Database Driver Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 18:21:12 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Controller Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 18:21:12 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 18:21:12 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Controller Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 18:21:12 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 18:21:12 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 18:21:12 --> Model Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 18:21:12 --> Model Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Model Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Model Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Model Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Model Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Model Class Initialized
DEBUG - 2015-03-11 18:21:12 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Controller Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 18:21:12 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 18:21:12 --> Model Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Model Class Initialized
DEBUG - 2015-03-11 18:21:12 --> Model Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Config Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Hooks Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Config Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Hooks Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Config Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Hooks Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Config Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Hooks Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Config Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Hooks Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Utf8 Class Initialized
DEBUG - 2015-03-11 19:04:18 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 19:04:18 --> Utf8 Class Initialized
DEBUG - 2015-03-11 19:04:18 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 19:04:18 --> URI Class Initialized
DEBUG - 2015-03-11 19:04:18 --> URI Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Router Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Utf8 Class Initialized
DEBUG - 2015-03-11 19:04:18 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 19:04:18 --> Utf8 Class Initialized
DEBUG - 2015-03-11 19:04:18 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 19:04:18 --> URI Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Router Class Initialized
DEBUG - 2015-03-11 19:04:18 --> URI Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Router Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Router Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Utf8 Class Initialized
DEBUG - 2015-03-11 19:04:18 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 19:04:18 --> Output Class Initialized
DEBUG - 2015-03-11 19:04:18 --> URI Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Output Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Security Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Security Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Input Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 19:04:18 --> Output Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Security Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Output Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Security Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Language Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Router Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Input Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 19:04:18 --> Language Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Input Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 19:04:18 --> Language Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Input Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 19:04:18 --> Language Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Output Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Security Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Input Class Initialized
DEBUG - 2015-03-11 19:04:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 19:04:18 --> Language Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Loader Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Loader Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Loader Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Loader Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Loader Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Database Driver Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Database Driver Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Database Driver Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Database Driver Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Database Driver Class Initialized
DEBUG - 2015-03-11 19:04:19 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Controller Class Initialized
DEBUG - 2015-03-11 19:04:19 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Controller Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 19:04:19 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Controller Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 19:04:19 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 19:04:19 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Controller Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 19:04:19 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Controller Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 19:04:19 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 19:04:19 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 19:04:19 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 19:04:19 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 19:04:19 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 19:04:19 --> Model Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Model Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Model Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Model Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Model Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Model Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Model Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Model Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Model Class Initialized
DEBUG - 2015-03-11 19:04:19 --> Model Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Config Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Hooks Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Utf8 Class Initialized
DEBUG - 2015-03-11 19:04:39 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 19:04:39 --> URI Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Router Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Output Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Security Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Input Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 19:04:39 --> Language Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Loader Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Database Driver Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Config Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Hooks Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Utf8 Class Initialized
DEBUG - 2015-03-11 19:04:39 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 19:04:39 --> URI Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Router Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Output Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Security Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Input Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 19:04:39 --> Language Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Loader Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Database Driver Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Config Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Hooks Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Utf8 Class Initialized
DEBUG - 2015-03-11 19:04:39 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 19:04:39 --> URI Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Router Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Output Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Security Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Input Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 19:04:39 --> Language Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Loader Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Database Driver Class Initialized
DEBUG - 2015-03-11 19:04:39 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Controller Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 19:04:39 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 19:04:39 --> Model Class Initialized
DEBUG - 2015-03-11 19:04:39 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Controller Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 19:04:39 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 19:04:39 --> Model Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Model Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Model Class Initialized
DEBUG - 2015-03-11 19:04:39 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Controller Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 19:04:39 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 19:04:39 --> Model Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Model Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Config Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Hooks Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Utf8 Class Initialized
DEBUG - 2015-03-11 19:04:39 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 19:04:39 --> URI Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Router Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Output Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Security Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Input Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 19:04:39 --> Language Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Loader Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Database Driver Class Initialized
DEBUG - 2015-03-11 19:04:39 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Controller Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 19:04:39 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 19:04:39 --> Model Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Model Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Config Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Hooks Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Utf8 Class Initialized
DEBUG - 2015-03-11 19:04:39 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 19:04:39 --> URI Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Router Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Output Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Security Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Input Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 19:04:39 --> Language Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Loader Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Database Driver Class Initialized
DEBUG - 2015-03-11 19:04:39 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Controller Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 19:04:39 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 19:04:39 --> Model Class Initialized
DEBUG - 2015-03-11 19:04:39 --> Model Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Config Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Hooks Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Utf8 Class Initialized
DEBUG - 2015-03-11 19:05:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 19:05:47 --> URI Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Router Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Output Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Security Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Input Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 19:05:47 --> Language Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Loader Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Database Driver Class Initialized
DEBUG - 2015-03-11 19:05:47 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Controller Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 19:05:47 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 19:05:47 --> Model Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Model Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Config Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Hooks Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Utf8 Class Initialized
DEBUG - 2015-03-11 19:05:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 19:05:47 --> URI Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Router Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Output Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Security Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Input Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 19:05:47 --> Language Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Loader Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Database Driver Class Initialized
DEBUG - 2015-03-11 19:05:47 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Controller Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 19:05:47 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 19:05:47 --> Model Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Model Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Config Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Hooks Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Utf8 Class Initialized
DEBUG - 2015-03-11 19:05:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 19:05:47 --> URI Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Router Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Output Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Security Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Input Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 19:05:47 --> Language Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Loader Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Database Driver Class Initialized
DEBUG - 2015-03-11 19:05:47 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Controller Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Config Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Hooks Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Utf8 Class Initialized
DEBUG - 2015-03-11 19:05:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 19:05:47 --> URI Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Router Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Output Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Security Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Input Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 19:05:47 --> Language Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Loader Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Database Driver Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 19:05:47 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 19:05:47 --> Model Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Model Class Initialized
DEBUG - 2015-03-11 19:05:47 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Controller Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 19:05:47 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 19:05:47 --> Model Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Model Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Config Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Hooks Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Utf8 Class Initialized
DEBUG - 2015-03-11 19:05:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 19:05:47 --> URI Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Router Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Output Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Security Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Input Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 19:05:47 --> Language Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Loader Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Database Driver Class Initialized
DEBUG - 2015-03-11 19:05:47 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Controller Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 19:05:47 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 19:05:47 --> Model Class Initialized
DEBUG - 2015-03-11 19:05:47 --> Model Class Initialized
DEBUG - 2015-03-11 19:06:27 --> Config Class Initialized
DEBUG - 2015-03-11 19:06:27 --> Hooks Class Initialized
DEBUG - 2015-03-11 19:06:27 --> Utf8 Class Initialized
DEBUG - 2015-03-11 19:06:27 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 19:06:27 --> URI Class Initialized
DEBUG - 2015-03-11 19:06:27 --> Router Class Initialized
DEBUG - 2015-03-11 19:06:27 --> Output Class Initialized
DEBUG - 2015-03-11 19:06:27 --> Security Class Initialized
DEBUG - 2015-03-11 19:06:27 --> Input Class Initialized
DEBUG - 2015-03-11 19:06:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 19:06:27 --> Language Class Initialized
DEBUG - 2015-03-11 19:06:27 --> Loader Class Initialized
DEBUG - 2015-03-11 19:06:27 --> Database Driver Class Initialized
DEBUG - 2015-03-11 19:06:27 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 19:06:27 --> Controller Class Initialized
DEBUG - 2015-03-11 19:06:27 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 19:06:27 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 19:06:27 --> Model Class Initialized
DEBUG - 2015-03-11 19:06:27 --> Model Class Initialized
DEBUG - 2015-03-11 19:06:28 --> Config Class Initialized
DEBUG - 2015-03-11 19:06:28 --> Hooks Class Initialized
DEBUG - 2015-03-11 19:06:28 --> Utf8 Class Initialized
DEBUG - 2015-03-11 19:06:28 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 19:06:28 --> URI Class Initialized
DEBUG - 2015-03-11 19:06:28 --> Router Class Initialized
DEBUG - 2015-03-11 19:06:28 --> Output Class Initialized
DEBUG - 2015-03-11 19:06:28 --> Security Class Initialized
DEBUG - 2015-03-11 19:06:28 --> Input Class Initialized
DEBUG - 2015-03-11 19:06:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 19:06:28 --> Language Class Initialized
DEBUG - 2015-03-11 19:06:28 --> Loader Class Initialized
DEBUG - 2015-03-11 19:06:28 --> Database Driver Class Initialized
DEBUG - 2015-03-11 19:06:28 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 19:06:28 --> Controller Class Initialized
DEBUG - 2015-03-11 19:06:28 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 19:06:28 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 19:06:28 --> Model Class Initialized
DEBUG - 2015-03-11 19:06:28 --> Model Class Initialized
DEBUG - 2015-03-11 19:06:37 --> Config Class Initialized
DEBUG - 2015-03-11 19:06:37 --> Hooks Class Initialized
DEBUG - 2015-03-11 19:06:37 --> Utf8 Class Initialized
DEBUG - 2015-03-11 19:06:37 --> UTF-8 Support Enabled
DEBUG - 2015-03-11 19:06:37 --> URI Class Initialized
DEBUG - 2015-03-11 19:06:37 --> Router Class Initialized
DEBUG - 2015-03-11 19:06:37 --> Output Class Initialized
DEBUG - 2015-03-11 19:06:37 --> Security Class Initialized
DEBUG - 2015-03-11 19:06:37 --> Input Class Initialized
DEBUG - 2015-03-11 19:06:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-11 19:06:37 --> Language Class Initialized
DEBUG - 2015-03-11 19:06:37 --> Loader Class Initialized
DEBUG - 2015-03-11 19:06:37 --> Database Driver Class Initialized
DEBUG - 2015-03-11 19:06:37 --> XML-RPC Class Initialized
DEBUG - 2015-03-11 19:06:37 --> Controller Class Initialized
DEBUG - 2015-03-11 19:06:37 --> Config file loaded: application/config/rest.php
DEBUG - 2015-03-11 19:06:37 --> Helper loaded: inflector_helper
DEBUG - 2015-03-11 19:06:37 --> Model Class Initialized
DEBUG - 2015-03-11 19:06:37 --> Model Class Initialized
