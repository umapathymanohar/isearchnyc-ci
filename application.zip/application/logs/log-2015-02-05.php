<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-02-05 14:08:07 --> Config Class Initialized
DEBUG - 2015-02-05 14:08:07 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:08:07 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:08:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:08:07 --> URI Class Initialized
DEBUG - 2015-02-05 14:08:07 --> Router Class Initialized
ERROR - 2015-02-05 14:08:07 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-05 14:12:52 --> Config Class Initialized
DEBUG - 2015-02-05 14:12:52 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:12:52 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:12:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:12:52 --> URI Class Initialized
DEBUG - 2015-02-05 14:12:52 --> Router Class Initialized
DEBUG - 2015-02-05 14:12:52 --> Output Class Initialized
DEBUG - 2015-02-05 14:12:52 --> Security Class Initialized
DEBUG - 2015-02-05 14:12:52 --> Input Class Initialized
DEBUG - 2015-02-05 14:12:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:12:53 --> Language Class Initialized
DEBUG - 2015-02-05 14:12:53 --> Loader Class Initialized
DEBUG - 2015-02-05 14:12:53 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:12:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-02-05 14:12:53 --> Severity: Warning  --> mysql_pconnect(): Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-02-05 14:12:53 --> Unable to connect to the database
DEBUG - 2015-02-05 14:12:53 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-05 14:13:11 --> Config Class Initialized
DEBUG - 2015-02-05 14:13:11 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:13:11 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:13:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:13:11 --> URI Class Initialized
DEBUG - 2015-02-05 14:13:11 --> Router Class Initialized
DEBUG - 2015-02-05 14:13:11 --> Output Class Initialized
DEBUG - 2015-02-05 14:13:11 --> Security Class Initialized
DEBUG - 2015-02-05 14:13:11 --> Input Class Initialized
DEBUG - 2015-02-05 14:13:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:13:11 --> Language Class Initialized
DEBUG - 2015-02-05 14:13:11 --> Loader Class Initialized
DEBUG - 2015-02-05 14:13:11 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:13:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-02-05 14:13:11 --> Severity: Warning  --> mysql_pconnect(): Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-02-05 14:13:11 --> Unable to connect to the database
DEBUG - 2015-02-05 14:13:11 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-05 14:13:38 --> Config Class Initialized
DEBUG - 2015-02-05 14:13:38 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:13:38 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:13:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:13:38 --> URI Class Initialized
DEBUG - 2015-02-05 14:13:38 --> Router Class Initialized
DEBUG - 2015-02-05 14:13:38 --> Output Class Initialized
DEBUG - 2015-02-05 14:13:38 --> Security Class Initialized
DEBUG - 2015-02-05 14:13:38 --> Input Class Initialized
DEBUG - 2015-02-05 14:13:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:13:38 --> Language Class Initialized
DEBUG - 2015-02-05 14:13:38 --> Loader Class Initialized
DEBUG - 2015-02-05 14:13:38 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:13:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-02-05 14:13:38 --> Severity: Warning  --> mysql_pconnect(): Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-02-05 14:13:38 --> Unable to connect to the database
DEBUG - 2015-02-05 14:13:38 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-05 14:13:41 --> Config Class Initialized
DEBUG - 2015-02-05 14:13:41 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:13:41 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:13:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:13:41 --> URI Class Initialized
DEBUG - 2015-02-05 14:13:41 --> Router Class Initialized
DEBUG - 2015-02-05 14:13:41 --> Output Class Initialized
DEBUG - 2015-02-05 14:13:41 --> Security Class Initialized
DEBUG - 2015-02-05 14:13:41 --> Input Class Initialized
DEBUG - 2015-02-05 14:13:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:13:41 --> Language Class Initialized
DEBUG - 2015-02-05 14:13:41 --> Loader Class Initialized
DEBUG - 2015-02-05 14:13:41 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:13:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-02-05 14:13:41 --> Severity: Warning  --> mysql_pconnect(): Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-02-05 14:13:41 --> Unable to connect to the database
DEBUG - 2015-02-05 14:13:41 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-05 14:13:47 --> Config Class Initialized
DEBUG - 2015-02-05 14:13:47 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:13:47 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:13:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:13:47 --> URI Class Initialized
DEBUG - 2015-02-05 14:13:47 --> Router Class Initialized
DEBUG - 2015-02-05 14:13:47 --> Output Class Initialized
DEBUG - 2015-02-05 14:13:47 --> Security Class Initialized
DEBUG - 2015-02-05 14:13:47 --> Input Class Initialized
DEBUG - 2015-02-05 14:13:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:13:47 --> Language Class Initialized
DEBUG - 2015-02-05 14:13:47 --> Loader Class Initialized
DEBUG - 2015-02-05 14:13:47 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:13:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-02-05 14:13:47 --> Severity: Warning  --> mysql_pconnect(): Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-02-05 14:13:47 --> Unable to connect to the database
DEBUG - 2015-02-05 14:13:47 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-05 14:14:17 --> Config Class Initialized
DEBUG - 2015-02-05 14:14:17 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:14:17 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:14:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:14:17 --> URI Class Initialized
DEBUG - 2015-02-05 14:14:17 --> Router Class Initialized
DEBUG - 2015-02-05 14:14:17 --> Output Class Initialized
DEBUG - 2015-02-05 14:14:17 --> Security Class Initialized
DEBUG - 2015-02-05 14:14:17 --> Input Class Initialized
DEBUG - 2015-02-05 14:14:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:14:17 --> Language Class Initialized
DEBUG - 2015-02-05 14:14:17 --> Loader Class Initialized
DEBUG - 2015-02-05 14:14:17 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:14:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:14:17 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:14:17 --> Controller Class Initialized
DEBUG - 2015-02-05 14:14:17 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:14:18 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:14:18 --> Model Class Initialized
DEBUG - 2015-02-05 14:14:18 --> Model Class Initialized
DEBUG - 2015-02-05 14:14:22 --> Config Class Initialized
DEBUG - 2015-02-05 14:14:22 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:14:22 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:14:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:14:22 --> URI Class Initialized
DEBUG - 2015-02-05 14:14:22 --> Router Class Initialized
DEBUG - 2015-02-05 14:14:22 --> Output Class Initialized
DEBUG - 2015-02-05 14:14:22 --> Security Class Initialized
DEBUG - 2015-02-05 14:14:22 --> Input Class Initialized
DEBUG - 2015-02-05 14:14:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:14:22 --> Language Class Initialized
DEBUG - 2015-02-05 14:14:22 --> Loader Class Initialized
DEBUG - 2015-02-05 14:14:22 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:14:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:14:22 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:14:22 --> Controller Class Initialized
DEBUG - 2015-02-05 14:14:22 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:14:22 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:14:22 --> Model Class Initialized
DEBUG - 2015-02-05 14:14:22 --> Model Class Initialized
DEBUG - 2015-02-05 14:14:22 --> File loaded: application/views/email/registration.php
DEBUG - 2015-02-05 14:14:22 --> Email Class Initialized
DEBUG - 2015-02-05 14:14:25 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-05 14:14:30 --> Config Class Initialized
DEBUG - 2015-02-05 14:14:30 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:14:30 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:14:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:14:30 --> URI Class Initialized
DEBUG - 2015-02-05 14:14:30 --> Router Class Initialized
DEBUG - 2015-02-05 14:14:30 --> Output Class Initialized
DEBUG - 2015-02-05 14:14:30 --> Security Class Initialized
DEBUG - 2015-02-05 14:14:30 --> Input Class Initialized
DEBUG - 2015-02-05 14:14:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:14:30 --> Language Class Initialized
DEBUG - 2015-02-05 14:14:30 --> Loader Class Initialized
DEBUG - 2015-02-05 14:14:30 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:14:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:14:30 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:14:30 --> Controller Class Initialized
DEBUG - 2015-02-05 14:14:30 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:14:30 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:14:30 --> Model Class Initialized
DEBUG - 2015-02-05 14:14:30 --> Model Class Initialized
DEBUG - 2015-02-05 14:14:35 --> Config Class Initialized
DEBUG - 2015-02-05 14:14:35 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:14:35 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:14:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:14:35 --> URI Class Initialized
DEBUG - 2015-02-05 14:14:35 --> Router Class Initialized
ERROR - 2015-02-05 14:14:35 --> 404 Page Not Found --> api/user
DEBUG - 2015-02-05 14:15:03 --> Config Class Initialized
DEBUG - 2015-02-05 14:15:03 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:15:03 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:15:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:15:03 --> URI Class Initialized
DEBUG - 2015-02-05 14:15:03 --> Router Class Initialized
DEBUG - 2015-02-05 14:15:03 --> Output Class Initialized
DEBUG - 2015-02-05 14:15:03 --> Security Class Initialized
DEBUG - 2015-02-05 14:15:03 --> Input Class Initialized
DEBUG - 2015-02-05 14:15:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:15:03 --> Language Class Initialized
DEBUG - 2015-02-05 14:15:03 --> Loader Class Initialized
DEBUG - 2015-02-05 14:15:03 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:15:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:15:03 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:15:03 --> Controller Class Initialized
DEBUG - 2015-02-05 14:15:03 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:15:03 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:15:03 --> Model Class Initialized
DEBUG - 2015-02-05 14:15:03 --> Model Class Initialized
DEBUG - 2015-02-05 14:15:03 --> File loaded: application/views/email/registration.php
DEBUG - 2015-02-05 14:15:03 --> Email Class Initialized
DEBUG - 2015-02-05 14:15:04 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-05 14:15:06 --> DB Transaction Failure
ERROR - 2015-02-05 14:15:06 --> Query error: Table 'thunderbirds.admin_users' doesn't exist
DEBUG - 2015-02-05 14:15:06 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-05 14:15:34 --> Config Class Initialized
DEBUG - 2015-02-05 14:15:34 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:15:34 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:15:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:15:34 --> URI Class Initialized
DEBUG - 2015-02-05 14:15:34 --> Router Class Initialized
DEBUG - 2015-02-05 14:15:34 --> Output Class Initialized
DEBUG - 2015-02-05 14:15:34 --> Security Class Initialized
DEBUG - 2015-02-05 14:15:34 --> Input Class Initialized
DEBUG - 2015-02-05 14:15:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:15:34 --> Language Class Initialized
DEBUG - 2015-02-05 14:15:34 --> Loader Class Initialized
DEBUG - 2015-02-05 14:15:34 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:15:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:15:34 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:15:34 --> Controller Class Initialized
DEBUG - 2015-02-05 14:15:34 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:15:34 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:15:34 --> Model Class Initialized
DEBUG - 2015-02-05 14:15:34 --> Model Class Initialized
DEBUG - 2015-02-05 14:16:00 --> Config Class Initialized
DEBUG - 2015-02-05 14:16:00 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:16:00 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:16:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:16:00 --> URI Class Initialized
DEBUG - 2015-02-05 14:16:00 --> Router Class Initialized
DEBUG - 2015-02-05 14:16:00 --> Output Class Initialized
DEBUG - 2015-02-05 14:16:00 --> Security Class Initialized
DEBUG - 2015-02-05 14:16:00 --> Input Class Initialized
DEBUG - 2015-02-05 14:16:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:16:00 --> Language Class Initialized
DEBUG - 2015-02-05 14:16:00 --> Loader Class Initialized
DEBUG - 2015-02-05 14:16:00 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:16:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:16:00 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:16:00 --> Controller Class Initialized
DEBUG - 2015-02-05 14:16:00 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:16:00 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:16:00 --> Model Class Initialized
DEBUG - 2015-02-05 14:16:00 --> Model Class Initialized
DEBUG - 2015-02-05 14:16:00 --> File loaded: application/views/email/registration.php
DEBUG - 2015-02-05 14:16:00 --> Email Class Initialized
DEBUG - 2015-02-05 14:16:01 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-05 14:16:02 --> DB Transaction Failure
ERROR - 2015-02-05 14:16:02 --> Query error: Table 'thunderbirds.admin_users' doesn't exist
DEBUG - 2015-02-05 14:16:02 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-05 14:16:24 --> Config Class Initialized
DEBUG - 2015-02-05 14:16:24 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:16:24 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:16:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:16:24 --> URI Class Initialized
DEBUG - 2015-02-05 14:16:25 --> Router Class Initialized
DEBUG - 2015-02-05 14:16:25 --> Output Class Initialized
DEBUG - 2015-02-05 14:16:25 --> Security Class Initialized
DEBUG - 2015-02-05 14:16:25 --> Input Class Initialized
DEBUG - 2015-02-05 14:16:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:16:25 --> Language Class Initialized
DEBUG - 2015-02-05 14:16:25 --> Loader Class Initialized
DEBUG - 2015-02-05 14:16:25 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:16:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:16:25 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:16:25 --> Controller Class Initialized
DEBUG - 2015-02-05 14:16:25 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:16:25 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:16:25 --> Model Class Initialized
DEBUG - 2015-02-05 14:16:25 --> Model Class Initialized
DEBUG - 2015-02-05 14:16:52 --> Config Class Initialized
DEBUG - 2015-02-05 14:16:52 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:16:52 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:16:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:16:52 --> URI Class Initialized
DEBUG - 2015-02-05 14:16:52 --> Router Class Initialized
DEBUG - 2015-02-05 14:16:52 --> Output Class Initialized
DEBUG - 2015-02-05 14:16:52 --> Security Class Initialized
DEBUG - 2015-02-05 14:16:52 --> Input Class Initialized
DEBUG - 2015-02-05 14:16:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:16:52 --> Language Class Initialized
DEBUG - 2015-02-05 14:16:52 --> Loader Class Initialized
DEBUG - 2015-02-05 14:16:52 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:16:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:16:52 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:16:52 --> Controller Class Initialized
DEBUG - 2015-02-05 14:16:52 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:16:52 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:16:52 --> Model Class Initialized
DEBUG - 2015-02-05 14:16:52 --> Model Class Initialized
DEBUG - 2015-02-05 14:16:52 --> File loaded: application/views/email/registration.php
DEBUG - 2015-02-05 14:16:52 --> Email Class Initialized
DEBUG - 2015-02-05 14:16:53 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-05 14:17:12 --> Config Class Initialized
DEBUG - 2015-02-05 14:17:12 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:17:12 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:17:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:17:12 --> URI Class Initialized
DEBUG - 2015-02-05 14:17:12 --> Router Class Initialized
DEBUG - 2015-02-05 14:17:12 --> Output Class Initialized
DEBUG - 2015-02-05 14:17:12 --> Security Class Initialized
DEBUG - 2015-02-05 14:17:12 --> Input Class Initialized
DEBUG - 2015-02-05 14:17:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:17:12 --> Language Class Initialized
DEBUG - 2015-02-05 14:17:12 --> Loader Class Initialized
DEBUG - 2015-02-05 14:17:12 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:17:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:17:12 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:17:12 --> Controller Class Initialized
DEBUG - 2015-02-05 14:17:12 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:17:12 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:17:12 --> Model Class Initialized
DEBUG - 2015-02-05 14:17:12 --> Model Class Initialized
DEBUG - 2015-02-05 14:17:12 --> DB Transaction Failure
ERROR - 2015-02-05 14:17:12 --> Query error: Table 'thunderbirds.admin_users' doesn't exist
DEBUG - 2015-02-05 14:17:12 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-05 14:18:09 --> Config Class Initialized
DEBUG - 2015-02-05 14:18:09 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:18:09 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:18:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:18:09 --> URI Class Initialized
DEBUG - 2015-02-05 14:18:09 --> Router Class Initialized
DEBUG - 2015-02-05 14:18:09 --> Output Class Initialized
DEBUG - 2015-02-05 14:18:09 --> Security Class Initialized
DEBUG - 2015-02-05 14:18:09 --> Input Class Initialized
DEBUG - 2015-02-05 14:18:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:18:09 --> Language Class Initialized
DEBUG - 2015-02-05 14:18:09 --> Loader Class Initialized
DEBUG - 2015-02-05 14:18:09 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:18:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:18:09 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:18:09 --> Controller Class Initialized
DEBUG - 2015-02-05 14:18:09 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:18:09 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:18:09 --> Model Class Initialized
DEBUG - 2015-02-05 14:18:09 --> Model Class Initialized
DEBUG - 2015-02-05 14:18:10 --> DB Transaction Failure
ERROR - 2015-02-05 14:18:10 --> Query error: Table 'thunderbirds.admin_users' doesn't exist
DEBUG - 2015-02-05 14:18:10 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-05 14:20:24 --> Config Class Initialized
DEBUG - 2015-02-05 14:20:24 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:20:24 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:20:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:20:24 --> URI Class Initialized
DEBUG - 2015-02-05 14:20:24 --> Router Class Initialized
DEBUG - 2015-02-05 14:20:24 --> Output Class Initialized
DEBUG - 2015-02-05 14:20:24 --> Security Class Initialized
DEBUG - 2015-02-05 14:20:24 --> Input Class Initialized
DEBUG - 2015-02-05 14:20:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:20:24 --> Language Class Initialized
DEBUG - 2015-02-05 14:20:24 --> Loader Class Initialized
DEBUG - 2015-02-05 14:20:24 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:20:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:20:24 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:20:24 --> Controller Class Initialized
DEBUG - 2015-02-05 14:20:24 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:20:24 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:20:24 --> Model Class Initialized
DEBUG - 2015-02-05 14:20:24 --> Model Class Initialized
DEBUG - 2015-02-05 14:20:25 --> DB Transaction Failure
ERROR - 2015-02-05 14:20:25 --> Query error: Unknown column 'username' in 'field list'
DEBUG - 2015-02-05 14:20:25 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-05 14:20:58 --> Config Class Initialized
DEBUG - 2015-02-05 14:20:58 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:20:58 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:20:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:20:58 --> URI Class Initialized
DEBUG - 2015-02-05 14:20:58 --> Router Class Initialized
DEBUG - 2015-02-05 14:20:58 --> Output Class Initialized
DEBUG - 2015-02-05 14:20:58 --> Security Class Initialized
DEBUG - 2015-02-05 14:20:58 --> Input Class Initialized
DEBUG - 2015-02-05 14:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:20:58 --> Language Class Initialized
DEBUG - 2015-02-05 14:20:58 --> Loader Class Initialized
DEBUG - 2015-02-05 14:20:58 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:20:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:20:58 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:20:58 --> Controller Class Initialized
DEBUG - 2015-02-05 14:20:58 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:20:58 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:20:58 --> Model Class Initialized
DEBUG - 2015-02-05 14:20:58 --> Model Class Initialized
DEBUG - 2015-02-05 14:21:05 --> Config Class Initialized
DEBUG - 2015-02-05 14:21:05 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:21:05 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:21:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:21:05 --> URI Class Initialized
DEBUG - 2015-02-05 14:21:05 --> Router Class Initialized
DEBUG - 2015-02-05 14:21:05 --> Output Class Initialized
DEBUG - 2015-02-05 14:21:05 --> Security Class Initialized
DEBUG - 2015-02-05 14:21:05 --> Input Class Initialized
DEBUG - 2015-02-05 14:21:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:21:05 --> Language Class Initialized
DEBUG - 2015-02-05 14:21:05 --> Loader Class Initialized
DEBUG - 2015-02-05 14:21:05 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:21:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:21:05 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:21:05 --> Controller Class Initialized
DEBUG - 2015-02-05 14:21:05 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:21:05 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:21:05 --> Model Class Initialized
DEBUG - 2015-02-05 14:21:05 --> Model Class Initialized
DEBUG - 2015-02-05 14:21:16 --> Config Class Initialized
DEBUG - 2015-02-05 14:21:16 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:21:16 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:21:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:21:16 --> URI Class Initialized
DEBUG - 2015-02-05 14:21:16 --> Router Class Initialized
DEBUG - 2015-02-05 14:21:16 --> Output Class Initialized
DEBUG - 2015-02-05 14:21:16 --> Security Class Initialized
DEBUG - 2015-02-05 14:21:16 --> Input Class Initialized
DEBUG - 2015-02-05 14:21:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:21:16 --> Language Class Initialized
DEBUG - 2015-02-05 14:21:16 --> Loader Class Initialized
DEBUG - 2015-02-05 14:21:16 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:21:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:21:16 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:21:16 --> Controller Class Initialized
DEBUG - 2015-02-05 14:21:16 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:21:16 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:21:16 --> Model Class Initialized
DEBUG - 2015-02-05 14:21:16 --> Model Class Initialized
DEBUG - 2015-02-05 14:21:25 --> Config Class Initialized
DEBUG - 2015-02-05 14:21:25 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:21:25 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:21:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:21:25 --> URI Class Initialized
DEBUG - 2015-02-05 14:21:25 --> Router Class Initialized
ERROR - 2015-02-05 14:21:25 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-05 14:21:49 --> Config Class Initialized
DEBUG - 2015-02-05 14:21:49 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:21:49 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:21:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:21:49 --> URI Class Initialized
DEBUG - 2015-02-05 14:21:49 --> Router Class Initialized
ERROR - 2015-02-05 14:21:49 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-05 14:23:10 --> Config Class Initialized
DEBUG - 2015-02-05 14:23:10 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:23:10 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:23:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:23:10 --> URI Class Initialized
DEBUG - 2015-02-05 14:23:10 --> Router Class Initialized
ERROR - 2015-02-05 14:23:10 --> 404 Page Not Found --> api/create_collectible
DEBUG - 2015-02-05 14:23:35 --> Config Class Initialized
DEBUG - 2015-02-05 14:23:35 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:23:35 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:23:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:23:35 --> URI Class Initialized
DEBUG - 2015-02-05 14:23:35 --> Router Class Initialized
ERROR - 2015-02-05 14:23:35 --> 404 Page Not Found --> api/collectible
DEBUG - 2015-02-05 14:23:52 --> Config Class Initialized
DEBUG - 2015-02-05 14:23:52 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:23:52 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:23:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:23:52 --> URI Class Initialized
DEBUG - 2015-02-05 14:23:52 --> Router Class Initialized
DEBUG - 2015-02-05 14:23:52 --> Output Class Initialized
DEBUG - 2015-02-05 14:23:52 --> Security Class Initialized
DEBUG - 2015-02-05 14:23:52 --> Input Class Initialized
DEBUG - 2015-02-05 14:23:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:23:52 --> Language Class Initialized
DEBUG - 2015-02-05 14:23:52 --> Loader Class Initialized
DEBUG - 2015-02-05 14:23:52 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:23:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:23:52 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:23:52 --> Controller Class Initialized
DEBUG - 2015-02-05 14:23:52 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:23:52 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:23:52 --> Model Class Initialized
DEBUG - 2015-02-05 14:23:52 --> Model Class Initialized
DEBUG - 2015-02-05 14:23:52 --> DB Transaction Failure
ERROR - 2015-02-05 14:23:52 --> Query error: Table 'thunderbirds.collectible' doesn't exist
DEBUG - 2015-02-05 14:23:52 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-05 14:24:38 --> Config Class Initialized
DEBUG - 2015-02-05 14:24:38 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:24:38 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:24:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:24:38 --> URI Class Initialized
DEBUG - 2015-02-05 14:24:38 --> Router Class Initialized
DEBUG - 2015-02-05 14:24:38 --> Output Class Initialized
DEBUG - 2015-02-05 14:24:38 --> Security Class Initialized
DEBUG - 2015-02-05 14:24:38 --> Input Class Initialized
DEBUG - 2015-02-05 14:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:24:38 --> Language Class Initialized
DEBUG - 2015-02-05 14:24:38 --> Loader Class Initialized
DEBUG - 2015-02-05 14:24:38 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:24:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:24:38 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:24:38 --> Controller Class Initialized
DEBUG - 2015-02-05 14:24:38 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:24:38 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:24:38 --> Model Class Initialized
DEBUG - 2015-02-05 14:24:38 --> Model Class Initialized
DEBUG - 2015-02-05 14:30:31 --> Config Class Initialized
DEBUG - 2015-02-05 14:30:31 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:30:31 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:30:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:30:31 --> URI Class Initialized
DEBUG - 2015-02-05 14:30:31 --> Router Class Initialized
DEBUG - 2015-02-05 14:30:31 --> Output Class Initialized
DEBUG - 2015-02-05 14:30:31 --> Security Class Initialized
DEBUG - 2015-02-05 14:30:31 --> Input Class Initialized
DEBUG - 2015-02-05 14:30:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:30:31 --> Language Class Initialized
DEBUG - 2015-02-05 14:30:31 --> Loader Class Initialized
DEBUG - 2015-02-05 14:30:31 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:30:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:30:31 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:30:31 --> Controller Class Initialized
DEBUG - 2015-02-05 14:30:31 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:30:31 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:30:31 --> Model Class Initialized
DEBUG - 2015-02-05 14:30:31 --> Model Class Initialized
ERROR - 2015-02-05 14:30:31 --> Severity: Notice  --> Undefined index: collectible_id /Volumes/Data/www/thunderbirds-hub-site/server/application/models/collectible_model.php 157
ERROR - 2015-02-05 14:30:31 --> Severity: Notice  --> Undefined index: missing /Volumes/Data/www/thunderbirds-hub-site/server/application/controllers/api/collectibles.php 129
ERROR - 2015-02-05 14:30:31 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds-hub-site/server/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds-hub-site/server/application/libraries/REST_Controller.php 485
ERROR - 2015-02-05 14:30:31 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds-hub-site/server/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds-hub-site/server/system/core/Common.php 442
ERROR - 2015-02-05 14:30:31 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds-hub-site/server/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds-hub-site/server/application/libraries/REST_Controller.php 503
DEBUG - 2015-02-05 14:31:10 --> Config Class Initialized
DEBUG - 2015-02-05 14:31:10 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:31:10 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:31:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:31:10 --> URI Class Initialized
DEBUG - 2015-02-05 14:31:10 --> Router Class Initialized
DEBUG - 2015-02-05 14:31:10 --> Output Class Initialized
DEBUG - 2015-02-05 14:31:10 --> Security Class Initialized
DEBUG - 2015-02-05 14:31:10 --> Input Class Initialized
DEBUG - 2015-02-05 14:31:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:31:10 --> Language Class Initialized
DEBUG - 2015-02-05 14:31:10 --> Loader Class Initialized
DEBUG - 2015-02-05 14:31:10 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:31:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:31:10 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:31:10 --> Controller Class Initialized
DEBUG - 2015-02-05 14:31:10 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:31:10 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:31:10 --> Model Class Initialized
DEBUG - 2015-02-05 14:31:10 --> Model Class Initialized
DEBUG - 2015-02-05 14:31:15 --> Config Class Initialized
DEBUG - 2015-02-05 14:31:15 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:31:15 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:31:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:31:15 --> URI Class Initialized
DEBUG - 2015-02-05 14:31:15 --> Router Class Initialized
DEBUG - 2015-02-05 14:31:15 --> Output Class Initialized
DEBUG - 2015-02-05 14:31:15 --> Security Class Initialized
DEBUG - 2015-02-05 14:31:15 --> Input Class Initialized
DEBUG - 2015-02-05 14:31:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:31:15 --> Language Class Initialized
DEBUG - 2015-02-05 14:31:15 --> Loader Class Initialized
DEBUG - 2015-02-05 14:31:15 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:31:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:31:15 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:31:15 --> Controller Class Initialized
DEBUG - 2015-02-05 14:31:15 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:31:15 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:31:15 --> Model Class Initialized
DEBUG - 2015-02-05 14:31:15 --> Model Class Initialized
DEBUG - 2015-02-05 14:39:52 --> Config Class Initialized
DEBUG - 2015-02-05 14:39:52 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:39:52 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:39:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:39:52 --> URI Class Initialized
DEBUG - 2015-02-05 14:39:52 --> Router Class Initialized
ERROR - 2015-02-05 14:39:52 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-05 14:40:13 --> Config Class Initialized
DEBUG - 2015-02-05 14:40:13 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:40:13 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:40:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:40:13 --> URI Class Initialized
DEBUG - 2015-02-05 14:40:13 --> Router Class Initialized
DEBUG - 2015-02-05 14:40:13 --> Output Class Initialized
DEBUG - 2015-02-05 14:40:13 --> Security Class Initialized
DEBUG - 2015-02-05 14:40:13 --> Input Class Initialized
DEBUG - 2015-02-05 14:40:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:40:13 --> Language Class Initialized
DEBUG - 2015-02-05 14:40:13 --> Loader Class Initialized
DEBUG - 2015-02-05 14:40:13 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:40:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:40:13 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:40:13 --> Controller Class Initialized
DEBUG - 2015-02-05 14:40:13 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:40:13 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:40:13 --> Model Class Initialized
DEBUG - 2015-02-05 14:40:13 --> Model Class Initialized
DEBUG - 2015-02-05 14:40:13 --> DB Transaction Failure
ERROR - 2015-02-05 14:40:13 --> Query error: Table 'thunderbirds.message' doesn't exist
DEBUG - 2015-02-05 14:40:13 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-05 14:40:25 --> Config Class Initialized
DEBUG - 2015-02-05 14:40:25 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:40:25 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:40:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:40:25 --> URI Class Initialized
DEBUG - 2015-02-05 14:40:25 --> Router Class Initialized
DEBUG - 2015-02-05 14:40:25 --> Output Class Initialized
DEBUG - 2015-02-05 14:40:25 --> Security Class Initialized
DEBUG - 2015-02-05 14:40:25 --> Input Class Initialized
DEBUG - 2015-02-05 14:40:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:40:25 --> Language Class Initialized
DEBUG - 2015-02-05 14:40:25 --> Loader Class Initialized
DEBUG - 2015-02-05 14:40:25 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:40:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:40:25 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:40:25 --> Controller Class Initialized
DEBUG - 2015-02-05 14:40:25 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:40:25 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:40:25 --> Model Class Initialized
DEBUG - 2015-02-05 14:40:25 --> Model Class Initialized
DEBUG - 2015-02-05 14:40:32 --> Config Class Initialized
DEBUG - 2015-02-05 14:40:32 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:40:32 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:40:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:40:32 --> URI Class Initialized
DEBUG - 2015-02-05 14:40:32 --> Router Class Initialized
DEBUG - 2015-02-05 14:40:32 --> Output Class Initialized
DEBUG - 2015-02-05 14:40:32 --> Security Class Initialized
DEBUG - 2015-02-05 14:40:32 --> Input Class Initialized
DEBUG - 2015-02-05 14:40:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:40:32 --> Language Class Initialized
DEBUG - 2015-02-05 14:40:32 --> Loader Class Initialized
DEBUG - 2015-02-05 14:40:32 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:40:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:40:32 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:40:32 --> Controller Class Initialized
DEBUG - 2015-02-05 14:40:32 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:40:32 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:40:32 --> Model Class Initialized
DEBUG - 2015-02-05 14:40:32 --> Model Class Initialized
DEBUG - 2015-02-05 14:40:32 --> DB Transaction Failure
ERROR - 2015-02-05 14:40:32 --> Query error: Table 'thunderbirds.message' doesn't exist
DEBUG - 2015-02-05 14:40:32 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-05 14:41:04 --> Config Class Initialized
DEBUG - 2015-02-05 14:41:04 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:41:04 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:41:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:41:04 --> URI Class Initialized
DEBUG - 2015-02-05 14:41:04 --> Router Class Initialized
DEBUG - 2015-02-05 14:41:04 --> Output Class Initialized
DEBUG - 2015-02-05 14:41:04 --> Security Class Initialized
DEBUG - 2015-02-05 14:41:04 --> Input Class Initialized
DEBUG - 2015-02-05 14:41:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:41:04 --> Language Class Initialized
DEBUG - 2015-02-05 14:41:04 --> Loader Class Initialized
DEBUG - 2015-02-05 14:41:04 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:41:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:41:04 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:41:04 --> Controller Class Initialized
DEBUG - 2015-02-05 14:41:04 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:41:04 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:41:04 --> Model Class Initialized
DEBUG - 2015-02-05 14:41:04 --> Model Class Initialized
DEBUG - 2015-02-05 14:41:04 --> DB Transaction Failure
ERROR - 2015-02-05 14:41:04 --> Query error: Unknown column 'message_image' in 'field list'
DEBUG - 2015-02-05 14:41:04 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-05 14:41:45 --> Config Class Initialized
DEBUG - 2015-02-05 14:41:45 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:41:45 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:41:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:41:45 --> URI Class Initialized
DEBUG - 2015-02-05 14:41:45 --> Router Class Initialized
ERROR - 2015-02-05 14:41:45 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-05 14:42:02 --> Config Class Initialized
DEBUG - 2015-02-05 14:42:02 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:42:02 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:42:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:42:02 --> URI Class Initialized
DEBUG - 2015-02-05 14:42:02 --> Router Class Initialized
ERROR - 2015-02-05 14:42:02 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-05 14:42:24 --> Config Class Initialized
DEBUG - 2015-02-05 14:42:24 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:42:24 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:42:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:42:24 --> URI Class Initialized
DEBUG - 2015-02-05 14:42:24 --> Router Class Initialized
DEBUG - 2015-02-05 14:42:24 --> Output Class Initialized
DEBUG - 2015-02-05 14:42:24 --> Security Class Initialized
DEBUG - 2015-02-05 14:42:24 --> Input Class Initialized
DEBUG - 2015-02-05 14:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:42:24 --> Language Class Initialized
DEBUG - 2015-02-05 14:42:24 --> Loader Class Initialized
DEBUG - 2015-02-05 14:42:24 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:42:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:42:24 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:42:24 --> Controller Class Initialized
DEBUG - 2015-02-05 14:42:24 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:42:24 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:42:24 --> Model Class Initialized
DEBUG - 2015-02-05 14:42:24 --> Model Class Initialized
DEBUG - 2015-02-05 14:42:24 --> DB Transaction Failure
ERROR - 2015-02-05 14:42:24 --> Query error: Unknown column 'message_image' in 'field list'
DEBUG - 2015-02-05 14:42:24 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-05 14:42:34 --> Config Class Initialized
DEBUG - 2015-02-05 14:42:34 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:42:34 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:42:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:42:34 --> URI Class Initialized
DEBUG - 2015-02-05 14:42:34 --> Router Class Initialized
DEBUG - 2015-02-05 14:42:34 --> Output Class Initialized
DEBUG - 2015-02-05 14:42:34 --> Security Class Initialized
DEBUG - 2015-02-05 14:42:34 --> Input Class Initialized
DEBUG - 2015-02-05 14:42:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:42:34 --> Language Class Initialized
DEBUG - 2015-02-05 14:42:34 --> Loader Class Initialized
DEBUG - 2015-02-05 14:42:34 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:42:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:42:34 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:42:34 --> Controller Class Initialized
DEBUG - 2015-02-05 14:42:34 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:42:34 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:42:34 --> Model Class Initialized
DEBUG - 2015-02-05 14:42:34 --> Model Class Initialized
DEBUG - 2015-02-05 14:42:34 --> DB Transaction Failure
ERROR - 2015-02-05 14:42:34 --> Query error: Unknown column 'message_date_send' in 'field list'
DEBUG - 2015-02-05 14:42:34 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-05 14:42:47 --> Config Class Initialized
DEBUG - 2015-02-05 14:42:47 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:42:47 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:42:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:42:47 --> URI Class Initialized
DEBUG - 2015-02-05 14:42:47 --> Router Class Initialized
DEBUG - 2015-02-05 14:42:47 --> Output Class Initialized
DEBUG - 2015-02-05 14:42:47 --> Security Class Initialized
DEBUG - 2015-02-05 14:42:47 --> Input Class Initialized
DEBUG - 2015-02-05 14:42:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:42:47 --> Language Class Initialized
DEBUG - 2015-02-05 14:42:47 --> Loader Class Initialized
DEBUG - 2015-02-05 14:42:47 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:42:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:42:47 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:42:47 --> Controller Class Initialized
DEBUG - 2015-02-05 14:42:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:42:47 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:42:47 --> Model Class Initialized
DEBUG - 2015-02-05 14:42:47 --> Model Class Initialized
DEBUG - 2015-02-05 14:45:16 --> Config Class Initialized
DEBUG - 2015-02-05 14:45:16 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:45:16 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:45:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:45:16 --> URI Class Initialized
DEBUG - 2015-02-05 14:45:16 --> Router Class Initialized
DEBUG - 2015-02-05 14:45:16 --> Output Class Initialized
DEBUG - 2015-02-05 14:45:16 --> Security Class Initialized
DEBUG - 2015-02-05 14:45:16 --> Input Class Initialized
DEBUG - 2015-02-05 14:45:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:45:16 --> Language Class Initialized
DEBUG - 2015-02-05 14:45:16 --> Loader Class Initialized
DEBUG - 2015-02-05 14:45:16 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:45:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:45:16 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:45:16 --> Controller Class Initialized
DEBUG - 2015-02-05 14:45:16 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:45:16 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:45:16 --> Model Class Initialized
DEBUG - 2015-02-05 14:45:16 --> Model Class Initialized
DEBUG - 2015-02-05 14:47:14 --> Config Class Initialized
DEBUG - 2015-02-05 14:47:14 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:47:14 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:47:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:47:14 --> URI Class Initialized
DEBUG - 2015-02-05 14:47:14 --> Router Class Initialized
DEBUG - 2015-02-05 14:47:14 --> Output Class Initialized
DEBUG - 2015-02-05 14:47:14 --> Security Class Initialized
DEBUG - 2015-02-05 14:47:14 --> Input Class Initialized
DEBUG - 2015-02-05 14:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:47:14 --> Language Class Initialized
DEBUG - 2015-02-05 14:47:14 --> Loader Class Initialized
DEBUG - 2015-02-05 14:47:14 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:47:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:47:14 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:47:14 --> Controller Class Initialized
DEBUG - 2015-02-05 14:47:14 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:47:14 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:47:14 --> Model Class Initialized
DEBUG - 2015-02-05 14:47:14 --> Model Class Initialized
DEBUG - 2015-02-05 14:47:36 --> Config Class Initialized
DEBUG - 2015-02-05 14:47:36 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:47:36 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:47:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:47:36 --> URI Class Initialized
DEBUG - 2015-02-05 14:47:36 --> Router Class Initialized
DEBUG - 2015-02-05 14:47:36 --> Output Class Initialized
DEBUG - 2015-02-05 14:47:36 --> Security Class Initialized
DEBUG - 2015-02-05 14:47:36 --> Input Class Initialized
DEBUG - 2015-02-05 14:47:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:47:36 --> Language Class Initialized
DEBUG - 2015-02-05 14:47:36 --> Loader Class Initialized
DEBUG - 2015-02-05 14:47:36 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:47:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:47:36 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:47:36 --> Controller Class Initialized
DEBUG - 2015-02-05 14:47:36 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:47:36 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:47:36 --> Model Class Initialized
DEBUG - 2015-02-05 14:47:36 --> Model Class Initialized
DEBUG - 2015-02-05 14:48:06 --> Config Class Initialized
DEBUG - 2015-02-05 14:48:06 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:48:06 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:48:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:48:06 --> URI Class Initialized
DEBUG - 2015-02-05 14:48:06 --> Router Class Initialized
DEBUG - 2015-02-05 14:48:06 --> Output Class Initialized
DEBUG - 2015-02-05 14:48:06 --> Security Class Initialized
DEBUG - 2015-02-05 14:48:06 --> Input Class Initialized
DEBUG - 2015-02-05 14:48:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:48:06 --> Language Class Initialized
DEBUG - 2015-02-05 14:48:06 --> Loader Class Initialized
DEBUG - 2015-02-05 14:48:06 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:48:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:48:06 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:48:06 --> Controller Class Initialized
DEBUG - 2015-02-05 14:48:06 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:48:06 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:48:06 --> Model Class Initialized
DEBUG - 2015-02-05 14:48:06 --> Model Class Initialized
DEBUG - 2015-02-05 14:48:06 --> DB Transaction Failure
ERROR - 2015-02-05 14:48:06 --> Query error: Table 'thunderbirds.user_message_status' doesn't exist
DEBUG - 2015-02-05 14:48:06 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-05 14:48:42 --> Config Class Initialized
DEBUG - 2015-02-05 14:48:42 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:48:42 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:48:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:48:42 --> URI Class Initialized
DEBUG - 2015-02-05 14:48:42 --> Router Class Initialized
DEBUG - 2015-02-05 14:48:42 --> Output Class Initialized
DEBUG - 2015-02-05 14:48:42 --> Security Class Initialized
DEBUG - 2015-02-05 14:48:42 --> Input Class Initialized
DEBUG - 2015-02-05 14:48:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:48:42 --> Language Class Initialized
DEBUG - 2015-02-05 14:48:42 --> Loader Class Initialized
DEBUG - 2015-02-05 14:48:42 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:48:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:48:42 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:48:42 --> Controller Class Initialized
DEBUG - 2015-02-05 14:48:42 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:48:42 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:48:42 --> Model Class Initialized
DEBUG - 2015-02-05 14:48:42 --> Model Class Initialized
DEBUG - 2015-02-05 14:49:50 --> Config Class Initialized
DEBUG - 2015-02-05 14:49:50 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:49:50 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:49:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:49:50 --> URI Class Initialized
DEBUG - 2015-02-05 14:49:50 --> Router Class Initialized
DEBUG - 2015-02-05 14:49:50 --> Output Class Initialized
DEBUG - 2015-02-05 14:49:50 --> Security Class Initialized
DEBUG - 2015-02-05 14:49:50 --> Input Class Initialized
DEBUG - 2015-02-05 14:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:49:50 --> Language Class Initialized
DEBUG - 2015-02-05 14:49:50 --> Loader Class Initialized
DEBUG - 2015-02-05 14:49:50 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:49:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:49:50 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:49:50 --> Controller Class Initialized
DEBUG - 2015-02-05 14:49:50 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:49:50 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:49:50 --> Model Class Initialized
DEBUG - 2015-02-05 14:49:50 --> Model Class Initialized
DEBUG - 2015-02-05 14:50:21 --> Config Class Initialized
DEBUG - 2015-02-05 14:50:21 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:50:21 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:50:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:50:21 --> URI Class Initialized
DEBUG - 2015-02-05 14:50:21 --> Router Class Initialized
DEBUG - 2015-02-05 14:50:21 --> Output Class Initialized
DEBUG - 2015-02-05 14:50:21 --> Security Class Initialized
DEBUG - 2015-02-05 14:50:21 --> Input Class Initialized
DEBUG - 2015-02-05 14:50:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:50:21 --> Language Class Initialized
DEBUG - 2015-02-05 14:50:21 --> Loader Class Initialized
DEBUG - 2015-02-05 14:50:21 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:50:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:50:21 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:50:21 --> Controller Class Initialized
DEBUG - 2015-02-05 14:50:21 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:50:21 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:50:21 --> Model Class Initialized
DEBUG - 2015-02-05 14:50:21 --> Model Class Initialized
DEBUG - 2015-02-05 14:51:28 --> Config Class Initialized
DEBUG - 2015-02-05 14:51:28 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:51:28 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:51:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:51:28 --> URI Class Initialized
DEBUG - 2015-02-05 14:51:28 --> Router Class Initialized
DEBUG - 2015-02-05 14:51:28 --> Output Class Initialized
DEBUG - 2015-02-05 14:51:28 --> Security Class Initialized
DEBUG - 2015-02-05 14:51:28 --> Input Class Initialized
DEBUG - 2015-02-05 14:51:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:51:28 --> Language Class Initialized
DEBUG - 2015-02-05 14:51:28 --> Loader Class Initialized
DEBUG - 2015-02-05 14:51:28 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:51:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:51:28 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:51:28 --> Controller Class Initialized
DEBUG - 2015-02-05 14:51:28 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:51:28 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:51:28 --> Model Class Initialized
DEBUG - 2015-02-05 14:51:28 --> Model Class Initialized
DEBUG - 2015-02-05 14:53:30 --> Config Class Initialized
DEBUG - 2015-02-05 14:53:30 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:53:30 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:53:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:53:30 --> URI Class Initialized
DEBUG - 2015-02-05 14:53:30 --> Router Class Initialized
DEBUG - 2015-02-05 14:53:30 --> Output Class Initialized
DEBUG - 2015-02-05 14:53:30 --> Security Class Initialized
DEBUG - 2015-02-05 14:53:30 --> Input Class Initialized
DEBUG - 2015-02-05 14:53:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:53:30 --> Language Class Initialized
DEBUG - 2015-02-05 14:53:30 --> Loader Class Initialized
DEBUG - 2015-02-05 14:53:30 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:53:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:53:30 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:53:30 --> Controller Class Initialized
DEBUG - 2015-02-05 14:53:30 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:53:30 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:53:30 --> Model Class Initialized
DEBUG - 2015-02-05 14:55:04 --> Config Class Initialized
DEBUG - 2015-02-05 14:55:04 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:55:04 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:55:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:55:04 --> URI Class Initialized
DEBUG - 2015-02-05 14:55:04 --> Router Class Initialized
DEBUG - 2015-02-05 14:55:04 --> Output Class Initialized
DEBUG - 2015-02-05 14:55:04 --> Security Class Initialized
DEBUG - 2015-02-05 14:55:04 --> Input Class Initialized
DEBUG - 2015-02-05 14:55:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:55:04 --> Language Class Initialized
DEBUG - 2015-02-05 14:55:04 --> Loader Class Initialized
DEBUG - 2015-02-05 14:55:04 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:55:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:55:04 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:55:04 --> Controller Class Initialized
DEBUG - 2015-02-05 14:55:04 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:55:04 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:55:04 --> Model Class Initialized
DEBUG - 2015-02-05 14:55:14 --> Config Class Initialized
DEBUG - 2015-02-05 14:55:14 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:55:14 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:55:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:55:14 --> URI Class Initialized
DEBUG - 2015-02-05 14:55:14 --> Router Class Initialized
DEBUG - 2015-02-05 14:55:14 --> Output Class Initialized
DEBUG - 2015-02-05 14:55:14 --> Security Class Initialized
DEBUG - 2015-02-05 14:55:14 --> Input Class Initialized
DEBUG - 2015-02-05 14:55:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:55:14 --> Language Class Initialized
DEBUG - 2015-02-05 14:55:14 --> Loader Class Initialized
DEBUG - 2015-02-05 14:55:14 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:55:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:55:14 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:55:14 --> Controller Class Initialized
DEBUG - 2015-02-05 14:55:14 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:55:14 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:55:14 --> Model Class Initialized
DEBUG - 2015-02-05 14:55:17 --> Config Class Initialized
DEBUG - 2015-02-05 14:55:17 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:55:17 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:55:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:55:17 --> URI Class Initialized
DEBUG - 2015-02-05 14:55:17 --> Router Class Initialized
DEBUG - 2015-02-05 14:55:17 --> Output Class Initialized
DEBUG - 2015-02-05 14:55:17 --> Security Class Initialized
DEBUG - 2015-02-05 14:55:17 --> Input Class Initialized
DEBUG - 2015-02-05 14:55:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:55:17 --> Language Class Initialized
DEBUG - 2015-02-05 14:55:17 --> Loader Class Initialized
DEBUG - 2015-02-05 14:55:17 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:55:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:55:17 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:55:17 --> Controller Class Initialized
DEBUG - 2015-02-05 14:55:17 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:55:17 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:55:17 --> Model Class Initialized
DEBUG - 2015-02-05 14:56:10 --> Config Class Initialized
DEBUG - 2015-02-05 14:56:10 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:56:10 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:56:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:56:10 --> URI Class Initialized
DEBUG - 2015-02-05 14:56:10 --> Router Class Initialized
DEBUG - 2015-02-05 14:56:10 --> Output Class Initialized
DEBUG - 2015-02-05 14:56:10 --> Security Class Initialized
DEBUG - 2015-02-05 14:56:10 --> Input Class Initialized
DEBUG - 2015-02-05 14:56:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:56:10 --> Language Class Initialized
DEBUG - 2015-02-05 14:56:10 --> Loader Class Initialized
DEBUG - 2015-02-05 14:56:10 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:56:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:56:10 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:56:10 --> Controller Class Initialized
DEBUG - 2015-02-05 14:56:10 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:56:10 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:56:10 --> Model Class Initialized
DEBUG - 2015-02-05 14:56:11 --> Config Class Initialized
DEBUG - 2015-02-05 14:56:11 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:56:11 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:56:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:56:11 --> URI Class Initialized
DEBUG - 2015-02-05 14:56:11 --> Router Class Initialized
DEBUG - 2015-02-05 14:56:11 --> Output Class Initialized
DEBUG - 2015-02-05 14:56:11 --> Security Class Initialized
DEBUG - 2015-02-05 14:56:11 --> Input Class Initialized
DEBUG - 2015-02-05 14:56:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:56:11 --> Language Class Initialized
DEBUG - 2015-02-05 14:56:11 --> Loader Class Initialized
DEBUG - 2015-02-05 14:56:11 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:56:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:56:11 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:56:11 --> Controller Class Initialized
DEBUG - 2015-02-05 14:56:11 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:56:11 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:56:11 --> Model Class Initialized
DEBUG - 2015-02-05 14:56:11 --> Config Class Initialized
DEBUG - 2015-02-05 14:56:11 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:56:11 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:56:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:56:11 --> URI Class Initialized
DEBUG - 2015-02-05 14:56:11 --> Router Class Initialized
DEBUG - 2015-02-05 14:56:11 --> Output Class Initialized
DEBUG - 2015-02-05 14:56:11 --> Security Class Initialized
DEBUG - 2015-02-05 14:56:11 --> Input Class Initialized
DEBUG - 2015-02-05 14:56:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:56:11 --> Language Class Initialized
DEBUG - 2015-02-05 14:56:11 --> Loader Class Initialized
DEBUG - 2015-02-05 14:56:11 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:56:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:56:11 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:56:11 --> Controller Class Initialized
DEBUG - 2015-02-05 14:56:11 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:56:11 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:56:11 --> Model Class Initialized
DEBUG - 2015-02-05 14:56:12 --> Config Class Initialized
DEBUG - 2015-02-05 14:56:12 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:56:12 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:56:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:56:12 --> URI Class Initialized
DEBUG - 2015-02-05 14:56:12 --> Router Class Initialized
DEBUG - 2015-02-05 14:56:12 --> Output Class Initialized
DEBUG - 2015-02-05 14:56:12 --> Security Class Initialized
DEBUG - 2015-02-05 14:56:12 --> Input Class Initialized
DEBUG - 2015-02-05 14:56:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:56:12 --> Language Class Initialized
DEBUG - 2015-02-05 14:56:12 --> Loader Class Initialized
DEBUG - 2015-02-05 14:56:12 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:56:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:56:12 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:56:12 --> Controller Class Initialized
DEBUG - 2015-02-05 14:56:12 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:56:12 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:56:12 --> Model Class Initialized
DEBUG - 2015-02-05 14:56:16 --> Config Class Initialized
DEBUG - 2015-02-05 14:56:16 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:56:16 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:56:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:56:16 --> URI Class Initialized
DEBUG - 2015-02-05 14:56:16 --> Router Class Initialized
DEBUG - 2015-02-05 14:56:16 --> Output Class Initialized
DEBUG - 2015-02-05 14:56:16 --> Security Class Initialized
DEBUG - 2015-02-05 14:56:16 --> Input Class Initialized
DEBUG - 2015-02-05 14:56:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:56:16 --> Language Class Initialized
DEBUG - 2015-02-05 14:56:16 --> Loader Class Initialized
DEBUG - 2015-02-05 14:56:16 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:56:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:56:16 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:56:16 --> Controller Class Initialized
DEBUG - 2015-02-05 14:56:16 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:56:16 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:56:16 --> Model Class Initialized
DEBUG - 2015-02-05 14:56:20 --> Config Class Initialized
DEBUG - 2015-02-05 14:56:20 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:56:20 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:56:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:56:20 --> URI Class Initialized
DEBUG - 2015-02-05 14:56:20 --> Router Class Initialized
DEBUG - 2015-02-05 14:56:20 --> Output Class Initialized
DEBUG - 2015-02-05 14:56:20 --> Security Class Initialized
DEBUG - 2015-02-05 14:56:20 --> Input Class Initialized
DEBUG - 2015-02-05 14:56:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:56:20 --> Language Class Initialized
DEBUG - 2015-02-05 14:56:20 --> Loader Class Initialized
DEBUG - 2015-02-05 14:56:20 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:56:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:56:20 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:56:20 --> Controller Class Initialized
DEBUG - 2015-02-05 14:56:20 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:56:20 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:56:20 --> Model Class Initialized
DEBUG - 2015-02-05 14:56:21 --> Config Class Initialized
DEBUG - 2015-02-05 14:56:21 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:56:21 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:56:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:56:21 --> URI Class Initialized
DEBUG - 2015-02-05 14:56:21 --> Router Class Initialized
DEBUG - 2015-02-05 14:56:21 --> Output Class Initialized
DEBUG - 2015-02-05 14:56:21 --> Security Class Initialized
DEBUG - 2015-02-05 14:56:21 --> Input Class Initialized
DEBUG - 2015-02-05 14:56:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:56:21 --> Language Class Initialized
DEBUG - 2015-02-05 14:56:21 --> Loader Class Initialized
DEBUG - 2015-02-05 14:56:21 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:56:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:56:21 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:56:21 --> Controller Class Initialized
DEBUG - 2015-02-05 14:56:21 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:56:21 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:56:21 --> Model Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Config Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:56:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:56:22 --> URI Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Router Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Output Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Security Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Input Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:56:22 --> Language Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Loader Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:56:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:56:22 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Controller Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:56:22 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:56:22 --> Model Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Config Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:56:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:56:22 --> URI Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Router Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Output Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Security Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Input Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:56:22 --> Language Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Loader Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:56:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:56:22 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Controller Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:56:22 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:56:22 --> Model Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Config Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:56:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:56:22 --> URI Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Router Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Output Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Security Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Input Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:56:22 --> Language Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Loader Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:56:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:56:22 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Controller Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:56:22 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:56:22 --> Model Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Config Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:56:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:56:22 --> URI Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Router Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Output Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Security Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Input Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:56:22 --> Language Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Loader Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:56:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:56:22 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Controller Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:56:22 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:56:22 --> Model Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Config Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:56:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:56:22 --> URI Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Router Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Output Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Security Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Input Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:56:22 --> Language Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Loader Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:56:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:56:22 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Controller Class Initialized
DEBUG - 2015-02-05 14:56:22 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:56:22 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:56:22 --> Model Class Initialized
DEBUG - 2015-02-05 14:56:34 --> Config Class Initialized
DEBUG - 2015-02-05 14:56:34 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:56:34 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:56:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:56:34 --> URI Class Initialized
DEBUG - 2015-02-05 14:56:34 --> Router Class Initialized
DEBUG - 2015-02-05 14:56:34 --> Output Class Initialized
DEBUG - 2015-02-05 14:56:34 --> Security Class Initialized
DEBUG - 2015-02-05 14:56:34 --> Input Class Initialized
DEBUG - 2015-02-05 14:56:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:56:34 --> Language Class Initialized
DEBUG - 2015-02-05 14:56:34 --> Loader Class Initialized
DEBUG - 2015-02-05 14:56:34 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:56:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:56:34 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:56:34 --> Controller Class Initialized
DEBUG - 2015-02-05 14:56:34 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:56:34 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:56:34 --> Model Class Initialized
DEBUG - 2015-02-05 14:56:34 --> Model Class Initialized
DEBUG - 2015-02-05 14:56:37 --> Config Class Initialized
DEBUG - 2015-02-05 14:56:37 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:56:37 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:56:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:56:37 --> URI Class Initialized
DEBUG - 2015-02-05 14:56:37 --> Router Class Initialized
DEBUG - 2015-02-05 14:56:37 --> Output Class Initialized
DEBUG - 2015-02-05 14:56:37 --> Security Class Initialized
DEBUG - 2015-02-05 14:56:37 --> Input Class Initialized
DEBUG - 2015-02-05 14:56:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:56:37 --> Language Class Initialized
DEBUG - 2015-02-05 14:56:37 --> Loader Class Initialized
DEBUG - 2015-02-05 14:56:37 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:56:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:56:37 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:56:37 --> Controller Class Initialized
DEBUG - 2015-02-05 14:56:37 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:56:37 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:56:37 --> Model Class Initialized
DEBUG - 2015-02-05 14:56:37 --> Model Class Initialized
DEBUG - 2015-02-05 14:56:42 --> Config Class Initialized
DEBUG - 2015-02-05 14:56:42 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:56:42 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:56:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:56:42 --> URI Class Initialized
DEBUG - 2015-02-05 14:56:42 --> Router Class Initialized
DEBUG - 2015-02-05 14:56:42 --> Output Class Initialized
DEBUG - 2015-02-05 14:56:42 --> Security Class Initialized
DEBUG - 2015-02-05 14:56:42 --> Input Class Initialized
DEBUG - 2015-02-05 14:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:56:42 --> Language Class Initialized
DEBUG - 2015-02-05 14:56:42 --> Loader Class Initialized
DEBUG - 2015-02-05 14:56:42 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:56:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:56:42 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:56:42 --> Controller Class Initialized
DEBUG - 2015-02-05 14:56:42 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:56:42 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:56:42 --> Model Class Initialized
DEBUG - 2015-02-05 14:56:42 --> Model Class Initialized
DEBUG - 2015-02-05 14:59:23 --> Config Class Initialized
DEBUG - 2015-02-05 14:59:23 --> Hooks Class Initialized
DEBUG - 2015-02-05 14:59:23 --> Utf8 Class Initialized
DEBUG - 2015-02-05 14:59:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 14:59:23 --> URI Class Initialized
DEBUG - 2015-02-05 14:59:23 --> Router Class Initialized
DEBUG - 2015-02-05 14:59:23 --> Output Class Initialized
DEBUG - 2015-02-05 14:59:23 --> Security Class Initialized
DEBUG - 2015-02-05 14:59:23 --> Input Class Initialized
DEBUG - 2015-02-05 14:59:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 14:59:23 --> Language Class Initialized
DEBUG - 2015-02-05 14:59:23 --> Loader Class Initialized
DEBUG - 2015-02-05 14:59:23 --> Database Driver Class Initialized
ERROR - 2015-02-05 14:59:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 14:59:23 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 14:59:23 --> Controller Class Initialized
DEBUG - 2015-02-05 14:59:23 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 14:59:23 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 14:59:23 --> Model Class Initialized
DEBUG - 2015-02-05 14:59:23 --> Model Class Initialized
DEBUG - 2015-02-05 15:01:02 --> Config Class Initialized
DEBUG - 2015-02-05 15:01:02 --> Hooks Class Initialized
DEBUG - 2015-02-05 15:01:02 --> Utf8 Class Initialized
DEBUG - 2015-02-05 15:01:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 15:01:02 --> URI Class Initialized
DEBUG - 2015-02-05 15:01:02 --> Router Class Initialized
DEBUG - 2015-02-05 15:01:02 --> Output Class Initialized
DEBUG - 2015-02-05 15:01:02 --> Security Class Initialized
DEBUG - 2015-02-05 15:01:02 --> Input Class Initialized
DEBUG - 2015-02-05 15:01:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 15:01:02 --> Language Class Initialized
DEBUG - 2015-02-05 15:01:02 --> Loader Class Initialized
DEBUG - 2015-02-05 15:01:02 --> Database Driver Class Initialized
ERROR - 2015-02-05 15:01:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 15:01:02 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 15:01:02 --> Controller Class Initialized
DEBUG - 2015-02-05 15:01:02 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 15:01:02 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 15:01:02 --> Model Class Initialized
DEBUG - 2015-02-05 15:01:02 --> Model Class Initialized
DEBUG - 2015-02-05 15:01:05 --> Config Class Initialized
DEBUG - 2015-02-05 15:01:05 --> Hooks Class Initialized
DEBUG - 2015-02-05 15:01:05 --> Utf8 Class Initialized
DEBUG - 2015-02-05 15:01:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 15:01:05 --> URI Class Initialized
DEBUG - 2015-02-05 15:01:05 --> Router Class Initialized
DEBUG - 2015-02-05 15:01:05 --> Output Class Initialized
DEBUG - 2015-02-05 15:01:05 --> Security Class Initialized
DEBUG - 2015-02-05 15:01:05 --> Input Class Initialized
DEBUG - 2015-02-05 15:01:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 15:01:05 --> Language Class Initialized
DEBUG - 2015-02-05 15:01:05 --> Loader Class Initialized
DEBUG - 2015-02-05 15:01:05 --> Database Driver Class Initialized
ERROR - 2015-02-05 15:01:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 15:01:05 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 15:01:05 --> Controller Class Initialized
DEBUG - 2015-02-05 15:01:05 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 15:01:05 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 15:01:05 --> Model Class Initialized
DEBUG - 2015-02-05 15:01:05 --> Model Class Initialized
DEBUG - 2015-02-05 15:01:18 --> Config Class Initialized
DEBUG - 2015-02-05 15:01:18 --> Hooks Class Initialized
DEBUG - 2015-02-05 15:01:18 --> Utf8 Class Initialized
DEBUG - 2015-02-05 15:01:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 15:01:18 --> URI Class Initialized
DEBUG - 2015-02-05 15:01:18 --> Router Class Initialized
DEBUG - 2015-02-05 15:01:18 --> Output Class Initialized
DEBUG - 2015-02-05 15:01:18 --> Security Class Initialized
DEBUG - 2015-02-05 15:01:18 --> Input Class Initialized
DEBUG - 2015-02-05 15:01:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 15:01:18 --> Language Class Initialized
DEBUG - 2015-02-05 15:01:18 --> Loader Class Initialized
DEBUG - 2015-02-05 15:01:18 --> Database Driver Class Initialized
ERROR - 2015-02-05 15:01:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 15:01:18 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 15:01:18 --> Controller Class Initialized
DEBUG - 2015-02-05 15:01:18 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 15:01:18 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 15:01:18 --> Model Class Initialized
DEBUG - 2015-02-05 15:01:18 --> Model Class Initialized
DEBUG - 2015-02-05 15:02:17 --> Config Class Initialized
DEBUG - 2015-02-05 15:02:17 --> Hooks Class Initialized
DEBUG - 2015-02-05 15:02:17 --> Utf8 Class Initialized
DEBUG - 2015-02-05 15:02:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 15:02:17 --> URI Class Initialized
DEBUG - 2015-02-05 15:02:17 --> Router Class Initialized
DEBUG - 2015-02-05 15:02:17 --> Output Class Initialized
DEBUG - 2015-02-05 15:02:17 --> Security Class Initialized
DEBUG - 2015-02-05 15:02:17 --> Input Class Initialized
DEBUG - 2015-02-05 15:02:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 15:02:17 --> Language Class Initialized
DEBUG - 2015-02-05 15:02:17 --> Loader Class Initialized
DEBUG - 2015-02-05 15:02:17 --> Database Driver Class Initialized
ERROR - 2015-02-05 15:02:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 15:02:17 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 15:02:17 --> Controller Class Initialized
DEBUG - 2015-02-05 15:02:17 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 15:02:17 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 15:02:17 --> Model Class Initialized
DEBUG - 2015-02-05 15:02:17 --> Model Class Initialized
DEBUG - 2015-02-05 15:02:25 --> Config Class Initialized
DEBUG - 2015-02-05 15:02:25 --> Hooks Class Initialized
DEBUG - 2015-02-05 15:02:25 --> Utf8 Class Initialized
DEBUG - 2015-02-05 15:02:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 15:02:25 --> URI Class Initialized
DEBUG - 2015-02-05 15:02:25 --> Router Class Initialized
DEBUG - 2015-02-05 15:02:25 --> Output Class Initialized
DEBUG - 2015-02-05 15:02:25 --> Security Class Initialized
DEBUG - 2015-02-05 15:02:25 --> Input Class Initialized
DEBUG - 2015-02-05 15:02:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 15:02:25 --> Language Class Initialized
DEBUG - 2015-02-05 15:02:25 --> Loader Class Initialized
DEBUG - 2015-02-05 15:02:25 --> Database Driver Class Initialized
ERROR - 2015-02-05 15:02:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 15:02:25 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 15:02:25 --> Controller Class Initialized
DEBUG - 2015-02-05 15:02:25 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 15:02:25 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 15:02:25 --> Model Class Initialized
DEBUG - 2015-02-05 15:02:25 --> Model Class Initialized
DEBUG - 2015-02-05 15:02:59 --> Config Class Initialized
DEBUG - 2015-02-05 15:02:59 --> Hooks Class Initialized
DEBUG - 2015-02-05 15:02:59 --> Utf8 Class Initialized
DEBUG - 2015-02-05 15:02:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 15:02:59 --> URI Class Initialized
DEBUG - 2015-02-05 15:02:59 --> Router Class Initialized
DEBUG - 2015-02-05 15:02:59 --> Output Class Initialized
DEBUG - 2015-02-05 15:02:59 --> Security Class Initialized
DEBUG - 2015-02-05 15:02:59 --> Input Class Initialized
DEBUG - 2015-02-05 15:02:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 15:02:59 --> Language Class Initialized
DEBUG - 2015-02-05 15:02:59 --> Loader Class Initialized
DEBUG - 2015-02-05 15:02:59 --> Database Driver Class Initialized
ERROR - 2015-02-05 15:02:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 15:02:59 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 15:02:59 --> Controller Class Initialized
DEBUG - 2015-02-05 15:02:59 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 15:02:59 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 15:02:59 --> Model Class Initialized
DEBUG - 2015-02-05 15:02:59 --> Model Class Initialized
DEBUG - 2015-02-05 15:03:03 --> Config Class Initialized
DEBUG - 2015-02-05 15:03:03 --> Hooks Class Initialized
DEBUG - 2015-02-05 15:03:03 --> Utf8 Class Initialized
DEBUG - 2015-02-05 15:03:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 15:03:03 --> URI Class Initialized
DEBUG - 2015-02-05 15:03:03 --> Router Class Initialized
DEBUG - 2015-02-05 15:03:03 --> Output Class Initialized
DEBUG - 2015-02-05 15:03:03 --> Security Class Initialized
DEBUG - 2015-02-05 15:03:03 --> Input Class Initialized
DEBUG - 2015-02-05 15:03:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 15:03:03 --> Language Class Initialized
DEBUG - 2015-02-05 15:03:03 --> Loader Class Initialized
DEBUG - 2015-02-05 15:03:03 --> Database Driver Class Initialized
ERROR - 2015-02-05 15:03:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 15:03:03 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 15:03:03 --> Controller Class Initialized
DEBUG - 2015-02-05 15:03:03 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 15:03:03 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 15:03:03 --> Model Class Initialized
DEBUG - 2015-02-05 15:03:03 --> Model Class Initialized
DEBUG - 2015-02-05 15:03:07 --> Config Class Initialized
DEBUG - 2015-02-05 15:03:07 --> Hooks Class Initialized
DEBUG - 2015-02-05 15:03:07 --> Utf8 Class Initialized
DEBUG - 2015-02-05 15:03:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 15:03:07 --> URI Class Initialized
DEBUG - 2015-02-05 15:03:07 --> Router Class Initialized
DEBUG - 2015-02-05 15:03:07 --> Output Class Initialized
DEBUG - 2015-02-05 15:03:07 --> Security Class Initialized
DEBUG - 2015-02-05 15:03:07 --> Input Class Initialized
DEBUG - 2015-02-05 15:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 15:03:07 --> Language Class Initialized
DEBUG - 2015-02-05 15:03:07 --> Loader Class Initialized
DEBUG - 2015-02-05 15:03:07 --> Database Driver Class Initialized
ERROR - 2015-02-05 15:03:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 15:03:07 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 15:03:07 --> Controller Class Initialized
DEBUG - 2015-02-05 15:03:07 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 15:03:07 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 15:03:07 --> Model Class Initialized
DEBUG - 2015-02-05 15:03:07 --> Model Class Initialized
DEBUG - 2015-02-05 15:03:33 --> Config Class Initialized
DEBUG - 2015-02-05 15:03:33 --> Hooks Class Initialized
DEBUG - 2015-02-05 15:03:33 --> Utf8 Class Initialized
DEBUG - 2015-02-05 15:03:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 15:03:33 --> URI Class Initialized
DEBUG - 2015-02-05 15:03:33 --> Router Class Initialized
DEBUG - 2015-02-05 15:03:33 --> Output Class Initialized
DEBUG - 2015-02-05 15:03:33 --> Security Class Initialized
DEBUG - 2015-02-05 15:03:33 --> Input Class Initialized
DEBUG - 2015-02-05 15:03:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 15:03:33 --> Language Class Initialized
DEBUG - 2015-02-05 15:03:33 --> Loader Class Initialized
DEBUG - 2015-02-05 15:03:33 --> Database Driver Class Initialized
ERROR - 2015-02-05 15:03:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 15:03:33 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 15:03:33 --> Controller Class Initialized
DEBUG - 2015-02-05 15:03:33 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 15:03:33 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 15:03:33 --> Model Class Initialized
DEBUG - 2015-02-05 15:03:33 --> Model Class Initialized
DEBUG - 2015-02-05 15:04:29 --> Config Class Initialized
DEBUG - 2015-02-05 15:04:29 --> Hooks Class Initialized
DEBUG - 2015-02-05 15:04:29 --> Utf8 Class Initialized
DEBUG - 2015-02-05 15:04:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 15:04:29 --> URI Class Initialized
DEBUG - 2015-02-05 15:04:29 --> Router Class Initialized
DEBUG - 2015-02-05 15:04:29 --> Output Class Initialized
DEBUG - 2015-02-05 15:04:29 --> Security Class Initialized
DEBUG - 2015-02-05 15:04:29 --> Input Class Initialized
DEBUG - 2015-02-05 15:04:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 15:04:29 --> Language Class Initialized
DEBUG - 2015-02-05 15:04:29 --> Loader Class Initialized
DEBUG - 2015-02-05 15:04:29 --> Database Driver Class Initialized
ERROR - 2015-02-05 15:04:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 15:04:29 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 15:04:29 --> Controller Class Initialized
DEBUG - 2015-02-05 15:04:29 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 15:04:29 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 15:04:29 --> Model Class Initialized
DEBUG - 2015-02-05 15:04:29 --> Model Class Initialized
DEBUG - 2015-02-05 15:05:48 --> Config Class Initialized
DEBUG - 2015-02-05 15:05:48 --> Hooks Class Initialized
DEBUG - 2015-02-05 15:05:48 --> Utf8 Class Initialized
DEBUG - 2015-02-05 15:05:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 15:05:48 --> URI Class Initialized
DEBUG - 2015-02-05 15:05:48 --> Router Class Initialized
DEBUG - 2015-02-05 15:05:48 --> Output Class Initialized
DEBUG - 2015-02-05 15:05:48 --> Security Class Initialized
DEBUG - 2015-02-05 15:05:48 --> Input Class Initialized
DEBUG - 2015-02-05 15:05:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 15:05:48 --> Language Class Initialized
DEBUG - 2015-02-05 15:05:48 --> Loader Class Initialized
DEBUG - 2015-02-05 15:05:48 --> Database Driver Class Initialized
ERROR - 2015-02-05 15:05:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 15:05:48 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 15:05:48 --> Controller Class Initialized
DEBUG - 2015-02-05 15:05:48 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 15:05:48 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 15:05:48 --> Model Class Initialized
DEBUG - 2015-02-05 15:05:48 --> Model Class Initialized
ERROR - 2015-02-05 15:05:48 --> Severity: Notice  --> Undefined index: collectible_id /Volumes/Data/www/thunderbirds-hub-site/server/application/models/collectible_model.php 157
ERROR - 2015-02-05 15:05:48 --> Severity: Notice  --> Undefined index: missing /Volumes/Data/www/thunderbirds-hub-site/server/application/controllers/api/collectibles.php 129
ERROR - 2015-02-05 15:05:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds-hub-site/server/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds-hub-site/server/application/libraries/REST_Controller.php 485
ERROR - 2015-02-05 15:05:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds-hub-site/server/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds-hub-site/server/system/core/Common.php 442
ERROR - 2015-02-05 15:05:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds-hub-site/server/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds-hub-site/server/application/libraries/REST_Controller.php 503
DEBUG - 2015-02-05 15:06:16 --> Config Class Initialized
DEBUG - 2015-02-05 15:06:16 --> Hooks Class Initialized
DEBUG - 2015-02-05 15:06:16 --> Utf8 Class Initialized
DEBUG - 2015-02-05 15:06:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 15:06:16 --> URI Class Initialized
DEBUG - 2015-02-05 15:06:16 --> Router Class Initialized
DEBUG - 2015-02-05 15:06:16 --> Output Class Initialized
DEBUG - 2015-02-05 15:06:16 --> Security Class Initialized
DEBUG - 2015-02-05 15:06:16 --> Input Class Initialized
DEBUG - 2015-02-05 15:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 15:06:16 --> Language Class Initialized
DEBUG - 2015-02-05 15:06:16 --> Loader Class Initialized
DEBUG - 2015-02-05 15:06:16 --> Database Driver Class Initialized
ERROR - 2015-02-05 15:06:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 15:06:16 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 15:06:16 --> Controller Class Initialized
DEBUG - 2015-02-05 15:06:16 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 15:06:16 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 15:06:16 --> Model Class Initialized
DEBUG - 2015-02-05 15:06:16 --> Model Class Initialized
DEBUG - 2015-02-05 15:06:16 --> DB Transaction Failure
ERROR - 2015-02-05 15:06:16 --> Query error: Table 'thunderbirds.collectibles_relationship' doesn't exist
DEBUG - 2015-02-05 15:06:16 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-05 15:06:31 --> Config Class Initialized
DEBUG - 2015-02-05 15:06:31 --> Hooks Class Initialized
DEBUG - 2015-02-05 15:06:31 --> Utf8 Class Initialized
DEBUG - 2015-02-05 15:06:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 15:06:31 --> URI Class Initialized
DEBUG - 2015-02-05 15:06:31 --> Router Class Initialized
DEBUG - 2015-02-05 15:06:31 --> Output Class Initialized
DEBUG - 2015-02-05 15:06:31 --> Security Class Initialized
DEBUG - 2015-02-05 15:06:31 --> Input Class Initialized
DEBUG - 2015-02-05 15:06:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 15:06:31 --> Language Class Initialized
DEBUG - 2015-02-05 15:06:31 --> Loader Class Initialized
DEBUG - 2015-02-05 15:06:31 --> Database Driver Class Initialized
ERROR - 2015-02-05 15:06:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 15:06:31 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 15:06:31 --> Controller Class Initialized
DEBUG - 2015-02-05 15:06:31 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 15:06:31 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 15:06:31 --> Model Class Initialized
DEBUG - 2015-02-05 15:06:31 --> Model Class Initialized
DEBUG - 2015-02-05 15:24:55 --> Config Class Initialized
DEBUG - 2015-02-05 15:24:55 --> Hooks Class Initialized
DEBUG - 2015-02-05 15:24:55 --> Utf8 Class Initialized
DEBUG - 2015-02-05 15:24:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 15:24:55 --> URI Class Initialized
DEBUG - 2015-02-05 15:24:55 --> Router Class Initialized
ERROR - 2015-02-05 15:24:55 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-05 15:31:01 --> Config Class Initialized
DEBUG - 2015-02-05 15:31:01 --> Hooks Class Initialized
DEBUG - 2015-02-05 15:31:01 --> Utf8 Class Initialized
DEBUG - 2015-02-05 15:31:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 15:31:01 --> URI Class Initialized
DEBUG - 2015-02-05 15:31:01 --> Router Class Initialized
ERROR - 2015-02-05 15:31:01 --> 404 Page Not Found --> api/api
DEBUG - 2015-02-05 15:31:09 --> Config Class Initialized
DEBUG - 2015-02-05 15:31:09 --> Hooks Class Initialized
DEBUG - 2015-02-05 15:31:09 --> Utf8 Class Initialized
DEBUG - 2015-02-05 15:31:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 15:31:09 --> URI Class Initialized
DEBUG - 2015-02-05 15:31:09 --> Router Class Initialized
ERROR - 2015-02-05 15:31:09 --> 404 Page Not Found --> api/challenges
DEBUG - 2015-02-05 15:31:36 --> Config Class Initialized
DEBUG - 2015-02-05 15:31:36 --> Hooks Class Initialized
DEBUG - 2015-02-05 15:31:36 --> Utf8 Class Initialized
DEBUG - 2015-02-05 15:31:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 15:31:36 --> URI Class Initialized
DEBUG - 2015-02-05 15:31:36 --> Router Class Initialized
DEBUG - 2015-02-05 15:31:36 --> Output Class Initialized
DEBUG - 2015-02-05 15:31:36 --> Security Class Initialized
DEBUG - 2015-02-05 15:31:36 --> Input Class Initialized
DEBUG - 2015-02-05 15:31:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 15:31:36 --> Language Class Initialized
DEBUG - 2015-02-05 15:31:37 --> Loader Class Initialized
DEBUG - 2015-02-05 15:31:37 --> Database Driver Class Initialized
ERROR - 2015-02-05 15:31:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 15:31:37 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 15:31:37 --> Controller Class Initialized
DEBUG - 2015-02-05 15:31:37 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 15:31:37 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 15:31:37 --> Model Class Initialized
DEBUG - 2015-02-05 15:31:37 --> Model Class Initialized
DEBUG - 2015-02-05 15:31:37 --> DB Transaction Failure
ERROR - 2015-02-05 15:31:37 --> Query error: Table 'thunderbirds.challenge' doesn't exist
DEBUG - 2015-02-05 15:31:37 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-05 15:31:58 --> Config Class Initialized
DEBUG - 2015-02-05 15:31:58 --> Hooks Class Initialized
DEBUG - 2015-02-05 15:31:58 --> Utf8 Class Initialized
DEBUG - 2015-02-05 15:31:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 15:31:58 --> URI Class Initialized
DEBUG - 2015-02-05 15:31:58 --> Router Class Initialized
DEBUG - 2015-02-05 15:31:58 --> Output Class Initialized
DEBUG - 2015-02-05 15:31:58 --> Security Class Initialized
DEBUG - 2015-02-05 15:31:58 --> Input Class Initialized
DEBUG - 2015-02-05 15:31:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 15:31:58 --> Language Class Initialized
DEBUG - 2015-02-05 15:31:58 --> Loader Class Initialized
DEBUG - 2015-02-05 15:31:58 --> Database Driver Class Initialized
ERROR - 2015-02-05 15:31:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 15:31:58 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 15:31:58 --> Controller Class Initialized
DEBUG - 2015-02-05 15:31:58 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 15:31:58 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 15:31:58 --> Model Class Initialized
DEBUG - 2015-02-05 15:31:58 --> Model Class Initialized
DEBUG - 2015-02-05 15:32:28 --> Config Class Initialized
DEBUG - 2015-02-05 15:32:28 --> Hooks Class Initialized
DEBUG - 2015-02-05 15:32:28 --> Utf8 Class Initialized
DEBUG - 2015-02-05 15:32:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 15:32:28 --> URI Class Initialized
DEBUG - 2015-02-05 15:32:28 --> Router Class Initialized
ERROR - 2015-02-05 15:32:28 --> 404 Page Not Found --> api/chanllenges
DEBUG - 2015-02-05 15:32:42 --> Config Class Initialized
DEBUG - 2015-02-05 15:32:42 --> Hooks Class Initialized
DEBUG - 2015-02-05 15:32:42 --> Utf8 Class Initialized
DEBUG - 2015-02-05 15:32:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 15:32:42 --> URI Class Initialized
DEBUG - 2015-02-05 15:32:42 --> Router Class Initialized
DEBUG - 2015-02-05 15:32:42 --> Output Class Initialized
DEBUG - 2015-02-05 15:32:42 --> Security Class Initialized
DEBUG - 2015-02-05 15:32:42 --> Input Class Initialized
DEBUG - 2015-02-05 15:32:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 15:32:42 --> Language Class Initialized
DEBUG - 2015-02-05 15:32:42 --> Loader Class Initialized
DEBUG - 2015-02-05 15:32:42 --> Database Driver Class Initialized
ERROR - 2015-02-05 15:32:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 15:32:42 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 15:32:42 --> Controller Class Initialized
DEBUG - 2015-02-05 15:32:42 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 15:32:42 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 15:32:42 --> Model Class Initialized
DEBUG - 2015-02-05 15:32:42 --> Model Class Initialized
DEBUG - 2015-02-05 15:33:00 --> Config Class Initialized
DEBUG - 2015-02-05 15:33:00 --> Hooks Class Initialized
DEBUG - 2015-02-05 15:33:00 --> Utf8 Class Initialized
DEBUG - 2015-02-05 15:33:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 15:33:00 --> URI Class Initialized
DEBUG - 2015-02-05 15:33:00 --> Router Class Initialized
DEBUG - 2015-02-05 15:33:00 --> Output Class Initialized
DEBUG - 2015-02-05 15:33:00 --> Security Class Initialized
DEBUG - 2015-02-05 15:33:00 --> Input Class Initialized
DEBUG - 2015-02-05 15:33:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 15:33:00 --> Language Class Initialized
DEBUG - 2015-02-05 15:33:00 --> Loader Class Initialized
DEBUG - 2015-02-05 15:33:00 --> Database Driver Class Initialized
ERROR - 2015-02-05 15:33:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 15:33:00 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 15:33:00 --> Controller Class Initialized
DEBUG - 2015-02-05 15:33:00 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 15:33:00 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 15:33:00 --> Model Class Initialized
DEBUG - 2015-02-05 15:33:00 --> Model Class Initialized
DEBUG - 2015-02-05 15:34:50 --> Config Class Initialized
DEBUG - 2015-02-05 15:34:50 --> Hooks Class Initialized
DEBUG - 2015-02-05 15:34:50 --> Utf8 Class Initialized
DEBUG - 2015-02-05 15:34:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 15:34:50 --> URI Class Initialized
DEBUG - 2015-02-05 15:34:50 --> Router Class Initialized
DEBUG - 2015-02-05 15:34:50 --> Output Class Initialized
DEBUG - 2015-02-05 15:34:50 --> Security Class Initialized
DEBUG - 2015-02-05 15:34:50 --> Input Class Initialized
DEBUG - 2015-02-05 15:34:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 15:34:50 --> Language Class Initialized
DEBUG - 2015-02-05 15:34:50 --> Loader Class Initialized
DEBUG - 2015-02-05 15:34:50 --> Database Driver Class Initialized
ERROR - 2015-02-05 15:34:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 15:34:50 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 15:34:50 --> Controller Class Initialized
DEBUG - 2015-02-05 15:34:50 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 15:34:50 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 15:34:50 --> Model Class Initialized
DEBUG - 2015-02-05 15:34:50 --> Model Class Initialized
DEBUG - 2015-02-05 15:35:50 --> Config Class Initialized
DEBUG - 2015-02-05 15:35:50 --> Hooks Class Initialized
DEBUG - 2015-02-05 15:35:50 --> Utf8 Class Initialized
DEBUG - 2015-02-05 15:35:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 15:35:50 --> URI Class Initialized
DEBUG - 2015-02-05 15:35:50 --> Router Class Initialized
DEBUG - 2015-02-05 15:35:50 --> Output Class Initialized
DEBUG - 2015-02-05 15:35:50 --> Security Class Initialized
DEBUG - 2015-02-05 15:35:50 --> Input Class Initialized
DEBUG - 2015-02-05 15:35:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 15:35:50 --> Language Class Initialized
DEBUG - 2015-02-05 15:35:50 --> Loader Class Initialized
DEBUG - 2015-02-05 15:35:50 --> Database Driver Class Initialized
ERROR - 2015-02-05 15:35:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 15:35:50 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 15:35:50 --> Controller Class Initialized
DEBUG - 2015-02-05 15:35:50 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 15:35:50 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 15:35:50 --> Model Class Initialized
DEBUG - 2015-02-05 15:35:50 --> Model Class Initialized
DEBUG - 2015-02-05 15:36:28 --> Config Class Initialized
DEBUG - 2015-02-05 15:36:28 --> Hooks Class Initialized
DEBUG - 2015-02-05 15:36:28 --> Utf8 Class Initialized
DEBUG - 2015-02-05 15:36:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 15:36:28 --> URI Class Initialized
DEBUG - 2015-02-05 15:36:28 --> Router Class Initialized
DEBUG - 2015-02-05 15:36:28 --> Output Class Initialized
DEBUG - 2015-02-05 15:36:28 --> Security Class Initialized
DEBUG - 2015-02-05 15:36:28 --> Input Class Initialized
DEBUG - 2015-02-05 15:36:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 15:36:28 --> Language Class Initialized
DEBUG - 2015-02-05 15:36:28 --> Loader Class Initialized
DEBUG - 2015-02-05 15:36:28 --> Database Driver Class Initialized
ERROR - 2015-02-05 15:36:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds-hub-site/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2015-02-05 15:36:28 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 15:36:28 --> Controller Class Initialized
DEBUG - 2015-02-05 15:36:28 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 15:36:28 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 15:36:28 --> Model Class Initialized
DEBUG - 2015-02-05 15:36:28 --> Model Class Initialized
DEBUG - 2015-02-05 22:03:20 --> Config Class Initialized
DEBUG - 2015-02-05 22:03:20 --> Hooks Class Initialized
DEBUG - 2015-02-05 22:03:20 --> Utf8 Class Initialized
DEBUG - 2015-02-05 22:03:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 22:03:20 --> URI Class Initialized
DEBUG - 2015-02-05 22:03:20 --> Router Class Initialized
DEBUG - 2015-02-05 22:03:20 --> Output Class Initialized
DEBUG - 2015-02-05 22:03:20 --> Security Class Initialized
DEBUG - 2015-02-05 22:03:20 --> Input Class Initialized
DEBUG - 2015-02-05 22:03:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 22:03:20 --> Language Class Initialized
DEBUG - 2015-02-05 22:03:20 --> Loader Class Initialized
DEBUG - 2015-02-05 22:03:20 --> Database Driver Class Initialized
DEBUG - 2015-02-05 22:03:21 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 22:03:21 --> Controller Class Initialized
DEBUG - 2015-02-05 22:03:21 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 22:03:21 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 22:03:21 --> Model Class Initialized
DEBUG - 2015-02-05 22:03:21 --> Model Class Initialized
DEBUG - 2015-02-05 23:04:03 --> Config Class Initialized
DEBUG - 2015-02-05 23:04:03 --> Hooks Class Initialized
DEBUG - 2015-02-05 23:04:03 --> Utf8 Class Initialized
DEBUG - 2015-02-05 23:04:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 23:04:03 --> URI Class Initialized
DEBUG - 2015-02-05 23:04:03 --> Router Class Initialized
DEBUG - 2015-02-05 23:04:03 --> Output Class Initialized
DEBUG - 2015-02-05 23:04:03 --> Security Class Initialized
DEBUG - 2015-02-05 23:04:03 --> Input Class Initialized
DEBUG - 2015-02-05 23:04:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 23:04:03 --> Language Class Initialized
DEBUG - 2015-02-05 23:04:03 --> Loader Class Initialized
DEBUG - 2015-02-05 23:04:03 --> Database Driver Class Initialized
DEBUG - 2015-02-05 23:04:04 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 23:04:04 --> Controller Class Initialized
DEBUG - 2015-02-05 23:04:04 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 23:04:04 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 23:04:04 --> Model Class Initialized
DEBUG - 2015-02-05 23:05:00 --> Config Class Initialized
DEBUG - 2015-02-05 23:05:00 --> Hooks Class Initialized
DEBUG - 2015-02-05 23:05:00 --> Utf8 Class Initialized
DEBUG - 2015-02-05 23:05:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-05 23:05:00 --> URI Class Initialized
DEBUG - 2015-02-05 23:05:00 --> Router Class Initialized
DEBUG - 2015-02-05 23:05:00 --> Output Class Initialized
DEBUG - 2015-02-05 23:05:00 --> Security Class Initialized
DEBUG - 2015-02-05 23:05:00 --> Input Class Initialized
DEBUG - 2015-02-05 23:05:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-05 23:05:00 --> Language Class Initialized
DEBUG - 2015-02-05 23:05:00 --> Loader Class Initialized
DEBUG - 2015-02-05 23:05:00 --> Database Driver Class Initialized
DEBUG - 2015-02-05 23:05:01 --> XML-RPC Class Initialized
DEBUG - 2015-02-05 23:05:01 --> Controller Class Initialized
DEBUG - 2015-02-05 23:05:01 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-05 23:05:01 --> Helper loaded: inflector_helper
DEBUG - 2015-02-05 23:05:01 --> Model Class Initialized
DEBUG - 2015-02-05 23:05:01 --> Model Class Initialized
DEBUG - 2015-02-05 23:05:01 --> File loaded: application/views/email/registration.php
DEBUG - 2015-02-05 23:05:01 --> Email Class Initialized
DEBUG - 2015-02-05 23:05:03 --> Language file loaded: language/english/email_lang.php
