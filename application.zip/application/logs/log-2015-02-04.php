<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-02-04 19:02:24 --> Config Class Initialized
DEBUG - 2015-02-04 19:02:24 --> Hooks Class Initialized
DEBUG - 2015-02-04 19:02:25 --> Utf8 Class Initialized
DEBUG - 2015-02-04 19:02:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 19:02:25 --> URI Class Initialized
DEBUG - 2015-02-04 19:02:25 --> Router Class Initialized
DEBUG - 2015-02-04 19:02:25 --> Output Class Initialized
DEBUG - 2015-02-04 19:02:25 --> Security Class Initialized
DEBUG - 2015-02-04 19:02:25 --> Input Class Initialized
DEBUG - 2015-02-04 19:02:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 19:02:25 --> Language Class Initialized
DEBUG - 2015-02-04 19:02:25 --> Loader Class Initialized
DEBUG - 2015-02-04 19:02:25 --> Database Driver Class Initialized
DEBUG - 2015-02-04 19:02:26 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 19:02:26 --> Controller Class Initialized
DEBUG - 2015-02-04 19:02:26 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 19:02:26 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 19:02:46 --> Model Class Initialized
DEBUG - 2015-02-04 19:02:46 --> Model Class Initialized
DEBUG - 2015-02-04 19:04:37 --> Config Class Initialized
DEBUG - 2015-02-04 19:04:37 --> Hooks Class Initialized
DEBUG - 2015-02-04 19:04:37 --> Utf8 Class Initialized
DEBUG - 2015-02-04 19:04:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 19:04:37 --> URI Class Initialized
DEBUG - 2015-02-04 19:04:37 --> Router Class Initialized
DEBUG - 2015-02-04 19:04:37 --> Output Class Initialized
DEBUG - 2015-02-04 19:04:37 --> Security Class Initialized
DEBUG - 2015-02-04 19:04:37 --> Input Class Initialized
DEBUG - 2015-02-04 19:04:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 19:04:37 --> Language Class Initialized
DEBUG - 2015-02-04 19:04:37 --> Loader Class Initialized
DEBUG - 2015-02-04 19:04:37 --> Database Driver Class Initialized
DEBUG - 2015-02-04 19:04:37 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 19:04:37 --> Controller Class Initialized
DEBUG - 2015-02-04 19:04:37 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 19:04:37 --> Config Class Initialized
DEBUG - 2015-02-04 19:04:37 --> Hooks Class Initialized
DEBUG - 2015-02-04 19:04:37 --> Utf8 Class Initialized
DEBUG - 2015-02-04 19:04:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 19:04:37 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 19:04:37 --> URI Class Initialized
DEBUG - 2015-02-04 19:04:37 --> Router Class Initialized
DEBUG - 2015-02-04 19:04:37 --> Output Class Initialized
DEBUG - 2015-02-04 19:04:37 --> Security Class Initialized
DEBUG - 2015-02-04 19:04:37 --> Input Class Initialized
DEBUG - 2015-02-04 19:04:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 19:04:37 --> Language Class Initialized
DEBUG - 2015-02-04 19:04:37 --> Loader Class Initialized
DEBUG - 2015-02-04 19:04:37 --> Database Driver Class Initialized
DEBUG - 2015-02-04 19:04:38 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 19:04:38 --> Controller Class Initialized
DEBUG - 2015-02-04 19:04:38 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 19:04:38 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 19:04:51 --> Config Class Initialized
DEBUG - 2015-02-04 19:04:51 --> Hooks Class Initialized
DEBUG - 2015-02-04 19:04:51 --> Utf8 Class Initialized
DEBUG - 2015-02-04 19:04:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 19:04:51 --> URI Class Initialized
DEBUG - 2015-02-04 19:04:51 --> Router Class Initialized
DEBUG - 2015-02-04 19:04:51 --> Output Class Initialized
DEBUG - 2015-02-04 19:04:51 --> Security Class Initialized
DEBUG - 2015-02-04 19:04:51 --> Input Class Initialized
DEBUG - 2015-02-04 19:04:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 19:04:51 --> Language Class Initialized
DEBUG - 2015-02-04 19:04:51 --> Loader Class Initialized
DEBUG - 2015-02-04 19:04:51 --> Database Driver Class Initialized
DEBUG - 2015-02-04 19:04:52 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 19:04:52 --> Controller Class Initialized
DEBUG - 2015-02-04 19:04:52 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 19:04:52 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 19:04:56 --> Model Class Initialized
DEBUG - 2015-02-04 19:04:56 --> Model Class Initialized
DEBUG - 2015-02-04 19:04:56 --> File loaded: application/views/email/registration.php
DEBUG - 2015-02-04 19:04:56 --> Email Class Initialized
DEBUG - 2015-02-04 19:04:57 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-04 19:04:58 --> Model Class Initialized
DEBUG - 2015-02-04 19:04:58 --> Model Class Initialized
DEBUG - 2015-02-04 19:04:58 --> File loaded: application/views/email/registration.php
DEBUG - 2015-02-04 19:04:58 --> Email Class Initialized
DEBUG - 2015-02-04 19:04:59 --> Language file loaded: language/english/email_lang.php
ERROR - 2015-02-04 19:05:10 --> Severity: Notice  --> Trying to get property of non-object D:\www\thunderbirds\server\application\models\users_model.php 514
ERROR - 2015-02-04 19:05:10 --> Severity: Notice  --> Trying to get property of non-object D:\www\thunderbirds\server\application\models\users_model.php 514
DEBUG - 2015-02-04 19:05:12 --> Model Class Initialized
DEBUG - 2015-02-04 19:05:12 --> Model Class Initialized
DEBUG - 2015-02-04 19:05:18 --> Config Class Initialized
DEBUG - 2015-02-04 19:05:18 --> Hooks Class Initialized
DEBUG - 2015-02-04 19:05:18 --> Utf8 Class Initialized
DEBUG - 2015-02-04 19:05:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 19:05:18 --> URI Class Initialized
DEBUG - 2015-02-04 19:05:18 --> Router Class Initialized
DEBUG - 2015-02-04 19:05:18 --> Output Class Initialized
DEBUG - 2015-02-04 19:05:18 --> Security Class Initialized
DEBUG - 2015-02-04 19:05:18 --> Input Class Initialized
DEBUG - 2015-02-04 19:05:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 19:05:18 --> Language Class Initialized
DEBUG - 2015-02-04 19:05:18 --> Loader Class Initialized
DEBUG - 2015-02-04 19:05:18 --> Database Driver Class Initialized
DEBUG - 2015-02-04 19:05:18 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 19:05:18 --> Controller Class Initialized
DEBUG - 2015-02-04 19:05:18 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 19:05:18 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 19:05:27 --> Config Class Initialized
DEBUG - 2015-02-04 19:05:27 --> Hooks Class Initialized
DEBUG - 2015-02-04 19:05:27 --> Utf8 Class Initialized
DEBUG - 2015-02-04 19:05:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 19:05:27 --> URI Class Initialized
DEBUG - 2015-02-04 19:05:27 --> Router Class Initialized
DEBUG - 2015-02-04 19:05:27 --> Output Class Initialized
DEBUG - 2015-02-04 19:05:27 --> Security Class Initialized
DEBUG - 2015-02-04 19:05:27 --> Input Class Initialized
DEBUG - 2015-02-04 19:05:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 19:05:27 --> Language Class Initialized
DEBUG - 2015-02-04 19:05:27 --> Loader Class Initialized
DEBUG - 2015-02-04 19:05:27 --> Database Driver Class Initialized
DEBUG - 2015-02-04 19:05:27 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 19:05:27 --> Controller Class Initialized
DEBUG - 2015-02-04 19:05:27 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 19:05:27 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 19:05:39 --> Model Class Initialized
DEBUG - 2015-02-04 19:05:39 --> Model Class Initialized
DEBUG - 2015-02-04 19:05:49 --> Model Class Initialized
DEBUG - 2015-02-04 19:05:49 --> Model Class Initialized
DEBUG - 2015-02-04 19:22:40 --> Config Class Initialized
DEBUG - 2015-02-04 19:22:40 --> Hooks Class Initialized
DEBUG - 2015-02-04 19:22:40 --> Utf8 Class Initialized
DEBUG - 2015-02-04 19:22:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 19:22:40 --> URI Class Initialized
DEBUG - 2015-02-04 19:22:40 --> Router Class Initialized
DEBUG - 2015-02-04 19:22:40 --> Output Class Initialized
DEBUG - 2015-02-04 19:22:40 --> Security Class Initialized
DEBUG - 2015-02-04 19:22:40 --> Input Class Initialized
DEBUG - 2015-02-04 19:22:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 19:22:40 --> Language Class Initialized
DEBUG - 2015-02-04 19:22:40 --> Config Class Initialized
DEBUG - 2015-02-04 19:22:40 --> Hooks Class Initialized
DEBUG - 2015-02-04 19:22:40 --> Utf8 Class Initialized
DEBUG - 2015-02-04 19:22:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 19:22:40 --> URI Class Initialized
DEBUG - 2015-02-04 19:22:40 --> Router Class Initialized
DEBUG - 2015-02-04 19:22:40 --> Loader Class Initialized
DEBUG - 2015-02-04 19:22:40 --> Output Class Initialized
DEBUG - 2015-02-04 19:22:40 --> Security Class Initialized
DEBUG - 2015-02-04 19:22:40 --> Input Class Initialized
DEBUG - 2015-02-04 19:22:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 19:22:40 --> Language Class Initialized
DEBUG - 2015-02-04 19:22:40 --> Database Driver Class Initialized
DEBUG - 2015-02-04 19:22:40 --> Loader Class Initialized
DEBUG - 2015-02-04 19:22:40 --> Database Driver Class Initialized
DEBUG - 2015-02-04 19:22:40 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 19:22:40 --> Controller Class Initialized
DEBUG - 2015-02-04 19:22:40 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 19:22:40 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 19:22:40 --> Model Class Initialized
DEBUG - 2015-02-04 19:22:40 --> Model Class Initialized
DEBUG - 2015-02-04 19:22:41 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 19:22:41 --> Controller Class Initialized
DEBUG - 2015-02-04 19:22:41 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 19:22:41 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 19:22:41 --> Model Class Initialized
DEBUG - 2015-02-04 19:22:41 --> Model Class Initialized
DEBUG - 2015-02-04 19:22:46 --> Config Class Initialized
DEBUG - 2015-02-04 19:22:46 --> Hooks Class Initialized
DEBUG - 2015-02-04 19:22:46 --> Utf8 Class Initialized
DEBUG - 2015-02-04 19:22:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 19:22:46 --> URI Class Initialized
DEBUG - 2015-02-04 19:22:46 --> Router Class Initialized
DEBUG - 2015-02-04 19:22:46 --> Output Class Initialized
DEBUG - 2015-02-04 19:22:46 --> Security Class Initialized
DEBUG - 2015-02-04 19:22:46 --> Input Class Initialized
DEBUG - 2015-02-04 19:22:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 19:22:46 --> Language Class Initialized
DEBUG - 2015-02-04 19:22:46 --> Loader Class Initialized
DEBUG - 2015-02-04 19:22:46 --> Database Driver Class Initialized
DEBUG - 2015-02-04 19:22:46 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 19:22:46 --> Controller Class Initialized
DEBUG - 2015-02-04 19:22:46 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 19:22:46 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 19:22:46 --> Model Class Initialized
DEBUG - 2015-02-04 19:22:46 --> Model Class Initialized
DEBUG - 2015-02-04 19:56:12 --> Config Class Initialized
DEBUG - 2015-02-04 19:56:12 --> Hooks Class Initialized
DEBUG - 2015-02-04 19:56:12 --> Utf8 Class Initialized
DEBUG - 2015-02-04 19:56:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 19:56:12 --> URI Class Initialized
DEBUG - 2015-02-04 19:56:12 --> Router Class Initialized
DEBUG - 2015-02-04 19:56:12 --> Output Class Initialized
DEBUG - 2015-02-04 19:56:12 --> Security Class Initialized
DEBUG - 2015-02-04 19:56:12 --> Input Class Initialized
DEBUG - 2015-02-04 19:56:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 19:56:12 --> Language Class Initialized
DEBUG - 2015-02-04 19:56:12 --> Loader Class Initialized
DEBUG - 2015-02-04 19:56:12 --> Database Driver Class Initialized
DEBUG - 2015-02-04 19:56:13 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 19:56:13 --> Controller Class Initialized
DEBUG - 2015-02-04 19:56:13 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 19:56:13 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 19:56:13 --> Model Class Initialized
DEBUG - 2015-02-04 19:56:13 --> Model Class Initialized
DEBUG - 2015-02-04 19:56:41 --> Config Class Initialized
DEBUG - 2015-02-04 19:56:41 --> Hooks Class Initialized
DEBUG - 2015-02-04 19:56:41 --> Utf8 Class Initialized
DEBUG - 2015-02-04 19:56:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 19:56:41 --> URI Class Initialized
DEBUG - 2015-02-04 19:56:41 --> Router Class Initialized
DEBUG - 2015-02-04 19:56:41 --> Output Class Initialized
DEBUG - 2015-02-04 19:56:41 --> Security Class Initialized
DEBUG - 2015-02-04 19:56:41 --> Input Class Initialized
DEBUG - 2015-02-04 19:56:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 19:56:41 --> Language Class Initialized
DEBUG - 2015-02-04 19:56:41 --> Loader Class Initialized
DEBUG - 2015-02-04 19:56:41 --> Database Driver Class Initialized
DEBUG - 2015-02-04 19:56:41 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 19:56:41 --> Controller Class Initialized
DEBUG - 2015-02-04 19:56:41 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 19:56:41 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 19:56:41 --> Model Class Initialized
DEBUG - 2015-02-04 19:56:41 --> Model Class Initialized
DEBUG - 2015-02-04 19:56:44 --> Config Class Initialized
DEBUG - 2015-02-04 19:56:44 --> Hooks Class Initialized
DEBUG - 2015-02-04 19:56:44 --> Utf8 Class Initialized
DEBUG - 2015-02-04 19:56:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 19:56:44 --> URI Class Initialized
DEBUG - 2015-02-04 19:56:44 --> Router Class Initialized
DEBUG - 2015-02-04 19:56:44 --> Output Class Initialized
DEBUG - 2015-02-04 19:56:44 --> Security Class Initialized
DEBUG - 2015-02-04 19:56:44 --> Input Class Initialized
DEBUG - 2015-02-04 19:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 19:56:44 --> Language Class Initialized
DEBUG - 2015-02-04 19:56:44 --> Loader Class Initialized
DEBUG - 2015-02-04 19:56:44 --> Database Driver Class Initialized
DEBUG - 2015-02-04 19:56:44 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 19:56:44 --> Controller Class Initialized
DEBUG - 2015-02-04 19:56:44 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 19:56:44 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 19:56:44 --> Model Class Initialized
DEBUG - 2015-02-04 19:56:44 --> Model Class Initialized
DEBUG - 2015-02-04 19:56:44 --> File loaded: application/views/email/registration.php
DEBUG - 2015-02-04 19:56:44 --> Email Class Initialized
DEBUG - 2015-02-04 19:56:45 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-04 19:57:48 --> Config Class Initialized
DEBUG - 2015-02-04 19:57:48 --> Hooks Class Initialized
DEBUG - 2015-02-04 19:57:48 --> Utf8 Class Initialized
DEBUG - 2015-02-04 19:57:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 19:57:48 --> URI Class Initialized
DEBUG - 2015-02-04 19:57:48 --> Router Class Initialized
DEBUG - 2015-02-04 19:57:48 --> Output Class Initialized
DEBUG - 2015-02-04 19:57:48 --> Security Class Initialized
DEBUG - 2015-02-04 19:57:48 --> Input Class Initialized
DEBUG - 2015-02-04 19:57:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 19:57:48 --> Language Class Initialized
DEBUG - 2015-02-04 19:57:48 --> Config Class Initialized
DEBUG - 2015-02-04 19:57:48 --> Hooks Class Initialized
DEBUG - 2015-02-04 19:57:48 --> Utf8 Class Initialized
DEBUG - 2015-02-04 19:57:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 19:57:48 --> URI Class Initialized
DEBUG - 2015-02-04 19:57:48 --> Router Class Initialized
DEBUG - 2015-02-04 19:57:48 --> Output Class Initialized
DEBUG - 2015-02-04 19:57:48 --> Loader Class Initialized
DEBUG - 2015-02-04 19:57:48 --> Security Class Initialized
DEBUG - 2015-02-04 19:57:48 --> Input Class Initialized
DEBUG - 2015-02-04 19:57:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 19:57:48 --> Language Class Initialized
DEBUG - 2015-02-04 19:57:48 --> Database Driver Class Initialized
DEBUG - 2015-02-04 19:57:48 --> Loader Class Initialized
DEBUG - 2015-02-04 19:57:48 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 19:57:48 --> Controller Class Initialized
DEBUG - 2015-02-04 19:57:48 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 19:57:48 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 19:57:48 --> Model Class Initialized
DEBUG - 2015-02-04 19:57:48 --> Database Driver Class Initialized
DEBUG - 2015-02-04 19:57:48 --> Model Class Initialized
DEBUG - 2015-02-04 19:57:48 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 19:57:48 --> Controller Class Initialized
DEBUG - 2015-02-04 19:57:48 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 19:57:48 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 19:57:48 --> Model Class Initialized
DEBUG - 2015-02-04 19:57:48 --> DB Transaction Failure
ERROR - 2015-02-04 19:57:48 --> Query error: Unknown column 'username' in 'where clause'
DEBUG - 2015-02-04 19:57:48 --> Model Class Initialized
DEBUG - 2015-02-04 19:57:48 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-04 19:57:48 --> DB Transaction Failure
ERROR - 2015-02-04 19:57:48 --> Query error: Unknown column 'username' in 'where clause'
DEBUG - 2015-02-04 19:57:48 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-04 19:57:55 --> Config Class Initialized
DEBUG - 2015-02-04 19:57:55 --> Hooks Class Initialized
DEBUG - 2015-02-04 19:57:55 --> Utf8 Class Initialized
DEBUG - 2015-02-04 19:57:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 19:57:55 --> URI Class Initialized
DEBUG - 2015-02-04 19:57:55 --> Router Class Initialized
DEBUG - 2015-02-04 19:57:55 --> Output Class Initialized
DEBUG - 2015-02-04 19:57:55 --> Security Class Initialized
DEBUG - 2015-02-04 19:57:55 --> Input Class Initialized
DEBUG - 2015-02-04 19:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 19:57:55 --> Language Class Initialized
DEBUG - 2015-02-04 19:57:55 --> Loader Class Initialized
DEBUG - 2015-02-04 19:57:55 --> Database Driver Class Initialized
DEBUG - 2015-02-04 19:57:56 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 19:57:56 --> Controller Class Initialized
DEBUG - 2015-02-04 19:57:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 19:57:56 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 19:57:56 --> Model Class Initialized
DEBUG - 2015-02-04 19:57:56 --> Model Class Initialized
DEBUG - 2015-02-04 19:57:56 --> DB Transaction Failure
ERROR - 2015-02-04 19:57:56 --> Query error: Unknown column 'username' in 'where clause'
DEBUG - 2015-02-04 19:57:56 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-04 19:59:00 --> Config Class Initialized
DEBUG - 2015-02-04 19:59:00 --> Hooks Class Initialized
DEBUG - 2015-02-04 19:59:00 --> Utf8 Class Initialized
DEBUG - 2015-02-04 19:59:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 19:59:00 --> URI Class Initialized
DEBUG - 2015-02-04 19:59:00 --> Router Class Initialized
DEBUG - 2015-02-04 19:59:00 --> Output Class Initialized
DEBUG - 2015-02-04 19:59:00 --> Security Class Initialized
DEBUG - 2015-02-04 19:59:00 --> Input Class Initialized
DEBUG - 2015-02-04 19:59:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 19:59:00 --> Language Class Initialized
DEBUG - 2015-02-04 19:59:00 --> Loader Class Initialized
DEBUG - 2015-02-04 19:59:00 --> Database Driver Class Initialized
DEBUG - 2015-02-04 19:59:00 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 19:59:00 --> Controller Class Initialized
DEBUG - 2015-02-04 19:59:00 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 19:59:00 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 19:59:00 --> Model Class Initialized
DEBUG - 2015-02-04 19:59:00 --> Model Class Initialized
DEBUG - 2015-02-04 19:59:00 --> DB Transaction Failure
ERROR - 2015-02-04 19:59:00 --> Query error: Unknown column 'username' in 'where clause'
DEBUG - 2015-02-04 19:59:00 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-04 19:59:08 --> Config Class Initialized
DEBUG - 2015-02-04 19:59:08 --> Hooks Class Initialized
DEBUG - 2015-02-04 19:59:08 --> Utf8 Class Initialized
DEBUG - 2015-02-04 19:59:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 19:59:08 --> URI Class Initialized
DEBUG - 2015-02-04 19:59:08 --> Router Class Initialized
DEBUG - 2015-02-04 19:59:08 --> Output Class Initialized
DEBUG - 2015-02-04 19:59:08 --> Security Class Initialized
DEBUG - 2015-02-04 19:59:08 --> Input Class Initialized
DEBUG - 2015-02-04 19:59:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 19:59:08 --> Language Class Initialized
DEBUG - 2015-02-04 19:59:08 --> Loader Class Initialized
DEBUG - 2015-02-04 19:59:08 --> Database Driver Class Initialized
DEBUG - 2015-02-04 19:59:08 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 19:59:08 --> Controller Class Initialized
DEBUG - 2015-02-04 19:59:08 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 19:59:08 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 19:59:08 --> Model Class Initialized
DEBUG - 2015-02-04 19:59:08 --> Model Class Initialized
DEBUG - 2015-02-04 19:59:20 --> Config Class Initialized
DEBUG - 2015-02-04 19:59:20 --> Hooks Class Initialized
DEBUG - 2015-02-04 19:59:20 --> Utf8 Class Initialized
DEBUG - 2015-02-04 19:59:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 19:59:20 --> URI Class Initialized
DEBUG - 2015-02-04 19:59:20 --> Router Class Initialized
DEBUG - 2015-02-04 19:59:20 --> Output Class Initialized
DEBUG - 2015-02-04 19:59:20 --> Security Class Initialized
DEBUG - 2015-02-04 19:59:20 --> Input Class Initialized
DEBUG - 2015-02-04 19:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 19:59:20 --> Language Class Initialized
DEBUG - 2015-02-04 19:59:20 --> Loader Class Initialized
DEBUG - 2015-02-04 19:59:20 --> Database Driver Class Initialized
DEBUG - 2015-02-04 19:59:20 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 19:59:20 --> Controller Class Initialized
DEBUG - 2015-02-04 19:59:20 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 19:59:20 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 19:59:20 --> Model Class Initialized
DEBUG - 2015-02-04 19:59:20 --> Model Class Initialized
DEBUG - 2015-02-04 20:00:08 --> Config Class Initialized
DEBUG - 2015-02-04 20:00:08 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:00:08 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:00:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:00:08 --> URI Class Initialized
DEBUG - 2015-02-04 20:00:08 --> Router Class Initialized
DEBUG - 2015-02-04 20:00:08 --> Output Class Initialized
DEBUG - 2015-02-04 20:00:08 --> Security Class Initialized
DEBUG - 2015-02-04 20:00:08 --> Input Class Initialized
DEBUG - 2015-02-04 20:00:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:00:08 --> Language Class Initialized
DEBUG - 2015-02-04 20:00:08 --> Loader Class Initialized
DEBUG - 2015-02-04 20:00:08 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:00:08 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:00:08 --> Controller Class Initialized
DEBUG - 2015-02-04 20:00:08 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:00:08 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:00:08 --> Model Class Initialized
DEBUG - 2015-02-04 20:00:08 --> Model Class Initialized
DEBUG - 2015-02-04 20:00:10 --> Config Class Initialized
DEBUG - 2015-02-04 20:00:10 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:00:10 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:00:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:00:10 --> URI Class Initialized
DEBUG - 2015-02-04 20:00:10 --> Router Class Initialized
DEBUG - 2015-02-04 20:00:10 --> Output Class Initialized
DEBUG - 2015-02-04 20:00:10 --> Security Class Initialized
DEBUG - 2015-02-04 20:00:10 --> Input Class Initialized
DEBUG - 2015-02-04 20:00:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:00:10 --> Language Class Initialized
DEBUG - 2015-02-04 20:00:10 --> Loader Class Initialized
DEBUG - 2015-02-04 20:00:10 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:00:10 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:00:10 --> Controller Class Initialized
DEBUG - 2015-02-04 20:00:10 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:00:10 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:00:10 --> Model Class Initialized
DEBUG - 2015-02-04 20:00:10 --> Model Class Initialized
DEBUG - 2015-02-04 20:00:11 --> Config Class Initialized
DEBUG - 2015-02-04 20:00:11 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:00:11 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:00:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:00:11 --> URI Class Initialized
DEBUG - 2015-02-04 20:00:11 --> Router Class Initialized
DEBUG - 2015-02-04 20:00:11 --> Output Class Initialized
DEBUG - 2015-02-04 20:00:11 --> Security Class Initialized
DEBUG - 2015-02-04 20:00:11 --> Input Class Initialized
DEBUG - 2015-02-04 20:00:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:00:11 --> Language Class Initialized
DEBUG - 2015-02-04 20:00:11 --> Loader Class Initialized
DEBUG - 2015-02-04 20:00:11 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:00:11 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:00:11 --> Controller Class Initialized
DEBUG - 2015-02-04 20:00:11 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:00:11 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:00:11 --> Model Class Initialized
DEBUG - 2015-02-04 20:00:11 --> Model Class Initialized
DEBUG - 2015-02-04 20:01:56 --> Config Class Initialized
DEBUG - 2015-02-04 20:01:56 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:01:56 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:01:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:01:56 --> URI Class Initialized
DEBUG - 2015-02-04 20:01:56 --> Router Class Initialized
DEBUG - 2015-02-04 20:01:56 --> Output Class Initialized
DEBUG - 2015-02-04 20:01:56 --> Security Class Initialized
DEBUG - 2015-02-04 20:01:56 --> Input Class Initialized
DEBUG - 2015-02-04 20:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:01:56 --> Language Class Initialized
DEBUG - 2015-02-04 20:01:56 --> Loader Class Initialized
DEBUG - 2015-02-04 20:01:56 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:01:56 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:01:56 --> Controller Class Initialized
DEBUG - 2015-02-04 20:01:56 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:01:56 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:01:56 --> Model Class Initialized
DEBUG - 2015-02-04 20:01:56 --> Model Class Initialized
DEBUG - 2015-02-04 20:02:05 --> Config Class Initialized
DEBUG - 2015-02-04 20:02:05 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:02:05 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:02:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:02:05 --> URI Class Initialized
DEBUG - 2015-02-04 20:02:05 --> Router Class Initialized
DEBUG - 2015-02-04 20:02:05 --> Output Class Initialized
DEBUG - 2015-02-04 20:02:05 --> Security Class Initialized
DEBUG - 2015-02-04 20:02:05 --> Input Class Initialized
DEBUG - 2015-02-04 20:02:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:02:05 --> Language Class Initialized
DEBUG - 2015-02-04 20:02:05 --> Loader Class Initialized
DEBUG - 2015-02-04 20:02:05 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:02:05 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:02:05 --> Controller Class Initialized
DEBUG - 2015-02-04 20:02:05 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:02:05 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:02:05 --> Model Class Initialized
DEBUG - 2015-02-04 20:02:05 --> Model Class Initialized
DEBUG - 2015-02-04 20:02:05 --> File loaded: application/views/email/registration.php
DEBUG - 2015-02-04 20:02:05 --> Email Class Initialized
DEBUG - 2015-02-04 20:02:06 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-04 20:03:59 --> Config Class Initialized
DEBUG - 2015-02-04 20:03:59 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:03:59 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:03:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:03:59 --> URI Class Initialized
DEBUG - 2015-02-04 20:03:59 --> Router Class Initialized
DEBUG - 2015-02-04 20:03:59 --> Output Class Initialized
DEBUG - 2015-02-04 20:03:59 --> Security Class Initialized
DEBUG - 2015-02-04 20:03:59 --> Input Class Initialized
DEBUG - 2015-02-04 20:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:03:59 --> Language Class Initialized
DEBUG - 2015-02-04 20:03:59 --> Loader Class Initialized
DEBUG - 2015-02-04 20:03:59 --> Config Class Initialized
DEBUG - 2015-02-04 20:03:59 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:03:59 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:03:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:03:59 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:03:59 --> URI Class Initialized
DEBUG - 2015-02-04 20:03:59 --> Router Class Initialized
DEBUG - 2015-02-04 20:03:59 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:03:59 --> Output Class Initialized
DEBUG - 2015-02-04 20:03:59 --> Controller Class Initialized
DEBUG - 2015-02-04 20:03:59 --> Security Class Initialized
DEBUG - 2015-02-04 20:03:59 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:03:59 --> Input Class Initialized
DEBUG - 2015-02-04 20:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:03:59 --> Language Class Initialized
DEBUG - 2015-02-04 20:03:59 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:03:59 --> Model Class Initialized
DEBUG - 2015-02-04 20:03:59 --> Model Class Initialized
DEBUG - 2015-02-04 20:03:59 --> File loaded: application/views/email/registration.php
DEBUG - 2015-02-04 20:03:59 --> Loader Class Initialized
DEBUG - 2015-02-04 20:03:59 --> Email Class Initialized
DEBUG - 2015-02-04 20:03:59 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:03:59 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:03:59 --> Controller Class Initialized
DEBUG - 2015-02-04 20:03:59 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:03:59 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:03:59 --> Model Class Initialized
DEBUG - 2015-02-04 20:03:59 --> Model Class Initialized
DEBUG - 2015-02-04 20:03:59 --> File loaded: application/views/email/registration.php
DEBUG - 2015-02-04 20:03:59 --> Email Class Initialized
DEBUG - 2015-02-04 20:04:00 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-04 20:04:00 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-04 20:04:22 --> Config Class Initialized
DEBUG - 2015-02-04 20:04:22 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:04:22 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:04:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:04:22 --> URI Class Initialized
DEBUG - 2015-02-04 20:04:22 --> Router Class Initialized
DEBUG - 2015-02-04 20:04:22 --> Output Class Initialized
DEBUG - 2015-02-04 20:04:22 --> Security Class Initialized
DEBUG - 2015-02-04 20:04:22 --> Input Class Initialized
DEBUG - 2015-02-04 20:04:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:04:22 --> Language Class Initialized
DEBUG - 2015-02-04 20:04:22 --> Loader Class Initialized
DEBUG - 2015-02-04 20:04:22 --> Config Class Initialized
DEBUG - 2015-02-04 20:04:22 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:04:22 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:04:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:04:22 --> URI Class Initialized
DEBUG - 2015-02-04 20:04:22 --> Router Class Initialized
DEBUG - 2015-02-04 20:04:22 --> Output Class Initialized
DEBUG - 2015-02-04 20:04:22 --> Security Class Initialized
DEBUG - 2015-02-04 20:04:22 --> Input Class Initialized
DEBUG - 2015-02-04 20:04:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:04:22 --> Language Class Initialized
DEBUG - 2015-02-04 20:04:22 --> Loader Class Initialized
DEBUG - 2015-02-04 20:04:22 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:04:22 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:04:22 --> Controller Class Initialized
DEBUG - 2015-02-04 20:04:22 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:04:22 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:04:22 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:04:22 --> Model Class Initialized
DEBUG - 2015-02-04 20:04:22 --> Model Class Initialized
DEBUG - 2015-02-04 20:04:22 --> File loaded: application/views/email/registration.php
DEBUG - 2015-02-04 20:04:22 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:04:22 --> Controller Class Initialized
DEBUG - 2015-02-04 20:04:22 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:04:22 --> Email Class Initialized
DEBUG - 2015-02-04 20:04:22 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:04:22 --> Model Class Initialized
DEBUG - 2015-02-04 20:04:22 --> Model Class Initialized
DEBUG - 2015-02-04 20:04:22 --> File loaded: application/views/email/registration.php
DEBUG - 2015-02-04 20:04:22 --> Email Class Initialized
DEBUG - 2015-02-04 20:04:25 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-04 20:04:25 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-04 20:04:47 --> Config Class Initialized
DEBUG - 2015-02-04 20:04:47 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:04:47 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:04:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:04:47 --> URI Class Initialized
DEBUG - 2015-02-04 20:04:47 --> Router Class Initialized
DEBUG - 2015-02-04 20:04:47 --> Output Class Initialized
DEBUG - 2015-02-04 20:04:47 --> Security Class Initialized
DEBUG - 2015-02-04 20:04:47 --> Input Class Initialized
DEBUG - 2015-02-04 20:04:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:04:47 --> Language Class Initialized
DEBUG - 2015-02-04 20:04:47 --> Loader Class Initialized
DEBUG - 2015-02-04 20:04:47 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:04:47 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:04:47 --> Controller Class Initialized
DEBUG - 2015-02-04 20:04:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:04:47 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:04:47 --> Model Class Initialized
DEBUG - 2015-02-04 20:04:47 --> Model Class Initialized
DEBUG - 2015-02-04 20:05:27 --> Config Class Initialized
DEBUG - 2015-02-04 20:05:27 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:05:27 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:05:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:05:27 --> URI Class Initialized
DEBUG - 2015-02-04 20:05:27 --> Router Class Initialized
DEBUG - 2015-02-04 20:05:27 --> Output Class Initialized
DEBUG - 2015-02-04 20:05:27 --> Security Class Initialized
DEBUG - 2015-02-04 20:05:27 --> Input Class Initialized
DEBUG - 2015-02-04 20:05:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:05:27 --> Language Class Initialized
DEBUG - 2015-02-04 20:05:27 --> Loader Class Initialized
DEBUG - 2015-02-04 20:05:27 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:05:27 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:05:27 --> Controller Class Initialized
DEBUG - 2015-02-04 20:05:27 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:05:27 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:05:27 --> Model Class Initialized
DEBUG - 2015-02-04 20:05:27 --> Model Class Initialized
DEBUG - 2015-02-04 20:05:27 --> File loaded: application/views/email/registration.php
DEBUG - 2015-02-04 20:05:27 --> Email Class Initialized
DEBUG - 2015-02-04 20:05:29 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-04 20:05:41 --> Config Class Initialized
DEBUG - 2015-02-04 20:05:41 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:05:41 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:05:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:05:41 --> URI Class Initialized
DEBUG - 2015-02-04 20:05:41 --> Router Class Initialized
DEBUG - 2015-02-04 20:05:41 --> Output Class Initialized
DEBUG - 2015-02-04 20:05:41 --> Security Class Initialized
DEBUG - 2015-02-04 20:05:41 --> Input Class Initialized
DEBUG - 2015-02-04 20:05:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:05:41 --> Language Class Initialized
DEBUG - 2015-02-04 20:05:41 --> Loader Class Initialized
DEBUG - 2015-02-04 20:05:41 --> Config Class Initialized
DEBUG - 2015-02-04 20:05:41 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:05:41 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:05:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:05:41 --> URI Class Initialized
DEBUG - 2015-02-04 20:05:41 --> Router Class Initialized
DEBUG - 2015-02-04 20:05:41 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:05:41 --> Output Class Initialized
DEBUG - 2015-02-04 20:05:41 --> Security Class Initialized
DEBUG - 2015-02-04 20:05:41 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:05:41 --> Controller Class Initialized
DEBUG - 2015-02-04 20:05:41 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:05:41 --> Input Class Initialized
DEBUG - 2015-02-04 20:05:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:05:41 --> Language Class Initialized
DEBUG - 2015-02-04 20:05:41 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:05:41 --> Model Class Initialized
DEBUG - 2015-02-04 20:05:41 --> Model Class Initialized
DEBUG - 2015-02-04 20:05:41 --> Loader Class Initialized
DEBUG - 2015-02-04 20:05:41 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:05:41 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:05:41 --> Controller Class Initialized
DEBUG - 2015-02-04 20:05:41 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:05:41 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:05:41 --> Model Class Initialized
DEBUG - 2015-02-04 20:05:41 --> Model Class Initialized
DEBUG - 2015-02-04 20:06:26 --> Config Class Initialized
DEBUG - 2015-02-04 20:06:26 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:06:26 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:06:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:06:26 --> URI Class Initialized
DEBUG - 2015-02-04 20:06:26 --> Router Class Initialized
DEBUG - 2015-02-04 20:06:26 --> Output Class Initialized
DEBUG - 2015-02-04 20:06:26 --> Security Class Initialized
DEBUG - 2015-02-04 20:06:26 --> Input Class Initialized
DEBUG - 2015-02-04 20:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:06:26 --> Language Class Initialized
DEBUG - 2015-02-04 20:06:26 --> Loader Class Initialized
DEBUG - 2015-02-04 20:06:26 --> Config Class Initialized
DEBUG - 2015-02-04 20:06:26 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:06:26 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:06:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:06:26 --> URI Class Initialized
DEBUG - 2015-02-04 20:06:26 --> Router Class Initialized
DEBUG - 2015-02-04 20:06:26 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:06:26 --> Output Class Initialized
DEBUG - 2015-02-04 20:06:26 --> Security Class Initialized
DEBUG - 2015-02-04 20:06:26 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:06:26 --> Controller Class Initialized
DEBUG - 2015-02-04 20:06:26 --> Input Class Initialized
DEBUG - 2015-02-04 20:06:26 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:06:26 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:06:26 --> Model Class Initialized
DEBUG - 2015-02-04 20:06:26 --> Model Class Initialized
DEBUG - 2015-02-04 20:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:06:26 --> Language Class Initialized
DEBUG - 2015-02-04 20:06:26 --> Loader Class Initialized
DEBUG - 2015-02-04 20:06:26 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:06:26 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:06:26 --> Controller Class Initialized
DEBUG - 2015-02-04 20:06:26 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:06:26 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:06:26 --> Model Class Initialized
DEBUG - 2015-02-04 20:06:26 --> Model Class Initialized
DEBUG - 2015-02-04 20:06:51 --> Config Class Initialized
DEBUG - 2015-02-04 20:06:51 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:06:51 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:06:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:06:51 --> URI Class Initialized
DEBUG - 2015-02-04 20:06:51 --> Router Class Initialized
DEBUG - 2015-02-04 20:06:51 --> Output Class Initialized
DEBUG - 2015-02-04 20:06:51 --> Config Class Initialized
DEBUG - 2015-02-04 20:06:51 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:06:51 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:06:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:06:51 --> Security Class Initialized
DEBUG - 2015-02-04 20:06:51 --> URI Class Initialized
DEBUG - 2015-02-04 20:06:51 --> Input Class Initialized
DEBUG - 2015-02-04 20:06:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:06:51 --> Router Class Initialized
DEBUG - 2015-02-04 20:06:51 --> Language Class Initialized
DEBUG - 2015-02-04 20:06:51 --> Output Class Initialized
DEBUG - 2015-02-04 20:06:51 --> Security Class Initialized
DEBUG - 2015-02-04 20:06:51 --> Input Class Initialized
DEBUG - 2015-02-04 20:06:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:06:51 --> Language Class Initialized
DEBUG - 2015-02-04 20:06:51 --> Loader Class Initialized
DEBUG - 2015-02-04 20:06:51 --> Loader Class Initialized
DEBUG - 2015-02-04 20:06:51 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:06:51 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:06:51 --> Controller Class Initialized
DEBUG - 2015-02-04 20:06:51 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:06:51 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:06:51 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:06:51 --> Model Class Initialized
DEBUG - 2015-02-04 20:06:51 --> Model Class Initialized
DEBUG - 2015-02-04 20:06:51 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:06:51 --> Controller Class Initialized
DEBUG - 2015-02-04 20:06:51 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:06:51 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:06:51 --> Model Class Initialized
DEBUG - 2015-02-04 20:06:51 --> Model Class Initialized
DEBUG - 2015-02-04 20:07:19 --> Config Class Initialized
DEBUG - 2015-02-04 20:07:19 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:07:19 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:07:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:07:19 --> URI Class Initialized
DEBUG - 2015-02-04 20:07:19 --> Router Class Initialized
DEBUG - 2015-02-04 20:07:19 --> Output Class Initialized
DEBUG - 2015-02-04 20:07:19 --> Security Class Initialized
DEBUG - 2015-02-04 20:07:19 --> Input Class Initialized
DEBUG - 2015-02-04 20:07:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:07:19 --> Language Class Initialized
DEBUG - 2015-02-04 20:07:19 --> Loader Class Initialized
DEBUG - 2015-02-04 20:07:19 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:07:19 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:07:19 --> Controller Class Initialized
DEBUG - 2015-02-04 20:07:19 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:07:19 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:07:19 --> Model Class Initialized
DEBUG - 2015-02-04 20:07:19 --> Model Class Initialized
DEBUG - 2015-02-04 20:07:19 --> Email Class Initialized
DEBUG - 2015-02-04 20:07:20 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-04 20:07:22 --> Final output sent to browser
DEBUG - 2015-02-04 20:07:22 --> Total execution time: 2.8469
DEBUG - 2015-02-04 20:07:35 --> Config Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:07:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:07:35 --> URI Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Config Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:07:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:07:35 --> URI Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Router Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Router Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Output Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Output Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Security Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Security Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Input Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:07:35 --> Input Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Language Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:07:35 --> Language Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Loader Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Loader Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:07:35 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Controller Class Initialized
DEBUG - 2015-02-04 20:07:35 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Controller Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:07:35 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:07:35 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:07:35 --> Model Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:07:35 --> Model Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Model Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Model Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Email Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Email Class Initialized
DEBUG - 2015-02-04 20:07:35 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-04 20:07:36 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-04 20:07:38 --> Final output sent to browser
DEBUG - 2015-02-04 20:07:38 --> Total execution time: 3.1150
DEBUG - 2015-02-04 20:07:38 --> Final output sent to browser
DEBUG - 2015-02-04 20:07:38 --> Total execution time: 3.1188
DEBUG - 2015-02-04 20:08:58 --> Config Class Initialized
DEBUG - 2015-02-04 20:08:58 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:08:58 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:08:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:08:58 --> URI Class Initialized
DEBUG - 2015-02-04 20:08:58 --> Router Class Initialized
DEBUG - 2015-02-04 20:08:58 --> Config Class Initialized
DEBUG - 2015-02-04 20:08:58 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:08:58 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:08:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:08:58 --> Output Class Initialized
DEBUG - 2015-02-04 20:08:58 --> URI Class Initialized
DEBUG - 2015-02-04 20:08:58 --> Security Class Initialized
DEBUG - 2015-02-04 20:08:58 --> Router Class Initialized
DEBUG - 2015-02-04 20:08:58 --> Input Class Initialized
DEBUG - 2015-02-04 20:08:58 --> Output Class Initialized
DEBUG - 2015-02-04 20:08:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:08:58 --> Language Class Initialized
DEBUG - 2015-02-04 20:08:58 --> Security Class Initialized
DEBUG - 2015-02-04 20:08:58 --> Input Class Initialized
DEBUG - 2015-02-04 20:08:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:08:58 --> Language Class Initialized
DEBUG - 2015-02-04 20:08:58 --> Loader Class Initialized
DEBUG - 2015-02-04 20:08:58 --> Loader Class Initialized
DEBUG - 2015-02-04 20:08:58 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:08:58 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:08:58 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:08:58 --> Controller Class Initialized
DEBUG - 2015-02-04 20:08:58 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:08:58 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:08:58 --> Controller Class Initialized
DEBUG - 2015-02-04 20:08:58 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:08:58 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:08:58 --> Model Class Initialized
DEBUG - 2015-02-04 20:08:58 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:08:58 --> Model Class Initialized
DEBUG - 2015-02-04 20:08:58 --> Model Class Initialized
DEBUG - 2015-02-04 20:08:58 --> Model Class Initialized
DEBUG - 2015-02-04 20:10:11 --> Config Class Initialized
DEBUG - 2015-02-04 20:10:11 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:10:11 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:10:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:10:11 --> URI Class Initialized
DEBUG - 2015-02-04 20:10:11 --> Router Class Initialized
DEBUG - 2015-02-04 20:10:11 --> Output Class Initialized
DEBUG - 2015-02-04 20:10:11 --> Security Class Initialized
DEBUG - 2015-02-04 20:10:11 --> Input Class Initialized
DEBUG - 2015-02-04 20:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:10:11 --> Language Class Initialized
DEBUG - 2015-02-04 20:10:11 --> Loader Class Initialized
DEBUG - 2015-02-04 20:10:11 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:10:11 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:10:11 --> Controller Class Initialized
DEBUG - 2015-02-04 20:10:11 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:10:11 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:10:11 --> Model Class Initialized
DEBUG - 2015-02-04 20:10:11 --> Model Class Initialized
DEBUG - 2015-02-04 20:10:11 --> DB Transaction Failure
ERROR - 2015-02-04 20:10:11 --> Query error: Unknown column 'u.username' in 'field list'
DEBUG - 2015-02-04 20:10:11 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-04 20:11:12 --> Config Class Initialized
DEBUG - 2015-02-04 20:11:12 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:11:12 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:11:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:11:12 --> URI Class Initialized
DEBUG - 2015-02-04 20:11:12 --> Router Class Initialized
DEBUG - 2015-02-04 20:11:12 --> Output Class Initialized
DEBUG - 2015-02-04 20:11:12 --> Security Class Initialized
DEBUG - 2015-02-04 20:11:12 --> Input Class Initialized
DEBUG - 2015-02-04 20:11:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:11:12 --> Language Class Initialized
DEBUG - 2015-02-04 20:11:12 --> Loader Class Initialized
DEBUG - 2015-02-04 20:11:12 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:11:12 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:11:12 --> Controller Class Initialized
DEBUG - 2015-02-04 20:11:12 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:11:12 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:11:12 --> Model Class Initialized
DEBUG - 2015-02-04 20:11:12 --> Model Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Config Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:18:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:18:05 --> URI Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Router Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Output Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Security Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Input Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:18:05 --> Language Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Loader Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:18:05 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Controller Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:18:05 --> Config Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:18:05 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Model Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:18:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:18:05 --> URI Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Router Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Output Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Model Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Security Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Input Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:18:05 --> Language Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Loader Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:18:05 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Controller Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:18:05 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:18:05 --> Model Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Model Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Config Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:18:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:18:05 --> URI Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Router Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Output Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Security Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Input Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:18:05 --> Language Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Loader Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:18:05 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Controller Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:18:05 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:18:05 --> Model Class Initialized
DEBUG - 2015-02-04 20:18:05 --> Model Class Initialized
DEBUG - 2015-02-04 20:18:06 --> Config Class Initialized
DEBUG - 2015-02-04 20:18:06 --> Hooks Class Initialized
DEBUG - 2015-02-04 20:18:06 --> Utf8 Class Initialized
DEBUG - 2015-02-04 20:18:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 20:18:06 --> URI Class Initialized
DEBUG - 2015-02-04 20:18:06 --> Router Class Initialized
DEBUG - 2015-02-04 20:18:06 --> Output Class Initialized
DEBUG - 2015-02-04 20:18:06 --> Security Class Initialized
DEBUG - 2015-02-04 20:18:06 --> Input Class Initialized
DEBUG - 2015-02-04 20:18:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 20:18:06 --> Language Class Initialized
DEBUG - 2015-02-04 20:18:06 --> Loader Class Initialized
DEBUG - 2015-02-04 20:18:06 --> Database Driver Class Initialized
DEBUG - 2015-02-04 20:18:06 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 20:18:06 --> Controller Class Initialized
DEBUG - 2015-02-04 20:18:06 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 20:18:06 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 20:18:06 --> Model Class Initialized
DEBUG - 2015-02-04 20:18:06 --> Model Class Initialized
DEBUG - 2015-02-04 21:24:59 --> Config Class Initialized
DEBUG - 2015-02-04 21:24:59 --> Hooks Class Initialized
DEBUG - 2015-02-04 21:24:59 --> Utf8 Class Initialized
DEBUG - 2015-02-04 21:24:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 21:24:59 --> URI Class Initialized
DEBUG - 2015-02-04 21:24:59 --> Router Class Initialized
DEBUG - 2015-02-04 21:24:59 --> Output Class Initialized
DEBUG - 2015-02-04 21:24:59 --> Security Class Initialized
DEBUG - 2015-02-04 21:24:59 --> Input Class Initialized
DEBUG - 2015-02-04 21:24:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 21:24:59 --> Language Class Initialized
DEBUG - 2015-02-04 21:24:59 --> Loader Class Initialized
DEBUG - 2015-02-04 21:24:59 --> Database Driver Class Initialized
DEBUG - 2015-02-04 21:24:59 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 21:24:59 --> Controller Class Initialized
DEBUG - 2015-02-04 21:24:59 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 21:24:59 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 21:24:59 --> Model Class Initialized
DEBUG - 2015-02-04 21:24:59 --> Model Class Initialized
DEBUG - 2015-02-04 21:24:59 --> File loaded: application/views/email/registration.php
DEBUG - 2015-02-04 21:24:59 --> Email Class Initialized
DEBUG - 2015-02-04 21:25:00 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-04 21:25:12 --> Config Class Initialized
DEBUG - 2015-02-04 21:25:12 --> Hooks Class Initialized
DEBUG - 2015-02-04 21:25:12 --> Utf8 Class Initialized
DEBUG - 2015-02-04 21:25:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 21:25:12 --> URI Class Initialized
DEBUG - 2015-02-04 21:25:12 --> Router Class Initialized
DEBUG - 2015-02-04 21:25:12 --> Output Class Initialized
DEBUG - 2015-02-04 21:25:12 --> Security Class Initialized
DEBUG - 2015-02-04 21:25:12 --> Input Class Initialized
DEBUG - 2015-02-04 21:25:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 21:25:12 --> Language Class Initialized
DEBUG - 2015-02-04 21:25:12 --> Loader Class Initialized
DEBUG - 2015-02-04 21:25:12 --> Database Driver Class Initialized
DEBUG - 2015-02-04 21:25:12 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 21:25:12 --> Controller Class Initialized
DEBUG - 2015-02-04 21:25:12 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 21:25:12 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 21:25:12 --> Model Class Initialized
DEBUG - 2015-02-04 21:25:12 --> Model Class Initialized
DEBUG - 2015-02-04 21:25:22 --> Config Class Initialized
DEBUG - 2015-02-04 21:25:22 --> Hooks Class Initialized
DEBUG - 2015-02-04 21:25:22 --> Utf8 Class Initialized
DEBUG - 2015-02-04 21:25:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 21:25:22 --> URI Class Initialized
DEBUG - 2015-02-04 21:25:22 --> Router Class Initialized
DEBUG - 2015-02-04 21:25:22 --> Output Class Initialized
DEBUG - 2015-02-04 21:25:22 --> Security Class Initialized
DEBUG - 2015-02-04 21:25:22 --> Input Class Initialized
DEBUG - 2015-02-04 21:25:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 21:25:22 --> Language Class Initialized
DEBUG - 2015-02-04 21:25:22 --> Loader Class Initialized
DEBUG - 2015-02-04 21:25:22 --> Database Driver Class Initialized
DEBUG - 2015-02-04 21:25:22 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 21:25:22 --> Controller Class Initialized
DEBUG - 2015-02-04 21:25:22 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 21:25:22 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 21:25:22 --> Model Class Initialized
DEBUG - 2015-02-04 21:25:22 --> Model Class Initialized
DEBUG - 2015-02-04 21:25:36 --> Config Class Initialized
DEBUG - 2015-02-04 21:25:36 --> Hooks Class Initialized
DEBUG - 2015-02-04 21:25:36 --> Utf8 Class Initialized
DEBUG - 2015-02-04 21:25:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 21:25:36 --> URI Class Initialized
DEBUG - 2015-02-04 21:25:36 --> Router Class Initialized
DEBUG - 2015-02-04 21:25:36 --> Output Class Initialized
DEBUG - 2015-02-04 21:25:36 --> Security Class Initialized
DEBUG - 2015-02-04 21:25:36 --> Input Class Initialized
DEBUG - 2015-02-04 21:25:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 21:25:36 --> Language Class Initialized
DEBUG - 2015-02-04 21:25:36 --> Loader Class Initialized
DEBUG - 2015-02-04 21:25:36 --> Database Driver Class Initialized
DEBUG - 2015-02-04 21:25:36 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 21:25:36 --> Controller Class Initialized
DEBUG - 2015-02-04 21:25:36 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 21:25:36 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 21:25:36 --> Model Class Initialized
DEBUG - 2015-02-04 21:25:36 --> Model Class Initialized
DEBUG - 2015-02-04 21:26:43 --> Config Class Initialized
DEBUG - 2015-02-04 21:26:43 --> Hooks Class Initialized
DEBUG - 2015-02-04 21:26:43 --> Utf8 Class Initialized
DEBUG - 2015-02-04 21:26:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 21:26:43 --> URI Class Initialized
DEBUG - 2015-02-04 21:26:43 --> Router Class Initialized
DEBUG - 2015-02-04 21:26:43 --> Output Class Initialized
DEBUG - 2015-02-04 21:26:43 --> Security Class Initialized
DEBUG - 2015-02-04 21:26:43 --> Input Class Initialized
DEBUG - 2015-02-04 21:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 21:26:43 --> Language Class Initialized
DEBUG - 2015-02-04 21:26:43 --> Loader Class Initialized
DEBUG - 2015-02-04 21:26:43 --> Database Driver Class Initialized
DEBUG - 2015-02-04 21:26:43 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 21:26:43 --> Controller Class Initialized
DEBUG - 2015-02-04 21:26:43 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 21:26:43 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 21:26:43 --> Model Class Initialized
DEBUG - 2015-02-04 21:26:43 --> Model Class Initialized
DEBUG - 2015-02-04 21:27:18 --> Config Class Initialized
DEBUG - 2015-02-04 21:27:18 --> Hooks Class Initialized
DEBUG - 2015-02-04 21:27:18 --> Utf8 Class Initialized
DEBUG - 2015-02-04 21:27:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 21:27:18 --> URI Class Initialized
DEBUG - 2015-02-04 21:27:18 --> Router Class Initialized
DEBUG - 2015-02-04 21:27:18 --> Output Class Initialized
DEBUG - 2015-02-04 21:27:18 --> Security Class Initialized
DEBUG - 2015-02-04 21:27:18 --> Input Class Initialized
DEBUG - 2015-02-04 21:27:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 21:27:18 --> Language Class Initialized
DEBUG - 2015-02-04 21:27:18 --> Loader Class Initialized
DEBUG - 2015-02-04 21:27:18 --> Database Driver Class Initialized
DEBUG - 2015-02-04 21:27:18 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 21:27:18 --> Controller Class Initialized
DEBUG - 2015-02-04 21:27:18 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 21:27:18 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 21:27:18 --> Model Class Initialized
DEBUG - 2015-02-04 21:27:18 --> Model Class Initialized
ERROR - 2015-02-04 21:27:18 --> Severity: Notice  --> Undefined index: child_id D:\www\thunderbirds\server\application\models\adminusers_model.php 127
ERROR - 2015-02-04 21:27:18 --> Severity: Notice  --> Undefined index: missing D:\www\thunderbirds\server\application\controllers\api\adminusers.php 176
DEBUG - 2015-02-04 21:27:36 --> Config Class Initialized
DEBUG - 2015-02-04 21:27:36 --> Hooks Class Initialized
DEBUG - 2015-02-04 21:27:36 --> Utf8 Class Initialized
DEBUG - 2015-02-04 21:27:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 21:27:36 --> URI Class Initialized
DEBUG - 2015-02-04 21:27:36 --> Router Class Initialized
DEBUG - 2015-02-04 21:27:36 --> Output Class Initialized
DEBUG - 2015-02-04 21:27:36 --> Security Class Initialized
DEBUG - 2015-02-04 21:27:36 --> Input Class Initialized
DEBUG - 2015-02-04 21:27:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 21:27:36 --> Language Class Initialized
DEBUG - 2015-02-04 21:27:36 --> Loader Class Initialized
DEBUG - 2015-02-04 21:27:36 --> Database Driver Class Initialized
DEBUG - 2015-02-04 21:27:36 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 21:27:36 --> Controller Class Initialized
DEBUG - 2015-02-04 21:27:36 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 21:27:36 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 21:27:36 --> Model Class Initialized
DEBUG - 2015-02-04 21:27:36 --> Model Class Initialized
ERROR - 2015-02-04 21:27:36 --> Severity: Notice  --> Undefined index: child_id D:\www\thunderbirds\server\application\models\adminusers_model.php 127
ERROR - 2015-02-04 21:27:36 --> Severity: Notice  --> Undefined index: missing D:\www\thunderbirds\server\application\controllers\api\adminusers.php 176
DEBUG - 2015-02-04 21:27:47 --> Config Class Initialized
DEBUG - 2015-02-04 21:27:47 --> Hooks Class Initialized
DEBUG - 2015-02-04 21:27:47 --> Utf8 Class Initialized
DEBUG - 2015-02-04 21:27:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 21:27:47 --> URI Class Initialized
DEBUG - 2015-02-04 21:27:47 --> Router Class Initialized
DEBUG - 2015-02-04 21:27:47 --> Output Class Initialized
DEBUG - 2015-02-04 21:27:47 --> Security Class Initialized
DEBUG - 2015-02-04 21:27:47 --> Input Class Initialized
DEBUG - 2015-02-04 21:27:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 21:27:47 --> Language Class Initialized
DEBUG - 2015-02-04 21:27:47 --> Loader Class Initialized
DEBUG - 2015-02-04 21:27:47 --> Database Driver Class Initialized
DEBUG - 2015-02-04 21:27:47 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 21:27:47 --> Controller Class Initialized
DEBUG - 2015-02-04 21:27:47 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 21:27:47 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 21:27:47 --> Model Class Initialized
DEBUG - 2015-02-04 21:27:47 --> Model Class Initialized
ERROR - 2015-02-04 21:27:47 --> Severity: Notice  --> Undefined index: child_id D:\www\thunderbirds\server\application\models\adminusers_model.php 127
ERROR - 2015-02-04 21:27:47 --> Severity: Notice  --> Undefined index: missing D:\www\thunderbirds\server\application\controllers\api\adminusers.php 176
DEBUG - 2015-02-04 21:28:01 --> Config Class Initialized
DEBUG - 2015-02-04 21:28:01 --> Hooks Class Initialized
DEBUG - 2015-02-04 21:28:01 --> Utf8 Class Initialized
DEBUG - 2015-02-04 21:28:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 21:28:01 --> URI Class Initialized
DEBUG - 2015-02-04 21:28:01 --> Router Class Initialized
DEBUG - 2015-02-04 21:28:01 --> Output Class Initialized
DEBUG - 2015-02-04 21:28:01 --> Security Class Initialized
DEBUG - 2015-02-04 21:28:01 --> Input Class Initialized
DEBUG - 2015-02-04 21:28:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 21:28:01 --> Language Class Initialized
DEBUG - 2015-02-04 21:28:01 --> Loader Class Initialized
DEBUG - 2015-02-04 21:28:01 --> Database Driver Class Initialized
DEBUG - 2015-02-04 21:28:01 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 21:28:01 --> Controller Class Initialized
DEBUG - 2015-02-04 21:28:01 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 21:28:01 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 21:28:01 --> Model Class Initialized
DEBUG - 2015-02-04 21:28:01 --> Model Class Initialized
DEBUG - 2015-02-04 21:28:14 --> Config Class Initialized
DEBUG - 2015-02-04 21:28:14 --> Hooks Class Initialized
DEBUG - 2015-02-04 21:28:14 --> Utf8 Class Initialized
DEBUG - 2015-02-04 21:28:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 21:28:14 --> URI Class Initialized
DEBUG - 2015-02-04 21:28:14 --> Router Class Initialized
DEBUG - 2015-02-04 21:28:14 --> Output Class Initialized
DEBUG - 2015-02-04 21:28:14 --> Security Class Initialized
DEBUG - 2015-02-04 21:28:14 --> Input Class Initialized
DEBUG - 2015-02-04 21:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 21:28:14 --> Language Class Initialized
DEBUG - 2015-02-04 21:28:14 --> Loader Class Initialized
DEBUG - 2015-02-04 21:28:14 --> Database Driver Class Initialized
DEBUG - 2015-02-04 21:28:14 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 21:28:14 --> Controller Class Initialized
DEBUG - 2015-02-04 21:28:14 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 21:28:14 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 21:28:14 --> Model Class Initialized
DEBUG - 2015-02-04 21:28:14 --> Model Class Initialized
DEBUG - 2015-02-04 21:28:38 --> Config Class Initialized
DEBUG - 2015-02-04 21:28:38 --> Hooks Class Initialized
DEBUG - 2015-02-04 21:28:38 --> Utf8 Class Initialized
DEBUG - 2015-02-04 21:28:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 21:28:38 --> URI Class Initialized
DEBUG - 2015-02-04 21:28:38 --> Router Class Initialized
DEBUG - 2015-02-04 21:28:38 --> Output Class Initialized
DEBUG - 2015-02-04 21:28:38 --> Security Class Initialized
DEBUG - 2015-02-04 21:28:38 --> Input Class Initialized
DEBUG - 2015-02-04 21:28:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 21:28:38 --> Language Class Initialized
DEBUG - 2015-02-04 21:28:38 --> Loader Class Initialized
DEBUG - 2015-02-04 21:28:38 --> Database Driver Class Initialized
DEBUG - 2015-02-04 21:28:38 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 21:28:38 --> Controller Class Initialized
DEBUG - 2015-02-04 21:28:38 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 21:28:38 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 21:28:38 --> Model Class Initialized
DEBUG - 2015-02-04 21:28:38 --> Model Class Initialized
ERROR - 2015-02-04 21:28:38 --> Severity: Notice  --> Undefined index: child_id D:\www\thunderbirds\server\application\models\adminusers_model.php 127
ERROR - 2015-02-04 21:28:38 --> Severity: Notice  --> Undefined index: missing D:\www\thunderbirds\server\application\controllers\api\adminusers.php 176
DEBUG - 2015-02-04 21:29:30 --> Config Class Initialized
DEBUG - 2015-02-04 21:29:30 --> Hooks Class Initialized
DEBUG - 2015-02-04 21:29:30 --> Utf8 Class Initialized
DEBUG - 2015-02-04 21:29:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 21:29:30 --> URI Class Initialized
DEBUG - 2015-02-04 21:29:30 --> Router Class Initialized
DEBUG - 2015-02-04 21:29:30 --> Output Class Initialized
DEBUG - 2015-02-04 21:29:30 --> Security Class Initialized
DEBUG - 2015-02-04 21:29:30 --> Input Class Initialized
DEBUG - 2015-02-04 21:29:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 21:29:30 --> Language Class Initialized
DEBUG - 2015-02-04 21:29:30 --> Loader Class Initialized
DEBUG - 2015-02-04 21:29:30 --> Database Driver Class Initialized
DEBUG - 2015-02-04 21:29:30 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 21:29:30 --> Controller Class Initialized
DEBUG - 2015-02-04 21:29:30 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 21:29:30 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 21:29:30 --> Model Class Initialized
DEBUG - 2015-02-04 21:29:30 --> Model Class Initialized
ERROR - 2015-02-04 21:29:30 --> Severity: Notice  --> Undefined index: child_id D:\www\thunderbirds\server\application\models\adminusers_model.php 127
ERROR - 2015-02-04 21:29:30 --> Severity: Notice  --> Undefined index: missing D:\www\thunderbirds\server\application\controllers\api\adminusers.php 176
DEBUG - 2015-02-04 21:29:38 --> Config Class Initialized
DEBUG - 2015-02-04 21:29:38 --> Hooks Class Initialized
DEBUG - 2015-02-04 21:29:38 --> Utf8 Class Initialized
DEBUG - 2015-02-04 21:29:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 21:29:38 --> URI Class Initialized
DEBUG - 2015-02-04 21:29:38 --> Router Class Initialized
DEBUG - 2015-02-04 21:29:38 --> Output Class Initialized
DEBUG - 2015-02-04 21:29:38 --> Security Class Initialized
DEBUG - 2015-02-04 21:29:38 --> Input Class Initialized
DEBUG - 2015-02-04 21:29:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 21:29:38 --> Language Class Initialized
DEBUG - 2015-02-04 21:29:38 --> Loader Class Initialized
DEBUG - 2015-02-04 21:29:38 --> Database Driver Class Initialized
DEBUG - 2015-02-04 21:29:38 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 21:29:38 --> Controller Class Initialized
DEBUG - 2015-02-04 21:29:38 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 21:29:38 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 21:29:38 --> Model Class Initialized
DEBUG - 2015-02-04 21:29:38 --> Model Class Initialized
DEBUG - 2015-02-04 21:29:57 --> Config Class Initialized
DEBUG - 2015-02-04 21:29:57 --> Hooks Class Initialized
DEBUG - 2015-02-04 21:29:57 --> Utf8 Class Initialized
DEBUG - 2015-02-04 21:29:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 21:29:57 --> URI Class Initialized
DEBUG - 2015-02-04 21:29:57 --> Router Class Initialized
DEBUG - 2015-02-04 21:29:57 --> Output Class Initialized
DEBUG - 2015-02-04 21:29:57 --> Security Class Initialized
DEBUG - 2015-02-04 21:29:57 --> Input Class Initialized
DEBUG - 2015-02-04 21:29:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 21:29:57 --> Language Class Initialized
DEBUG - 2015-02-04 21:29:57 --> Loader Class Initialized
DEBUG - 2015-02-04 21:29:57 --> Database Driver Class Initialized
DEBUG - 2015-02-04 21:29:57 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 21:29:57 --> Controller Class Initialized
DEBUG - 2015-02-04 21:29:57 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 21:29:57 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 21:29:57 --> Model Class Initialized
DEBUG - 2015-02-04 21:29:57 --> Model Class Initialized
ERROR - 2015-02-04 21:29:57 --> Severity: Notice  --> Undefined index: child_id D:\www\thunderbirds\server\application\models\adminusers_model.php 127
ERROR - 2015-02-04 21:29:57 --> Severity: Notice  --> Undefined index: missing D:\www\thunderbirds\server\application\controllers\api\adminusers.php 176
DEBUG - 2015-02-04 21:30:58 --> Config Class Initialized
DEBUG - 2015-02-04 21:30:58 --> Hooks Class Initialized
DEBUG - 2015-02-04 21:30:58 --> Utf8 Class Initialized
DEBUG - 2015-02-04 21:30:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 21:30:58 --> URI Class Initialized
DEBUG - 2015-02-04 21:30:58 --> Router Class Initialized
DEBUG - 2015-02-04 21:30:58 --> Output Class Initialized
DEBUG - 2015-02-04 21:30:58 --> Security Class Initialized
DEBUG - 2015-02-04 21:30:58 --> Input Class Initialized
DEBUG - 2015-02-04 21:30:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-02-04 21:30:58 --> Language Class Initialized
DEBUG - 2015-02-04 21:30:58 --> Loader Class Initialized
DEBUG - 2015-02-04 21:30:58 --> Database Driver Class Initialized
DEBUG - 2015-02-04 21:30:58 --> XML-RPC Class Initialized
DEBUG - 2015-02-04 21:30:58 --> Controller Class Initialized
DEBUG - 2015-02-04 21:30:58 --> Config file loaded: application/config/rest.php
DEBUG - 2015-02-04 21:30:58 --> Helper loaded: inflector_helper
DEBUG - 2015-02-04 21:30:58 --> Model Class Initialized
DEBUG - 2015-02-04 21:30:58 --> Model Class Initialized
