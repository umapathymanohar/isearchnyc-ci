<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-12-19 06:27:17 --> Config Class Initialized
DEBUG - 2014-12-19 06:27:17 --> Hooks Class Initialized
DEBUG - 2014-12-19 06:27:17 --> Utf8 Class Initialized
DEBUG - 2014-12-19 06:27:17 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 06:27:17 --> URI Class Initialized
DEBUG - 2014-12-19 06:27:17 --> Router Class Initialized
DEBUG - 2014-12-19 06:27:17 --> Output Class Initialized
DEBUG - 2014-12-19 06:27:17 --> Security Class Initialized
DEBUG - 2014-12-19 06:27:17 --> Input Class Initialized
DEBUG - 2014-12-19 06:27:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 06:27:17 --> Language Class Initialized
DEBUG - 2014-12-19 06:27:17 --> Loader Class Initialized
DEBUG - 2014-12-19 06:27:17 --> Database Driver Class Initialized
ERROR - 2014-12-19 06:27:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 06:27:17 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 06:27:17 --> Controller Class Initialized
DEBUG - 2014-12-19 06:27:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 06:27:17 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 06:27:19 --> Model Class Initialized
DEBUG - 2014-12-19 06:27:19 --> Model Class Initialized
DEBUG - 2014-12-19 06:27:23 --> Config Class Initialized
DEBUG - 2014-12-19 06:27:23 --> Hooks Class Initialized
DEBUG - 2014-12-19 06:27:23 --> Utf8 Class Initialized
DEBUG - 2014-12-19 06:27:23 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 06:27:23 --> URI Class Initialized
DEBUG - 2014-12-19 06:27:24 --> Router Class Initialized
DEBUG - 2014-12-19 06:27:24 --> Output Class Initialized
DEBUG - 2014-12-19 06:27:24 --> Security Class Initialized
DEBUG - 2014-12-19 06:27:24 --> Input Class Initialized
DEBUG - 2014-12-19 06:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 06:27:24 --> Language Class Initialized
DEBUG - 2014-12-19 06:27:24 --> Loader Class Initialized
DEBUG - 2014-12-19 06:27:24 --> Database Driver Class Initialized
ERROR - 2014-12-19 06:27:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 06:27:24 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 06:27:24 --> Controller Class Initialized
DEBUG - 2014-12-19 06:27:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 06:27:24 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 06:27:25 --> Model Class Initialized
DEBUG - 2014-12-19 06:27:25 --> Model Class Initialized
ERROR - 2014-12-19 06:27:26 --> Severity: Notice  --> Array to string conversion /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/controllers/api/users.php 181
ERROR - 2014-12-19 06:27:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/libraries/REST_Controller.php 485
ERROR - 2014-12-19 06:27:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Common.php 442
ERROR - 2014-12-19 06:27:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/libraries/REST_Controller.php 503
DEBUG - 2014-12-19 06:28:38 --> Config Class Initialized
DEBUG - 2014-12-19 06:28:38 --> Hooks Class Initialized
DEBUG - 2014-12-19 06:28:38 --> Utf8 Class Initialized
DEBUG - 2014-12-19 06:28:38 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 06:28:38 --> URI Class Initialized
DEBUG - 2014-12-19 06:28:38 --> Router Class Initialized
DEBUG - 2014-12-19 06:28:38 --> Output Class Initialized
DEBUG - 2014-12-19 06:28:38 --> Security Class Initialized
DEBUG - 2014-12-19 06:28:38 --> Input Class Initialized
DEBUG - 2014-12-19 06:28:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 06:28:38 --> Language Class Initialized
DEBUG - 2014-12-19 06:28:38 --> Loader Class Initialized
DEBUG - 2014-12-19 06:28:38 --> Database Driver Class Initialized
ERROR - 2014-12-19 06:28:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 06:28:38 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 06:28:38 --> Controller Class Initialized
DEBUG - 2014-12-19 06:28:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 06:28:38 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 06:28:40 --> Model Class Initialized
DEBUG - 2014-12-19 06:28:40 --> Model Class Initialized
ERROR - 2014-12-19 06:28:40 --> Severity: Notice  --> Array to string conversion /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/controllers/api/users.php 181
ERROR - 2014-12-19 06:28:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/libraries/REST_Controller.php 485
ERROR - 2014-12-19 06:28:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Common.php 442
ERROR - 2014-12-19 06:28:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/libraries/REST_Controller.php 503
DEBUG - 2014-12-19 06:29:13 --> Config Class Initialized
DEBUG - 2014-12-19 06:29:13 --> Hooks Class Initialized
DEBUG - 2014-12-19 06:29:13 --> Utf8 Class Initialized
DEBUG - 2014-12-19 06:29:13 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 06:29:13 --> URI Class Initialized
DEBUG - 2014-12-19 06:29:13 --> Router Class Initialized
DEBUG - 2014-12-19 06:29:13 --> Output Class Initialized
DEBUG - 2014-12-19 06:29:13 --> Security Class Initialized
DEBUG - 2014-12-19 06:29:13 --> Input Class Initialized
DEBUG - 2014-12-19 06:29:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 06:29:13 --> Language Class Initialized
DEBUG - 2014-12-19 06:29:13 --> Loader Class Initialized
DEBUG - 2014-12-19 06:29:13 --> Database Driver Class Initialized
ERROR - 2014-12-19 06:29:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 06:29:13 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 06:29:13 --> Controller Class Initialized
DEBUG - 2014-12-19 06:29:13 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 06:29:13 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 06:29:15 --> Model Class Initialized
DEBUG - 2014-12-19 06:29:15 --> Model Class Initialized
DEBUG - 2014-12-19 06:29:46 --> Config Class Initialized
DEBUG - 2014-12-19 06:29:46 --> Hooks Class Initialized
DEBUG - 2014-12-19 06:29:46 --> Utf8 Class Initialized
DEBUG - 2014-12-19 06:29:46 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 06:29:46 --> URI Class Initialized
DEBUG - 2014-12-19 06:29:46 --> Router Class Initialized
DEBUG - 2014-12-19 06:29:46 --> Output Class Initialized
DEBUG - 2014-12-19 06:29:46 --> Security Class Initialized
DEBUG - 2014-12-19 06:29:46 --> Input Class Initialized
DEBUG - 2014-12-19 06:29:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 06:29:46 --> Language Class Initialized
DEBUG - 2014-12-19 06:29:46 --> Loader Class Initialized
DEBUG - 2014-12-19 06:29:46 --> Database Driver Class Initialized
ERROR - 2014-12-19 06:29:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 06:29:46 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 06:29:46 --> Controller Class Initialized
DEBUG - 2014-12-19 06:29:46 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 06:29:46 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 06:29:48 --> Model Class Initialized
DEBUG - 2014-12-19 06:29:48 --> Model Class Initialized
ERROR - 2014-12-19 06:29:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/controllers/api/users.php:181) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/libraries/REST_Controller.php 485
ERROR - 2014-12-19 06:29:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/controllers/api/users.php:181) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Common.php 442
ERROR - 2014-12-19 06:29:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/controllers/api/users.php:181) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/libraries/REST_Controller.php 503
DEBUG - 2014-12-19 06:30:30 --> Config Class Initialized
DEBUG - 2014-12-19 06:30:30 --> Hooks Class Initialized
DEBUG - 2014-12-19 06:30:30 --> Utf8 Class Initialized
DEBUG - 2014-12-19 06:30:30 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 06:30:30 --> URI Class Initialized
DEBUG - 2014-12-19 06:30:30 --> Router Class Initialized
DEBUG - 2014-12-19 06:30:30 --> Output Class Initialized
DEBUG - 2014-12-19 06:30:30 --> Security Class Initialized
DEBUG - 2014-12-19 06:30:30 --> Input Class Initialized
DEBUG - 2014-12-19 06:30:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 06:30:30 --> Language Class Initialized
DEBUG - 2014-12-19 06:30:30 --> Loader Class Initialized
DEBUG - 2014-12-19 06:30:30 --> Database Driver Class Initialized
ERROR - 2014-12-19 06:30:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 06:30:30 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 06:30:30 --> Controller Class Initialized
DEBUG - 2014-12-19 06:30:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 06:30:30 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 06:30:32 --> Model Class Initialized
DEBUG - 2014-12-19 06:30:32 --> Model Class Initialized
DEBUG - 2014-12-19 06:33:51 --> Config Class Initialized
DEBUG - 2014-12-19 06:33:51 --> Hooks Class Initialized
DEBUG - 2014-12-19 06:33:51 --> Utf8 Class Initialized
DEBUG - 2014-12-19 06:33:51 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 06:33:51 --> URI Class Initialized
DEBUG - 2014-12-19 06:33:51 --> Router Class Initialized
DEBUG - 2014-12-19 06:33:51 --> Output Class Initialized
DEBUG - 2014-12-19 06:33:51 --> Security Class Initialized
DEBUG - 2014-12-19 06:33:51 --> Input Class Initialized
DEBUG - 2014-12-19 06:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 06:33:51 --> Language Class Initialized
DEBUG - 2014-12-19 06:33:51 --> Loader Class Initialized
DEBUG - 2014-12-19 06:33:51 --> Database Driver Class Initialized
ERROR - 2014-12-19 06:33:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 06:33:51 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 06:33:51 --> Controller Class Initialized
DEBUG - 2014-12-19 06:33:51 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 06:33:51 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 06:33:53 --> Model Class Initialized
DEBUG - 2014-12-19 06:33:53 --> Model Class Initialized
DEBUG - 2014-12-19 06:33:59 --> Config Class Initialized
DEBUG - 2014-12-19 06:33:59 --> Hooks Class Initialized
DEBUG - 2014-12-19 06:33:59 --> Utf8 Class Initialized
DEBUG - 2014-12-19 06:33:59 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 06:33:59 --> URI Class Initialized
DEBUG - 2014-12-19 06:33:59 --> Router Class Initialized
DEBUG - 2014-12-19 06:33:59 --> Output Class Initialized
DEBUG - 2014-12-19 06:33:59 --> Security Class Initialized
DEBUG - 2014-12-19 06:33:59 --> Input Class Initialized
DEBUG - 2014-12-19 06:33:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 06:33:59 --> Language Class Initialized
DEBUG - 2014-12-19 06:33:59 --> Loader Class Initialized
DEBUG - 2014-12-19 06:33:59 --> Database Driver Class Initialized
ERROR - 2014-12-19 06:33:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 06:33:59 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 06:33:59 --> Controller Class Initialized
DEBUG - 2014-12-19 06:33:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 06:33:59 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 06:34:01 --> Model Class Initialized
DEBUG - 2014-12-19 06:34:01 --> Model Class Initialized
DEBUG - 2014-12-19 06:34:01 --> Final output sent to browser
DEBUG - 2014-12-19 06:34:01 --> Total execution time: 1.7137
DEBUG - 2014-12-19 06:34:37 --> Config Class Initialized
DEBUG - 2014-12-19 06:34:37 --> Hooks Class Initialized
DEBUG - 2014-12-19 06:34:37 --> Utf8 Class Initialized
DEBUG - 2014-12-19 06:34:37 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 06:34:37 --> URI Class Initialized
DEBUG - 2014-12-19 06:34:37 --> Router Class Initialized
DEBUG - 2014-12-19 06:34:37 --> Output Class Initialized
DEBUG - 2014-12-19 06:34:37 --> Security Class Initialized
DEBUG - 2014-12-19 06:34:37 --> Input Class Initialized
DEBUG - 2014-12-19 06:34:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 06:34:37 --> Language Class Initialized
DEBUG - 2014-12-19 06:34:37 --> Loader Class Initialized
DEBUG - 2014-12-19 06:34:37 --> Database Driver Class Initialized
ERROR - 2014-12-19 06:34:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 06:34:37 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 06:34:37 --> Controller Class Initialized
DEBUG - 2014-12-19 06:34:37 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 06:34:37 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 06:34:39 --> Model Class Initialized
DEBUG - 2014-12-19 06:34:39 --> Model Class Initialized
DEBUG - 2014-12-19 06:37:30 --> Config Class Initialized
DEBUG - 2014-12-19 06:37:30 --> Hooks Class Initialized
DEBUG - 2014-12-19 06:37:30 --> Utf8 Class Initialized
DEBUG - 2014-12-19 06:37:30 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 06:37:30 --> URI Class Initialized
DEBUG - 2014-12-19 06:37:30 --> Router Class Initialized
DEBUG - 2014-12-19 06:37:30 --> Output Class Initialized
DEBUG - 2014-12-19 06:37:30 --> Security Class Initialized
DEBUG - 2014-12-19 06:37:30 --> Input Class Initialized
DEBUG - 2014-12-19 06:37:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 06:37:30 --> Language Class Initialized
DEBUG - 2014-12-19 06:37:30 --> Loader Class Initialized
DEBUG - 2014-12-19 06:37:30 --> Database Driver Class Initialized
ERROR - 2014-12-19 06:37:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 06:37:30 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 06:37:30 --> Controller Class Initialized
DEBUG - 2014-12-19 06:37:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 06:37:30 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 06:37:32 --> Model Class Initialized
DEBUG - 2014-12-19 06:37:32 --> Model Class Initialized
DEBUG - 2014-12-19 06:37:36 --> Config Class Initialized
DEBUG - 2014-12-19 06:37:36 --> Hooks Class Initialized
DEBUG - 2014-12-19 06:37:36 --> Utf8 Class Initialized
DEBUG - 2014-12-19 06:37:36 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 06:37:36 --> URI Class Initialized
DEBUG - 2014-12-19 06:37:36 --> Router Class Initialized
DEBUG - 2014-12-19 06:37:36 --> Output Class Initialized
DEBUG - 2014-12-19 06:37:36 --> Security Class Initialized
DEBUG - 2014-12-19 06:37:36 --> Input Class Initialized
DEBUG - 2014-12-19 06:37:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 06:37:36 --> Language Class Initialized
DEBUG - 2014-12-19 06:37:36 --> Loader Class Initialized
DEBUG - 2014-12-19 06:37:36 --> Database Driver Class Initialized
ERROR - 2014-12-19 06:37:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 06:37:36 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 06:37:36 --> Controller Class Initialized
DEBUG - 2014-12-19 06:37:36 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 06:37:36 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 06:37:37 --> Model Class Initialized
DEBUG - 2014-12-19 06:37:37 --> Model Class Initialized
DEBUG - 2014-12-19 08:20:04 --> Config Class Initialized
DEBUG - 2014-12-19 08:20:04 --> Hooks Class Initialized
DEBUG - 2014-12-19 08:20:04 --> Utf8 Class Initialized
DEBUG - 2014-12-19 08:20:04 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 08:20:04 --> URI Class Initialized
DEBUG - 2014-12-19 08:20:04 --> Router Class Initialized
DEBUG - 2014-12-19 08:20:04 --> Output Class Initialized
DEBUG - 2014-12-19 08:20:04 --> Security Class Initialized
DEBUG - 2014-12-19 08:20:04 --> Input Class Initialized
DEBUG - 2014-12-19 08:20:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 08:20:04 --> Language Class Initialized
DEBUG - 2014-12-19 08:20:04 --> Loader Class Initialized
DEBUG - 2014-12-19 08:20:04 --> Database Driver Class Initialized
ERROR - 2014-12-19 08:20:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 08:20:04 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 08:20:04 --> Controller Class Initialized
DEBUG - 2014-12-19 08:20:04 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 08:20:04 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 08:20:06 --> Model Class Initialized
DEBUG - 2014-12-19 08:20:06 --> Model Class Initialized
DEBUG - 2014-12-19 08:20:13 --> Config Class Initialized
DEBUG - 2014-12-19 08:20:13 --> Hooks Class Initialized
DEBUG - 2014-12-19 08:20:13 --> Utf8 Class Initialized
DEBUG - 2014-12-19 08:20:13 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 08:20:13 --> URI Class Initialized
DEBUG - 2014-12-19 08:20:13 --> Router Class Initialized
DEBUG - 2014-12-19 08:20:13 --> Output Class Initialized
DEBUG - 2014-12-19 08:20:13 --> Security Class Initialized
DEBUG - 2014-12-19 08:20:13 --> Input Class Initialized
DEBUG - 2014-12-19 08:20:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 08:20:13 --> Language Class Initialized
DEBUG - 2014-12-19 08:20:13 --> Loader Class Initialized
DEBUG - 2014-12-19 08:20:13 --> Database Driver Class Initialized
ERROR - 2014-12-19 08:20:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 08:20:13 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 08:20:13 --> Controller Class Initialized
DEBUG - 2014-12-19 08:20:13 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 08:20:13 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 08:20:13 --> Model Class Initialized
DEBUG - 2014-12-19 08:20:13 --> Model Class Initialized
DEBUG - 2014-12-19 08:20:56 --> Config Class Initialized
DEBUG - 2014-12-19 08:20:56 --> Hooks Class Initialized
DEBUG - 2014-12-19 08:20:56 --> Utf8 Class Initialized
DEBUG - 2014-12-19 08:20:56 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 08:20:56 --> URI Class Initialized
DEBUG - 2014-12-19 08:20:56 --> Router Class Initialized
DEBUG - 2014-12-19 08:20:56 --> Output Class Initialized
DEBUG - 2014-12-19 08:20:56 --> Security Class Initialized
DEBUG - 2014-12-19 08:20:56 --> Input Class Initialized
DEBUG - 2014-12-19 08:20:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 08:20:56 --> Language Class Initialized
DEBUG - 2014-12-19 08:20:56 --> Loader Class Initialized
DEBUG - 2014-12-19 08:20:56 --> Database Driver Class Initialized
ERROR - 2014-12-19 08:20:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 08:20:56 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 08:20:56 --> Controller Class Initialized
DEBUG - 2014-12-19 08:20:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 08:20:56 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 08:20:56 --> Model Class Initialized
DEBUG - 2014-12-19 08:20:56 --> Model Class Initialized
DEBUG - 2014-12-19 08:21:45 --> Config Class Initialized
DEBUG - 2014-12-19 08:21:45 --> Hooks Class Initialized
DEBUG - 2014-12-19 08:21:45 --> Utf8 Class Initialized
DEBUG - 2014-12-19 08:21:45 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 08:21:45 --> URI Class Initialized
DEBUG - 2014-12-19 08:21:45 --> Router Class Initialized
DEBUG - 2014-12-19 08:21:45 --> Output Class Initialized
DEBUG - 2014-12-19 08:21:45 --> Security Class Initialized
DEBUG - 2014-12-19 08:21:45 --> Input Class Initialized
DEBUG - 2014-12-19 08:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 08:21:45 --> Language Class Initialized
DEBUG - 2014-12-19 08:21:45 --> Loader Class Initialized
DEBUG - 2014-12-19 08:21:45 --> Database Driver Class Initialized
ERROR - 2014-12-19 08:21:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 08:21:45 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 08:21:45 --> Controller Class Initialized
DEBUG - 2014-12-19 08:21:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 08:21:45 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 08:21:45 --> Model Class Initialized
DEBUG - 2014-12-19 08:21:45 --> Model Class Initialized
DEBUG - 2014-12-19 08:21:55 --> Config Class Initialized
DEBUG - 2014-12-19 08:21:55 --> Hooks Class Initialized
DEBUG - 2014-12-19 08:21:55 --> Utf8 Class Initialized
DEBUG - 2014-12-19 08:21:55 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 08:21:55 --> URI Class Initialized
DEBUG - 2014-12-19 08:21:55 --> Router Class Initialized
DEBUG - 2014-12-19 08:21:55 --> Output Class Initialized
DEBUG - 2014-12-19 08:21:55 --> Security Class Initialized
DEBUG - 2014-12-19 08:21:55 --> Input Class Initialized
DEBUG - 2014-12-19 08:21:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 08:21:55 --> Language Class Initialized
DEBUG - 2014-12-19 08:21:55 --> Loader Class Initialized
DEBUG - 2014-12-19 08:21:55 --> Database Driver Class Initialized
ERROR - 2014-12-19 08:21:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 08:21:55 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 08:21:55 --> Controller Class Initialized
DEBUG - 2014-12-19 08:21:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 08:21:55 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 08:21:55 --> Model Class Initialized
DEBUG - 2014-12-19 08:21:55 --> Model Class Initialized
DEBUG - 2014-12-19 08:22:12 --> Config Class Initialized
DEBUG - 2014-12-19 08:22:12 --> Hooks Class Initialized
DEBUG - 2014-12-19 08:22:12 --> Utf8 Class Initialized
DEBUG - 2014-12-19 08:22:12 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 08:22:12 --> URI Class Initialized
DEBUG - 2014-12-19 08:22:12 --> Router Class Initialized
DEBUG - 2014-12-19 08:22:12 --> Output Class Initialized
DEBUG - 2014-12-19 08:22:12 --> Security Class Initialized
DEBUG - 2014-12-19 08:22:12 --> Input Class Initialized
DEBUG - 2014-12-19 08:22:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 08:22:12 --> Language Class Initialized
DEBUG - 2014-12-19 08:22:12 --> Loader Class Initialized
DEBUG - 2014-12-19 08:22:12 --> Database Driver Class Initialized
ERROR - 2014-12-19 08:22:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 08:22:12 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 08:22:12 --> Controller Class Initialized
DEBUG - 2014-12-19 08:22:12 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 08:22:12 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 08:22:12 --> Model Class Initialized
DEBUG - 2014-12-19 08:22:12 --> Model Class Initialized
DEBUG - 2014-12-19 08:22:45 --> Config Class Initialized
DEBUG - 2014-12-19 08:22:45 --> Hooks Class Initialized
DEBUG - 2014-12-19 08:22:45 --> Utf8 Class Initialized
DEBUG - 2014-12-19 08:22:45 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 08:22:45 --> URI Class Initialized
DEBUG - 2014-12-19 08:22:45 --> Router Class Initialized
DEBUG - 2014-12-19 08:22:45 --> Output Class Initialized
DEBUG - 2014-12-19 08:22:45 --> Security Class Initialized
DEBUG - 2014-12-19 08:22:45 --> Input Class Initialized
DEBUG - 2014-12-19 08:22:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 08:22:45 --> Language Class Initialized
DEBUG - 2014-12-19 08:22:45 --> Loader Class Initialized
DEBUG - 2014-12-19 08:22:45 --> Database Driver Class Initialized
ERROR - 2014-12-19 08:22:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 08:22:45 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 08:22:45 --> Controller Class Initialized
DEBUG - 2014-12-19 08:22:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 08:22:45 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 08:22:45 --> Model Class Initialized
DEBUG - 2014-12-19 08:22:45 --> Model Class Initialized
DEBUG - 2014-12-19 08:22:50 --> Config Class Initialized
DEBUG - 2014-12-19 08:22:50 --> Hooks Class Initialized
DEBUG - 2014-12-19 08:22:50 --> Utf8 Class Initialized
DEBUG - 2014-12-19 08:22:50 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 08:22:50 --> URI Class Initialized
DEBUG - 2014-12-19 08:22:50 --> Router Class Initialized
DEBUG - 2014-12-19 08:22:50 --> Output Class Initialized
DEBUG - 2014-12-19 08:22:50 --> Security Class Initialized
DEBUG - 2014-12-19 08:22:50 --> Input Class Initialized
DEBUG - 2014-12-19 08:22:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 08:22:50 --> Language Class Initialized
DEBUG - 2014-12-19 08:22:50 --> Loader Class Initialized
DEBUG - 2014-12-19 08:22:50 --> Database Driver Class Initialized
ERROR - 2014-12-19 08:22:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 08:22:50 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 08:22:50 --> Controller Class Initialized
DEBUG - 2014-12-19 08:22:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 08:22:50 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 08:22:50 --> Model Class Initialized
DEBUG - 2014-12-19 08:22:50 --> Model Class Initialized
DEBUG - 2014-12-19 08:23:13 --> Config Class Initialized
DEBUG - 2014-12-19 08:23:13 --> Hooks Class Initialized
DEBUG - 2014-12-19 08:23:13 --> Utf8 Class Initialized
DEBUG - 2014-12-19 08:23:13 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 08:23:13 --> URI Class Initialized
DEBUG - 2014-12-19 08:23:13 --> Router Class Initialized
DEBUG - 2014-12-19 08:23:13 --> Output Class Initialized
DEBUG - 2014-12-19 08:23:13 --> Security Class Initialized
DEBUG - 2014-12-19 08:23:13 --> Input Class Initialized
DEBUG - 2014-12-19 08:23:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 08:23:13 --> Language Class Initialized
DEBUG - 2014-12-19 08:23:13 --> Loader Class Initialized
DEBUG - 2014-12-19 08:23:13 --> Database Driver Class Initialized
ERROR - 2014-12-19 08:23:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 08:23:13 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 08:23:13 --> Controller Class Initialized
DEBUG - 2014-12-19 08:23:13 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 08:23:13 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 08:23:13 --> Model Class Initialized
DEBUG - 2014-12-19 08:23:13 --> Model Class Initialized
DEBUG - 2014-12-19 08:31:53 --> Config Class Initialized
DEBUG - 2014-12-19 08:31:53 --> Hooks Class Initialized
DEBUG - 2014-12-19 08:31:53 --> Utf8 Class Initialized
DEBUG - 2014-12-19 08:31:53 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 08:31:53 --> URI Class Initialized
DEBUG - 2014-12-19 08:31:53 --> Router Class Initialized
DEBUG - 2014-12-19 08:31:53 --> Output Class Initialized
DEBUG - 2014-12-19 08:31:53 --> Security Class Initialized
DEBUG - 2014-12-19 08:31:53 --> Input Class Initialized
DEBUG - 2014-12-19 08:31:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 08:31:53 --> Language Class Initialized
DEBUG - 2014-12-19 08:31:53 --> Loader Class Initialized
DEBUG - 2014-12-19 08:31:53 --> Database Driver Class Initialized
ERROR - 2014-12-19 08:31:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 08:31:53 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 08:31:53 --> Controller Class Initialized
DEBUG - 2014-12-19 08:31:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 08:31:53 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 08:31:55 --> Model Class Initialized
DEBUG - 2014-12-19 08:31:55 --> Model Class Initialized
DEBUG - 2014-12-19 08:33:17 --> Config Class Initialized
DEBUG - 2014-12-19 08:33:17 --> Hooks Class Initialized
DEBUG - 2014-12-19 08:33:17 --> Utf8 Class Initialized
DEBUG - 2014-12-19 08:33:17 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 08:33:17 --> URI Class Initialized
DEBUG - 2014-12-19 08:33:17 --> Router Class Initialized
DEBUG - 2014-12-19 08:33:17 --> Output Class Initialized
DEBUG - 2014-12-19 08:33:17 --> Security Class Initialized
DEBUG - 2014-12-19 08:33:17 --> Input Class Initialized
DEBUG - 2014-12-19 08:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 08:33:17 --> Language Class Initialized
DEBUG - 2014-12-19 08:33:17 --> Loader Class Initialized
DEBUG - 2014-12-19 08:33:17 --> Database Driver Class Initialized
ERROR - 2014-12-19 08:33:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 08:33:17 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 08:33:17 --> Controller Class Initialized
DEBUG - 2014-12-19 08:33:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 08:33:17 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 08:33:19 --> Model Class Initialized
DEBUG - 2014-12-19 08:33:19 --> Model Class Initialized
DEBUG - 2014-12-19 08:34:57 --> Config Class Initialized
DEBUG - 2014-12-19 08:34:57 --> Hooks Class Initialized
DEBUG - 2014-12-19 08:34:57 --> Utf8 Class Initialized
DEBUG - 2014-12-19 08:34:57 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 08:34:57 --> URI Class Initialized
DEBUG - 2014-12-19 08:34:57 --> Router Class Initialized
DEBUG - 2014-12-19 08:34:57 --> Output Class Initialized
DEBUG - 2014-12-19 08:34:57 --> Security Class Initialized
DEBUG - 2014-12-19 08:34:57 --> Input Class Initialized
DEBUG - 2014-12-19 08:34:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 08:34:57 --> Language Class Initialized
DEBUG - 2014-12-19 08:34:57 --> Loader Class Initialized
DEBUG - 2014-12-19 08:34:57 --> Database Driver Class Initialized
ERROR - 2014-12-19 08:34:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 08:34:57 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 08:34:57 --> Controller Class Initialized
DEBUG - 2014-12-19 08:34:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 08:34:57 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 08:34:59 --> Model Class Initialized
DEBUG - 2014-12-19 08:34:59 --> Model Class Initialized
DEBUG - 2014-12-19 08:36:49 --> Config Class Initialized
DEBUG - 2014-12-19 08:36:49 --> Hooks Class Initialized
DEBUG - 2014-12-19 08:36:49 --> Utf8 Class Initialized
DEBUG - 2014-12-19 08:36:49 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 08:36:49 --> URI Class Initialized
DEBUG - 2014-12-19 08:36:49 --> Router Class Initialized
DEBUG - 2014-12-19 08:36:49 --> Output Class Initialized
DEBUG - 2014-12-19 08:36:49 --> Security Class Initialized
DEBUG - 2014-12-19 08:36:49 --> Input Class Initialized
DEBUG - 2014-12-19 08:36:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 08:36:49 --> Language Class Initialized
DEBUG - 2014-12-19 08:36:49 --> Loader Class Initialized
DEBUG - 2014-12-19 08:36:49 --> Database Driver Class Initialized
ERROR - 2014-12-19 08:36:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 08:36:49 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 08:36:49 --> Controller Class Initialized
DEBUG - 2014-12-19 08:36:49 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 08:36:49 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 08:36:50 --> Model Class Initialized
DEBUG - 2014-12-19 08:36:50 --> Model Class Initialized
DEBUG - 2014-12-19 09:10:50 --> Config Class Initialized
DEBUG - 2014-12-19 09:10:50 --> Hooks Class Initialized
DEBUG - 2014-12-19 09:10:50 --> Utf8 Class Initialized
DEBUG - 2014-12-19 09:10:50 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 09:10:50 --> URI Class Initialized
DEBUG - 2014-12-19 09:10:50 --> Router Class Initialized
DEBUG - 2014-12-19 09:10:50 --> Output Class Initialized
DEBUG - 2014-12-19 09:10:50 --> Security Class Initialized
DEBUG - 2014-12-19 09:10:50 --> Input Class Initialized
DEBUG - 2014-12-19 09:10:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 09:10:50 --> Language Class Initialized
DEBUG - 2014-12-19 09:10:50 --> Loader Class Initialized
DEBUG - 2014-12-19 09:10:50 --> Database Driver Class Initialized
ERROR - 2014-12-19 09:10:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 09:10:50 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 09:10:50 --> Controller Class Initialized
DEBUG - 2014-12-19 09:10:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 09:10:50 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 09:10:50 --> Model Class Initialized
DEBUG - 2014-12-19 09:10:50 --> Model Class Initialized
DEBUG - 2014-12-19 09:10:55 --> Config Class Initialized
DEBUG - 2014-12-19 09:10:55 --> Hooks Class Initialized
DEBUG - 2014-12-19 09:10:55 --> Utf8 Class Initialized
DEBUG - 2014-12-19 09:10:55 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 09:10:55 --> URI Class Initialized
DEBUG - 2014-12-19 09:10:55 --> Router Class Initialized
DEBUG - 2014-12-19 09:10:55 --> Output Class Initialized
DEBUG - 2014-12-19 09:10:55 --> Security Class Initialized
DEBUG - 2014-12-19 09:10:55 --> Input Class Initialized
DEBUG - 2014-12-19 09:10:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 09:10:55 --> Language Class Initialized
DEBUG - 2014-12-19 09:10:55 --> Loader Class Initialized
DEBUG - 2014-12-19 09:10:55 --> Database Driver Class Initialized
ERROR - 2014-12-19 09:10:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 09:10:55 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 09:10:55 --> Controller Class Initialized
DEBUG - 2014-12-19 09:10:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 09:10:55 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 09:10:55 --> Model Class Initialized
DEBUG - 2014-12-19 09:10:55 --> Model Class Initialized
DEBUG - 2014-12-19 09:19:40 --> Config Class Initialized
DEBUG - 2014-12-19 09:19:40 --> Hooks Class Initialized
DEBUG - 2014-12-19 09:19:40 --> Utf8 Class Initialized
DEBUG - 2014-12-19 09:19:40 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 09:19:40 --> URI Class Initialized
DEBUG - 2014-12-19 09:19:40 --> Router Class Initialized
DEBUG - 2014-12-19 09:19:40 --> Output Class Initialized
DEBUG - 2014-12-19 09:19:40 --> Security Class Initialized
DEBUG - 2014-12-19 09:19:40 --> Input Class Initialized
DEBUG - 2014-12-19 09:19:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 09:19:40 --> Language Class Initialized
DEBUG - 2014-12-19 09:19:40 --> Loader Class Initialized
DEBUG - 2014-12-19 09:19:40 --> Database Driver Class Initialized
ERROR - 2014-12-19 09:19:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 09:19:40 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 09:19:40 --> Controller Class Initialized
DEBUG - 2014-12-19 09:19:40 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 09:19:40 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 09:19:42 --> Model Class Initialized
DEBUG - 2014-12-19 09:19:42 --> Model Class Initialized
DEBUG - 2014-12-19 09:34:47 --> Config Class Initialized
DEBUG - 2014-12-19 09:34:47 --> Hooks Class Initialized
DEBUG - 2014-12-19 09:34:47 --> Utf8 Class Initialized
DEBUG - 2014-12-19 09:34:47 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 09:34:47 --> URI Class Initialized
DEBUG - 2014-12-19 09:34:47 --> Router Class Initialized
DEBUG - 2014-12-19 09:34:47 --> Output Class Initialized
DEBUG - 2014-12-19 09:34:47 --> Security Class Initialized
DEBUG - 2014-12-19 09:34:47 --> Input Class Initialized
DEBUG - 2014-12-19 09:34:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 09:34:47 --> Language Class Initialized
DEBUG - 2014-12-19 09:34:47 --> Loader Class Initialized
DEBUG - 2014-12-19 09:34:47 --> Database Driver Class Initialized
ERROR - 2014-12-19 09:34:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 09:34:47 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 09:34:47 --> Controller Class Initialized
DEBUG - 2014-12-19 09:34:47 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 09:34:47 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 09:34:49 --> Model Class Initialized
DEBUG - 2014-12-19 09:34:49 --> Model Class Initialized
DEBUG - 2014-12-19 09:34:49 --> Email Class Initialized
DEBUG - 2014-12-19 09:34:52 --> Language file loaded: language/english/email_lang.php
DEBUG - 2014-12-19 09:34:56 --> Final output sent to browser
DEBUG - 2014-12-19 09:34:56 --> Total execution time: 8.4658
DEBUG - 2014-12-19 09:36:16 --> Config Class Initialized
DEBUG - 2014-12-19 09:36:16 --> Hooks Class Initialized
DEBUG - 2014-12-19 09:36:16 --> Utf8 Class Initialized
DEBUG - 2014-12-19 09:36:16 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 09:36:16 --> URI Class Initialized
DEBUG - 2014-12-19 09:36:16 --> Router Class Initialized
DEBUG - 2014-12-19 09:36:16 --> Output Class Initialized
DEBUG - 2014-12-19 09:36:16 --> Security Class Initialized
DEBUG - 2014-12-19 09:36:16 --> Input Class Initialized
DEBUG - 2014-12-19 09:36:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 09:36:16 --> Language Class Initialized
DEBUG - 2014-12-19 09:36:16 --> Loader Class Initialized
DEBUG - 2014-12-19 09:36:16 --> Database Driver Class Initialized
ERROR - 2014-12-19 09:36:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 09:36:16 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 09:36:16 --> Controller Class Initialized
DEBUG - 2014-12-19 09:36:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 09:36:16 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 09:36:18 --> Model Class Initialized
DEBUG - 2014-12-19 09:36:18 --> Model Class Initialized
DEBUG - 2014-12-19 09:36:18 --> Email Class Initialized
DEBUG - 2014-12-19 09:36:19 --> Language file loaded: language/english/email_lang.php
DEBUG - 2014-12-19 09:36:23 --> Final output sent to browser
DEBUG - 2014-12-19 09:36:23 --> Total execution time: 7.0124
DEBUG - 2014-12-19 09:45:13 --> Config Class Initialized
DEBUG - 2014-12-19 09:45:13 --> Hooks Class Initialized
DEBUG - 2014-12-19 09:45:13 --> Utf8 Class Initialized
DEBUG - 2014-12-19 09:45:13 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 09:45:13 --> URI Class Initialized
DEBUG - 2014-12-19 09:45:13 --> Router Class Initialized
DEBUG - 2014-12-19 09:45:13 --> Output Class Initialized
DEBUG - 2014-12-19 09:45:13 --> Security Class Initialized
DEBUG - 2014-12-19 09:45:13 --> Input Class Initialized
DEBUG - 2014-12-19 09:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 09:45:13 --> Language Class Initialized
DEBUG - 2014-12-19 09:45:13 --> Loader Class Initialized
DEBUG - 2014-12-19 09:45:13 --> Database Driver Class Initialized
ERROR - 2014-12-19 09:45:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 09:45:13 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 09:45:13 --> Controller Class Initialized
DEBUG - 2014-12-19 09:45:13 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 09:45:13 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 09:45:15 --> Model Class Initialized
DEBUG - 2014-12-19 09:45:15 --> Model Class Initialized
DEBUG - 2014-12-19 09:45:15 --> Email Class Initialized
DEBUG - 2014-12-19 09:45:17 --> Language file loaded: language/english/email_lang.php
ERROR - 2014-12-19 09:45:21 --> Severity: Notice  --> Undefined index: missing /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/controllers/api/users.php 230
ERROR - 2014-12-19 09:45:21 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/libraries/REST_Controller.php 485
ERROR - 2014-12-19 09:45:21 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Common.php 442
ERROR - 2014-12-19 09:45:21 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/libraries/REST_Controller.php 503
DEBUG - 2014-12-19 09:46:45 --> Config Class Initialized
DEBUG - 2014-12-19 09:46:45 --> Hooks Class Initialized
DEBUG - 2014-12-19 09:46:45 --> Utf8 Class Initialized
DEBUG - 2014-12-19 09:46:45 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 09:46:45 --> URI Class Initialized
DEBUG - 2014-12-19 09:46:45 --> Router Class Initialized
DEBUG - 2014-12-19 09:46:45 --> Output Class Initialized
DEBUG - 2014-12-19 09:46:45 --> Security Class Initialized
DEBUG - 2014-12-19 09:46:45 --> Input Class Initialized
DEBUG - 2014-12-19 09:46:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 09:46:45 --> Language Class Initialized
DEBUG - 2014-12-19 09:46:45 --> Loader Class Initialized
DEBUG - 2014-12-19 09:46:45 --> Database Driver Class Initialized
ERROR - 2014-12-19 09:46:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 09:46:45 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 09:46:45 --> Controller Class Initialized
DEBUG - 2014-12-19 09:46:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 09:46:45 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 09:46:47 --> Model Class Initialized
DEBUG - 2014-12-19 09:46:47 --> Model Class Initialized
DEBUG - 2014-12-19 09:46:47 --> Email Class Initialized
DEBUG - 2014-12-19 09:46:49 --> Language file loaded: language/english/email_lang.php
ERROR - 2014-12-19 09:46:52 --> Severity: Notice  --> Undefined index: missing /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/controllers/api/users.php 230
ERROR - 2014-12-19 09:46:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/libraries/REST_Controller.php 485
ERROR - 2014-12-19 09:46:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Common.php 442
ERROR - 2014-12-19 09:46:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/core/Exceptions.php:185) /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/application/libraries/REST_Controller.php 503
DEBUG - 2014-12-19 09:47:46 --> Config Class Initialized
DEBUG - 2014-12-19 09:47:46 --> Hooks Class Initialized
DEBUG - 2014-12-19 09:47:46 --> Utf8 Class Initialized
DEBUG - 2014-12-19 09:47:46 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 09:47:46 --> URI Class Initialized
DEBUG - 2014-12-19 09:47:46 --> Router Class Initialized
DEBUG - 2014-12-19 09:47:46 --> Output Class Initialized
DEBUG - 2014-12-19 09:47:46 --> Security Class Initialized
DEBUG - 2014-12-19 09:47:46 --> Input Class Initialized
DEBUG - 2014-12-19 09:47:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 09:47:46 --> Language Class Initialized
DEBUG - 2014-12-19 09:47:46 --> Loader Class Initialized
DEBUG - 2014-12-19 09:47:46 --> Database Driver Class Initialized
ERROR - 2014-12-19 09:47:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 09:47:46 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 09:47:46 --> Controller Class Initialized
DEBUG - 2014-12-19 09:47:46 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 09:47:46 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 09:47:47 --> Model Class Initialized
DEBUG - 2014-12-19 09:47:47 --> Model Class Initialized
DEBUG - 2014-12-19 09:47:47 --> Email Class Initialized
DEBUG - 2014-12-19 09:47:48 --> Language file loaded: language/english/email_lang.php
DEBUG - 2014-12-19 10:39:59 --> Config Class Initialized
DEBUG - 2014-12-19 10:39:59 --> Hooks Class Initialized
DEBUG - 2014-12-19 10:39:59 --> Utf8 Class Initialized
DEBUG - 2014-12-19 10:39:59 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 10:39:59 --> URI Class Initialized
DEBUG - 2014-12-19 10:39:59 --> Router Class Initialized
DEBUG - 2014-12-19 10:39:59 --> Output Class Initialized
DEBUG - 2014-12-19 10:39:59 --> Security Class Initialized
DEBUG - 2014-12-19 10:39:59 --> Input Class Initialized
DEBUG - 2014-12-19 10:39:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 10:39:59 --> Language Class Initialized
DEBUG - 2014-12-19 10:39:59 --> Loader Class Initialized
DEBUG - 2014-12-19 10:39:59 --> Database Driver Class Initialized
ERROR - 2014-12-19 10:39:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 10:39:59 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 10:39:59 --> Controller Class Initialized
DEBUG - 2014-12-19 10:39:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 10:39:59 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 10:40:01 --> Model Class Initialized
DEBUG - 2014-12-19 10:40:01 --> Model Class Initialized
DEBUG - 2014-12-19 10:40:01 --> Email Class Initialized
DEBUG - 2014-12-19 10:40:03 --> Language file loaded: language/english/email_lang.php
DEBUG - 2014-12-19 10:41:50 --> Config Class Initialized
DEBUG - 2014-12-19 10:41:50 --> Hooks Class Initialized
DEBUG - 2014-12-19 10:41:50 --> Utf8 Class Initialized
DEBUG - 2014-12-19 10:41:50 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 10:41:50 --> URI Class Initialized
DEBUG - 2014-12-19 10:41:50 --> Router Class Initialized
DEBUG - 2014-12-19 10:41:50 --> Output Class Initialized
DEBUG - 2014-12-19 10:41:50 --> Security Class Initialized
DEBUG - 2014-12-19 10:41:50 --> Input Class Initialized
DEBUG - 2014-12-19 10:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 10:41:50 --> Language Class Initialized
DEBUG - 2014-12-19 10:41:50 --> Loader Class Initialized
DEBUG - 2014-12-19 10:41:50 --> Database Driver Class Initialized
ERROR - 2014-12-19 10:41:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 10:41:50 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 10:41:50 --> Controller Class Initialized
DEBUG - 2014-12-19 10:41:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 10:41:50 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 10:41:52 --> Model Class Initialized
DEBUG - 2014-12-19 10:41:52 --> Model Class Initialized
DEBUG - 2014-12-19 10:42:20 --> Config Class Initialized
DEBUG - 2014-12-19 10:42:20 --> Hooks Class Initialized
DEBUG - 2014-12-19 10:42:20 --> Utf8 Class Initialized
DEBUG - 2014-12-19 10:42:20 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 10:42:20 --> URI Class Initialized
DEBUG - 2014-12-19 10:42:20 --> Router Class Initialized
DEBUG - 2014-12-19 10:42:20 --> Output Class Initialized
DEBUG - 2014-12-19 10:42:20 --> Security Class Initialized
DEBUG - 2014-12-19 10:42:20 --> Input Class Initialized
DEBUG - 2014-12-19 10:42:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 10:42:20 --> Language Class Initialized
DEBUG - 2014-12-19 10:42:20 --> Loader Class Initialized
DEBUG - 2014-12-19 10:42:20 --> Database Driver Class Initialized
ERROR - 2014-12-19 10:42:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 10:42:20 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 10:42:20 --> Controller Class Initialized
DEBUG - 2014-12-19 10:42:20 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 10:42:20 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 10:42:22 --> Model Class Initialized
DEBUG - 2014-12-19 10:42:22 --> Model Class Initialized
DEBUG - 2014-12-19 10:43:30 --> Config Class Initialized
DEBUG - 2014-12-19 10:43:30 --> Hooks Class Initialized
DEBUG - 2014-12-19 10:43:30 --> Utf8 Class Initialized
DEBUG - 2014-12-19 10:43:30 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 10:43:30 --> URI Class Initialized
DEBUG - 2014-12-19 10:43:30 --> Router Class Initialized
DEBUG - 2014-12-19 10:43:30 --> Output Class Initialized
DEBUG - 2014-12-19 10:43:30 --> Security Class Initialized
DEBUG - 2014-12-19 10:43:30 --> Input Class Initialized
DEBUG - 2014-12-19 10:43:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 10:43:30 --> Language Class Initialized
DEBUG - 2014-12-19 10:43:30 --> Loader Class Initialized
DEBUG - 2014-12-19 10:43:30 --> Database Driver Class Initialized
ERROR - 2014-12-19 10:43:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 10:43:30 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 10:43:30 --> Controller Class Initialized
DEBUG - 2014-12-19 10:43:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 10:43:30 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 10:43:32 --> Model Class Initialized
DEBUG - 2014-12-19 10:43:32 --> Model Class Initialized
DEBUG - 2014-12-19 10:43:32 --> Email Class Initialized
DEBUG - 2014-12-19 10:43:33 --> Language file loaded: language/english/email_lang.php
DEBUG - 2014-12-19 10:44:07 --> Config Class Initialized
DEBUG - 2014-12-19 10:44:07 --> Hooks Class Initialized
DEBUG - 2014-12-19 10:44:07 --> Utf8 Class Initialized
DEBUG - 2014-12-19 10:44:07 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 10:44:07 --> URI Class Initialized
DEBUG - 2014-12-19 10:44:07 --> Router Class Initialized
DEBUG - 2014-12-19 10:44:07 --> Output Class Initialized
DEBUG - 2014-12-19 10:44:07 --> Security Class Initialized
DEBUG - 2014-12-19 10:44:07 --> Input Class Initialized
DEBUG - 2014-12-19 10:44:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 10:44:07 --> Language Class Initialized
DEBUG - 2014-12-19 10:44:07 --> Loader Class Initialized
DEBUG - 2014-12-19 10:44:07 --> Database Driver Class Initialized
ERROR - 2014-12-19 10:44:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 10:44:07 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 10:44:07 --> Controller Class Initialized
DEBUG - 2014-12-19 10:44:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 10:44:07 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 10:44:08 --> Model Class Initialized
DEBUG - 2014-12-19 10:44:08 --> Model Class Initialized
DEBUG - 2014-12-19 10:44:22 --> Config Class Initialized
DEBUG - 2014-12-19 10:44:22 --> Hooks Class Initialized
DEBUG - 2014-12-19 10:44:22 --> Utf8 Class Initialized
DEBUG - 2014-12-19 10:44:22 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 10:44:22 --> URI Class Initialized
DEBUG - 2014-12-19 10:44:22 --> Router Class Initialized
DEBUG - 2014-12-19 10:44:22 --> Output Class Initialized
DEBUG - 2014-12-19 10:44:22 --> Security Class Initialized
DEBUG - 2014-12-19 10:44:22 --> Input Class Initialized
DEBUG - 2014-12-19 10:44:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 10:44:22 --> Language Class Initialized
DEBUG - 2014-12-19 10:44:22 --> Loader Class Initialized
DEBUG - 2014-12-19 10:44:22 --> Database Driver Class Initialized
ERROR - 2014-12-19 10:44:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 10:44:22 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 10:44:22 --> Controller Class Initialized
DEBUG - 2014-12-19 10:44:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 10:44:22 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 10:44:24 --> Model Class Initialized
DEBUG - 2014-12-19 10:44:24 --> Model Class Initialized
DEBUG - 2014-12-19 10:44:40 --> Config Class Initialized
DEBUG - 2014-12-19 10:44:40 --> Hooks Class Initialized
DEBUG - 2014-12-19 10:44:40 --> Utf8 Class Initialized
DEBUG - 2014-12-19 10:44:40 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 10:44:40 --> URI Class Initialized
DEBUG - 2014-12-19 10:44:40 --> Router Class Initialized
DEBUG - 2014-12-19 10:44:40 --> Output Class Initialized
DEBUG - 2014-12-19 10:44:40 --> Security Class Initialized
DEBUG - 2014-12-19 10:44:40 --> Input Class Initialized
DEBUG - 2014-12-19 10:44:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 10:44:40 --> Language Class Initialized
DEBUG - 2014-12-19 10:44:40 --> Loader Class Initialized
DEBUG - 2014-12-19 10:44:40 --> Database Driver Class Initialized
ERROR - 2014-12-19 10:44:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 10:44:40 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 10:44:40 --> Controller Class Initialized
DEBUG - 2014-12-19 10:44:40 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 10:44:40 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 10:44:42 --> Model Class Initialized
DEBUG - 2014-12-19 10:44:42 --> Model Class Initialized
DEBUG - 2014-12-19 10:44:42 --> Email Class Initialized
DEBUG - 2014-12-19 10:44:43 --> Language file loaded: language/english/email_lang.php
DEBUG - 2014-12-19 10:56:51 --> Config Class Initialized
DEBUG - 2014-12-19 10:56:51 --> Hooks Class Initialized
DEBUG - 2014-12-19 10:56:51 --> Utf8 Class Initialized
DEBUG - 2014-12-19 10:56:51 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 10:56:51 --> URI Class Initialized
DEBUG - 2014-12-19 10:56:51 --> Router Class Initialized
DEBUG - 2014-12-19 10:56:51 --> Output Class Initialized
DEBUG - 2014-12-19 10:56:51 --> Security Class Initialized
DEBUG - 2014-12-19 10:56:51 --> Input Class Initialized
DEBUG - 2014-12-19 10:56:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 10:56:51 --> Language Class Initialized
DEBUG - 2014-12-19 10:56:51 --> Loader Class Initialized
DEBUG - 2014-12-19 10:56:51 --> Database Driver Class Initialized
ERROR - 2014-12-19 10:56:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 10:56:51 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 10:56:51 --> Controller Class Initialized
DEBUG - 2014-12-19 10:56:51 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 10:56:51 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 10:56:53 --> Model Class Initialized
DEBUG - 2014-12-19 10:56:53 --> Model Class Initialized
DEBUG - 2014-12-19 10:56:53 --> Email Class Initialized
DEBUG - 2014-12-19 10:56:54 --> Language file loaded: language/english/email_lang.php
DEBUG - 2014-12-19 10:57:23 --> Config Class Initialized
DEBUG - 2014-12-19 10:57:23 --> Hooks Class Initialized
DEBUG - 2014-12-19 10:57:23 --> Utf8 Class Initialized
DEBUG - 2014-12-19 10:57:23 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 10:57:23 --> URI Class Initialized
DEBUG - 2014-12-19 10:57:23 --> Router Class Initialized
DEBUG - 2014-12-19 10:57:23 --> Output Class Initialized
DEBUG - 2014-12-19 10:57:23 --> Security Class Initialized
DEBUG - 2014-12-19 10:57:23 --> Input Class Initialized
DEBUG - 2014-12-19 10:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 10:57:23 --> Language Class Initialized
DEBUG - 2014-12-19 10:57:23 --> Loader Class Initialized
DEBUG - 2014-12-19 10:57:23 --> Database Driver Class Initialized
ERROR - 2014-12-19 10:57:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 10:57:23 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 10:57:23 --> Controller Class Initialized
DEBUG - 2014-12-19 10:57:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 10:57:23 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 10:57:24 --> Model Class Initialized
DEBUG - 2014-12-19 10:57:24 --> Model Class Initialized
DEBUG - 2014-12-19 10:57:47 --> Config Class Initialized
DEBUG - 2014-12-19 10:57:47 --> Hooks Class Initialized
DEBUG - 2014-12-19 10:57:47 --> Utf8 Class Initialized
DEBUG - 2014-12-19 10:57:47 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 10:57:47 --> URI Class Initialized
DEBUG - 2014-12-19 10:57:47 --> Router Class Initialized
DEBUG - 2014-12-19 10:57:47 --> Output Class Initialized
DEBUG - 2014-12-19 10:57:47 --> Security Class Initialized
DEBUG - 2014-12-19 10:57:47 --> Input Class Initialized
DEBUG - 2014-12-19 10:57:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 10:57:47 --> Language Class Initialized
DEBUG - 2014-12-19 10:57:47 --> Loader Class Initialized
DEBUG - 2014-12-19 10:57:47 --> Database Driver Class Initialized
ERROR - 2014-12-19 10:57:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 10:57:47 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 10:57:47 --> Controller Class Initialized
DEBUG - 2014-12-19 10:57:47 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 10:57:47 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 10:57:49 --> Model Class Initialized
DEBUG - 2014-12-19 10:57:49 --> Model Class Initialized
DEBUG - 2014-12-19 10:58:06 --> Config Class Initialized
DEBUG - 2014-12-19 10:58:06 --> Hooks Class Initialized
DEBUG - 2014-12-19 10:58:06 --> Utf8 Class Initialized
DEBUG - 2014-12-19 10:58:06 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 10:58:06 --> URI Class Initialized
DEBUG - 2014-12-19 10:58:06 --> Router Class Initialized
DEBUG - 2014-12-19 10:58:06 --> Output Class Initialized
DEBUG - 2014-12-19 10:58:06 --> Security Class Initialized
DEBUG - 2014-12-19 10:58:06 --> Input Class Initialized
DEBUG - 2014-12-19 10:58:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 10:58:06 --> Language Class Initialized
DEBUG - 2014-12-19 10:58:06 --> Loader Class Initialized
DEBUG - 2014-12-19 10:58:06 --> Database Driver Class Initialized
ERROR - 2014-12-19 10:58:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 10:58:06 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 10:58:06 --> Controller Class Initialized
DEBUG - 2014-12-19 10:58:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 10:58:06 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 10:58:07 --> Model Class Initialized
DEBUG - 2014-12-19 10:58:07 --> Model Class Initialized
DEBUG - 2014-12-19 10:58:07 --> Email Class Initialized
DEBUG - 2014-12-19 10:58:08 --> Language file loaded: language/english/email_lang.php
DEBUG - 2014-12-19 10:59:19 --> Config Class Initialized
DEBUG - 2014-12-19 10:59:19 --> Hooks Class Initialized
DEBUG - 2014-12-19 10:59:19 --> Utf8 Class Initialized
DEBUG - 2014-12-19 10:59:19 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 10:59:19 --> URI Class Initialized
DEBUG - 2014-12-19 10:59:19 --> Router Class Initialized
DEBUG - 2014-12-19 10:59:19 --> Output Class Initialized
DEBUG - 2014-12-19 10:59:19 --> Security Class Initialized
DEBUG - 2014-12-19 10:59:19 --> Input Class Initialized
DEBUG - 2014-12-19 10:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 10:59:19 --> Language Class Initialized
DEBUG - 2014-12-19 10:59:19 --> Loader Class Initialized
DEBUG - 2014-12-19 10:59:19 --> Database Driver Class Initialized
ERROR - 2014-12-19 10:59:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 10:59:19 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 10:59:19 --> Controller Class Initialized
DEBUG - 2014-12-19 10:59:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 10:59:19 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 10:59:20 --> Model Class Initialized
DEBUG - 2014-12-19 10:59:56 --> Config Class Initialized
DEBUG - 2014-12-19 10:59:56 --> Hooks Class Initialized
DEBUG - 2014-12-19 10:59:56 --> Utf8 Class Initialized
DEBUG - 2014-12-19 10:59:56 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 10:59:56 --> URI Class Initialized
DEBUG - 2014-12-19 10:59:56 --> Router Class Initialized
DEBUG - 2014-12-19 10:59:56 --> Output Class Initialized
DEBUG - 2014-12-19 10:59:56 --> Security Class Initialized
DEBUG - 2014-12-19 10:59:56 --> Input Class Initialized
DEBUG - 2014-12-19 10:59:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 10:59:56 --> Language Class Initialized
DEBUG - 2014-12-19 10:59:56 --> Loader Class Initialized
DEBUG - 2014-12-19 10:59:56 --> Database Driver Class Initialized
ERROR - 2014-12-19 10:59:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 10:59:56 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 10:59:56 --> Controller Class Initialized
DEBUG - 2014-12-19 10:59:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 10:59:56 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 10:59:58 --> Model Class Initialized
DEBUG - 2014-12-19 11:00:05 --> Config Class Initialized
DEBUG - 2014-12-19 11:00:05 --> Hooks Class Initialized
DEBUG - 2014-12-19 11:00:05 --> Utf8 Class Initialized
DEBUG - 2014-12-19 11:00:05 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 11:00:05 --> URI Class Initialized
DEBUG - 2014-12-19 11:00:05 --> Router Class Initialized
DEBUG - 2014-12-19 11:00:05 --> Output Class Initialized
DEBUG - 2014-12-19 11:00:05 --> Security Class Initialized
DEBUG - 2014-12-19 11:00:05 --> Input Class Initialized
DEBUG - 2014-12-19 11:00:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 11:00:05 --> Language Class Initialized
DEBUG - 2014-12-19 11:00:05 --> Loader Class Initialized
DEBUG - 2014-12-19 11:00:05 --> Database Driver Class Initialized
ERROR - 2014-12-19 11:00:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 11:00:05 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 11:00:05 --> Controller Class Initialized
DEBUG - 2014-12-19 11:00:05 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 11:00:05 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 11:00:07 --> Model Class Initialized
DEBUG - 2014-12-19 11:00:15 --> Config Class Initialized
DEBUG - 2014-12-19 11:00:15 --> Hooks Class Initialized
DEBUG - 2014-12-19 11:00:15 --> Utf8 Class Initialized
DEBUG - 2014-12-19 11:00:15 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 11:00:15 --> URI Class Initialized
DEBUG - 2014-12-19 11:00:15 --> Router Class Initialized
DEBUG - 2014-12-19 11:00:15 --> Output Class Initialized
DEBUG - 2014-12-19 11:00:15 --> Security Class Initialized
DEBUG - 2014-12-19 11:00:15 --> Input Class Initialized
DEBUG - 2014-12-19 11:00:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 11:00:15 --> Language Class Initialized
DEBUG - 2014-12-19 11:00:15 --> Loader Class Initialized
DEBUG - 2014-12-19 11:00:15 --> Database Driver Class Initialized
ERROR - 2014-12-19 11:00:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 11:00:15 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 11:00:15 --> Controller Class Initialized
DEBUG - 2014-12-19 11:00:15 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 11:00:15 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 11:00:17 --> Model Class Initialized
DEBUG - 2014-12-19 11:01:33 --> Config Class Initialized
DEBUG - 2014-12-19 11:01:33 --> Hooks Class Initialized
DEBUG - 2014-12-19 11:01:33 --> Utf8 Class Initialized
DEBUG - 2014-12-19 11:01:33 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 11:01:33 --> URI Class Initialized
DEBUG - 2014-12-19 11:01:33 --> Router Class Initialized
DEBUG - 2014-12-19 11:01:33 --> Output Class Initialized
DEBUG - 2014-12-19 11:01:33 --> Security Class Initialized
DEBUG - 2014-12-19 11:01:33 --> Input Class Initialized
DEBUG - 2014-12-19 11:01:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 11:01:33 --> Language Class Initialized
DEBUG - 2014-12-19 11:01:33 --> Loader Class Initialized
DEBUG - 2014-12-19 11:01:33 --> Database Driver Class Initialized
ERROR - 2014-12-19 11:01:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 11:01:33 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 11:01:33 --> Controller Class Initialized
DEBUG - 2014-12-19 11:01:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 11:01:33 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 11:01:35 --> Model Class Initialized
DEBUG - 2014-12-19 11:05:35 --> Config Class Initialized
DEBUG - 2014-12-19 11:05:35 --> Hooks Class Initialized
DEBUG - 2014-12-19 11:05:35 --> Utf8 Class Initialized
DEBUG - 2014-12-19 11:05:35 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 11:05:35 --> URI Class Initialized
DEBUG - 2014-12-19 11:05:35 --> Router Class Initialized
DEBUG - 2014-12-19 11:05:35 --> Output Class Initialized
DEBUG - 2014-12-19 11:05:35 --> Security Class Initialized
DEBUG - 2014-12-19 11:05:35 --> Input Class Initialized
DEBUG - 2014-12-19 11:05:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 11:05:35 --> Language Class Initialized
DEBUG - 2014-12-19 11:05:35 --> Loader Class Initialized
DEBUG - 2014-12-19 11:05:35 --> Database Driver Class Initialized
ERROR - 2014-12-19 11:05:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 11:05:35 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 11:05:35 --> Controller Class Initialized
DEBUG - 2014-12-19 11:05:35 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 11:05:35 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 11:05:37 --> Model Class Initialized
DEBUG - 2014-12-19 11:06:23 --> Config Class Initialized
DEBUG - 2014-12-19 11:06:23 --> Hooks Class Initialized
DEBUG - 2014-12-19 11:06:23 --> Utf8 Class Initialized
DEBUG - 2014-12-19 11:06:23 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 11:06:23 --> URI Class Initialized
DEBUG - 2014-12-19 11:06:23 --> Router Class Initialized
DEBUG - 2014-12-19 11:06:23 --> Output Class Initialized
DEBUG - 2014-12-19 11:06:23 --> Security Class Initialized
DEBUG - 2014-12-19 11:06:23 --> Input Class Initialized
DEBUG - 2014-12-19 11:06:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 11:06:23 --> Language Class Initialized
DEBUG - 2014-12-19 11:06:23 --> Loader Class Initialized
DEBUG - 2014-12-19 11:06:23 --> Database Driver Class Initialized
ERROR - 2014-12-19 11:06:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 11:06:23 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 11:06:23 --> Controller Class Initialized
DEBUG - 2014-12-19 11:06:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 11:06:23 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 11:06:25 --> Model Class Initialized
DEBUG - 2014-12-19 11:06:25 --> Model Class Initialized
DEBUG - 2014-12-19 11:14:06 --> Config Class Initialized
DEBUG - 2014-12-19 11:14:07 --> Hooks Class Initialized
DEBUG - 2014-12-19 11:14:07 --> Utf8 Class Initialized
DEBUG - 2014-12-19 11:14:07 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 11:14:07 --> URI Class Initialized
DEBUG - 2014-12-19 11:14:07 --> Router Class Initialized
DEBUG - 2014-12-19 11:14:07 --> Output Class Initialized
DEBUG - 2014-12-19 11:14:07 --> Security Class Initialized
DEBUG - 2014-12-19 11:14:07 --> Input Class Initialized
DEBUG - 2014-12-19 11:14:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 11:14:07 --> Language Class Initialized
DEBUG - 2014-12-19 11:14:07 --> Loader Class Initialized
DEBUG - 2014-12-19 11:14:07 --> Database Driver Class Initialized
ERROR - 2014-12-19 11:14:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 11:14:07 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 11:14:07 --> Controller Class Initialized
DEBUG - 2014-12-19 11:14:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 11:14:07 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 11:14:08 --> Model Class Initialized
DEBUG - 2014-12-19 11:14:08 --> Model Class Initialized
DEBUG - 2014-12-19 11:14:14 --> Config Class Initialized
DEBUG - 2014-12-19 11:14:14 --> Hooks Class Initialized
DEBUG - 2014-12-19 11:14:14 --> Utf8 Class Initialized
DEBUG - 2014-12-19 11:14:14 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 11:14:14 --> URI Class Initialized
DEBUG - 2014-12-19 11:14:14 --> Router Class Initialized
DEBUG - 2014-12-19 11:14:14 --> Output Class Initialized
DEBUG - 2014-12-19 11:14:14 --> Security Class Initialized
DEBUG - 2014-12-19 11:14:14 --> Input Class Initialized
DEBUG - 2014-12-19 11:14:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 11:14:14 --> Language Class Initialized
DEBUG - 2014-12-19 11:14:14 --> Loader Class Initialized
DEBUG - 2014-12-19 11:14:14 --> Database Driver Class Initialized
ERROR - 2014-12-19 11:14:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 11:14:14 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 11:14:14 --> Controller Class Initialized
DEBUG - 2014-12-19 11:14:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 11:14:14 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 11:14:15 --> Model Class Initialized
DEBUG - 2014-12-19 11:14:15 --> Model Class Initialized
DEBUG - 2014-12-19 11:18:07 --> Config Class Initialized
DEBUG - 2014-12-19 11:18:07 --> Hooks Class Initialized
DEBUG - 2014-12-19 11:18:07 --> Utf8 Class Initialized
DEBUG - 2014-12-19 11:18:07 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 11:18:07 --> URI Class Initialized
DEBUG - 2014-12-19 11:18:07 --> Router Class Initialized
DEBUG - 2014-12-19 11:18:07 --> Output Class Initialized
DEBUG - 2014-12-19 11:18:07 --> Security Class Initialized
DEBUG - 2014-12-19 11:18:07 --> Input Class Initialized
DEBUG - 2014-12-19 11:18:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 11:18:07 --> Language Class Initialized
DEBUG - 2014-12-19 11:18:07 --> Loader Class Initialized
DEBUG - 2014-12-19 11:18:07 --> Database Driver Class Initialized
ERROR - 2014-12-19 11:18:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 11:18:07 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 11:18:07 --> Controller Class Initialized
DEBUG - 2014-12-19 11:18:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 11:18:07 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 11:18:09 --> Model Class Initialized
DEBUG - 2014-12-19 11:18:09 --> Model Class Initialized
DEBUG - 2014-12-19 11:19:55 --> Config Class Initialized
DEBUG - 2014-12-19 11:19:55 --> Hooks Class Initialized
DEBUG - 2014-12-19 11:19:55 --> Utf8 Class Initialized
DEBUG - 2014-12-19 11:19:55 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 11:19:55 --> URI Class Initialized
DEBUG - 2014-12-19 11:19:55 --> Router Class Initialized
DEBUG - 2014-12-19 11:19:55 --> Output Class Initialized
DEBUG - 2014-12-19 11:19:55 --> Security Class Initialized
DEBUG - 2014-12-19 11:19:55 --> Input Class Initialized
DEBUG - 2014-12-19 11:19:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 11:19:55 --> Language Class Initialized
DEBUG - 2014-12-19 11:19:55 --> Loader Class Initialized
DEBUG - 2014-12-19 11:19:55 --> Database Driver Class Initialized
ERROR - 2014-12-19 11:19:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 11:19:55 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 11:19:55 --> Controller Class Initialized
DEBUG - 2014-12-19 11:19:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 11:19:55 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 11:19:56 --> Model Class Initialized
DEBUG - 2014-12-19 11:19:56 --> Model Class Initialized
DEBUG - 2014-12-19 13:35:34 --> Config Class Initialized
DEBUG - 2014-12-19 13:35:34 --> Hooks Class Initialized
DEBUG - 2014-12-19 13:35:34 --> Utf8 Class Initialized
DEBUG - 2014-12-19 13:35:34 --> UTF-8 Support Enabled
DEBUG - 2014-12-19 13:35:34 --> URI Class Initialized
DEBUG - 2014-12-19 13:35:34 --> Router Class Initialized
DEBUG - 2014-12-19 13:35:34 --> Output Class Initialized
DEBUG - 2014-12-19 13:35:34 --> Security Class Initialized
DEBUG - 2014-12-19 13:35:34 --> Input Class Initialized
DEBUG - 2014-12-19 13:35:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-19 13:35:34 --> Language Class Initialized
DEBUG - 2014-12-19 13:35:34 --> Loader Class Initialized
DEBUG - 2014-12-19 13:35:34 --> Database Driver Class Initialized
ERROR - 2014-12-19 13:35:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-19 13:35:35 --> XML-RPC Class Initialized
DEBUG - 2014-12-19 13:35:35 --> Controller Class Initialized
DEBUG - 2014-12-19 13:35:35 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-19 13:35:35 --> Helper loaded: inflector_helper
DEBUG - 2014-12-19 13:35:35 --> Model Class Initialized
DEBUG - 2014-12-19 13:35:35 --> Model Class Initialized
