<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-12-20 05:46:27 --> Config Class Initialized
DEBUG - 2014-12-20 05:46:27 --> Hooks Class Initialized
DEBUG - 2014-12-20 05:46:27 --> Utf8 Class Initialized
DEBUG - 2014-12-20 05:46:27 --> UTF-8 Support Enabled
DEBUG - 2014-12-20 05:46:27 --> URI Class Initialized
DEBUG - 2014-12-20 05:46:27 --> Router Class Initialized
DEBUG - 2014-12-20 05:46:27 --> Output Class Initialized
DEBUG - 2014-12-20 05:46:27 --> Security Class Initialized
DEBUG - 2014-12-20 05:46:27 --> Input Class Initialized
DEBUG - 2014-12-20 05:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-20 05:46:27 --> Language Class Initialized
DEBUG - 2014-12-20 05:46:27 --> Loader Class Initialized
DEBUG - 2014-12-20 05:46:27 --> Database Driver Class Initialized
ERROR - 2014-12-20 05:46:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-20 05:46:27 --> XML-RPC Class Initialized
DEBUG - 2014-12-20 05:46:27 --> Controller Class Initialized
DEBUG - 2014-12-20 05:46:27 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-20 05:46:27 --> Helper loaded: inflector_helper
DEBUG - 2014-12-20 05:46:29 --> Model Class Initialized
DEBUG - 2014-12-20 05:46:29 --> Model Class Initialized
DEBUG - 2014-12-20 05:46:42 --> Config Class Initialized
DEBUG - 2014-12-20 05:46:42 --> Hooks Class Initialized
DEBUG - 2014-12-20 05:46:42 --> Utf8 Class Initialized
DEBUG - 2014-12-20 05:46:42 --> UTF-8 Support Enabled
DEBUG - 2014-12-20 05:46:42 --> URI Class Initialized
DEBUG - 2014-12-20 05:46:42 --> Router Class Initialized
DEBUG - 2014-12-20 05:46:42 --> Output Class Initialized
DEBUG - 2014-12-20 05:46:42 --> Security Class Initialized
DEBUG - 2014-12-20 05:46:42 --> Input Class Initialized
DEBUG - 2014-12-20 05:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-20 05:46:42 --> Language Class Initialized
DEBUG - 2014-12-20 05:46:42 --> Loader Class Initialized
DEBUG - 2014-12-20 05:46:42 --> Database Driver Class Initialized
ERROR - 2014-12-20 05:46:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-20 05:46:42 --> XML-RPC Class Initialized
DEBUG - 2014-12-20 05:46:42 --> Controller Class Initialized
DEBUG - 2014-12-20 05:46:42 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-20 05:46:42 --> Helper loaded: inflector_helper
DEBUG - 2014-12-20 05:46:44 --> Model Class Initialized
DEBUG - 2014-12-20 05:46:44 --> Model Class Initialized
DEBUG - 2014-12-20 05:46:49 --> Config Class Initialized
DEBUG - 2014-12-20 05:46:49 --> Hooks Class Initialized
DEBUG - 2014-12-20 05:46:49 --> Utf8 Class Initialized
DEBUG - 2014-12-20 05:46:49 --> UTF-8 Support Enabled
DEBUG - 2014-12-20 05:46:49 --> URI Class Initialized
DEBUG - 2014-12-20 05:46:49 --> Router Class Initialized
DEBUG - 2014-12-20 05:46:49 --> Output Class Initialized
DEBUG - 2014-12-20 05:46:49 --> Security Class Initialized
DEBUG - 2014-12-20 05:46:49 --> Input Class Initialized
DEBUG - 2014-12-20 05:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-20 05:46:49 --> Language Class Initialized
DEBUG - 2014-12-20 05:46:49 --> Loader Class Initialized
DEBUG - 2014-12-20 05:46:49 --> Database Driver Class Initialized
ERROR - 2014-12-20 05:46:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-20 05:46:49 --> XML-RPC Class Initialized
DEBUG - 2014-12-20 05:46:49 --> Controller Class Initialized
DEBUG - 2014-12-20 05:46:49 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-20 05:46:49 --> Helper loaded: inflector_helper
DEBUG - 2014-12-20 05:46:51 --> Model Class Initialized
DEBUG - 2014-12-20 05:46:51 --> Model Class Initialized
DEBUG - 2014-12-20 05:47:34 --> Config Class Initialized
DEBUG - 2014-12-20 05:47:34 --> Hooks Class Initialized
DEBUG - 2014-12-20 05:47:34 --> Utf8 Class Initialized
DEBUG - 2014-12-20 05:47:34 --> UTF-8 Support Enabled
DEBUG - 2014-12-20 05:47:34 --> URI Class Initialized
DEBUG - 2014-12-20 05:47:34 --> Router Class Initialized
DEBUG - 2014-12-20 05:47:34 --> Output Class Initialized
DEBUG - 2014-12-20 05:47:34 --> Security Class Initialized
DEBUG - 2014-12-20 05:47:34 --> Input Class Initialized
DEBUG - 2014-12-20 05:47:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-20 05:47:34 --> Language Class Initialized
DEBUG - 2014-12-20 05:47:34 --> Loader Class Initialized
DEBUG - 2014-12-20 05:47:34 --> Database Driver Class Initialized
ERROR - 2014-12-20 05:47:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Volumes/Data/www/thunderbirds/thunderbirds-hub-site/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-12-20 05:47:34 --> XML-RPC Class Initialized
DEBUG - 2014-12-20 05:47:34 --> Controller Class Initialized
DEBUG - 2014-12-20 05:47:34 --> Config file loaded: application/config/rest.php
DEBUG - 2014-12-20 05:47:34 --> Helper loaded: inflector_helper
DEBUG - 2014-12-20 05:47:34 --> Model Class Initialized
DEBUG - 2014-12-20 05:47:34 --> Model Class Initialized
