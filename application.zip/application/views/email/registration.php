<table width="100%" cellpadding="10" cellspacing="0" bgcolor="#E5E5E5">
   <tbody>
      <tr>
         <td valign="top" align="center">
            <table width="550" cellpadding="20" cellspacing="0" bgcolor="#FFFFFF">
               <tbody>
                  <tr>
                     <td bgcolor="#FFFFFF" valign="top" style="font-size:12px;color:#000000;line-height:150%;font-family:arial">
                        <p style="width:500px"><span style="padding-top:5px"><a><img src="#" border="0" title="ISearchNYC" alt="ISearchNYC" align="center" style="width:60px" class="CToWUd"></a><span style="font-size:15px;font-weight:bold;font-family:arial;line-height:0%;margin-left:20px">ISearchNYC </span></span><br><br>Hello <strong style="word-break:break-all"><?php echo $first_name .' '. $last_name; ?></strong></p>
                        <br>
                        <p>You have been registered successfully <br>
                        <p>You can click on the <a href="http://isearchnyc.com" target="_blank">Login</a> link to proceed forward.</p>
                        <br>
                        <p>Best Regards,</p>
                        <p>The ISearchNYC Team</p>
                     </td>
                  </tr>
               </tbody>
            </table>
         </td>
      </tr>
   </tbody>
</table>