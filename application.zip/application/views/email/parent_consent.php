<table width="100%" cellpadding="10" cellspacing="0" bgcolor="#E5E5E5">
   <tbody>
      <tr>
         <td valign="top" align="center">
            <table width="550" cellpadding="20" cellspacing="0" bgcolor="#FFFFFF">
               <tbody>
                  <tr>
                     <td bgcolor="#FFFFFF" valign="top" style="font-size:12px;color:#000000;line-height:150%;font-family:arial">
                        <p style="width:500px"><span style="padding-top:5px"><a><img src="http://irhq.com/images/IR_logo.png" border="0" title="Thunderbirds" alt="Thunderbirds" align="center" style="width:60px" class="CToWUd"></a><span style="font-size:15px;font-weight:bold;font-family:arial;line-height:0%;margin-left:20px">THUNDERBIRDS </span></span><br><br>Hello <strong style="word-break:break-all"></strong></p>
                        <br>
                        <p>Your child <?php echo $first_name .' '. $last_name; ?> has registered with us<br>
                        <p> <a href="#" target="_blank">Activate your child</a> </p>
                        <br>
                        <p>Best Regards,</p>
                        <p>The ISearchNYC Team</p>
                     </td>
                  </tr>
               </tbody>
            </table>
         </td>
      </tr>
   </tbody>
</table>